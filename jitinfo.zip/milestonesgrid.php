<?php include_once "staffinfo.php" ?>
<?php

// Create page object
if (!isset($milestones_grid)) $milestones_grid = new cmilestones_grid();

// Page init
$milestones_grid->Page_Init();

// Page main
$milestones_grid->Page_Main();

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$milestones_grid->Page_Render();
?>
<?php if ($milestones->Export == "") { ?>
<script type="text/javascript">

// Form object
var fmilestonesgrid = new ew_Form("fmilestonesgrid", "grid");
fmilestonesgrid.FormKeyCountName = '<?php echo $milestones_grid->FormKeyCountName ?>';

// Validate form
fmilestonesgrid.Validate = function() {
	if (!this.ValidateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.GetForm(), $fobj = $(fobj);
	if ($fobj.find("#a_confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.FormKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = $fobj.find("#a_list").val() == "gridinsert";
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
		var checkrow = (gridinsert) ? !this.EmptyRow(infix) : true;
		if (checkrow) {
			addcnt++;
			elm = this.GetElements("x" + infix + "_projectID");
			if (elm && !ew_CheckInteger(elm.value))
				return this.OnError(elm, "<?php echo ew_JsEncode2($milestones->projectID->FldErrMsg()) ?>");
			elm = this.GetElements("x" + infix + "_MilestoneDate");
			if (elm && !ew_CheckEuroDate(elm.value))
				return this.OnError(elm, "<?php echo ew_JsEncode2($milestones->MilestoneDate->FldErrMsg()) ?>");
			elm = this.GetElements("x" + infix + "_Reserved");
			if (elm && !ew_CheckInteger(elm.value))
				return this.OnError(elm, "<?php echo ew_JsEncode2($milestones->Reserved->FldErrMsg()) ?>");

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
		} // End Grid Add checking
	}
	return true;
}

// Check empty row
fmilestonesgrid.EmptyRow = function(infix) {
	var fobj = this.Form;
	if (ew_ValueChanged(fobj, infix, "projectID", false)) return false;
	if (ew_ValueChanged(fobj, infix, "MilestoneDate", false)) return false;
	if (ew_ValueChanged(fobj, infix, "Description", false)) return false;
	if (ew_ValueChanged(fobj, infix, "Status", false)) return false;
	if (ew_ValueChanged(fobj, infix, "Reserved", false)) return false;
	return true;
}

// Form_CustomValidate event
fmilestonesgrid.Form_CustomValidate = 
 function(fobj) { // DO NOT CHANGE THIS LINE!

 	// Your custom validation code here, return false if invalid. 
 	return true;
 }

// Use JavaScript validation or not
<?php if (EW_CLIENT_VALIDATE) { ?>
fmilestonesgrid.ValidateRequired = true;
<?php } else { ?>
fmilestonesgrid.ValidateRequired = false; 
<?php } ?>

// Dynamic selection lists
fmilestonesgrid.Lists["x_projectID"] = {"LinkField":"x_id","Ajax":true,"AutoFill":false,"DisplayFields":["x_name","","",""],"ParentFields":[],"ChildFields":[],"FilterFields":[],"Options":[],"Template":""};

// Form object for search
</script>
<?php } ?>
<?php
if ($milestones->CurrentAction == "gridadd") {
	if ($milestones->CurrentMode == "copy") {
		$bSelectLimit = $milestones_grid->UseSelectLimit;
		if ($bSelectLimit) {
			$milestones_grid->TotalRecs = $milestones->SelectRecordCount();
			$milestones_grid->Recordset = $milestones_grid->LoadRecordset($milestones_grid->StartRec-1, $milestones_grid->DisplayRecs);
		} else {
			if ($milestones_grid->Recordset = $milestones_grid->LoadRecordset())
				$milestones_grid->TotalRecs = $milestones_grid->Recordset->RecordCount();
		}
		$milestones_grid->StartRec = 1;
		$milestones_grid->DisplayRecs = $milestones_grid->TotalRecs;
	} else {
		$milestones->CurrentFilter = "0=1";
		$milestones_grid->StartRec = 1;
		$milestones_grid->DisplayRecs = $milestones->GridAddRowCount;
	}
	$milestones_grid->TotalRecs = $milestones_grid->DisplayRecs;
	$milestones_grid->StopRec = $milestones_grid->DisplayRecs;
} else {
	$bSelectLimit = $milestones_grid->UseSelectLimit;
	if ($bSelectLimit) {
		if ($milestones_grid->TotalRecs <= 0)
			$milestones_grid->TotalRecs = $milestones->SelectRecordCount();
	} else {
		if (!$milestones_grid->Recordset && ($milestones_grid->Recordset = $milestones_grid->LoadRecordset()))
			$milestones_grid->TotalRecs = $milestones_grid->Recordset->RecordCount();
	}
	$milestones_grid->StartRec = 1;
	$milestones_grid->DisplayRecs = $milestones_grid->TotalRecs; // Display all records
	if ($bSelectLimit)
		$milestones_grid->Recordset = $milestones_grid->LoadRecordset($milestones_grid->StartRec-1, $milestones_grid->DisplayRecs);

	// Set no record found message
	if ($milestones->CurrentAction == "" && $milestones_grid->TotalRecs == 0) {
		if (!$Security->CanList())
			$milestones_grid->setWarningMessage(ew_DeniedMsg());
		if ($milestones_grid->SearchWhere == "0=101")
			$milestones_grid->setWarningMessage($Language->Phrase("EnterSearchCriteria"));
		else
			$milestones_grid->setWarningMessage($Language->Phrase("NoRecord"));
	}
}
$milestones_grid->RenderOtherOptions();
?>
<?php $milestones_grid->ShowPageHeader(); ?>
<?php
$milestones_grid->ShowMessage();
?>
<?php if ($milestones_grid->TotalRecs > 0 || $milestones->CurrentAction <> "") { ?>
<div class="panel panel-default ewGrid">
<div id="fmilestonesgrid" class="ewForm form-inline">
<?php if ($milestones_grid->ShowOtherOptions) { ?>
<div class="panel-heading ewGridUpperPanel">
<?php
	foreach ($milestones_grid->OtherOptions as &$option)
		$option->Render("body");
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<div id="gmp_milestones" class="<?php if (ew_IsResponsiveLayout()) { echo "table-responsive "; } ?>ewGridMiddlePanel">
<table id="tbl_milestonesgrid" class="table ewTable">
<?php echo $milestones->TableCustomInnerHtml ?>
<thead><!-- Table header -->
	<tr class="ewTableHeader">
<?php

// Header row
$milestones_grid->RowType = EW_ROWTYPE_HEADER;

// Render list options
$milestones_grid->RenderListOptions();

// Render list options (header, left)
$milestones_grid->ListOptions->Render("header", "left");
?>
<?php if ($milestones->id->Visible) { // id ?>
	<?php if ($milestones->SortUrl($milestones->id) == "") { ?>
		<th data-name="id"><div id="elh_milestones_id" class="milestones_id"><div class="ewTableHeaderCaption"><?php echo $milestones->id->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="id"><div><div id="elh_milestones_id" class="milestones_id">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $milestones->id->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($milestones->id->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($milestones->id->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($milestones->projectID->Visible) { // projectID ?>
	<?php if ($milestones->SortUrl($milestones->projectID) == "") { ?>
		<th data-name="projectID"><div id="elh_milestones_projectID" class="milestones_projectID"><div class="ewTableHeaderCaption"><?php echo $milestones->projectID->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="projectID"><div><div id="elh_milestones_projectID" class="milestones_projectID">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $milestones->projectID->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($milestones->projectID->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($milestones->projectID->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($milestones->MilestoneDate->Visible) { // MilestoneDate ?>
	<?php if ($milestones->SortUrl($milestones->MilestoneDate) == "") { ?>
		<th data-name="MilestoneDate"><div id="elh_milestones_MilestoneDate" class="milestones_MilestoneDate"><div class="ewTableHeaderCaption"><?php echo $milestones->MilestoneDate->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="MilestoneDate"><div><div id="elh_milestones_MilestoneDate" class="milestones_MilestoneDate">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $milestones->MilestoneDate->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($milestones->MilestoneDate->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($milestones->MilestoneDate->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($milestones->Description->Visible) { // Description ?>
	<?php if ($milestones->SortUrl($milestones->Description) == "") { ?>
		<th data-name="Description"><div id="elh_milestones_Description" class="milestones_Description"><div class="ewTableHeaderCaption"><?php echo $milestones->Description->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Description"><div><div id="elh_milestones_Description" class="milestones_Description">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $milestones->Description->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($milestones->Description->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($milestones->Description->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($milestones->Status->Visible) { // Status ?>
	<?php if ($milestones->SortUrl($milestones->Status) == "") { ?>
		<th data-name="Status"><div id="elh_milestones_Status" class="milestones_Status"><div class="ewTableHeaderCaption"><?php echo $milestones->Status->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Status"><div><div id="elh_milestones_Status" class="milestones_Status">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $milestones->Status->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($milestones->Status->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($milestones->Status->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($milestones->Reserved->Visible) { // Reserved ?>
	<?php if ($milestones->SortUrl($milestones->Reserved) == "") { ?>
		<th data-name="Reserved"><div id="elh_milestones_Reserved" class="milestones_Reserved"><div class="ewTableHeaderCaption"><?php echo $milestones->Reserved->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Reserved"><div><div id="elh_milestones_Reserved" class="milestones_Reserved">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $milestones->Reserved->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($milestones->Reserved->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($milestones->Reserved->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php

// Render list options (header, right)
$milestones_grid->ListOptions->Render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
$milestones_grid->StartRec = 1;
$milestones_grid->StopRec = $milestones_grid->TotalRecs; // Show all records

// Restore number of post back records
if ($objForm) {
	$objForm->Index = -1;
	if ($objForm->HasValue($milestones_grid->FormKeyCountName) && ($milestones->CurrentAction == "gridadd" || $milestones->CurrentAction == "gridedit" || $milestones->CurrentAction == "F")) {
		$milestones_grid->KeyCount = $objForm->GetValue($milestones_grid->FormKeyCountName);
		$milestones_grid->StopRec = $milestones_grid->StartRec + $milestones_grid->KeyCount - 1;
	}
}
$milestones_grid->RecCnt = $milestones_grid->StartRec - 1;
if ($milestones_grid->Recordset && !$milestones_grid->Recordset->EOF) {
	$milestones_grid->Recordset->MoveFirst();
	$bSelectLimit = $milestones_grid->UseSelectLimit;
	if (!$bSelectLimit && $milestones_grid->StartRec > 1)
		$milestones_grid->Recordset->Move($milestones_grid->StartRec - 1);
} elseif (!$milestones->AllowAddDeleteRow && $milestones_grid->StopRec == 0) {
	$milestones_grid->StopRec = $milestones->GridAddRowCount;
}

// Initialize aggregate
$milestones->RowType = EW_ROWTYPE_AGGREGATEINIT;
$milestones->ResetAttrs();
$milestones_grid->RenderRow();
if ($milestones->CurrentAction == "gridadd")
	$milestones_grid->RowIndex = 0;
if ($milestones->CurrentAction == "gridedit")
	$milestones_grid->RowIndex = 0;
while ($milestones_grid->RecCnt < $milestones_grid->StopRec) {
	$milestones_grid->RecCnt++;
	if (intval($milestones_grid->RecCnt) >= intval($milestones_grid->StartRec)) {
		$milestones_grid->RowCnt++;
		if ($milestones->CurrentAction == "gridadd" || $milestones->CurrentAction == "gridedit" || $milestones->CurrentAction == "F") {
			$milestones_grid->RowIndex++;
			$objForm->Index = $milestones_grid->RowIndex;
			if ($objForm->HasValue($milestones_grid->FormActionName))
				$milestones_grid->RowAction = strval($objForm->GetValue($milestones_grid->FormActionName));
			elseif ($milestones->CurrentAction == "gridadd")
				$milestones_grid->RowAction = "insert";
			else
				$milestones_grid->RowAction = "";
		}

		// Set up key count
		$milestones_grid->KeyCount = $milestones_grid->RowIndex;

		// Init row class and style
		$milestones->ResetAttrs();
		$milestones->CssClass = "";
		if ($milestones->CurrentAction == "gridadd") {
			if ($milestones->CurrentMode == "copy") {
				$milestones_grid->LoadRowValues($milestones_grid->Recordset); // Load row values
				$milestones_grid->SetRecordKey($milestones_grid->RowOldKey, $milestones_grid->Recordset); // Set old record key
			} else {
				$milestones_grid->LoadDefaultValues(); // Load default values
				$milestones_grid->RowOldKey = ""; // Clear old key value
			}
		} else {
			$milestones_grid->LoadRowValues($milestones_grid->Recordset); // Load row values
		}
		$milestones->RowType = EW_ROWTYPE_VIEW; // Render view
		if ($milestones->CurrentAction == "gridadd") // Grid add
			$milestones->RowType = EW_ROWTYPE_ADD; // Render add
		if ($milestones->CurrentAction == "gridadd" && $milestones->EventCancelled && !$objForm->HasValue("k_blankrow")) // Insert failed
			$milestones_grid->RestoreCurrentRowFormValues($milestones_grid->RowIndex); // Restore form values
		if ($milestones->CurrentAction == "gridedit") { // Grid edit
			if ($milestones->EventCancelled) {
				$milestones_grid->RestoreCurrentRowFormValues($milestones_grid->RowIndex); // Restore form values
			}
			if ($milestones_grid->RowAction == "insert")
				$milestones->RowType = EW_ROWTYPE_ADD; // Render add
			else
				$milestones->RowType = EW_ROWTYPE_EDIT; // Render edit
		}
		if ($milestones->CurrentAction == "gridedit" && ($milestones->RowType == EW_ROWTYPE_EDIT || $milestones->RowType == EW_ROWTYPE_ADD) && $milestones->EventCancelled) // Update failed
			$milestones_grid->RestoreCurrentRowFormValues($milestones_grid->RowIndex); // Restore form values
		if ($milestones->RowType == EW_ROWTYPE_EDIT) // Edit row
			$milestones_grid->EditRowCnt++;
		if ($milestones->CurrentAction == "F") // Confirm row
			$milestones_grid->RestoreCurrentRowFormValues($milestones_grid->RowIndex); // Restore form values

		// Set up row id / data-rowindex
		$milestones->RowAttrs = array_merge($milestones->RowAttrs, array('data-rowindex'=>$milestones_grid->RowCnt, 'id'=>'r' . $milestones_grid->RowCnt . '_milestones', 'data-rowtype'=>$milestones->RowType));

		// Render row
		$milestones_grid->RenderRow();

		// Render list options
		$milestones_grid->RenderListOptions();

		// Skip delete row / empty row for confirm page
		if ($milestones_grid->RowAction <> "delete" && $milestones_grid->RowAction <> "insertdelete" && !($milestones_grid->RowAction == "insert" && $milestones->CurrentAction == "F" && $milestones_grid->EmptyRow())) {
?>
	<tr<?php echo $milestones->RowAttributes() ?>>
<?php

// Render list options (body, left)
$milestones_grid->ListOptions->Render("body", "left", $milestones_grid->RowCnt);
?>
	<?php if ($milestones->id->Visible) { // id ?>
		<td data-name="id"<?php echo $milestones->id->CellAttributes() ?>>
<?php if ($milestones->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<input type="hidden" data-table="milestones" data-field="x_id" name="o<?php echo $milestones_grid->RowIndex ?>_id" id="o<?php echo $milestones_grid->RowIndex ?>_id" value="<?php echo ew_HtmlEncode($milestones->id->OldValue) ?>">
<?php } ?>
<?php if ($milestones->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $milestones_grid->RowCnt ?>_milestones_id" class="form-group milestones_id">
<span<?php echo $milestones->id->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $milestones->id->EditValue ?></p></span>
</span>
<input type="hidden" data-table="milestones" data-field="x_id" name="x<?php echo $milestones_grid->RowIndex ?>_id" id="x<?php echo $milestones_grid->RowIndex ?>_id" value="<?php echo ew_HtmlEncode($milestones->id->CurrentValue) ?>">
<?php } ?>
<?php if ($milestones->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $milestones_grid->RowCnt ?>_milestones_id" class="milestones_id">
<span<?php echo $milestones->id->ViewAttributes() ?>>
<?php echo $milestones->id->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="milestones" data-field="x_id" name="x<?php echo $milestones_grid->RowIndex ?>_id" id="x<?php echo $milestones_grid->RowIndex ?>_id" value="<?php echo ew_HtmlEncode($milestones->id->FormValue) ?>">
<input type="hidden" data-table="milestones" data-field="x_id" name="o<?php echo $milestones_grid->RowIndex ?>_id" id="o<?php echo $milestones_grid->RowIndex ?>_id" value="<?php echo ew_HtmlEncode($milestones->id->OldValue) ?>">
<?php } ?>
<a id="<?php echo $milestones_grid->PageObjName . "_row_" . $milestones_grid->RowCnt ?>"></a></td>
	<?php } ?>
	<?php if ($milestones->projectID->Visible) { // projectID ?>
		<td data-name="projectID"<?php echo $milestones->projectID->CellAttributes() ?>>
<?php if ($milestones->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<?php if ($milestones->projectID->getSessionValue() <> "") { ?>
<span id="el<?php echo $milestones_grid->RowCnt ?>_milestones_projectID" class="form-group milestones_projectID">
<span<?php echo $milestones->projectID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $milestones->projectID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $milestones_grid->RowIndex ?>_projectID" name="x<?php echo $milestones_grid->RowIndex ?>_projectID" value="<?php echo ew_HtmlEncode($milestones->projectID->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $milestones_grid->RowCnt ?>_milestones_projectID" class="form-group milestones_projectID">
<?php
$wrkonchange = trim(" " . @$milestones->projectID->EditAttrs["onchange"]);
if ($wrkonchange <> "") $wrkonchange = " onchange=\"" . ew_JsEncode2($wrkonchange) . "\"";
$milestones->projectID->EditAttrs["onchange"] = "";
?>
<span id="as_x<?php echo $milestones_grid->RowIndex ?>_projectID" style="white-space: nowrap; z-index: <?php echo (9000 - $milestones_grid->RowCnt * 10) ?>">
	<input type="text" name="sv_x<?php echo $milestones_grid->RowIndex ?>_projectID" id="sv_x<?php echo $milestones_grid->RowIndex ?>_projectID" value="<?php echo $milestones->projectID->EditValue ?>" size="30" placeholder="<?php echo ew_HtmlEncode($milestones->projectID->getPlaceHolder()) ?>" data-placeholder="<?php echo ew_HtmlEncode($milestones->projectID->getPlaceHolder()) ?>"<?php echo $milestones->projectID->EditAttributes() ?>>
</span>
<input type="hidden" data-table="milestones" data-field="x_projectID" data-value-separator="<?php echo ew_HtmlEncode(is_array($milestones->projectID->DisplayValueSeparator) ? json_encode($milestones->projectID->DisplayValueSeparator) : $milestones->projectID->DisplayValueSeparator) ?>" name="x<?php echo $milestones_grid->RowIndex ?>_projectID" id="x<?php echo $milestones_grid->RowIndex ?>_projectID" value="<?php echo ew_HtmlEncode($milestones->projectID->CurrentValue) ?>"<?php echo $wrkonchange ?>>
<?php
$sSqlWrk = "SELECT `id`, `name` AS `DispFld` FROM `project`";
$sWhereWrk = "`name` LIKE '%{query_value}%'";
$milestones->Lookup_Selecting($milestones->projectID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
$sSqlWrk .= " LIMIT " . EW_AUTO_SUGGEST_MAX_ENTRIES;
?>
<input type="hidden" name="q_x<?php echo $milestones_grid->RowIndex ?>_projectID" id="q_x<?php echo $milestones_grid->RowIndex ?>_projectID" value="s=<?php echo ew_Encrypt($sSqlWrk) ?>&d=">
<script type="text/javascript">
fmilestonesgrid.CreateAutoSuggest({"id":"x<?php echo $milestones_grid->RowIndex ?>_projectID","forceSelect":false});
</script>
</span>
<?php } ?>
<input type="hidden" data-table="milestones" data-field="x_projectID" name="o<?php echo $milestones_grid->RowIndex ?>_projectID" id="o<?php echo $milestones_grid->RowIndex ?>_projectID" value="<?php echo ew_HtmlEncode($milestones->projectID->OldValue) ?>">
<?php } ?>
<?php if ($milestones->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<?php if ($milestones->projectID->getSessionValue() <> "") { ?>
<span id="el<?php echo $milestones_grid->RowCnt ?>_milestones_projectID" class="form-group milestones_projectID">
<span<?php echo $milestones->projectID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $milestones->projectID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $milestones_grid->RowIndex ?>_projectID" name="x<?php echo $milestones_grid->RowIndex ?>_projectID" value="<?php echo ew_HtmlEncode($milestones->projectID->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $milestones_grid->RowCnt ?>_milestones_projectID" class="form-group milestones_projectID">
<?php
$wrkonchange = trim(" " . @$milestones->projectID->EditAttrs["onchange"]);
if ($wrkonchange <> "") $wrkonchange = " onchange=\"" . ew_JsEncode2($wrkonchange) . "\"";
$milestones->projectID->EditAttrs["onchange"] = "";
?>
<span id="as_x<?php echo $milestones_grid->RowIndex ?>_projectID" style="white-space: nowrap; z-index: <?php echo (9000 - $milestones_grid->RowCnt * 10) ?>">
	<input type="text" name="sv_x<?php echo $milestones_grid->RowIndex ?>_projectID" id="sv_x<?php echo $milestones_grid->RowIndex ?>_projectID" value="<?php echo $milestones->projectID->EditValue ?>" size="30" placeholder="<?php echo ew_HtmlEncode($milestones->projectID->getPlaceHolder()) ?>" data-placeholder="<?php echo ew_HtmlEncode($milestones->projectID->getPlaceHolder()) ?>"<?php echo $milestones->projectID->EditAttributes() ?>>
</span>
<input type="hidden" data-table="milestones" data-field="x_projectID" data-value-separator="<?php echo ew_HtmlEncode(is_array($milestones->projectID->DisplayValueSeparator) ? json_encode($milestones->projectID->DisplayValueSeparator) : $milestones->projectID->DisplayValueSeparator) ?>" name="x<?php echo $milestones_grid->RowIndex ?>_projectID" id="x<?php echo $milestones_grid->RowIndex ?>_projectID" value="<?php echo ew_HtmlEncode($milestones->projectID->CurrentValue) ?>"<?php echo $wrkonchange ?>>
<?php
$sSqlWrk = "SELECT `id`, `name` AS `DispFld` FROM `project`";
$sWhereWrk = "`name` LIKE '%{query_value}%'";
$milestones->Lookup_Selecting($milestones->projectID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
$sSqlWrk .= " LIMIT " . EW_AUTO_SUGGEST_MAX_ENTRIES;
?>
<input type="hidden" name="q_x<?php echo $milestones_grid->RowIndex ?>_projectID" id="q_x<?php echo $milestones_grid->RowIndex ?>_projectID" value="s=<?php echo ew_Encrypt($sSqlWrk) ?>&d=">
<script type="text/javascript">
fmilestonesgrid.CreateAutoSuggest({"id":"x<?php echo $milestones_grid->RowIndex ?>_projectID","forceSelect":false});
</script>
</span>
<?php } ?>
<?php } ?>
<?php if ($milestones->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $milestones_grid->RowCnt ?>_milestones_projectID" class="milestones_projectID">
<span<?php echo $milestones->projectID->ViewAttributes() ?>>
<?php echo $milestones->projectID->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="milestones" data-field="x_projectID" name="x<?php echo $milestones_grid->RowIndex ?>_projectID" id="x<?php echo $milestones_grid->RowIndex ?>_projectID" value="<?php echo ew_HtmlEncode($milestones->projectID->FormValue) ?>">
<input type="hidden" data-table="milestones" data-field="x_projectID" name="o<?php echo $milestones_grid->RowIndex ?>_projectID" id="o<?php echo $milestones_grid->RowIndex ?>_projectID" value="<?php echo ew_HtmlEncode($milestones->projectID->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($milestones->MilestoneDate->Visible) { // MilestoneDate ?>
		<td data-name="MilestoneDate"<?php echo $milestones->MilestoneDate->CellAttributes() ?>>
<?php if ($milestones->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $milestones_grid->RowCnt ?>_milestones_MilestoneDate" class="form-group milestones_MilestoneDate">
<input type="text" data-table="milestones" data-field="x_MilestoneDate" data-format="7" name="x<?php echo $milestones_grid->RowIndex ?>_MilestoneDate" id="x<?php echo $milestones_grid->RowIndex ?>_MilestoneDate" placeholder="<?php echo ew_HtmlEncode($milestones->MilestoneDate->getPlaceHolder()) ?>" value="<?php echo $milestones->MilestoneDate->EditValue ?>"<?php echo $milestones->MilestoneDate->EditAttributes() ?>>
<?php if (!$milestones->MilestoneDate->ReadOnly && !$milestones->MilestoneDate->Disabled && !isset($milestones->MilestoneDate->EditAttrs["readonly"]) && !isset($milestones->MilestoneDate->EditAttrs["disabled"])) { ?>
<script type="text/javascript">
ew_CreateCalendar("fmilestonesgrid", "x<?php echo $milestones_grid->RowIndex ?>_MilestoneDate", "%d/%m/%Y");
</script>
<?php } ?>
</span>
<input type="hidden" data-table="milestones" data-field="x_MilestoneDate" name="o<?php echo $milestones_grid->RowIndex ?>_MilestoneDate" id="o<?php echo $milestones_grid->RowIndex ?>_MilestoneDate" value="<?php echo ew_HtmlEncode($milestones->MilestoneDate->OldValue) ?>">
<?php } ?>
<?php if ($milestones->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $milestones_grid->RowCnt ?>_milestones_MilestoneDate" class="form-group milestones_MilestoneDate">
<input type="text" data-table="milestones" data-field="x_MilestoneDate" data-format="7" name="x<?php echo $milestones_grid->RowIndex ?>_MilestoneDate" id="x<?php echo $milestones_grid->RowIndex ?>_MilestoneDate" placeholder="<?php echo ew_HtmlEncode($milestones->MilestoneDate->getPlaceHolder()) ?>" value="<?php echo $milestones->MilestoneDate->EditValue ?>"<?php echo $milestones->MilestoneDate->EditAttributes() ?>>
<?php if (!$milestones->MilestoneDate->ReadOnly && !$milestones->MilestoneDate->Disabled && !isset($milestones->MilestoneDate->EditAttrs["readonly"]) && !isset($milestones->MilestoneDate->EditAttrs["disabled"])) { ?>
<script type="text/javascript">
ew_CreateCalendar("fmilestonesgrid", "x<?php echo $milestones_grid->RowIndex ?>_MilestoneDate", "%d/%m/%Y");
</script>
<?php } ?>
</span>
<?php } ?>
<?php if ($milestones->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $milestones_grid->RowCnt ?>_milestones_MilestoneDate" class="milestones_MilestoneDate">
<span<?php echo $milestones->MilestoneDate->ViewAttributes() ?>>
<?php echo $milestones->MilestoneDate->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="milestones" data-field="x_MilestoneDate" name="x<?php echo $milestones_grid->RowIndex ?>_MilestoneDate" id="x<?php echo $milestones_grid->RowIndex ?>_MilestoneDate" value="<?php echo ew_HtmlEncode($milestones->MilestoneDate->FormValue) ?>">
<input type="hidden" data-table="milestones" data-field="x_MilestoneDate" name="o<?php echo $milestones_grid->RowIndex ?>_MilestoneDate" id="o<?php echo $milestones_grid->RowIndex ?>_MilestoneDate" value="<?php echo ew_HtmlEncode($milestones->MilestoneDate->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($milestones->Description->Visible) { // Description ?>
		<td data-name="Description"<?php echo $milestones->Description->CellAttributes() ?>>
<?php if ($milestones->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $milestones_grid->RowCnt ?>_milestones_Description" class="form-group milestones_Description">
<input type="text" data-table="milestones" data-field="x_Description" name="x<?php echo $milestones_grid->RowIndex ?>_Description" id="x<?php echo $milestones_grid->RowIndex ?>_Description" size="30" maxlength="255" placeholder="<?php echo ew_HtmlEncode($milestones->Description->getPlaceHolder()) ?>" value="<?php echo $milestones->Description->EditValue ?>"<?php echo $milestones->Description->EditAttributes() ?>>
</span>
<input type="hidden" data-table="milestones" data-field="x_Description" name="o<?php echo $milestones_grid->RowIndex ?>_Description" id="o<?php echo $milestones_grid->RowIndex ?>_Description" value="<?php echo ew_HtmlEncode($milestones->Description->OldValue) ?>">
<?php } ?>
<?php if ($milestones->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $milestones_grid->RowCnt ?>_milestones_Description" class="form-group milestones_Description">
<input type="text" data-table="milestones" data-field="x_Description" name="x<?php echo $milestones_grid->RowIndex ?>_Description" id="x<?php echo $milestones_grid->RowIndex ?>_Description" size="30" maxlength="255" placeholder="<?php echo ew_HtmlEncode($milestones->Description->getPlaceHolder()) ?>" value="<?php echo $milestones->Description->EditValue ?>"<?php echo $milestones->Description->EditAttributes() ?>>
</span>
<?php } ?>
<?php if ($milestones->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $milestones_grid->RowCnt ?>_milestones_Description" class="milestones_Description">
<span<?php echo $milestones->Description->ViewAttributes() ?>>
<?php echo $milestones->Description->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="milestones" data-field="x_Description" name="x<?php echo $milestones_grid->RowIndex ?>_Description" id="x<?php echo $milestones_grid->RowIndex ?>_Description" value="<?php echo ew_HtmlEncode($milestones->Description->FormValue) ?>">
<input type="hidden" data-table="milestones" data-field="x_Description" name="o<?php echo $milestones_grid->RowIndex ?>_Description" id="o<?php echo $milestones_grid->RowIndex ?>_Description" value="<?php echo ew_HtmlEncode($milestones->Description->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($milestones->Status->Visible) { // Status ?>
		<td data-name="Status"<?php echo $milestones->Status->CellAttributes() ?>>
<?php if ($milestones->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $milestones_grid->RowCnt ?>_milestones_Status" class="form-group milestones_Status">
<input type="text" data-table="milestones" data-field="x_Status" name="x<?php echo $milestones_grid->RowIndex ?>_Status" id="x<?php echo $milestones_grid->RowIndex ?>_Status" size="30" maxlength="20" placeholder="<?php echo ew_HtmlEncode($milestones->Status->getPlaceHolder()) ?>" value="<?php echo $milestones->Status->EditValue ?>"<?php echo $milestones->Status->EditAttributes() ?>>
</span>
<input type="hidden" data-table="milestones" data-field="x_Status" name="o<?php echo $milestones_grid->RowIndex ?>_Status" id="o<?php echo $milestones_grid->RowIndex ?>_Status" value="<?php echo ew_HtmlEncode($milestones->Status->OldValue) ?>">
<?php } ?>
<?php if ($milestones->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $milestones_grid->RowCnt ?>_milestones_Status" class="form-group milestones_Status">
<input type="text" data-table="milestones" data-field="x_Status" name="x<?php echo $milestones_grid->RowIndex ?>_Status" id="x<?php echo $milestones_grid->RowIndex ?>_Status" size="30" maxlength="20" placeholder="<?php echo ew_HtmlEncode($milestones->Status->getPlaceHolder()) ?>" value="<?php echo $milestones->Status->EditValue ?>"<?php echo $milestones->Status->EditAttributes() ?>>
</span>
<?php } ?>
<?php if ($milestones->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $milestones_grid->RowCnt ?>_milestones_Status" class="milestones_Status">
<span<?php echo $milestones->Status->ViewAttributes() ?>>
<?php echo $milestones->Status->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="milestones" data-field="x_Status" name="x<?php echo $milestones_grid->RowIndex ?>_Status" id="x<?php echo $milestones_grid->RowIndex ?>_Status" value="<?php echo ew_HtmlEncode($milestones->Status->FormValue) ?>">
<input type="hidden" data-table="milestones" data-field="x_Status" name="o<?php echo $milestones_grid->RowIndex ?>_Status" id="o<?php echo $milestones_grid->RowIndex ?>_Status" value="<?php echo ew_HtmlEncode($milestones->Status->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($milestones->Reserved->Visible) { // Reserved ?>
		<td data-name="Reserved"<?php echo $milestones->Reserved->CellAttributes() ?>>
<?php if ($milestones->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $milestones_grid->RowCnt ?>_milestones_Reserved" class="form-group milestones_Reserved">
<input type="text" data-table="milestones" data-field="x_Reserved" name="x<?php echo $milestones_grid->RowIndex ?>_Reserved" id="x<?php echo $milestones_grid->RowIndex ?>_Reserved" size="30" placeholder="<?php echo ew_HtmlEncode($milestones->Reserved->getPlaceHolder()) ?>" value="<?php echo $milestones->Reserved->EditValue ?>"<?php echo $milestones->Reserved->EditAttributes() ?>>
</span>
<input type="hidden" data-table="milestones" data-field="x_Reserved" name="o<?php echo $milestones_grid->RowIndex ?>_Reserved" id="o<?php echo $milestones_grid->RowIndex ?>_Reserved" value="<?php echo ew_HtmlEncode($milestones->Reserved->OldValue) ?>">
<?php } ?>
<?php if ($milestones->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $milestones_grid->RowCnt ?>_milestones_Reserved" class="form-group milestones_Reserved">
<input type="text" data-table="milestones" data-field="x_Reserved" name="x<?php echo $milestones_grid->RowIndex ?>_Reserved" id="x<?php echo $milestones_grid->RowIndex ?>_Reserved" size="30" placeholder="<?php echo ew_HtmlEncode($milestones->Reserved->getPlaceHolder()) ?>" value="<?php echo $milestones->Reserved->EditValue ?>"<?php echo $milestones->Reserved->EditAttributes() ?>>
</span>
<?php } ?>
<?php if ($milestones->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $milestones_grid->RowCnt ?>_milestones_Reserved" class="milestones_Reserved">
<span<?php echo $milestones->Reserved->ViewAttributes() ?>>
<?php echo $milestones->Reserved->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="milestones" data-field="x_Reserved" name="x<?php echo $milestones_grid->RowIndex ?>_Reserved" id="x<?php echo $milestones_grid->RowIndex ?>_Reserved" value="<?php echo ew_HtmlEncode($milestones->Reserved->FormValue) ?>">
<input type="hidden" data-table="milestones" data-field="x_Reserved" name="o<?php echo $milestones_grid->RowIndex ?>_Reserved" id="o<?php echo $milestones_grid->RowIndex ?>_Reserved" value="<?php echo ew_HtmlEncode($milestones->Reserved->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$milestones_grid->ListOptions->Render("body", "right", $milestones_grid->RowCnt);
?>
	</tr>
<?php if ($milestones->RowType == EW_ROWTYPE_ADD || $milestones->RowType == EW_ROWTYPE_EDIT) { ?>
<script type="text/javascript">
fmilestonesgrid.UpdateOpts(<?php echo $milestones_grid->RowIndex ?>);
</script>
<?php } ?>
<?php
	}
	} // End delete row checking
	if ($milestones->CurrentAction <> "gridadd" || $milestones->CurrentMode == "copy")
		if (!$milestones_grid->Recordset->EOF) $milestones_grid->Recordset->MoveNext();
}
?>
<?php
	if ($milestones->CurrentMode == "add" || $milestones->CurrentMode == "copy" || $milestones->CurrentMode == "edit") {
		$milestones_grid->RowIndex = '$rowindex$';
		$milestones_grid->LoadDefaultValues();

		// Set row properties
		$milestones->ResetAttrs();
		$milestones->RowAttrs = array_merge($milestones->RowAttrs, array('data-rowindex'=>$milestones_grid->RowIndex, 'id'=>'r0_milestones', 'data-rowtype'=>EW_ROWTYPE_ADD));
		ew_AppendClass($milestones->RowAttrs["class"], "ewTemplate");
		$milestones->RowType = EW_ROWTYPE_ADD;

		// Render row
		$milestones_grid->RenderRow();

		// Render list options
		$milestones_grid->RenderListOptions();
		$milestones_grid->StartRowCnt = 0;
?>
	<tr<?php echo $milestones->RowAttributes() ?>>
<?php

// Render list options (body, left)
$milestones_grid->ListOptions->Render("body", "left", $milestones_grid->RowIndex);
?>
	<?php if ($milestones->id->Visible) { // id ?>
		<td data-name="id">
<?php if ($milestones->CurrentAction <> "F") { ?>
<?php } else { ?>
<span id="el$rowindex$_milestones_id" class="form-group milestones_id">
<span<?php echo $milestones->id->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $milestones->id->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="milestones" data-field="x_id" name="x<?php echo $milestones_grid->RowIndex ?>_id" id="x<?php echo $milestones_grid->RowIndex ?>_id" value="<?php echo ew_HtmlEncode($milestones->id->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="milestones" data-field="x_id" name="o<?php echo $milestones_grid->RowIndex ?>_id" id="o<?php echo $milestones_grid->RowIndex ?>_id" value="<?php echo ew_HtmlEncode($milestones->id->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($milestones->projectID->Visible) { // projectID ?>
		<td data-name="projectID">
<?php if ($milestones->CurrentAction <> "F") { ?>
<?php if ($milestones->projectID->getSessionValue() <> "") { ?>
<span id="el$rowindex$_milestones_projectID" class="form-group milestones_projectID">
<span<?php echo $milestones->projectID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $milestones->projectID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $milestones_grid->RowIndex ?>_projectID" name="x<?php echo $milestones_grid->RowIndex ?>_projectID" value="<?php echo ew_HtmlEncode($milestones->projectID->CurrentValue) ?>">
<?php } else { ?>
<span id="el$rowindex$_milestones_projectID" class="form-group milestones_projectID">
<?php
$wrkonchange = trim(" " . @$milestones->projectID->EditAttrs["onchange"]);
if ($wrkonchange <> "") $wrkonchange = " onchange=\"" . ew_JsEncode2($wrkonchange) . "\"";
$milestones->projectID->EditAttrs["onchange"] = "";
?>
<span id="as_x<?php echo $milestones_grid->RowIndex ?>_projectID" style="white-space: nowrap; z-index: <?php echo (9000 - $milestones_grid->RowCnt * 10) ?>">
	<input type="text" name="sv_x<?php echo $milestones_grid->RowIndex ?>_projectID" id="sv_x<?php echo $milestones_grid->RowIndex ?>_projectID" value="<?php echo $milestones->projectID->EditValue ?>" size="30" placeholder="<?php echo ew_HtmlEncode($milestones->projectID->getPlaceHolder()) ?>" data-placeholder="<?php echo ew_HtmlEncode($milestones->projectID->getPlaceHolder()) ?>"<?php echo $milestones->projectID->EditAttributes() ?>>
</span>
<input type="hidden" data-table="milestones" data-field="x_projectID" data-value-separator="<?php echo ew_HtmlEncode(is_array($milestones->projectID->DisplayValueSeparator) ? json_encode($milestones->projectID->DisplayValueSeparator) : $milestones->projectID->DisplayValueSeparator) ?>" name="x<?php echo $milestones_grid->RowIndex ?>_projectID" id="x<?php echo $milestones_grid->RowIndex ?>_projectID" value="<?php echo ew_HtmlEncode($milestones->projectID->CurrentValue) ?>"<?php echo $wrkonchange ?>>
<?php
$sSqlWrk = "SELECT `id`, `name` AS `DispFld` FROM `project`";
$sWhereWrk = "`name` LIKE '%{query_value}%'";
$milestones->Lookup_Selecting($milestones->projectID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
$sSqlWrk .= " LIMIT " . EW_AUTO_SUGGEST_MAX_ENTRIES;
?>
<input type="hidden" name="q_x<?php echo $milestones_grid->RowIndex ?>_projectID" id="q_x<?php echo $milestones_grid->RowIndex ?>_projectID" value="s=<?php echo ew_Encrypt($sSqlWrk) ?>&d=">
<script type="text/javascript">
fmilestonesgrid.CreateAutoSuggest({"id":"x<?php echo $milestones_grid->RowIndex ?>_projectID","forceSelect":false});
</script>
</span>
<?php } ?>
<?php } else { ?>
<span id="el$rowindex$_milestones_projectID" class="form-group milestones_projectID">
<span<?php echo $milestones->projectID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $milestones->projectID->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="milestones" data-field="x_projectID" name="x<?php echo $milestones_grid->RowIndex ?>_projectID" id="x<?php echo $milestones_grid->RowIndex ?>_projectID" value="<?php echo ew_HtmlEncode($milestones->projectID->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="milestones" data-field="x_projectID" name="o<?php echo $milestones_grid->RowIndex ?>_projectID" id="o<?php echo $milestones_grid->RowIndex ?>_projectID" value="<?php echo ew_HtmlEncode($milestones->projectID->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($milestones->MilestoneDate->Visible) { // MilestoneDate ?>
		<td data-name="MilestoneDate">
<?php if ($milestones->CurrentAction <> "F") { ?>
<span id="el$rowindex$_milestones_MilestoneDate" class="form-group milestones_MilestoneDate">
<input type="text" data-table="milestones" data-field="x_MilestoneDate" data-format="7" name="x<?php echo $milestones_grid->RowIndex ?>_MilestoneDate" id="x<?php echo $milestones_grid->RowIndex ?>_MilestoneDate" placeholder="<?php echo ew_HtmlEncode($milestones->MilestoneDate->getPlaceHolder()) ?>" value="<?php echo $milestones->MilestoneDate->EditValue ?>"<?php echo $milestones->MilestoneDate->EditAttributes() ?>>
<?php if (!$milestones->MilestoneDate->ReadOnly && !$milestones->MilestoneDate->Disabled && !isset($milestones->MilestoneDate->EditAttrs["readonly"]) && !isset($milestones->MilestoneDate->EditAttrs["disabled"])) { ?>
<script type="text/javascript">
ew_CreateCalendar("fmilestonesgrid", "x<?php echo $milestones_grid->RowIndex ?>_MilestoneDate", "%d/%m/%Y");
</script>
<?php } ?>
</span>
<?php } else { ?>
<span id="el$rowindex$_milestones_MilestoneDate" class="form-group milestones_MilestoneDate">
<span<?php echo $milestones->MilestoneDate->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $milestones->MilestoneDate->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="milestones" data-field="x_MilestoneDate" name="x<?php echo $milestones_grid->RowIndex ?>_MilestoneDate" id="x<?php echo $milestones_grid->RowIndex ?>_MilestoneDate" value="<?php echo ew_HtmlEncode($milestones->MilestoneDate->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="milestones" data-field="x_MilestoneDate" name="o<?php echo $milestones_grid->RowIndex ?>_MilestoneDate" id="o<?php echo $milestones_grid->RowIndex ?>_MilestoneDate" value="<?php echo ew_HtmlEncode($milestones->MilestoneDate->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($milestones->Description->Visible) { // Description ?>
		<td data-name="Description">
<?php if ($milestones->CurrentAction <> "F") { ?>
<span id="el$rowindex$_milestones_Description" class="form-group milestones_Description">
<input type="text" data-table="milestones" data-field="x_Description" name="x<?php echo $milestones_grid->RowIndex ?>_Description" id="x<?php echo $milestones_grid->RowIndex ?>_Description" size="30" maxlength="255" placeholder="<?php echo ew_HtmlEncode($milestones->Description->getPlaceHolder()) ?>" value="<?php echo $milestones->Description->EditValue ?>"<?php echo $milestones->Description->EditAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_milestones_Description" class="form-group milestones_Description">
<span<?php echo $milestones->Description->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $milestones->Description->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="milestones" data-field="x_Description" name="x<?php echo $milestones_grid->RowIndex ?>_Description" id="x<?php echo $milestones_grid->RowIndex ?>_Description" value="<?php echo ew_HtmlEncode($milestones->Description->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="milestones" data-field="x_Description" name="o<?php echo $milestones_grid->RowIndex ?>_Description" id="o<?php echo $milestones_grid->RowIndex ?>_Description" value="<?php echo ew_HtmlEncode($milestones->Description->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($milestones->Status->Visible) { // Status ?>
		<td data-name="Status">
<?php if ($milestones->CurrentAction <> "F") { ?>
<span id="el$rowindex$_milestones_Status" class="form-group milestones_Status">
<input type="text" data-table="milestones" data-field="x_Status" name="x<?php echo $milestones_grid->RowIndex ?>_Status" id="x<?php echo $milestones_grid->RowIndex ?>_Status" size="30" maxlength="20" placeholder="<?php echo ew_HtmlEncode($milestones->Status->getPlaceHolder()) ?>" value="<?php echo $milestones->Status->EditValue ?>"<?php echo $milestones->Status->EditAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_milestones_Status" class="form-group milestones_Status">
<span<?php echo $milestones->Status->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $milestones->Status->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="milestones" data-field="x_Status" name="x<?php echo $milestones_grid->RowIndex ?>_Status" id="x<?php echo $milestones_grid->RowIndex ?>_Status" value="<?php echo ew_HtmlEncode($milestones->Status->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="milestones" data-field="x_Status" name="o<?php echo $milestones_grid->RowIndex ?>_Status" id="o<?php echo $milestones_grid->RowIndex ?>_Status" value="<?php echo ew_HtmlEncode($milestones->Status->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($milestones->Reserved->Visible) { // Reserved ?>
		<td data-name="Reserved">
<?php if ($milestones->CurrentAction <> "F") { ?>
<span id="el$rowindex$_milestones_Reserved" class="form-group milestones_Reserved">
<input type="text" data-table="milestones" data-field="x_Reserved" name="x<?php echo $milestones_grid->RowIndex ?>_Reserved" id="x<?php echo $milestones_grid->RowIndex ?>_Reserved" size="30" placeholder="<?php echo ew_HtmlEncode($milestones->Reserved->getPlaceHolder()) ?>" value="<?php echo $milestones->Reserved->EditValue ?>"<?php echo $milestones->Reserved->EditAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_milestones_Reserved" class="form-group milestones_Reserved">
<span<?php echo $milestones->Reserved->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $milestones->Reserved->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="milestones" data-field="x_Reserved" name="x<?php echo $milestones_grid->RowIndex ?>_Reserved" id="x<?php echo $milestones_grid->RowIndex ?>_Reserved" value="<?php echo ew_HtmlEncode($milestones->Reserved->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="milestones" data-field="x_Reserved" name="o<?php echo $milestones_grid->RowIndex ?>_Reserved" id="o<?php echo $milestones_grid->RowIndex ?>_Reserved" value="<?php echo ew_HtmlEncode($milestones->Reserved->OldValue) ?>">
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$milestones_grid->ListOptions->Render("body", "right", $milestones_grid->RowCnt);
?>
<script type="text/javascript">
fmilestonesgrid.UpdateOpts(<?php echo $milestones_grid->RowIndex ?>);
</script>
	</tr>
<?php
}
?>
</tbody>
</table>
<?php if ($milestones->CurrentMode == "add" || $milestones->CurrentMode == "copy") { ?>
<input type="hidden" name="a_list" id="a_list" value="gridinsert">
<input type="hidden" name="<?php echo $milestones_grid->FormKeyCountName ?>" id="<?php echo $milestones_grid->FormKeyCountName ?>" value="<?php echo $milestones_grid->KeyCount ?>">
<?php echo $milestones_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($milestones->CurrentMode == "edit") { ?>
<input type="hidden" name="a_list" id="a_list" value="gridupdate">
<input type="hidden" name="<?php echo $milestones_grid->FormKeyCountName ?>" id="<?php echo $milestones_grid->FormKeyCountName ?>" value="<?php echo $milestones_grid->KeyCount ?>">
<?php echo $milestones_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($milestones->CurrentMode == "") { ?>
<input type="hidden" name="a_list" id="a_list" value="">
<?php } ?>
<input type="hidden" name="detailpage" value="fmilestonesgrid">
</div>
<?php

// Close recordset
if ($milestones_grid->Recordset)
	$milestones_grid->Recordset->Close();
?>
<?php if ($milestones_grid->ShowOtherOptions) { ?>
<div class="panel-footer ewGridLowerPanel">
<?php
	foreach ($milestones_grid->OtherOptions as &$option)
		$option->Render("body", "bottom");
?>
</div>
<div class="clearfix"></div>
<?php } ?>
</div>
</div>
<?php } ?>
<?php if ($milestones_grid->TotalRecs == 0 && $milestones->CurrentAction == "") { // Show other options ?>
<div class="ewListOtherOptions">
<?php
	foreach ($milestones_grid->OtherOptions as &$option) {
		$option->ButtonClass = "";
		$option->Render("body", "");
	}
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php if ($milestones->Export == "") { ?>
<script type="text/javascript">
fmilestonesgrid.Init();
</script>
<?php } ?>
<?php
$milestones_grid->ShowPageFooter();
if (EW_DEBUG_ENABLED)
	echo ew_DebugMsg();
?>
<?php
$milestones_grid->Page_Terminate();
?>
