<?php

// id
// Name
// Active
// tor

?>
<?php if ($committee->Visible) { ?>
<!-- <h4 class="ewMasterCaption"><?php echo $committee->TableCaption() ?></h4> -->
<table id="tbl_committeemaster" class="table table-bordered table-striped ewViewTable">
<?php echo $committee->TableCustomInnerHtml ?>
	<tbody>
<?php if ($committee->id->Visible) { // id ?>
		<tr id="r_id">
			<td><?php echo $committee->id->FldCaption() ?></td>
			<td<?php echo $committee->id->CellAttributes() ?>>
<span id="el_committee_id">
<span<?php echo $committee->id->ViewAttributes() ?>>
<?php echo $committee->id->ListViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($committee->Name->Visible) { // Name ?>
		<tr id="r_Name">
			<td><?php echo $committee->Name->FldCaption() ?></td>
			<td<?php echo $committee->Name->CellAttributes() ?>>
<span id="el_committee_Name">
<span<?php echo $committee->Name->ViewAttributes() ?>>
<?php echo $committee->Name->ListViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($committee->Active->Visible) { // Active ?>
		<tr id="r_Active">
			<td><?php echo $committee->Active->FldCaption() ?></td>
			<td<?php echo $committee->Active->CellAttributes() ?>>
<span id="el_committee_Active">
<span<?php echo $committee->Active->ViewAttributes() ?>>
<?php echo $committee->Active->ListViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($committee->tor->Visible) { // tor ?>
		<tr id="r_tor">
			<td><?php echo $committee->tor->FldCaption() ?></td>
			<td<?php echo $committee->tor->CellAttributes() ?>>
<span id="el_committee_tor">
<span<?php echo $committee->tor->ViewAttributes() ?>>
<?php echo ew_GetFileViewTag($committee->tor, $committee->tor->ListViewValue()) ?>
</span>
</span>
</td>
		</tr>
<?php } ?>
	</tbody>
</table>
<?php } ?>
