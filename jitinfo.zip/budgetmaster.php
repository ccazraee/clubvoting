<?php

// id
// ProjectID
// BudgetYear
// Amount

?>
<?php if ($budget->Visible) { ?>
<!-- <h4 class="ewMasterCaption"><?php echo $budget->TableCaption() ?></h4> -->
<table id="tbl_budgetmaster" class="table table-bordered table-striped ewViewTable">
<?php echo $budget->TableCustomInnerHtml ?>
	<tbody>
<?php if ($budget->id->Visible) { // id ?>
		<tr id="r_id">
			<td><?php echo $budget->id->FldCaption() ?></td>
			<td<?php echo $budget->id->CellAttributes() ?>>
<span id="el_budget_id">
<span<?php echo $budget->id->ViewAttributes() ?>>
<?php echo $budget->id->ListViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($budget->ProjectID->Visible) { // ProjectID ?>
		<tr id="r_ProjectID">
			<td><?php echo $budget->ProjectID->FldCaption() ?></td>
			<td<?php echo $budget->ProjectID->CellAttributes() ?>>
<span id="el_budget_ProjectID">
<span<?php echo $budget->ProjectID->ViewAttributes() ?>>
<?php echo $budget->ProjectID->ListViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($budget->BudgetYear->Visible) { // BudgetYear ?>
		<tr id="r_BudgetYear">
			<td><?php echo $budget->BudgetYear->FldCaption() ?></td>
			<td<?php echo $budget->BudgetYear->CellAttributes() ?>>
<span id="el_budget_BudgetYear">
<span<?php echo $budget->BudgetYear->ViewAttributes() ?>>
<?php echo $budget->BudgetYear->ListViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($budget->Amount->Visible) { // Amount ?>
		<tr id="r_Amount">
			<td><?php echo $budget->Amount->FldCaption() ?></td>
			<td<?php echo $budget->Amount->CellAttributes() ?>>
<span id="el_budget_Amount">
<span<?php echo $budget->Amount->ViewAttributes() ?>>
<?php echo $budget->Amount->ListViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
	</tbody>
</table>
<?php } ?>
