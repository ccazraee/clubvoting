<?php

// id
// classname
// StartDate
// EndDate
// category
// Organizer
// Payment
// Fees

?>
<?php if ($class->Visible) { ?>
<!-- <h4 class="ewMasterCaption"><?php echo $class->TableCaption() ?></h4> -->
<table id="tbl_classmaster" class="table table-bordered table-striped ewViewTable">
<?php echo $class->TableCustomInnerHtml ?>
	<tbody>
<?php if ($class->id->Visible) { // id ?>
		<tr id="r_id">
			<td><?php echo $class->id->FldCaption() ?></td>
			<td<?php echo $class->id->CellAttributes() ?>>
<span id="el_class_id">
<span<?php echo $class->id->ViewAttributes() ?>>
<?php echo $class->id->ListViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($class->classname->Visible) { // classname ?>
		<tr id="r_classname">
			<td><?php echo $class->classname->FldCaption() ?></td>
			<td<?php echo $class->classname->CellAttributes() ?>>
<span id="el_class_classname">
<span<?php echo $class->classname->ViewAttributes() ?>>
<?php echo $class->classname->ListViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($class->StartDate->Visible) { // StartDate ?>
		<tr id="r_StartDate">
			<td><?php echo $class->StartDate->FldCaption() ?></td>
			<td<?php echo $class->StartDate->CellAttributes() ?>>
<span id="el_class_StartDate">
<span<?php echo $class->StartDate->ViewAttributes() ?>>
<?php echo $class->StartDate->ListViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($class->EndDate->Visible) { // EndDate ?>
		<tr id="r_EndDate">
			<td><?php echo $class->EndDate->FldCaption() ?></td>
			<td<?php echo $class->EndDate->CellAttributes() ?>>
<span id="el_class_EndDate">
<span<?php echo $class->EndDate->ViewAttributes() ?>>
<?php echo $class->EndDate->ListViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($class->category->Visible) { // category ?>
		<tr id="r_category">
			<td><?php echo $class->category->FldCaption() ?></td>
			<td<?php echo $class->category->CellAttributes() ?>>
<span id="el_class_category">
<span<?php echo $class->category->ViewAttributes() ?>>
<?php echo $class->category->ListViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($class->Organizer->Visible) { // Organizer ?>
		<tr id="r_Organizer">
			<td><?php echo $class->Organizer->FldCaption() ?></td>
			<td<?php echo $class->Organizer->CellAttributes() ?>>
<span id="el_class_Organizer">
<span<?php echo $class->Organizer->ViewAttributes() ?>>
<?php echo $class->Organizer->ListViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($class->Payment->Visible) { // Payment ?>
		<tr id="r_Payment">
			<td><?php echo $class->Payment->FldCaption() ?></td>
			<td<?php echo $class->Payment->CellAttributes() ?>>
<span id="el_class_Payment">
<span<?php echo $class->Payment->ViewAttributes() ?>>
<?php echo $class->Payment->ListViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($class->Fees->Visible) { // Fees ?>
		<tr id="r_Fees">
			<td><?php echo $class->Fees->FldCaption() ?></td>
			<td<?php echo $class->Fees->CellAttributes() ?>>
<span id="el_class_Fees">
<span<?php echo $class->Fees->ViewAttributes() ?>>
<?php echo $class->Fees->ListViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
	</tbody>
</table>
<?php } ?>
