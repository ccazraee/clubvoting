<?php
if (session_id() == "") session_start(); // Initialize Session data
ob_start(); // Turn on output buffering
?>
<?php include_once "ewcfg12.php" ?>
<?php include_once ((EW_USE_ADODB) ? "adodb5/adodb.inc.php" : "ewmysql12.php") ?>
<?php include_once "phpfn12.php" ?>
<?php include_once "milestonesinfo.php" ?>
<?php include_once "projectinfo.php" ?>
<?php include_once "staffinfo.php" ?>
<?php include_once "userfn12.php" ?>
<?php

//
// Page class
//

$milestones_add = NULL; // Initialize page object first

class cmilestones_add extends cmilestones {

	// Page ID
	var $PageID = 'add';

	// Project ID
	var $ProjectID = "{E654CCD7-163B-4B2E-BFA7-AC8697684A42}";

	// Table name
	var $TableName = 'milestones';

	// Page object name
	var $PageObjName = 'milestones_add';

	// Page name
	function PageName() {
		return ew_CurrentPage();
	}

	// Page URL
	function PageUrl() {
		$PageUrl = ew_CurrentPage() . "?";
		if ($this->UseTokenInUrl) $PageUrl .= "t=" . $this->TableVar . "&"; // Add page token
		return $PageUrl;
	}
    var $AuditTrailOnAdd = TRUE;
    var $AuditTrailOnEdit = FALSE;
    var $AuditTrailOnDelete = FALSE;
    var $AuditTrailOnView = FALSE;
    var $AuditTrailOnViewData = FALSE;
    var $AuditTrailOnSearch = FALSE;

	// Message
	function getMessage() {
		return @$_SESSION[EW_SESSION_MESSAGE];
	}

	function setMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_MESSAGE], $v);
	}

	function getFailureMessage() {
		return @$_SESSION[EW_SESSION_FAILURE_MESSAGE];
	}

	function setFailureMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_FAILURE_MESSAGE], $v);
	}

	function getSuccessMessage() {
		return @$_SESSION[EW_SESSION_SUCCESS_MESSAGE];
	}

	function setSuccessMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_SUCCESS_MESSAGE], $v);
	}

	function getWarningMessage() {
		return @$_SESSION[EW_SESSION_WARNING_MESSAGE];
	}

	function setWarningMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_WARNING_MESSAGE], $v);
	}

	// Methods to clear message
	function ClearMessage() {
		$_SESSION[EW_SESSION_MESSAGE] = "";
	}

	function ClearFailureMessage() {
		$_SESSION[EW_SESSION_FAILURE_MESSAGE] = "";
	}

	function ClearSuccessMessage() {
		$_SESSION[EW_SESSION_SUCCESS_MESSAGE] = "";
	}

	function ClearWarningMessage() {
		$_SESSION[EW_SESSION_WARNING_MESSAGE] = "";
	}

	function ClearMessages() {
		$_SESSION[EW_SESSION_MESSAGE] = "";
		$_SESSION[EW_SESSION_FAILURE_MESSAGE] = "";
		$_SESSION[EW_SESSION_SUCCESS_MESSAGE] = "";
		$_SESSION[EW_SESSION_WARNING_MESSAGE] = "";
	}

	// Show message
	function ShowMessage() {
		$hidden = FALSE;
		$html = "";

		// Message
		$sMessage = $this->getMessage();
		$this->Message_Showing($sMessage, "");
		if ($sMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sMessage;
			$html .= "<div class=\"alert alert-info ewInfo\">" . $sMessage . "</div>";
			$_SESSION[EW_SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$sWarningMessage = $this->getWarningMessage();
		$this->Message_Showing($sWarningMessage, "warning");
		if ($sWarningMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sWarningMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sWarningMessage;
			$html .= "<div class=\"alert alert-warning ewWarning\">" . $sWarningMessage . "</div>";
			$_SESSION[EW_SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$sSuccessMessage = $this->getSuccessMessage();
		$this->Message_Showing($sSuccessMessage, "success");
		if ($sSuccessMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sSuccessMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sSuccessMessage;
			$html .= "<div class=\"alert alert-success ewSuccess\">" . $sSuccessMessage . "</div>";
			$_SESSION[EW_SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$sErrorMessage = $this->getFailureMessage();
		$this->Message_Showing($sErrorMessage, "failure");
		if ($sErrorMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sErrorMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sErrorMessage;
			$html .= "<div class=\"alert alert-danger ewError\">" . $sErrorMessage . "</div>";
			$_SESSION[EW_SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo "<div class=\"ewMessageDialog\"" . (($hidden) ? " style=\"display: none;\"" : "") . ">" . $html . "</div>";
	}
	var $PageHeader;
	var $PageFooter;

	// Show Page Header
	function ShowPageHeader() {
		$sHeader = $this->PageHeader;
		$this->Page_DataRendering($sHeader);
		if ($sHeader <> "") { // Header exists, display
			echo "<p>" . $sHeader . "</p>";
		}
	}

	// Show Page Footer
	function ShowPageFooter() {
		$sFooter = $this->PageFooter;
		$this->Page_DataRendered($sFooter);
		if ($sFooter <> "") { // Footer exists, display
			echo "<p>" . $sFooter . "</p>";
		}
	}

	// Validate page request
	function IsPageRequest() {
		global $objForm;
		if ($this->UseTokenInUrl) {
			if ($objForm)
				return ($this->TableVar == $objForm->GetValue("t"));
			if (@$_GET["t"] <> "")
				return ($this->TableVar == $_GET["t"]);
		} else {
			return TRUE;
		}
	}
	var $Token = "";
	var $TokenTimeout = 0;
	var $CheckToken = EW_CHECK_TOKEN;
	var $CheckTokenFn = "ew_CheckToken";
	var $CreateTokenFn = "ew_CreateToken";

	// Valid Post
	function ValidPost() {
		if (!$this->CheckToken || !ew_IsHttpPost())
			return TRUE;
		if (!isset($_POST[EW_TOKEN_NAME]))
			return FALSE;
		$fn = $this->CheckTokenFn;
		if (is_callable($fn))
			return $fn($_POST[EW_TOKEN_NAME], $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	function CreateToken() {
		global $gsToken;
		if ($this->CheckToken) {
			$fn = $this->CreateTokenFn;
			if ($this->Token == "" && is_callable($fn)) // Create token
				$this->Token = $fn();
			$gsToken = $this->Token; // Save to global variable
		}
	}

	//
	// Page class constructor
	//
	function __construct() {
		global $conn, $Language;
		global $UserTable, $UserTableConn;
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = ew_SessionTimeoutTime();

		// Language object
		if (!isset($Language)) $Language = new cLanguage();

		// Parent constuctor
		parent::__construct();

		// Table object (milestones)
		if (!isset($GLOBALS["milestones"]) || get_class($GLOBALS["milestones"]) == "cmilestones") {
			$GLOBALS["milestones"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["milestones"];
		}

		// Table object (project)
		if (!isset($GLOBALS['project'])) $GLOBALS['project'] = new cproject();

		// Table object (staff)
		if (!isset($GLOBALS['staff'])) $GLOBALS['staff'] = new cstaff();

		// Page ID
		if (!defined("EW_PAGE_ID"))
			define("EW_PAGE_ID", 'add', TRUE);

		// Table name (for backward compatibility)
		if (!defined("EW_TABLE_NAME"))
			define("EW_TABLE_NAME", 'milestones', TRUE);

		// Start timer
		if (!isset($GLOBALS["gTimer"])) $GLOBALS["gTimer"] = new cTimer();

		// Open connection
		if (!isset($conn)) $conn = ew_Connect($this->DBID);

		// User table object (staff)
		if (!isset($UserTable)) {
			$UserTable = new cstaff();
			$UserTableConn = Conn($UserTable->DBID);
		}
	}

	// 
	//  Page_Init
	//
	function Page_Init() {
		global $gsExport, $gsCustomExport, $gsExportFile, $UserProfile, $Language, $Security, $objForm;

		// Security
		$Security = new cAdvancedSecurity();
		if (!$Security->IsLoggedIn()) $Security->AutoLogin();
		if ($Security->IsLoggedIn()) $Security->TablePermission_Loading();
		$Security->LoadCurrentUserLevel($this->ProjectID . $this->TableName);
		if ($Security->IsLoggedIn()) $Security->TablePermission_Loaded();
		if (!$Security->CanAdd()) {
			$Security->SaveLastUrl();
			$this->setFailureMessage(ew_DeniedMsg()); // Set no permission
			$this->Page_Terminate(ew_GetUrl("milestoneslist.php"));
		}
		if ($Security->IsLoggedIn()) {
			$Security->UserID_Loading();
			$Security->LoadUserID();
			$Security->UserID_Loaded();
		}

		// Create form object
		$objForm = new cFormObj();
		$this->CurrentAction = (@$_GET["a"] <> "") ? $_GET["a"] : @$_POST["a_list"]; // Set up current action

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->ValidPost()) {
			echo $Language->Phrase("InvalidPostRequest");
			$this->Page_Terminate();
			exit();
		}

		// Process auto fill
		if (@$_POST["ajax"] == "autofill") {
			$results = $this->GetAutoFill(@$_POST["name"], @$_POST["q"]);
			if ($results) {

				// Clean output buffer
				if (!EW_DEBUG_ENABLED && ob_get_length())
					ob_end_clean();
				echo $results;
				$this->Page_Terminate();
				exit();
			}
		}

		// Create Token
		$this->CreateToken();
	}

	//
	// Page_Terminate
	//
	function Page_Terminate($url = "") {
		global $gsExportFile, $gTmpImages;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $EW_EXPORT, $milestones;
		if ($this->CustomExport <> "" && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, $EW_EXPORT)) {
				$sContent = ob_get_contents();
			if ($gsExportFile == "") $gsExportFile = $this->TableVar;
			$class = $EW_EXPORT[$this->CustomExport];
			if (class_exists($class)) {
				$doc = new $class($milestones);
				$doc->Text = $sContent;
				if ($this->Export == "email")
					echo $this->ExportEmail($doc->Text);
				else
					$doc->Export();
				ew_DeleteTmpImages(); // Delete temp images
				exit();
			}
		}
		$this->Page_Redirecting($url);

		 // Close connection
		ew_CloseConn();

		// Go to URL if specified
		if ($url <> "") {
			if (!EW_DEBUG_ENABLED && ob_get_length())
				ob_end_clean();
			header("Location: " . $url);
		}
		exit();
	}
	var $FormClassName = "form-horizontal ewForm ewAddForm";
	var $DbMasterFilter = "";
	var $DbDetailFilter = "";
	var $StartRec;
	var $Priv = 0;
	var $OldRecordset;
	var $CopyRecord;

	// 
	// Page main
	//
	function Page_Main() {
		global $objForm, $Language, $gsFormError;

		// Set up master/detail parameters
		$this->SetUpMasterParms();

		// Process form if post back
		if (@$_POST["a_add"] <> "") {
			$this->CurrentAction = $_POST["a_add"]; // Get form action
			$this->CopyRecord = $this->LoadOldRecord(); // Load old recordset
			$this->LoadFormValues(); // Load form values
		} else { // Not post back

			// Load key values from QueryString
			$this->CopyRecord = TRUE;
			if (@$_GET["id"] != "") {
				$this->id->setQueryStringValue($_GET["id"]);
				$this->setKey("id", $this->id->CurrentValue); // Set up key
			} else {
				$this->setKey("id", ""); // Clear key
				$this->CopyRecord = FALSE;
			}
			if ($this->CopyRecord) {
				$this->CurrentAction = "C"; // Copy record
			} else {
				$this->CurrentAction = "I"; // Display blank record
			}
		}

		// Set up Breadcrumb
		$this->SetupBreadcrumb();

		// Validate form if post back
		if (@$_POST["a_add"] <> "") {
			if (!$this->ValidateForm()) {
				$this->CurrentAction = "I"; // Form error, reset action
				$this->EventCancelled = TRUE; // Event cancelled
				$this->RestoreFormValues(); // Restore form values
				$this->setFailureMessage($gsFormError);
			}
		} else {
			if ($this->CurrentAction == "I") // Load default values for blank record
				$this->LoadDefaultValues();
		}

		// Perform action based on action code
		switch ($this->CurrentAction) {
			case "I": // Blank record, no action required
				break;
			case "C": // Copy an existing record
				if (!$this->LoadRow()) { // Load record based on key
					if ($this->getFailureMessage() == "") $this->setFailureMessage($Language->Phrase("NoRecord")); // No record found
					$this->Page_Terminate("milestoneslist.php"); // No matching record, return to list
				}
				break;
			case "A": // Add new record
				$this->SendEmail = TRUE; // Send email on add success
				if ($this->AddRow($this->OldRecordset)) { // Add successful
					if ($this->getSuccessMessage() == "")
						$this->setSuccessMessage($Language->Phrase("AddSuccess")); // Set up success message
					$sReturnUrl = $this->GetViewUrl();
					if (ew_GetPageName($sReturnUrl) == "milestoneslist.php")
						$sReturnUrl = $this->AddMasterUrl($sReturnUrl); // List page, return to list page with correct master key if necessary
					elseif (ew_GetPageName($sReturnUrl) == "milestonesview.php")
						$sReturnUrl = $this->GetViewUrl(); // View page, return to view page with keyurl directly
					$this->Page_Terminate($sReturnUrl); // Clean up and return
				} else {
					$this->EventCancelled = TRUE; // Event cancelled
					$this->RestoreFormValues(); // Add failed, restore form values
				}
		}

		// Render row based on row type
		$this->RowType = EW_ROWTYPE_ADD; // Render add type

		// Render row
		$this->ResetAttrs();
		$this->RenderRow();
	}

	// Get upload files
	function GetUploadFiles() {
		global $objForm, $Language;

		// Get upload data
	}

	// Load default values
	function LoadDefaultValues() {
		$this->projectID->CurrentValue = NULL;
		$this->projectID->OldValue = $this->projectID->CurrentValue;
		$this->MilestoneDate->CurrentValue = NULL;
		$this->MilestoneDate->OldValue = $this->MilestoneDate->CurrentValue;
		$this->Description->CurrentValue = NULL;
		$this->Description->OldValue = $this->Description->CurrentValue;
		$this->Status->CurrentValue = NULL;
		$this->Status->OldValue = $this->Status->CurrentValue;
		$this->Reserved->CurrentValue = NULL;
		$this->Reserved->OldValue = $this->Reserved->CurrentValue;
	}

	// Load form values
	function LoadFormValues() {

		// Load from form
		global $objForm;
		if (!$this->projectID->FldIsDetailKey) {
			$this->projectID->setFormValue($objForm->GetValue("x_projectID"));
		}
		if (!$this->MilestoneDate->FldIsDetailKey) {
			$this->MilestoneDate->setFormValue($objForm->GetValue("x_MilestoneDate"));
			$this->MilestoneDate->CurrentValue = ew_UnFormatDateTime($this->MilestoneDate->CurrentValue, 7);
		}
		if (!$this->Description->FldIsDetailKey) {
			$this->Description->setFormValue($objForm->GetValue("x_Description"));
		}
		if (!$this->Status->FldIsDetailKey) {
			$this->Status->setFormValue($objForm->GetValue("x_Status"));
		}
		if (!$this->Reserved->FldIsDetailKey) {
			$this->Reserved->setFormValue($objForm->GetValue("x_Reserved"));
		}
	}

	// Restore form values
	function RestoreFormValues() {
		global $objForm;
		$this->LoadOldRecord();
		$this->projectID->CurrentValue = $this->projectID->FormValue;
		$this->MilestoneDate->CurrentValue = $this->MilestoneDate->FormValue;
		$this->MilestoneDate->CurrentValue = ew_UnFormatDateTime($this->MilestoneDate->CurrentValue, 7);
		$this->Description->CurrentValue = $this->Description->FormValue;
		$this->Status->CurrentValue = $this->Status->FormValue;
		$this->Reserved->CurrentValue = $this->Reserved->FormValue;
	}

	// Load row based on key values
	function LoadRow() {
		global $Security, $Language;
		$sFilter = $this->KeyFilter();

		// Call Row Selecting event
		$this->Row_Selecting($sFilter);

		// Load SQL based on filter
		$this->CurrentFilter = $sFilter;
		$sSql = $this->SQL();
		$conn = &$this->Connection();
		$res = FALSE;
		$rs = ew_LoadRecordset($sSql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->LoadRowValues($rs); // Load row values
			$rs->Close();
		}
		return $res;
	}

	// Load row values from recordset
	function LoadRowValues(&$rs) {
		if (!$rs || $rs->EOF) return;

		// Call Row Selected event
		$row = &$rs->fields;
		$this->Row_Selected($row);
		$this->id->setDbValue($rs->fields('id'));
		$this->projectID->setDbValue($rs->fields('projectID'));
		$this->MilestoneDate->setDbValue($rs->fields('MilestoneDate'));
		$this->Description->setDbValue($rs->fields('Description'));
		$this->Status->setDbValue($rs->fields('Status'));
		$this->Reserved->setDbValue($rs->fields('Reserved'));
	}

	// Load DbValue from recordset
	function LoadDbValues(&$rs) {
		if (!$rs || !is_array($rs) && $rs->EOF) return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->id->DbValue = $row['id'];
		$this->projectID->DbValue = $row['projectID'];
		$this->MilestoneDate->DbValue = $row['MilestoneDate'];
		$this->Description->DbValue = $row['Description'];
		$this->Status->DbValue = $row['Status'];
		$this->Reserved->DbValue = $row['Reserved'];
	}

	// Load old record
	function LoadOldRecord() {

		// Load key values from Session
		$bValidKey = TRUE;
		if (strval($this->getKey("id")) <> "")
			$this->id->CurrentValue = $this->getKey("id"); // id
		else
			$bValidKey = FALSE;

		// Load old recordset
		if ($bValidKey) {
			$this->CurrentFilter = $this->KeyFilter();
			$sSql = $this->SQL();
			$conn = &$this->Connection();
			$this->OldRecordset = ew_LoadRecordset($sSql, $conn);
			$this->LoadRowValues($this->OldRecordset); // Load row values
		} else {
			$this->OldRecordset = NULL;
		}
		return $bValidKey;
	}

	// Render row values based on field settings
	function RenderRow() {
		global $Security, $Language, $gsLanguage;

		// Initialize URLs
		// Call Row_Rendering event

		$this->Row_Rendering();

		// Common render codes for all row types
		// id
		// projectID
		// MilestoneDate
		// Description
		// Status
		// Reserved

		if ($this->RowType == EW_ROWTYPE_VIEW) { // View row

		// id
		$this->id->ViewValue = $this->id->CurrentValue;
		$this->id->ViewCustomAttributes = "";

		// projectID
		$this->projectID->ViewValue = $this->projectID->CurrentValue;
		if (strval($this->projectID->CurrentValue) <> "") {
			$sFilterWrk = "`id`" . ew_SearchString("=", $this->projectID->CurrentValue, EW_DATATYPE_NUMBER, "");
		$sSqlWrk = "SELECT `id`, `name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `project`";
		$sWhereWrk = "";
		ew_AddFilter($sWhereWrk, $sFilterWrk);
		$this->Lookup_Selecting($this->projectID, $sWhereWrk); // Call Lookup selecting
		if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
			$rswrk = Conn()->Execute($sSqlWrk);
			if ($rswrk && !$rswrk->EOF) { // Lookup values found
				$arwrk = array();
				$arwrk[1] = $rswrk->fields('DispFld');
				$this->projectID->ViewValue = $this->projectID->DisplayValue($arwrk);
				$rswrk->Close();
			} else {
				$this->projectID->ViewValue = $this->projectID->CurrentValue;
			}
		} else {
			$this->projectID->ViewValue = NULL;
		}
		$this->projectID->ViewCustomAttributes = "";

		// MilestoneDate
		$this->MilestoneDate->ViewValue = $this->MilestoneDate->CurrentValue;
		$this->MilestoneDate->ViewValue = ew_FormatDateTime($this->MilestoneDate->ViewValue, 7);
		$this->MilestoneDate->ViewCustomAttributes = "";

		// Description
		$this->Description->ViewValue = $this->Description->CurrentValue;
		$this->Description->ViewCustomAttributes = "";

		// Status
		$this->Status->ViewValue = $this->Status->CurrentValue;
		$this->Status->ViewCustomAttributes = "";

		// Reserved
		$this->Reserved->ViewValue = $this->Reserved->CurrentValue;
		$this->Reserved->ViewCustomAttributes = "";

			// projectID
			$this->projectID->LinkCustomAttributes = "";
			$this->projectID->HrefValue = "";
			$this->projectID->TooltipValue = "";

			// MilestoneDate
			$this->MilestoneDate->LinkCustomAttributes = "";
			$this->MilestoneDate->HrefValue = "";
			$this->MilestoneDate->TooltipValue = "";

			// Description
			$this->Description->LinkCustomAttributes = "";
			$this->Description->HrefValue = "";
			$this->Description->TooltipValue = "";

			// Status
			$this->Status->LinkCustomAttributes = "";
			$this->Status->HrefValue = "";
			$this->Status->TooltipValue = "";

			// Reserved
			$this->Reserved->LinkCustomAttributes = "";
			$this->Reserved->HrefValue = "";
			$this->Reserved->TooltipValue = "";
		} elseif ($this->RowType == EW_ROWTYPE_ADD) { // Add row

			// projectID
			$this->projectID->EditAttrs["class"] = "form-control";
			$this->projectID->EditCustomAttributes = "";
			if ($this->projectID->getSessionValue() <> "") {
				$this->projectID->CurrentValue = $this->projectID->getSessionValue();
			$this->projectID->ViewValue = $this->projectID->CurrentValue;
			if (strval($this->projectID->CurrentValue) <> "") {
				$sFilterWrk = "`id`" . ew_SearchString("=", $this->projectID->CurrentValue, EW_DATATYPE_NUMBER, "");
			$sSqlWrk = "SELECT `id`, `name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `project`";
			$sWhereWrk = "";
			ew_AddFilter($sWhereWrk, $sFilterWrk);
			$this->Lookup_Selecting($this->projectID, $sWhereWrk); // Call Lookup selecting
			if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
				$rswrk = Conn()->Execute($sSqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = array();
					$arwrk[1] = $rswrk->fields('DispFld');
					$this->projectID->ViewValue = $this->projectID->DisplayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->projectID->ViewValue = $this->projectID->CurrentValue;
				}
			} else {
				$this->projectID->ViewValue = NULL;
			}
			$this->projectID->ViewCustomAttributes = "";
			} else {
			$this->projectID->EditValue = ew_HtmlEncode($this->projectID->CurrentValue);
			if (strval($this->projectID->CurrentValue) <> "") {
				$sFilterWrk = "`id`" . ew_SearchString("=", $this->projectID->CurrentValue, EW_DATATYPE_NUMBER, "");
			$sSqlWrk = "SELECT `id`, `name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `project`";
			$sWhereWrk = "";
			ew_AddFilter($sWhereWrk, $sFilterWrk);
			$this->Lookup_Selecting($this->projectID, $sWhereWrk); // Call Lookup selecting
			if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
				$rswrk = Conn()->Execute($sSqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = array();
					$arwrk[1] = ew_HtmlEncode($rswrk->fields('DispFld'));
					$this->projectID->EditValue = $this->projectID->DisplayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->projectID->EditValue = ew_HtmlEncode($this->projectID->CurrentValue);
				}
			} else {
				$this->projectID->EditValue = NULL;
			}
			$this->projectID->PlaceHolder = ew_RemoveHtml($this->projectID->FldCaption());
			}

			// MilestoneDate
			$this->MilestoneDate->EditAttrs["class"] = "form-control";
			$this->MilestoneDate->EditCustomAttributes = "";
			$this->MilestoneDate->EditValue = ew_HtmlEncode(ew_FormatDateTime($this->MilestoneDate->CurrentValue, 7));
			$this->MilestoneDate->PlaceHolder = ew_RemoveHtml($this->MilestoneDate->FldCaption());

			// Description
			$this->Description->EditAttrs["class"] = "form-control";
			$this->Description->EditCustomAttributes = "";
			$this->Description->EditValue = ew_HtmlEncode($this->Description->CurrentValue);
			$this->Description->PlaceHolder = ew_RemoveHtml($this->Description->FldCaption());

			// Status
			$this->Status->EditAttrs["class"] = "form-control";
			$this->Status->EditCustomAttributes = "";
			$this->Status->EditValue = ew_HtmlEncode($this->Status->CurrentValue);
			$this->Status->PlaceHolder = ew_RemoveHtml($this->Status->FldCaption());

			// Reserved
			$this->Reserved->EditAttrs["class"] = "form-control";
			$this->Reserved->EditCustomAttributes = "";
			$this->Reserved->EditValue = ew_HtmlEncode($this->Reserved->CurrentValue);
			$this->Reserved->PlaceHolder = ew_RemoveHtml($this->Reserved->FldCaption());

			// Add refer script
			// projectID

			$this->projectID->LinkCustomAttributes = "";
			$this->projectID->HrefValue = "";

			// MilestoneDate
			$this->MilestoneDate->LinkCustomAttributes = "";
			$this->MilestoneDate->HrefValue = "";

			// Description
			$this->Description->LinkCustomAttributes = "";
			$this->Description->HrefValue = "";

			// Status
			$this->Status->LinkCustomAttributes = "";
			$this->Status->HrefValue = "";

			// Reserved
			$this->Reserved->LinkCustomAttributes = "";
			$this->Reserved->HrefValue = "";
		}
		if ($this->RowType == EW_ROWTYPE_ADD ||
			$this->RowType == EW_ROWTYPE_EDIT ||
			$this->RowType == EW_ROWTYPE_SEARCH) { // Add / Edit / Search row
			$this->SetupFieldTitles();
		}

		// Call Row Rendered event
		if ($this->RowType <> EW_ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate form
	function ValidateForm() {
		global $Language, $gsFormError;

		// Initialize form error message
		$gsFormError = "";

		// Check if validation required
		if (!EW_SERVER_VALIDATE)
			return ($gsFormError == "");
		if (!ew_CheckInteger($this->projectID->FormValue)) {
			ew_AddMessage($gsFormError, $this->projectID->FldErrMsg());
		}
		if (!ew_CheckEuroDate($this->MilestoneDate->FormValue)) {
			ew_AddMessage($gsFormError, $this->MilestoneDate->FldErrMsg());
		}
		if (!ew_CheckInteger($this->Reserved->FormValue)) {
			ew_AddMessage($gsFormError, $this->Reserved->FldErrMsg());
		}

		// Return validate result
		$ValidateForm = ($gsFormError == "");

		// Call Form_CustomValidate event
		$sFormCustomError = "";
		$ValidateForm = $ValidateForm && $this->Form_CustomValidate($sFormCustomError);
		if ($sFormCustomError <> "") {
			ew_AddMessage($gsFormError, $sFormCustomError);
		}
		return $ValidateForm;
	}

	// Add record
	function AddRow($rsold = NULL) {
		global $Language, $Security;

		// Check referential integrity for master table 'project'
		$bValidMasterRecord = TRUE;
		$sMasterFilter = $this->SqlMasterFilter_project();
		if (strval($this->projectID->CurrentValue) <> "") {
			$sMasterFilter = str_replace("@id@", ew_AdjustSql($this->projectID->CurrentValue, "DB"), $sMasterFilter);
		} else {
			$bValidMasterRecord = FALSE;
		}
		if ($bValidMasterRecord) {
			$rsmaster = $GLOBALS["project"]->LoadRs($sMasterFilter);
			$bValidMasterRecord = ($rsmaster && !$rsmaster->EOF);
			$rsmaster->Close();
		}
		if (!$bValidMasterRecord) {
			$sRelatedRecordMsg = str_replace("%t", "project", $Language->Phrase("RelatedRecordRequired"));
			$this->setFailureMessage($sRelatedRecordMsg);
			return FALSE;
		}
		$conn = &$this->Connection();

		// Load db values from rsold
		if ($rsold) {
			$this->LoadDbValues($rsold);
		}
		$rsnew = array();

		// projectID
		$this->projectID->SetDbValueDef($rsnew, $this->projectID->CurrentValue, NULL, FALSE);

		// MilestoneDate
		$this->MilestoneDate->SetDbValueDef($rsnew, ew_UnFormatDateTime($this->MilestoneDate->CurrentValue, 7), NULL, FALSE);

		// Description
		$this->Description->SetDbValueDef($rsnew, $this->Description->CurrentValue, NULL, FALSE);

		// Status
		$this->Status->SetDbValueDef($rsnew, $this->Status->CurrentValue, NULL, FALSE);

		// Reserved
		$this->Reserved->SetDbValueDef($rsnew, $this->Reserved->CurrentValue, NULL, FALSE);

		// Call Row Inserting event
		$rs = ($rsold == NULL) ? NULL : $rsold->fields;
		$bInsertRow = $this->Row_Inserting($rs, $rsnew);
		if ($bInsertRow) {
			$conn->raiseErrorFn = $GLOBALS["EW_ERROR_FN"];
			$AddRow = $this->Insert($rsnew);
			$conn->raiseErrorFn = '';
			if ($AddRow) {

				// Get insert id if necessary
				$this->id->setDbValue($conn->Insert_ID());
				$rsnew['id'] = $this->id->DbValue;
			}
		} else {
			if ($this->getSuccessMessage() <> "" || $this->getFailureMessage() <> "") {

				// Use the message, do nothing
			} elseif ($this->CancelMessage <> "") {
				$this->setFailureMessage($this->CancelMessage);
				$this->CancelMessage = "";
			} else {
				$this->setFailureMessage($Language->Phrase("InsertCancelled"));
			}
			$AddRow = FALSE;
		}
		if ($AddRow) {

			// Call Row Inserted event
			$rs = ($rsold == NULL) ? NULL : $rsold->fields;
			$this->Row_Inserted($rs, $rsnew);
			$this->WriteAuditTrailOnAdd($rsnew);
		}
		return $AddRow;
	}

	// Set up master/detail based on QueryString
	function SetUpMasterParms() {
		$bValidMaster = FALSE;

		// Get the keys for master table
		if (isset($_GET[EW_TABLE_SHOW_MASTER])) {
			$sMasterTblVar = $_GET[EW_TABLE_SHOW_MASTER];
			if ($sMasterTblVar == "") {
				$bValidMaster = TRUE;
				$this->DbMasterFilter = "";
				$this->DbDetailFilter = "";
			}
			if ($sMasterTblVar == "project") {
				$bValidMaster = TRUE;
				if (@$_GET["fk_id"] <> "") {
					$GLOBALS["project"]->id->setQueryStringValue($_GET["fk_id"]);
					$this->projectID->setQueryStringValue($GLOBALS["project"]->id->QueryStringValue);
					$this->projectID->setSessionValue($this->projectID->QueryStringValue);
					if (!is_numeric($GLOBALS["project"]->id->QueryStringValue)) $bValidMaster = FALSE;
				} else {
					$bValidMaster = FALSE;
				}
			}
		} elseif (isset($_POST[EW_TABLE_SHOW_MASTER])) {
			$sMasterTblVar = $_POST[EW_TABLE_SHOW_MASTER];
			if ($sMasterTblVar == "") {
				$bValidMaster = TRUE;
				$this->DbMasterFilter = "";
				$this->DbDetailFilter = "";
			}
			if ($sMasterTblVar == "project") {
				$bValidMaster = TRUE;
				if (@$_POST["fk_id"] <> "") {
					$GLOBALS["project"]->id->setFormValue($_POST["fk_id"]);
					$this->projectID->setFormValue($GLOBALS["project"]->id->FormValue);
					$this->projectID->setSessionValue($this->projectID->FormValue);
					if (!is_numeric($GLOBALS["project"]->id->FormValue)) $bValidMaster = FALSE;
				} else {
					$bValidMaster = FALSE;
				}
			}
		}
		if ($bValidMaster) {

			// Save current master table
			$this->setCurrentMasterTable($sMasterTblVar);

			// Reset start record counter (new master key)
			$this->StartRec = 1;
			$this->setStartRecordNumber($this->StartRec);

			// Clear previous master key from Session
			if ($sMasterTblVar <> "project") {
				if ($this->projectID->CurrentValue == "") $this->projectID->setSessionValue("");
			}
		}
		$this->DbMasterFilter = $this->GetMasterFilter(); // Get master filter
		$this->DbDetailFilter = $this->GetDetailFilter(); // Get detail filter
	}

	// Set up Breadcrumb
	function SetupBreadcrumb() {
		global $Breadcrumb, $Language;
		$Breadcrumb = new cBreadcrumb();
		$url = substr(ew_CurrentUrl(), strrpos(ew_CurrentUrl(), "/")+1);
		$Breadcrumb->Add("list", $this->TableVar, $this->AddMasterUrl("milestoneslist.php"), "", $this->TableVar, TRUE);
		$PageId = ($this->CurrentAction == "C") ? "Copy" : "Add";
		$Breadcrumb->Add("add", $PageId, $url);
	}

	// Write Audit Trail start/end for grid update
	function WriteAuditTrailDummy($typ) {
		$table = 'milestones';
		$usr = CurrentUserID();
		ew_WriteAuditTrail("log", ew_StdCurrentDateTime(), ew_ScriptName(), $usr, $typ, $table, "", "", "", "");
	}

	// Write Audit Trail (add page)
	function WriteAuditTrailOnAdd(&$rs) {
		global $Language;
		if (!$this->AuditTrailOnAdd) return;
		$table = 'milestones';

		// Get key value
		$key = "";
		if ($key <> "") $key .= $GLOBALS["EW_COMPOSITE_KEY_SEPARATOR"];
		$key .= $rs['id'];

		// Write Audit Trail
		$dt = ew_StdCurrentDateTime();
		$id = ew_ScriptName();
		$usr = CurrentUserID();
		foreach (array_keys($rs) as $fldname) {
			if ($this->fields[$fldname]->FldDataType <> EW_DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->FldHtmlTag == "PASSWORD") {
					$newvalue = $Language->Phrase("PasswordMask"); // Password Field
				} elseif ($this->fields[$fldname]->FldDataType == EW_DATATYPE_MEMO) {
					if (EW_AUDIT_TRAIL_TO_DATABASE)
						$newvalue = $rs[$fldname];
					else
						$newvalue = "[MEMO]"; // Memo Field
				} elseif ($this->fields[$fldname]->FldDataType == EW_DATATYPE_XML) {
					$newvalue = "[XML]"; // XML Field
				} else {
					$newvalue = $rs[$fldname];
				}
				ew_WriteAuditTrail("log", $dt, $id, $usr, "A", $table, $fldname, $key, "", $newvalue);
			}
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$CustomError) {

		// Return error message in CustomError
		return TRUE;
	}
}
?>
<?php ew_Header(FALSE) ?>
<?php

// Create page object
if (!isset($milestones_add)) $milestones_add = new cmilestones_add();

// Page init
$milestones_add->Page_Init();

// Page main
$milestones_add->Page_Main();

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$milestones_add->Page_Render();
?>
<?php include_once "header.php" ?>
<script type="text/javascript">

// Form object
var CurrentPageID = EW_PAGE_ID = "add";
var CurrentForm = fmilestonesadd = new ew_Form("fmilestonesadd", "add");

// Validate form
fmilestonesadd.Validate = function() {
	if (!this.ValidateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.GetForm(), $fobj = $(fobj);
	if ($fobj.find("#a_confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.FormKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = $fobj.find("#a_list").val() == "gridinsert";
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
			elm = this.GetElements("x" + infix + "_projectID");
			if (elm && !ew_CheckInteger(elm.value))
				return this.OnError(elm, "<?php echo ew_JsEncode2($milestones->projectID->FldErrMsg()) ?>");
			elm = this.GetElements("x" + infix + "_MilestoneDate");
			if (elm && !ew_CheckEuroDate(elm.value))
				return this.OnError(elm, "<?php echo ew_JsEncode2($milestones->MilestoneDate->FldErrMsg()) ?>");
			elm = this.GetElements("x" + infix + "_Reserved");
			if (elm && !ew_CheckInteger(elm.value))
				return this.OnError(elm, "<?php echo ew_JsEncode2($milestones->Reserved->FldErrMsg()) ?>");

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
	}

	// Process detail forms
	var dfs = $fobj.find("input[name='detailpage']").get();
	for (var i = 0; i < dfs.length; i++) {
		var df = dfs[i], val = df.value;
		if (val && ewForms[val])
			if (!ewForms[val].Validate())
				return false;
	}
	return true;
}

// Form_CustomValidate event
fmilestonesadd.Form_CustomValidate = 
 function(fobj) { // DO NOT CHANGE THIS LINE!

 	// Your custom validation code here, return false if invalid. 
 	return true;
 }

// Use JavaScript validation or not
<?php if (EW_CLIENT_VALIDATE) { ?>
fmilestonesadd.ValidateRequired = true;
<?php } else { ?>
fmilestonesadd.ValidateRequired = false; 
<?php } ?>

// Dynamic selection lists
fmilestonesadd.Lists["x_projectID"] = {"LinkField":"x_id","Ajax":true,"AutoFill":false,"DisplayFields":["x_name","","",""],"ParentFields":[],"ChildFields":[],"FilterFields":[],"Options":[],"Template":""};

// Form object for search
</script>
<script type="text/javascript">

// Write your client script here, no need to add script tags.
</script>
<div class="ewToolbar">
<?php $Breadcrumb->Render(); ?>
<?php echo $Language->SelectionForm(); ?>
<div class="clearfix"></div>
</div>
<?php $milestones_add->ShowPageHeader(); ?>
<?php
$milestones_add->ShowMessage();
?>
<form name="fmilestonesadd" id="fmilestonesadd" class="<?php echo $milestones_add->FormClassName ?>" action="<?php echo ew_CurrentPage() ?>" method="post">
<?php if ($milestones_add->CheckToken) { ?>
<input type="hidden" name="<?php echo EW_TOKEN_NAME ?>" value="<?php echo $milestones_add->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="milestones">
<input type="hidden" name="a_add" id="a_add" value="A">
<?php if ($milestones->getCurrentMasterTable() == "project") { ?>
<input type="hidden" name="<?php echo EW_TABLE_SHOW_MASTER ?>" value="project">
<input type="hidden" name="fk_id" value="<?php echo $milestones->projectID->getSessionValue() ?>">
<?php } ?>
<div>
<?php if ($milestones->projectID->Visible) { // projectID ?>
	<div id="r_projectID" class="form-group">
		<label id="elh_milestones_projectID" class="col-sm-2 control-label ewLabel"><?php echo $milestones->projectID->FldCaption() ?></label>
		<div class="col-sm-10"><div<?php echo $milestones->projectID->CellAttributes() ?>>
<?php if ($milestones->projectID->getSessionValue() <> "") { ?>
<span id="el_milestones_projectID">
<span<?php echo $milestones->projectID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $milestones->projectID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x_projectID" name="x_projectID" value="<?php echo ew_HtmlEncode($milestones->projectID->CurrentValue) ?>">
<?php } else { ?>
<span id="el_milestones_projectID">
<?php
$wrkonchange = trim(" " . @$milestones->projectID->EditAttrs["onchange"]);
if ($wrkonchange <> "") $wrkonchange = " onchange=\"" . ew_JsEncode2($wrkonchange) . "\"";
$milestones->projectID->EditAttrs["onchange"] = "";
?>
<span id="as_x_projectID" style="white-space: nowrap; z-index: 8980">
	<input type="text" name="sv_x_projectID" id="sv_x_projectID" value="<?php echo $milestones->projectID->EditValue ?>" size="30" placeholder="<?php echo ew_HtmlEncode($milestones->projectID->getPlaceHolder()) ?>" data-placeholder="<?php echo ew_HtmlEncode($milestones->projectID->getPlaceHolder()) ?>"<?php echo $milestones->projectID->EditAttributes() ?>>
</span>
<input type="hidden" data-table="milestones" data-field="x_projectID" data-value-separator="<?php echo ew_HtmlEncode(is_array($milestones->projectID->DisplayValueSeparator) ? json_encode($milestones->projectID->DisplayValueSeparator) : $milestones->projectID->DisplayValueSeparator) ?>" name="x_projectID" id="x_projectID" value="<?php echo ew_HtmlEncode($milestones->projectID->CurrentValue) ?>"<?php echo $wrkonchange ?>>
<?php
$sSqlWrk = "SELECT `id`, `name` AS `DispFld` FROM `project`";
$sWhereWrk = "`name` LIKE '%{query_value}%'";
$milestones->Lookup_Selecting($milestones->projectID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
$sSqlWrk .= " LIMIT " . EW_AUTO_SUGGEST_MAX_ENTRIES;
?>
<input type="hidden" name="q_x_projectID" id="q_x_projectID" value="s=<?php echo ew_Encrypt($sSqlWrk) ?>&d=">
<script type="text/javascript">
fmilestonesadd.CreateAutoSuggest({"id":"x_projectID","forceSelect":false});
</script>
</span>
<?php } ?>
<?php echo $milestones->projectID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($milestones->MilestoneDate->Visible) { // MilestoneDate ?>
	<div id="r_MilestoneDate" class="form-group">
		<label id="elh_milestones_MilestoneDate" for="x_MilestoneDate" class="col-sm-2 control-label ewLabel"><?php echo $milestones->MilestoneDate->FldCaption() ?></label>
		<div class="col-sm-10"><div<?php echo $milestones->MilestoneDate->CellAttributes() ?>>
<span id="el_milestones_MilestoneDate">
<input type="text" data-table="milestones" data-field="x_MilestoneDate" data-format="7" name="x_MilestoneDate" id="x_MilestoneDate" placeholder="<?php echo ew_HtmlEncode($milestones->MilestoneDate->getPlaceHolder()) ?>" value="<?php echo $milestones->MilestoneDate->EditValue ?>"<?php echo $milestones->MilestoneDate->EditAttributes() ?>>
<?php if (!$milestones->MilestoneDate->ReadOnly && !$milestones->MilestoneDate->Disabled && !isset($milestones->MilestoneDate->EditAttrs["readonly"]) && !isset($milestones->MilestoneDate->EditAttrs["disabled"])) { ?>
<script type="text/javascript">
ew_CreateCalendar("fmilestonesadd", "x_MilestoneDate", "%d/%m/%Y");
</script>
<?php } ?>
</span>
<?php echo $milestones->MilestoneDate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($milestones->Description->Visible) { // Description ?>
	<div id="r_Description" class="form-group">
		<label id="elh_milestones_Description" for="x_Description" class="col-sm-2 control-label ewLabel"><?php echo $milestones->Description->FldCaption() ?></label>
		<div class="col-sm-10"><div<?php echo $milestones->Description->CellAttributes() ?>>
<span id="el_milestones_Description">
<input type="text" data-table="milestones" data-field="x_Description" name="x_Description" id="x_Description" size="30" maxlength="255" placeholder="<?php echo ew_HtmlEncode($milestones->Description->getPlaceHolder()) ?>" value="<?php echo $milestones->Description->EditValue ?>"<?php echo $milestones->Description->EditAttributes() ?>>
</span>
<?php echo $milestones->Description->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($milestones->Status->Visible) { // Status ?>
	<div id="r_Status" class="form-group">
		<label id="elh_milestones_Status" for="x_Status" class="col-sm-2 control-label ewLabel"><?php echo $milestones->Status->FldCaption() ?></label>
		<div class="col-sm-10"><div<?php echo $milestones->Status->CellAttributes() ?>>
<span id="el_milestones_Status">
<input type="text" data-table="milestones" data-field="x_Status" name="x_Status" id="x_Status" size="30" maxlength="20" placeholder="<?php echo ew_HtmlEncode($milestones->Status->getPlaceHolder()) ?>" value="<?php echo $milestones->Status->EditValue ?>"<?php echo $milestones->Status->EditAttributes() ?>>
</span>
<?php echo $milestones->Status->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($milestones->Reserved->Visible) { // Reserved ?>
	<div id="r_Reserved" class="form-group">
		<label id="elh_milestones_Reserved" for="x_Reserved" class="col-sm-2 control-label ewLabel"><?php echo $milestones->Reserved->FldCaption() ?></label>
		<div class="col-sm-10"><div<?php echo $milestones->Reserved->CellAttributes() ?>>
<span id="el_milestones_Reserved">
<input type="text" data-table="milestones" data-field="x_Reserved" name="x_Reserved" id="x_Reserved" size="30" placeholder="<?php echo ew_HtmlEncode($milestones->Reserved->getPlaceHolder()) ?>" value="<?php echo $milestones->Reserved->EditValue ?>"<?php echo $milestones->Reserved->EditAttributes() ?>>
</span>
<?php echo $milestones->Reserved->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div>
<div class="form-group">
	<div class="col-sm-offset-2 col-sm-10">
<button class="btn btn-primary ewButton" name="btnAction" id="btnAction" type="submit"><?php echo $Language->Phrase("AddBtn") ?></button>
<button class="btn btn-default ewButton" name="btnCancel" id="btnCancel" type="button" data-href="<?php echo $milestones_add->getReturnUrl() ?>"><?php echo $Language->Phrase("CancelBtn") ?></button>
	</div>
</div>
</form>
<script type="text/javascript">
fmilestonesadd.Init();
</script>
<?php
$milestones_add->ShowPageFooter();
if (EW_DEBUG_ENABLED)
	echo ew_DebugMsg();
?>
<script type="text/javascript">

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$milestones_add->Page_Terminate();
?>
