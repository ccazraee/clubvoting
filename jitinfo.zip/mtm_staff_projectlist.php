<?php
if (session_id() == "") session_start(); // Initialize Session data
ob_start(); // Turn on output buffering
?>
<?php include_once "ewcfg12.php" ?>
<?php include_once ((EW_USE_ADODB) ? "adodb5/adodb.inc.php" : "ewmysql12.php") ?>
<?php include_once "phpfn12.php" ?>
<?php include_once "mtm_staff_projectinfo.php" ?>
<?php include_once "projectinfo.php" ?>
<?php include_once "staffinfo.php" ?>
<?php include_once "userfn12.php" ?>
<?php

//
// Page class
//

$mtm_staff_project_list = NULL; // Initialize page object first

class cmtm_staff_project_list extends cmtm_staff_project {

	// Page ID
	var $PageID = 'list';

	// Project ID
	var $ProjectID = "{E654CCD7-163B-4B2E-BFA7-AC8697684A42}";

	// Table name
	var $TableName = 'mtm_staff_project';

	// Page object name
	var $PageObjName = 'mtm_staff_project_list';

	// Grid form hidden field names
	var $FormName = 'fmtm_staff_projectlist';
	var $FormActionName = 'k_action';
	var $FormKeyName = 'k_key';
	var $FormOldKeyName = 'k_oldkey';
	var $FormBlankRowName = 'k_blankrow';
	var $FormKeyCountName = 'key_count';

	// Page name
	function PageName() {
		return ew_CurrentPage();
	}

	// Page URL
	function PageUrl() {
		$PageUrl = ew_CurrentPage() . "?";
		if ($this->UseTokenInUrl) $PageUrl .= "t=" . $this->TableVar . "&"; // Add page token
		return $PageUrl;
	}

	// Page URLs
	var $AddUrl;
	var $EditUrl;
	var $CopyUrl;
	var $DeleteUrl;
	var $ViewUrl;
	var $ListUrl;

	// Export URLs
	var $ExportPrintUrl;
	var $ExportHtmlUrl;
	var $ExportExcelUrl;
	var $ExportWordUrl;
	var $ExportXmlUrl;
	var $ExportCsvUrl;
	var $ExportPdfUrl;

	// Custom export
	var $ExportExcelCustom = FALSE;
	var $ExportWordCustom = FALSE;
	var $ExportPdfCustom = FALSE;
	var $ExportEmailCustom = FALSE;

	// Update URLs
	var $InlineAddUrl;
	var $InlineCopyUrl;
	var $InlineEditUrl;
	var $GridAddUrl;
	var $GridEditUrl;
	var $MultiDeleteUrl;
	var $MultiUpdateUrl;
    var $AuditTrailOnAdd = TRUE;
    var $AuditTrailOnEdit = TRUE;
    var $AuditTrailOnDelete = TRUE;
    var $AuditTrailOnView = FALSE;
    var $AuditTrailOnViewData = FALSE;
    var $AuditTrailOnSearch = FALSE;

	// Message
	function getMessage() {
		return @$_SESSION[EW_SESSION_MESSAGE];
	}

	function setMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_MESSAGE], $v);
	}

	function getFailureMessage() {
		return @$_SESSION[EW_SESSION_FAILURE_MESSAGE];
	}

	function setFailureMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_FAILURE_MESSAGE], $v);
	}

	function getSuccessMessage() {
		return @$_SESSION[EW_SESSION_SUCCESS_MESSAGE];
	}

	function setSuccessMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_SUCCESS_MESSAGE], $v);
	}

	function getWarningMessage() {
		return @$_SESSION[EW_SESSION_WARNING_MESSAGE];
	}

	function setWarningMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_WARNING_MESSAGE], $v);
	}

	// Methods to clear message
	function ClearMessage() {
		$_SESSION[EW_SESSION_MESSAGE] = "";
	}

	function ClearFailureMessage() {
		$_SESSION[EW_SESSION_FAILURE_MESSAGE] = "";
	}

	function ClearSuccessMessage() {
		$_SESSION[EW_SESSION_SUCCESS_MESSAGE] = "";
	}

	function ClearWarningMessage() {
		$_SESSION[EW_SESSION_WARNING_MESSAGE] = "";
	}

	function ClearMessages() {
		$_SESSION[EW_SESSION_MESSAGE] = "";
		$_SESSION[EW_SESSION_FAILURE_MESSAGE] = "";
		$_SESSION[EW_SESSION_SUCCESS_MESSAGE] = "";
		$_SESSION[EW_SESSION_WARNING_MESSAGE] = "";
	}

	// Show message
	function ShowMessage() {
		$hidden = FALSE;
		$html = "";

		// Message
		$sMessage = $this->getMessage();
		$this->Message_Showing($sMessage, "");
		if ($sMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sMessage;
			$html .= "<div class=\"alert alert-info ewInfo\">" . $sMessage . "</div>";
			$_SESSION[EW_SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$sWarningMessage = $this->getWarningMessage();
		$this->Message_Showing($sWarningMessage, "warning");
		if ($sWarningMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sWarningMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sWarningMessage;
			$html .= "<div class=\"alert alert-warning ewWarning\">" . $sWarningMessage . "</div>";
			$_SESSION[EW_SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$sSuccessMessage = $this->getSuccessMessage();
		$this->Message_Showing($sSuccessMessage, "success");
		if ($sSuccessMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sSuccessMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sSuccessMessage;
			$html .= "<div class=\"alert alert-success ewSuccess\">" . $sSuccessMessage . "</div>";
			$_SESSION[EW_SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$sErrorMessage = $this->getFailureMessage();
		$this->Message_Showing($sErrorMessage, "failure");
		if ($sErrorMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sErrorMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sErrorMessage;
			$html .= "<div class=\"alert alert-danger ewError\">" . $sErrorMessage . "</div>";
			$_SESSION[EW_SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo "<div class=\"ewMessageDialog\"" . (($hidden) ? " style=\"display: none;\"" : "") . ">" . $html . "</div>";
	}
	var $PageHeader;
	var $PageFooter;

	// Show Page Header
	function ShowPageHeader() {
		$sHeader = $this->PageHeader;
		$this->Page_DataRendering($sHeader);
		if ($sHeader <> "") { // Header exists, display
			echo "<p>" . $sHeader . "</p>";
		}
	}

	// Show Page Footer
	function ShowPageFooter() {
		$sFooter = $this->PageFooter;
		$this->Page_DataRendered($sFooter);
		if ($sFooter <> "") { // Footer exists, display
			echo "<p>" . $sFooter . "</p>";
		}
	}

	// Validate page request
	function IsPageRequest() {
		global $objForm;
		if ($this->UseTokenInUrl) {
			if ($objForm)
				return ($this->TableVar == $objForm->GetValue("t"));
			if (@$_GET["t"] <> "")
				return ($this->TableVar == $_GET["t"]);
		} else {
			return TRUE;
		}
	}
	var $Token = "";
	var $TokenTimeout = 0;
	var $CheckToken = EW_CHECK_TOKEN;
	var $CheckTokenFn = "ew_CheckToken";
	var $CreateTokenFn = "ew_CreateToken";

	// Valid Post
	function ValidPost() {
		if (!$this->CheckToken || !ew_IsHttpPost())
			return TRUE;
		if (!isset($_POST[EW_TOKEN_NAME]))
			return FALSE;
		$fn = $this->CheckTokenFn;
		if (is_callable($fn))
			return $fn($_POST[EW_TOKEN_NAME], $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	function CreateToken() {
		global $gsToken;
		if ($this->CheckToken) {
			$fn = $this->CreateTokenFn;
			if ($this->Token == "" && is_callable($fn)) // Create token
				$this->Token = $fn();
			$gsToken = $this->Token; // Save to global variable
		}
	}

	//
	// Page class constructor
	//
	function __construct() {
		global $conn, $Language;
		global $UserTable, $UserTableConn;
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = ew_SessionTimeoutTime();

		// Language object
		if (!isset($Language)) $Language = new cLanguage();

		// Parent constuctor
		parent::__construct();

		// Table object (mtm_staff_project)
		if (!isset($GLOBALS["mtm_staff_project"]) || get_class($GLOBALS["mtm_staff_project"]) == "cmtm_staff_project") {
			$GLOBALS["mtm_staff_project"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["mtm_staff_project"];
		}

		// Initialize URLs
		$this->ExportPrintUrl = $this->PageUrl() . "export=print";
		$this->ExportExcelUrl = $this->PageUrl() . "export=excel";
		$this->ExportWordUrl = $this->PageUrl() . "export=word";
		$this->ExportHtmlUrl = $this->PageUrl() . "export=html";
		$this->ExportXmlUrl = $this->PageUrl() . "export=xml";
		$this->ExportCsvUrl = $this->PageUrl() . "export=csv";
		$this->ExportPdfUrl = $this->PageUrl() . "export=pdf";
		$this->AddUrl = "mtm_staff_projectadd.php";
		$this->InlineAddUrl = $this->PageUrl() . "a=add";
		$this->GridAddUrl = $this->PageUrl() . "a=gridadd";
		$this->GridEditUrl = $this->PageUrl() . "a=gridedit";
		$this->MultiDeleteUrl = "mtm_staff_projectdelete.php";
		$this->MultiUpdateUrl = "mtm_staff_projectupdate.php";

		// Table object (project)
		if (!isset($GLOBALS['project'])) $GLOBALS['project'] = new cproject();

		// Table object (staff)
		if (!isset($GLOBALS['staff'])) $GLOBALS['staff'] = new cstaff();

		// Page ID
		if (!defined("EW_PAGE_ID"))
			define("EW_PAGE_ID", 'list', TRUE);

		// Table name (for backward compatibility)
		if (!defined("EW_TABLE_NAME"))
			define("EW_TABLE_NAME", 'mtm_staff_project', TRUE);

		// Start timer
		if (!isset($GLOBALS["gTimer"])) $GLOBALS["gTimer"] = new cTimer();

		// Open connection
		if (!isset($conn)) $conn = ew_Connect($this->DBID);

		// User table object (staff)
		if (!isset($UserTable)) {
			$UserTable = new cstaff();
			$UserTableConn = Conn($UserTable->DBID);
		}

		// List options
		$this->ListOptions = new cListOptions();
		$this->ListOptions->TableVar = $this->TableVar;

		// Export options
		$this->ExportOptions = new cListOptions();
		$this->ExportOptions->Tag = "div";
		$this->ExportOptions->TagClassName = "ewExportOption";

		// Other options
		$this->OtherOptions['addedit'] = new cListOptions();
		$this->OtherOptions['addedit']->Tag = "div";
		$this->OtherOptions['addedit']->TagClassName = "ewAddEditOption";
		$this->OtherOptions['detail'] = new cListOptions();
		$this->OtherOptions['detail']->Tag = "div";
		$this->OtherOptions['detail']->TagClassName = "ewDetailOption";
		$this->OtherOptions['action'] = new cListOptions();
		$this->OtherOptions['action']->Tag = "div";
		$this->OtherOptions['action']->TagClassName = "ewActionOption";

		// Filter options
		$this->FilterOptions = new cListOptions();
		$this->FilterOptions->Tag = "div";
		$this->FilterOptions->TagClassName = "ewFilterOption fmtm_staff_projectlistsrch";

		// List actions
		$this->ListActions = new cListActions();
	}

	// 
	//  Page_Init
	//
	function Page_Init() {
		global $gsExport, $gsCustomExport, $gsExportFile, $UserProfile, $Language, $Security, $objForm;

		// Security
		$Security = new cAdvancedSecurity();
		if (!$Security->IsLoggedIn()) $Security->AutoLogin();
		if ($Security->IsLoggedIn()) $Security->TablePermission_Loading();
		$Security->LoadCurrentUserLevel($this->ProjectID . $this->TableName);
		if ($Security->IsLoggedIn()) $Security->TablePermission_Loaded();
		if (!$Security->CanList()) {
			$Security->SaveLastUrl();
			$this->setFailureMessage(ew_DeniedMsg()); // Set no permission
			$this->Page_Terminate(ew_GetUrl("login.php"));
		}
		if ($Security->IsLoggedIn()) {
			$Security->UserID_Loading();
			$Security->LoadUserID();
			$Security->UserID_Loaded();
		}

		// Create form object
		$objForm = new cFormObj();

		// Get export parameters
		$custom = "";
		if (@$_GET["export"] <> "") {
			$this->Export = $_GET["export"];
			$custom = @$_GET["custom"];
		} elseif (@$_POST["export"] <> "") {
			$this->Export = $_POST["export"];
			$custom = @$_POST["custom"];
		} elseif (ew_IsHttpPost()) {
			if (@$_POST["exporttype"] <> "")
				$this->Export = $_POST["exporttype"];
			$custom = @$_POST["custom"];
		} else {
			$this->setExportReturnUrl(ew_CurrentUrl());
		}
		$gsExportFile = $this->TableVar; // Get export file, used in header

		// Get custom export parameters
		if ($this->Export <> "" && $custom <> "") {
			$this->CustomExport = $this->Export;
			$this->Export = "print";
		}
		$gsCustomExport = $this->CustomExport;
		$gsExport = $this->Export; // Get export parameter, used in header

		// Update Export URLs
		if (defined("EW_USE_PHPEXCEL"))
			$this->ExportExcelCustom = FALSE;
		if ($this->ExportExcelCustom)
			$this->ExportExcelUrl .= "&amp;custom=1";
		if (defined("EW_USE_PHPWORD"))
			$this->ExportWordCustom = FALSE;
		if ($this->ExportWordCustom)
			$this->ExportWordUrl .= "&amp;custom=1";
		if ($this->ExportPdfCustom)
			$this->ExportPdfUrl .= "&amp;custom=1";
		$this->CurrentAction = (@$_GET["a"] <> "") ? $_GET["a"] : @$_POST["a_list"]; // Set up current action

		// Get grid add count
		$gridaddcnt = @$_GET[EW_TABLE_GRID_ADD_ROW_COUNT];
		if (is_numeric($gridaddcnt) && $gridaddcnt > 0)
			$this->GridAddRowCount = $gridaddcnt;

		// Set up list options
		$this->SetupListOptions();

		// Setup export options
		$this->SetupExportOptions();

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->ValidPost()) {
			echo $Language->Phrase("InvalidPostRequest");
			$this->Page_Terminate();
			exit();
		}

		// Process auto fill
		if (@$_POST["ajax"] == "autofill") {
			$results = $this->GetAutoFill(@$_POST["name"], @$_POST["q"]);
			if ($results) {

				// Clean output buffer
				if (!EW_DEBUG_ENABLED && ob_get_length())
					ob_end_clean();
				echo $results;
				$this->Page_Terminate();
				exit();
			}
		}

		// Create Token
		$this->CreateToken();

		// Set up master detail parameters
		$this->SetUpMasterParms();

		// Setup other options
		$this->SetupOtherOptions();

		// Set up custom action (compatible with old version)
		foreach ($this->CustomActions as $name => $action)
			$this->ListActions->Add($name, $action);

		// Show checkbox column if multiple action
		foreach ($this->ListActions->Items as $listaction) {
			if ($listaction->Select == EW_ACTION_MULTIPLE && $listaction->Allow) {
				$this->ListOptions->Items["checkbox"]->Visible = TRUE;
				break;
			}
		}
	}

	//
	// Page_Terminate
	//
	function Page_Terminate($url = "") {
		global $gsExportFile, $gTmpImages;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $EW_EXPORT, $mtm_staff_project;
		if ($this->CustomExport <> "" && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, $EW_EXPORT)) {
				$sContent = ob_get_contents();
			if ($gsExportFile == "") $gsExportFile = $this->TableVar;
			$class = $EW_EXPORT[$this->CustomExport];
			if (class_exists($class)) {
				$doc = new $class($mtm_staff_project);
				$doc->Text = $sContent;
				if ($this->Export == "email")
					echo $this->ExportEmail($doc->Text);
				else
					$doc->Export();
				ew_DeleteTmpImages(); // Delete temp images
				exit();
			}
		}
		$this->Page_Redirecting($url);

		 // Close connection
		ew_CloseConn();

		// Go to URL if specified
		if ($url <> "") {
			if (!EW_DEBUG_ENABLED && ob_get_length())
				ob_end_clean();
			header("Location: " . $url);
		}
		exit();
	}

	// Class variables
	var $ListOptions; // List options
	var $ExportOptions; // Export options
	var $SearchOptions; // Search options
	var $OtherOptions = array(); // Other options
	var $FilterOptions; // Filter options
	var $ListActions; // List actions
	var $SelectedCount = 0;
	var $SelectedIndex = 0;
	var $DisplayRecs = 50;
	var $StartRec;
	var $StopRec;
	var $TotalRecs = 0;
	var $RecRange = 10;
	var $Pager;
	var $DefaultSearchWhere = ""; // Default search WHERE clause
	var $SearchWhere = ""; // Search WHERE clause
	var $RecCnt = 0; // Record count
	var $EditRowCnt;
	var $StartRowCnt = 1;
	var $RowCnt = 0;
	var $Attrs = array(); // Row attributes and cell attributes
	var $RowIndex = 0; // Row index
	var $KeyCount = 0; // Key count
	var $RowAction = ""; // Row action
	var $RowOldKey = ""; // Row old key (for copy)
	var $RecPerRow = 0;
	var $MultiColumnClass;
	var $MultiColumnEditClass = "col-sm-12";
	var $MultiColumnCnt = 12;
	var $MultiColumnEditCnt = 12;
	var $GridCnt = 0;
	var $ColCnt = 0;
	var $DbMasterFilter = ""; // Master filter
	var $DbDetailFilter = ""; // Detail filter
	var $MasterRecordExists;	
	var $MultiSelectKey;
	var $Command;
	var $RestoreSearch = FALSE;
	var $DetailPages;
	var $Recordset;
	var $OldRecordset;

	//
	// Page main
	//
	function Page_Main() {
		global $objForm, $Language, $gsFormError, $gsSearchError, $Security;

		// Search filters
		$sSrchAdvanced = ""; // Advanced search filter
		$sSrchBasic = ""; // Basic search filter
		$sFilter = "";

		// Get command
		$this->Command = strtolower(@$_GET["cmd"]);
		if ($this->IsPageRequest()) { // Validate request

			// Process list action first
			if ($this->ProcessListAction()) // Ajax request
				$this->Page_Terminate();

			// Set up records per page
			$this->SetUpDisplayRecs();

			// Handle reset command
			$this->ResetCmd();

			// Set up Breadcrumb
			if ($this->Export == "")
				$this->SetupBreadcrumb();

			// Check QueryString parameters
			if (@$_GET["a"] <> "") {
				$this->CurrentAction = $_GET["a"];

				// Clear inline mode
				if ($this->CurrentAction == "cancel")
					$this->ClearInlineMode();

				// Switch to grid edit mode
				if ($this->CurrentAction == "gridedit")
					$this->GridEditMode();

				// Switch to inline edit mode
				if ($this->CurrentAction == "edit")
					$this->InlineEditMode();

				// Switch to inline add mode
				if ($this->CurrentAction == "add" || $this->CurrentAction == "copy")
					$this->InlineAddMode();

				// Switch to grid add mode
				if ($this->CurrentAction == "gridadd")
					$this->GridAddMode();
			} else {
				if (@$_POST["a_list"] <> "") {
					$this->CurrentAction = $_POST["a_list"]; // Get action

					// Grid Update
					if (($this->CurrentAction == "gridupdate" || $this->CurrentAction == "gridoverwrite") && @$_SESSION[EW_SESSION_INLINE_MODE] == "gridedit") {
						if ($this->ValidateGridForm()) {
							$bGridUpdate = $this->GridUpdate();
						} else {
							$bGridUpdate = FALSE;
							$this->setFailureMessage($gsFormError);
						}
						if (!$bGridUpdate) {
							$this->EventCancelled = TRUE;
							$this->CurrentAction = "gridedit"; // Stay in Grid Edit mode
						}
					}

					// Inline Update
					if (($this->CurrentAction == "update" || $this->CurrentAction == "overwrite") && @$_SESSION[EW_SESSION_INLINE_MODE] == "edit")
						$this->InlineUpdate();

					// Insert Inline
					if ($this->CurrentAction == "insert" && @$_SESSION[EW_SESSION_INLINE_MODE] == "add")
						$this->InlineInsert();

					// Grid Insert
					if ($this->CurrentAction == "gridinsert" && @$_SESSION[EW_SESSION_INLINE_MODE] == "gridadd") {
						if ($this->ValidateGridForm()) {
							$bGridInsert = $this->GridInsert();
						} else {
							$bGridInsert = FALSE;
							$this->setFailureMessage($gsFormError);
						}
						if (!$bGridInsert) {
							$this->EventCancelled = TRUE;
							$this->CurrentAction = "gridadd"; // Stay in Grid Add mode
						}
					}
				}
			}

			// Hide list options
			if ($this->Export <> "") {
				$this->ListOptions->HideAllOptions(array("sequence"));
				$this->ListOptions->UseDropDownButton = FALSE; // Disable drop down button
				$this->ListOptions->UseButtonGroup = FALSE; // Disable button group
			} elseif ($this->CurrentAction == "gridadd" || $this->CurrentAction == "gridedit") {
				$this->ListOptions->HideAllOptions();
				$this->ListOptions->UseDropDownButton = FALSE; // Disable drop down button
				$this->ListOptions->UseButtonGroup = FALSE; // Disable button group
			}

			// Hide options
			if ($this->Export <> "" || $this->CurrentAction <> "") {
				$this->ExportOptions->HideAllOptions();
				$this->FilterOptions->HideAllOptions();
			}

			// Hide other options
			if ($this->Export <> "") {
				foreach ($this->OtherOptions as &$option)
					$option->HideAllOptions();
			}

			// Show grid delete link for grid add / grid edit
			if ($this->AllowAddDeleteRow) {
				if ($this->CurrentAction == "gridadd" || $this->CurrentAction == "gridedit") {
					$item = $this->ListOptions->GetItem("griddelete");
					if ($item) $item->Visible = TRUE;
				}
			}

			// Get default search criteria
			ew_AddFilter($this->DefaultSearchWhere, $this->BasicSearchWhere(TRUE));

			// Get basic search values
			$this->LoadBasicSearchValues();

			// Restore filter list
			$this->RestoreFilterList();

			// Restore search parms from Session if not searching / reset / export
			if (($this->Export <> "" || $this->Command <> "search" && $this->Command <> "reset" && $this->Command <> "resetall") && $this->CheckSearchParms())
				$this->RestoreSearchParms();

			// Call Recordset SearchValidated event
			$this->Recordset_SearchValidated();

			// Set up sorting order
			$this->SetUpSortOrder();

			// Get basic search criteria
			if ($gsSearchError == "")
				$sSrchBasic = $this->BasicSearchWhere();
		}

		// Restore display records
		if ($this->getRecordsPerPage() <> "") {
			$this->DisplayRecs = $this->getRecordsPerPage(); // Restore from Session
		} else {
			$this->DisplayRecs = 50; // Load default
		}

		// Load Sorting Order
		$this->LoadSortOrder();

		// Load search default if no existing search criteria
		if (!$this->CheckSearchParms()) {

			// Load basic search from default
			$this->BasicSearch->LoadDefault();
			if ($this->BasicSearch->Keyword != "")
				$sSrchBasic = $this->BasicSearchWhere();
		}

		// Build search criteria
		ew_AddFilter($this->SearchWhere, $sSrchAdvanced);
		ew_AddFilter($this->SearchWhere, $sSrchBasic);

		// Call Recordset_Searching event
		$this->Recordset_Searching($this->SearchWhere);

		// Save search criteria
		if ($this->Command == "search" && !$this->RestoreSearch) {
			$this->setSearchWhere($this->SearchWhere); // Save to Session
			$this->StartRec = 1; // Reset start record counter
			$this->setStartRecordNumber($this->StartRec);
		} else {
			$this->SearchWhere = $this->getSearchWhere();
		}

		// Build filter
		$sFilter = "";
		if (!$Security->CanList())
			$sFilter = "(0=1)"; // Filter all records

		// Restore master/detail filter
		$this->DbMasterFilter = $this->GetMasterFilter(); // Restore master filter
		$this->DbDetailFilter = $this->GetDetailFilter(); // Restore detail filter

		// Add master User ID filter
		if ($Security->CurrentUserID() <> "" && !$Security->IsAdmin()) { // Non system admin
			if ($this->getCurrentMasterTable() == "staff")
				$this->DbMasterFilter = $this->AddMasterUserIDFilter($this->DbMasterFilter, "staff"); // Add master User ID filter
			if ($this->getCurrentMasterTable() == "project")
				$this->DbMasterFilter = $this->AddMasterUserIDFilter($this->DbMasterFilter, "project"); // Add master User ID filter
		}
		ew_AddFilter($sFilter, $this->DbDetailFilter);
		ew_AddFilter($sFilter, $this->SearchWhere);

		// Load master record
		if ($this->CurrentMode <> "add" && $this->GetMasterFilter() <> "" && $this->getCurrentMasterTable() == "staff") {
			global $staff;
			$rsmaster = $staff->LoadRs($this->DbMasterFilter);
			$this->MasterRecordExists = ($rsmaster && !$rsmaster->EOF);
			if (!$this->MasterRecordExists) {
				$this->setFailureMessage($Language->Phrase("NoRecord")); // Set no record found
				$this->Page_Terminate("stafflist.php"); // Return to master page
			} else {
				$staff->LoadListRowValues($rsmaster);
				$staff->RowType = EW_ROWTYPE_MASTER; // Master row
				$staff->RenderListRow();
				$rsmaster->Close();
			}
		}

		// Load master record
		if ($this->CurrentMode <> "add" && $this->GetMasterFilter() <> "" && $this->getCurrentMasterTable() == "project") {
			global $project;
			$rsmaster = $project->LoadRs($this->DbMasterFilter);
			$this->MasterRecordExists = ($rsmaster && !$rsmaster->EOF);
			if (!$this->MasterRecordExists) {
				$this->setFailureMessage($Language->Phrase("NoRecord")); // Set no record found
				$this->Page_Terminate("projectlist.php"); // Return to master page
			} else {
				$project->LoadListRowValues($rsmaster);
				$project->RowType = EW_ROWTYPE_MASTER; // Master row
				$project->RenderListRow();
				$rsmaster->Close();
			}
		}

		// Set up filter in session
		$this->setSessionWhere($sFilter);
		$this->CurrentFilter = "";

		// Export data only
		if ($this->CustomExport == "" && in_array($this->Export, array("html","word","excel","xml","csv","email","pdf"))) {
			$this->ExportData();
			$this->Page_Terminate(); // Terminate response
			exit();
		}

		// Load record count first
		if (!$this->IsAddOrEdit()) {
			$bSelectLimit = $this->UseSelectLimit;
			if ($bSelectLimit) {
				$this->TotalRecs = $this->SelectRecordCount();
			} else {
				if ($this->Recordset = $this->LoadRecordset())
					$this->TotalRecs = $this->Recordset->RecordCount();
			}
		}

		// Search options
		$this->SetupSearchOptions();
	}

	// Set up number of records displayed per page
	function SetUpDisplayRecs() {
		$sWrk = @$_GET[EW_TABLE_REC_PER_PAGE];
		if ($sWrk <> "") {
			if (is_numeric($sWrk)) {
				$this->DisplayRecs = intval($sWrk);
			} else {
				if (strtolower($sWrk) == "all") { // Display all records
					$this->DisplayRecs = -1;
				} else {
					$this->DisplayRecs = 50; // Non-numeric, load default
				}
			}
			$this->setRecordsPerPage($this->DisplayRecs); // Save to Session

			// Reset start position
			$this->StartRec = 1;
			$this->setStartRecordNumber($this->StartRec);
		}
	}

	//  Exit inline mode
	function ClearInlineMode() {
		$this->setKey("projID", ""); // Clear inline edit key
		$this->setKey("staffID", ""); // Clear inline edit key
		$this->LastAction = $this->CurrentAction; // Save last action
		$this->CurrentAction = ""; // Clear action
		$_SESSION[EW_SESSION_INLINE_MODE] = ""; // Clear inline mode
	}

	// Switch to Grid Add mode
	function GridAddMode() {
		$_SESSION[EW_SESSION_INLINE_MODE] = "gridadd"; // Enabled grid add
	}

	// Switch to Grid Edit mode
	function GridEditMode() {
		$_SESSION[EW_SESSION_INLINE_MODE] = "gridedit"; // Enable grid edit
	}

	// Switch to Inline Edit mode
	function InlineEditMode() {
		global $Security, $Language;
		if (!$Security->CanEdit())
			$this->Page_Terminate("login.php"); // Go to login page
		$bInlineEdit = TRUE;
		if (@$_GET["projID"] <> "") {
			$this->projID->setQueryStringValue($_GET["projID"]);
		} else {
			$bInlineEdit = FALSE;
		}
		if (@$_GET["staffID"] <> "") {
			$this->staffID->setQueryStringValue($_GET["staffID"]);
		} else {
			$bInlineEdit = FALSE;
		}
		if ($bInlineEdit) {
			if ($this->LoadRow()) {
				$this->setKey("projID", $this->projID->CurrentValue); // Set up inline edit key
				$this->setKey("staffID", $this->staffID->CurrentValue); // Set up inline edit key
				$_SESSION[EW_SESSION_INLINE_MODE] = "edit"; // Enable inline edit
			}
		}
	}

	// Perform update to Inline Edit record
	function InlineUpdate() {
		global $Language, $objForm, $gsFormError;
		$objForm->Index = 1; 
		$this->LoadFormValues(); // Get form values

		// Validate form
		$bInlineUpdate = TRUE;
		if (!$this->ValidateForm()) {	
			$bInlineUpdate = FALSE; // Form error, reset action
			$this->setFailureMessage($gsFormError);
		} else {
			$bInlineUpdate = FALSE;
			$rowkey = strval($objForm->GetValue($this->FormKeyName));
			if ($this->SetupKeyValues($rowkey)) { // Set up key values
				if ($this->CheckInlineEditKey()) { // Check key
					$this->SendEmail = TRUE; // Send email on update success
					$bInlineUpdate = $this->EditRow(); // Update record
				} else {
					$bInlineUpdate = FALSE;
				}
			}
		}
		if ($bInlineUpdate) { // Update success
			if ($this->getSuccessMessage() == "")
				$this->setSuccessMessage($Language->Phrase("UpdateSuccess")); // Set up success message
			$this->ClearInlineMode(); // Clear inline edit mode
		} else {
			if ($this->getFailureMessage() == "")
				$this->setFailureMessage($Language->Phrase("UpdateFailed")); // Set update failed message
			$this->EventCancelled = TRUE; // Cancel event
			$this->CurrentAction = "edit"; // Stay in edit mode
		}
	}

	// Check Inline Edit key
	function CheckInlineEditKey() {

		//CheckInlineEditKey = True
		if (strval($this->getKey("projID")) <> strval($this->projID->CurrentValue))
			return FALSE;
		if (strval($this->getKey("staffID")) <> strval($this->staffID->CurrentValue))
			return FALSE;
		return TRUE;
	}

	// Switch to Inline Add mode
	function InlineAddMode() {
		global $Security, $Language;
		if (!$Security->CanAdd())
			$this->Page_Terminate("login.php"); // Return to login page
		if ($this->CurrentAction == "copy") {
			if (@$_GET["projID"] <> "") {
				$this->projID->setQueryStringValue($_GET["projID"]);
				$this->setKey("projID", $this->projID->CurrentValue); // Set up key
			} else {
				$this->setKey("projID", ""); // Clear key
				$this->CurrentAction = "add";
			}
			if (@$_GET["staffID"] <> "") {
				$this->staffID->setQueryStringValue($_GET["staffID"]);
				$this->setKey("staffID", $this->staffID->CurrentValue); // Set up key
			} else {
				$this->setKey("staffID", ""); // Clear key
				$this->CurrentAction = "add";
			}
		}
		$_SESSION[EW_SESSION_INLINE_MODE] = "add"; // Enable inline add
	}

	// Perform update to Inline Add/Copy record
	function InlineInsert() {
		global $Language, $objForm, $gsFormError;
		$this->LoadOldRecord(); // Load old recordset
		$objForm->Index = 0;
		$this->LoadFormValues(); // Get form values

		// Validate form
		if (!$this->ValidateForm()) {
			$this->setFailureMessage($gsFormError); // Set validation error message
			$this->EventCancelled = TRUE; // Set event cancelled
			$this->CurrentAction = "add"; // Stay in add mode
			return;
		}
		$this->SendEmail = TRUE; // Send email on add success
		if ($this->AddRow($this->OldRecordset)) { // Add record
			if ($this->getSuccessMessage() == "")
				$this->setSuccessMessage($Language->Phrase("AddSuccess")); // Set up add success message
			$this->ClearInlineMode(); // Clear inline add mode
		} else { // Add failed
			$this->EventCancelled = TRUE; // Set event cancelled
			$this->CurrentAction = "add"; // Stay in add mode
		}
	}

	// Perform update to grid
	function GridUpdate() {
		global $Language, $objForm, $gsFormError;
		$bGridUpdate = TRUE;

		// Get old recordset
		$this->CurrentFilter = $this->BuildKeyFilter();
		if ($this->CurrentFilter == "")
			$this->CurrentFilter = "0=1";
		$sSql = $this->SQL();
		$conn = &$this->Connection();
		if ($rs = $conn->Execute($sSql)) {
			$rsold = $rs->GetRows();
			$rs->Close();
		}

		// Call Grid Updating event
		if (!$this->Grid_Updating($rsold)) {
			if ($this->getFailureMessage() == "")
				$this->setFailureMessage($Language->Phrase("GridEditCancelled")); // Set grid edit cancelled message
			return FALSE;
		}

		// Begin transaction
		$conn->BeginTrans();
		if ($this->AuditTrailOnEdit) $this->WriteAuditTrailDummy($Language->Phrase("BatchUpdateBegin")); // Batch update begin
		$sKey = "";

		// Update row index and get row key
		$objForm->Index = -1;
		$rowcnt = strval($objForm->GetValue($this->FormKeyCountName));
		if ($rowcnt == "" || !is_numeric($rowcnt))
			$rowcnt = 0;

		// Update all rows based on key
		for ($rowindex = 1; $rowindex <= $rowcnt; $rowindex++) {
			$objForm->Index = $rowindex;
			$rowkey = strval($objForm->GetValue($this->FormKeyName));
			$rowaction = strval($objForm->GetValue($this->FormActionName));

			// Load all values and keys
			if ($rowaction <> "insertdelete") { // Skip insert then deleted rows
				$this->LoadFormValues(); // Get form values
				if ($rowaction == "" || $rowaction == "edit" || $rowaction == "delete") {
					$bGridUpdate = $this->SetupKeyValues($rowkey); // Set up key values
				} else {
					$bGridUpdate = TRUE;
				}

				// Skip empty row
				if ($rowaction == "insert" && $this->EmptyRow()) {

					// No action required
				// Validate form and insert/update/delete record

				} elseif ($bGridUpdate) {
					if ($rowaction == "delete") {
						$this->CurrentFilter = $this->KeyFilter();
						$bGridUpdate = $this->DeleteRows(); // Delete this row
					} else if (!$this->ValidateForm()) {
						$bGridUpdate = FALSE; // Form error, reset action
						$this->setFailureMessage($gsFormError);
					} else {
						if ($rowaction == "insert") {
							$bGridUpdate = $this->AddRow(); // Insert this row
						} else {
							if ($rowkey <> "") {
								$this->SendEmail = FALSE; // Do not send email on update success
								$bGridUpdate = $this->EditRow(); // Update this row
							}
						} // End update
					}
				}
				if ($bGridUpdate) {
					if ($sKey <> "") $sKey .= ", ";
					$sKey .= $rowkey;
				} else {
					break;
				}
			}
		}
		if ($bGridUpdate) {
			$conn->CommitTrans(); // Commit transaction

			// Get new recordset
			if ($rs = $conn->Execute($sSql)) {
				$rsnew = $rs->GetRows();
				$rs->Close();
			}

			// Call Grid_Updated event
			$this->Grid_Updated($rsold, $rsnew);
			if ($this->AuditTrailOnEdit) $this->WriteAuditTrailDummy($Language->Phrase("BatchUpdateSuccess")); // Batch update success
			if ($this->getSuccessMessage() == "")
				$this->setSuccessMessage($Language->Phrase("UpdateSuccess")); // Set up update success message
			$this->ClearInlineMode(); // Clear inline edit mode
		} else {
			$conn->RollbackTrans(); // Rollback transaction
			if ($this->AuditTrailOnEdit) $this->WriteAuditTrailDummy($Language->Phrase("BatchUpdateRollback")); // Batch update rollback
			if ($this->getFailureMessage() == "")
				$this->setFailureMessage($Language->Phrase("UpdateFailed")); // Set update failed message
		}
		return $bGridUpdate;
	}

	// Build filter for all keys
	function BuildKeyFilter() {
		global $objForm;
		$sWrkFilter = "";

		// Update row index and get row key
		$rowindex = 1;
		$objForm->Index = $rowindex;
		$sThisKey = strval($objForm->GetValue($this->FormKeyName));
		while ($sThisKey <> "") {
			if ($this->SetupKeyValues($sThisKey)) {
				$sFilter = $this->KeyFilter();
				if ($sWrkFilter <> "") $sWrkFilter .= " OR ";
				$sWrkFilter .= $sFilter;
			} else {
				$sWrkFilter = "0=1";
				break;
			}

			// Update row index and get row key
			$rowindex++; // Next row
			$objForm->Index = $rowindex;
			$sThisKey = strval($objForm->GetValue($this->FormKeyName));
		}
		return $sWrkFilter;
	}

	// Set up key values
	function SetupKeyValues($key) {
		$arrKeyFlds = explode($GLOBALS["EW_COMPOSITE_KEY_SEPARATOR"], $key);
		if (count($arrKeyFlds) >= 2) {
			$this->projID->setFormValue($arrKeyFlds[0]);
			if (!is_numeric($this->projID->FormValue))
				return FALSE;
			$this->staffID->setFormValue($arrKeyFlds[1]);
			if (!is_numeric($this->staffID->FormValue))
				return FALSE;
		}
		return TRUE;
	}

	// Perform Grid Add
	function GridInsert() {
		global $Language, $objForm, $gsFormError;
		$rowindex = 1;
		$bGridInsert = FALSE;
		$conn = &$this->Connection();

		// Call Grid Inserting event
		if (!$this->Grid_Inserting()) {
			if ($this->getFailureMessage() == "") {
				$this->setFailureMessage($Language->Phrase("GridAddCancelled")); // Set grid add cancelled message
			}
			return FALSE;
		}

		// Begin transaction
		$conn->BeginTrans();

		// Init key filter
		$sWrkFilter = "";
		$addcnt = 0;
		if ($this->AuditTrailOnAdd) $this->WriteAuditTrailDummy($Language->Phrase("BatchInsertBegin")); // Batch insert begin
		$sKey = "";

		// Get row count
		$objForm->Index = -1;
		$rowcnt = strval($objForm->GetValue($this->FormKeyCountName));
		if ($rowcnt == "" || !is_numeric($rowcnt))
			$rowcnt = 0;

		// Insert all rows
		for ($rowindex = 1; $rowindex <= $rowcnt; $rowindex++) {

			// Load current row values
			$objForm->Index = $rowindex;
			$rowaction = strval($objForm->GetValue($this->FormActionName));
			if ($rowaction <> "" && $rowaction <> "insert")
				continue; // Skip
			$this->LoadFormValues(); // Get form values
			if (!$this->EmptyRow()) {
				$addcnt++;
				$this->SendEmail = FALSE; // Do not send email on insert success

				// Validate form
				if (!$this->ValidateForm()) {
					$bGridInsert = FALSE; // Form error, reset action
					$this->setFailureMessage($gsFormError);
				} else {
					$bGridInsert = $this->AddRow($this->OldRecordset); // Insert this row
				}
				if ($bGridInsert) {
					if ($sKey <> "") $sKey .= $GLOBALS["EW_COMPOSITE_KEY_SEPARATOR"];
					$sKey .= $this->projID->CurrentValue;
					if ($sKey <> "") $sKey .= $GLOBALS["EW_COMPOSITE_KEY_SEPARATOR"];
					$sKey .= $this->staffID->CurrentValue;

					// Add filter for this record
					$sFilter = $this->KeyFilter();
					if ($sWrkFilter <> "") $sWrkFilter .= " OR ";
					$sWrkFilter .= $sFilter;
				} else {
					break;
				}
			}
		}
		if ($addcnt == 0) { // No record inserted
			$this->setFailureMessage($Language->Phrase("NoAddRecord"));
			$bGridInsert = FALSE;
		}
		if ($bGridInsert) {
			$conn->CommitTrans(); // Commit transaction

			// Get new recordset
			$this->CurrentFilter = $sWrkFilter;
			$sSql = $this->SQL();
			if ($rs = $conn->Execute($sSql)) {
				$rsnew = $rs->GetRows();
				$rs->Close();
			}

			// Call Grid_Inserted event
			$this->Grid_Inserted($rsnew);
			if ($this->AuditTrailOnAdd) $this->WriteAuditTrailDummy($Language->Phrase("BatchInsertSuccess")); // Batch insert success
			if ($this->getSuccessMessage() == "")
				$this->setSuccessMessage($Language->Phrase("InsertSuccess")); // Set up insert success message
			$this->ClearInlineMode(); // Clear grid add mode
		} else {
			$conn->RollbackTrans(); // Rollback transaction
			if ($this->AuditTrailOnAdd) $this->WriteAuditTrailDummy($Language->Phrase("BatchInsertRollback")); // Batch insert rollback
			if ($this->getFailureMessage() == "") {
				$this->setFailureMessage($Language->Phrase("InsertFailed")); // Set insert failed message
			}
		}
		return $bGridInsert;
	}

	// Check if empty row
	function EmptyRow() {
		global $objForm;
		if ($objForm->HasValue("x_projID") && $objForm->HasValue("o_projID") && $this->projID->CurrentValue <> $this->projID->OldValue)
			return FALSE;
		if ($objForm->HasValue("x_staffID") && $objForm->HasValue("o_staffID") && $this->staffID->CurrentValue <> $this->staffID->OldValue)
			return FALSE;
		if ($objForm->HasValue("x_role") && $objForm->HasValue("o_role") && $this->role->CurrentValue <> $this->role->OldValue)
			return FALSE;
		if ($objForm->HasValue("x_TimeSpentProject") && $objForm->HasValue("o_TimeSpentProject") && $this->TimeSpentProject->CurrentValue <> $this->TimeSpentProject->OldValue)
			return FALSE;
		return TRUE;
	}

	// Validate grid form
	function ValidateGridForm() {
		global $objForm;

		// Get row count
		$objForm->Index = -1;
		$rowcnt = strval($objForm->GetValue($this->FormKeyCountName));
		if ($rowcnt == "" || !is_numeric($rowcnt))
			$rowcnt = 0;

		// Validate all records
		for ($rowindex = 1; $rowindex <= $rowcnt; $rowindex++) {

			// Load current row values
			$objForm->Index = $rowindex;
			$rowaction = strval($objForm->GetValue($this->FormActionName));
			if ($rowaction <> "delete" && $rowaction <> "insertdelete") {
				$this->LoadFormValues(); // Get form values
				if ($rowaction == "insert" && $this->EmptyRow()) {

					// Ignore
				} else if (!$this->ValidateForm()) {
					return FALSE;
				}
			}
		}
		return TRUE;
	}

	// Get all form values of the grid
	function GetGridFormValues() {
		global $objForm;

		// Get row count
		$objForm->Index = -1;
		$rowcnt = strval($objForm->GetValue($this->FormKeyCountName));
		if ($rowcnt == "" || !is_numeric($rowcnt))
			$rowcnt = 0;
		$rows = array();

		// Loop through all records
		for ($rowindex = 1; $rowindex <= $rowcnt; $rowindex++) {

			// Load current row values
			$objForm->Index = $rowindex;
			$rowaction = strval($objForm->GetValue($this->FormActionName));
			if ($rowaction <> "delete" && $rowaction <> "insertdelete") {
				$this->LoadFormValues(); // Get form values
				if ($rowaction == "insert" && $this->EmptyRow()) {

					// Ignore
				} else {
					$rows[] = $this->GetFieldValues("FormValue"); // Return row as array
				}
			}
		}
		return $rows; // Return as array of array
	}

	// Restore form values for current row
	function RestoreCurrentRowFormValues($idx) {
		global $objForm;

		// Get row based on current index
		$objForm->Index = $idx;
		$this->LoadFormValues(); // Load form values
	}

	// Get list of filters
	function GetFilterList() {

		// Initialize
		$sFilterList = "";
		$sFilterList = ew_Concat($sFilterList, $this->projID->AdvancedSearch->ToJSON(), ","); // Field projID
		$sFilterList = ew_Concat($sFilterList, $this->staffID->AdvancedSearch->ToJSON(), ","); // Field staffID
		$sFilterList = ew_Concat($sFilterList, $this->role->AdvancedSearch->ToJSON(), ","); // Field role
		$sFilterList = ew_Concat($sFilterList, $this->TimeSpentProject->AdvancedSearch->ToJSON(), ","); // Field TimeSpentProject
		if ($this->BasicSearch->Keyword <> "") {
			$sWrk = "\"" . EW_TABLE_BASIC_SEARCH . "\":\"" . ew_JsEncode2($this->BasicSearch->Keyword) . "\",\"" . EW_TABLE_BASIC_SEARCH_TYPE . "\":\"" . ew_JsEncode2($this->BasicSearch->Type) . "\"";
			$sFilterList = ew_Concat($sFilterList, $sWrk, ",");
		}

		// Return filter list in json
		return ($sFilterList <> "") ? "{" . $sFilterList . "}" : "null";
	}

	// Restore list of filters
	function RestoreFilterList() {

		// Return if not reset filter
		if (@$_POST["cmd"] <> "resetfilter")
			return FALSE;
		$filter = json_decode(ew_StripSlashes(@$_POST["filter"]), TRUE);
		$this->Command = "search";

		// Field projID
		$this->projID->AdvancedSearch->SearchValue = @$filter["x_projID"];
		$this->projID->AdvancedSearch->SearchOperator = @$filter["z_projID"];
		$this->projID->AdvancedSearch->SearchCondition = @$filter["v_projID"];
		$this->projID->AdvancedSearch->SearchValue2 = @$filter["y_projID"];
		$this->projID->AdvancedSearch->SearchOperator2 = @$filter["w_projID"];
		$this->projID->AdvancedSearch->Save();

		// Field staffID
		$this->staffID->AdvancedSearch->SearchValue = @$filter["x_staffID"];
		$this->staffID->AdvancedSearch->SearchOperator = @$filter["z_staffID"];
		$this->staffID->AdvancedSearch->SearchCondition = @$filter["v_staffID"];
		$this->staffID->AdvancedSearch->SearchValue2 = @$filter["y_staffID"];
		$this->staffID->AdvancedSearch->SearchOperator2 = @$filter["w_staffID"];
		$this->staffID->AdvancedSearch->Save();

		// Field role
		$this->role->AdvancedSearch->SearchValue = @$filter["x_role"];
		$this->role->AdvancedSearch->SearchOperator = @$filter["z_role"];
		$this->role->AdvancedSearch->SearchCondition = @$filter["v_role"];
		$this->role->AdvancedSearch->SearchValue2 = @$filter["y_role"];
		$this->role->AdvancedSearch->SearchOperator2 = @$filter["w_role"];
		$this->role->AdvancedSearch->Save();

		// Field TimeSpentProject
		$this->TimeSpentProject->AdvancedSearch->SearchValue = @$filter["x_TimeSpentProject"];
		$this->TimeSpentProject->AdvancedSearch->SearchOperator = @$filter["z_TimeSpentProject"];
		$this->TimeSpentProject->AdvancedSearch->SearchCondition = @$filter["v_TimeSpentProject"];
		$this->TimeSpentProject->AdvancedSearch->SearchValue2 = @$filter["y_TimeSpentProject"];
		$this->TimeSpentProject->AdvancedSearch->SearchOperator2 = @$filter["w_TimeSpentProject"];
		$this->TimeSpentProject->AdvancedSearch->Save();
		$this->BasicSearch->setKeyword(@$filter[EW_TABLE_BASIC_SEARCH]);
		$this->BasicSearch->setType(@$filter[EW_TABLE_BASIC_SEARCH_TYPE]);
	}

	// Return basic search SQL
	function BasicSearchSQL($arKeywords, $type) {
		$sWhere = "";
		$this->BuildBasicSearchSQL($sWhere, $this->role, $arKeywords, $type);
		return $sWhere;
	}

	// Build basic search SQL
	function BuildBasicSearchSql(&$Where, &$Fld, $arKeywords, $type) {
		$sDefCond = ($type == "OR") ? "OR" : "AND";
		$arSQL = array(); // Array for SQL parts
		$arCond = array(); // Array for search conditions
		$cnt = count($arKeywords);
		$j = 0; // Number of SQL parts
		for ($i = 0; $i < $cnt; $i++) {
			$Keyword = $arKeywords[$i];
			$Keyword = trim($Keyword);
			if (EW_BASIC_SEARCH_IGNORE_PATTERN <> "") {
				$Keyword = preg_replace(EW_BASIC_SEARCH_IGNORE_PATTERN, "\\", $Keyword);
				$ar = explode("\\", $Keyword);
			} else {
				$ar = array($Keyword);
			}
			foreach ($ar as $Keyword) {
				if ($Keyword <> "") {
					$sWrk = "";
					if ($Keyword == "OR" && $type == "") {
						if ($j > 0)
							$arCond[$j-1] = "OR";
					} elseif ($Keyword == EW_NULL_VALUE) {
						$sWrk = $Fld->FldExpression . " IS NULL";
					} elseif ($Keyword == EW_NOT_NULL_VALUE) {
						$sWrk = $Fld->FldExpression . " IS NOT NULL";
					} elseif ($Fld->FldIsVirtual && $Fld->FldVirtualSearch) {
						$sWrk = $Fld->FldVirtualExpression . ew_Like(ew_QuotedValue("%" . $Keyword . "%", EW_DATATYPE_STRING, $this->DBID), $this->DBID);
					} elseif ($Fld->FldDataType != EW_DATATYPE_NUMBER || is_numeric($Keyword)) {
						$sWrk = $Fld->FldBasicSearchExpression . ew_Like(ew_QuotedValue("%" . $Keyword . "%", EW_DATATYPE_STRING, $this->DBID), $this->DBID);
					}
					if ($sWrk <> "") {
						$arSQL[$j] = $sWrk;
						$arCond[$j] = $sDefCond;
						$j += 1;
					}
				}
			}
		}
		$cnt = count($arSQL);
		$bQuoted = FALSE;
		$sSql = "";
		if ($cnt > 0) {
			for ($i = 0; $i < $cnt-1; $i++) {
				if ($arCond[$i] == "OR") {
					if (!$bQuoted) $sSql .= "(";
					$bQuoted = TRUE;
				}
				$sSql .= $arSQL[$i];
				if ($bQuoted && $arCond[$i] <> "OR") {
					$sSql .= ")";
					$bQuoted = FALSE;
				}
				$sSql .= " " . $arCond[$i] . " ";
			}
			$sSql .= $arSQL[$cnt-1];
			if ($bQuoted)
				$sSql .= ")";
		}
		if ($sSql <> "") {
			if ($Where <> "") $Where .= " OR ";
			$Where .=  "(" . $sSql . ")";
		}
	}

	// Return basic search WHERE clause based on search keyword and type
	function BasicSearchWhere($Default = FALSE) {
		global $Security;
		$sSearchStr = "";
		if (!$Security->CanSearch()) return "";
		$sSearchKeyword = ($Default) ? $this->BasicSearch->KeywordDefault : $this->BasicSearch->Keyword;
		$sSearchType = ($Default) ? $this->BasicSearch->TypeDefault : $this->BasicSearch->Type;
		if ($sSearchKeyword <> "") {
			$sSearch = trim($sSearchKeyword);
			if ($sSearchType <> "=") {
				$ar = array();

				// Match quoted keywords (i.e.: "...")
				if (preg_match_all('/"([^"]*)"/i', $sSearch, $matches, PREG_SET_ORDER)) {
					foreach ($matches as $match) {
						$p = strpos($sSearch, $match[0]);
						$str = substr($sSearch, 0, $p);
						$sSearch = substr($sSearch, $p + strlen($match[0]));
						if (strlen(trim($str)) > 0)
							$ar = array_merge($ar, explode(" ", trim($str)));
						$ar[] = $match[1]; // Save quoted keyword
					}
				}

				// Match individual keywords
				if (strlen(trim($sSearch)) > 0)
					$ar = array_merge($ar, explode(" ", trim($sSearch)));

				// Search keyword in any fields
				if (($sSearchType == "OR" || $sSearchType == "AND") && $this->BasicSearch->BasicSearchAnyFields) {
					foreach ($ar as $sKeyword) {
						if ($sKeyword <> "") {
							if ($sSearchStr <> "") $sSearchStr .= " " . $sSearchType . " ";
							$sSearchStr .= "(" . $this->BasicSearchSQL(array($sKeyword), $sSearchType) . ")";
						}
					}
				} else {
					$sSearchStr = $this->BasicSearchSQL($ar, $sSearchType);
				}
			} else {
				$sSearchStr = $this->BasicSearchSQL(array($sSearch), $sSearchType);
			}
			if (!$Default) $this->Command = "search";
		}
		if (!$Default && $this->Command == "search") {
			$this->BasicSearch->setKeyword($sSearchKeyword);
			$this->BasicSearch->setType($sSearchType);
		}
		return $sSearchStr;
	}

	// Check if search parm exists
	function CheckSearchParms() {

		// Check basic search
		if ($this->BasicSearch->IssetSession())
			return TRUE;
		return FALSE;
	}

	// Clear all search parameters
	function ResetSearchParms() {

		// Clear search WHERE clause
		$this->SearchWhere = "";
		$this->setSearchWhere($this->SearchWhere);

		// Clear basic search parameters
		$this->ResetBasicSearchParms();
	}

	// Load advanced search default values
	function LoadAdvancedSearchDefault() {
		return FALSE;
	}

	// Clear all basic search parameters
	function ResetBasicSearchParms() {
		$this->BasicSearch->UnsetSession();
	}

	// Restore all search parameters
	function RestoreSearchParms() {
		$this->RestoreSearch = TRUE;

		// Restore basic search values
		$this->BasicSearch->Load();
	}

	// Set up sort parameters
	function SetUpSortOrder() {

		// Check for Ctrl pressed
		$bCtrl = (@$_GET["ctrl"] <> "");

		// Check for "order" parameter
		if (@$_GET["order"] <> "") {
			$this->CurrentOrder = ew_StripSlashes(@$_GET["order"]);
			$this->CurrentOrderType = @$_GET["ordertype"];
			$this->UpdateSort($this->projID, $bCtrl); // projID
			$this->UpdateSort($this->staffID, $bCtrl); // staffID
			$this->UpdateSort($this->role, $bCtrl); // role
			$this->UpdateSort($this->TimeSpentProject, $bCtrl); // TimeSpentProject
			$this->setStartRecordNumber(1); // Reset start position
		}
	}

	// Load sort order parameters
	function LoadSortOrder() {
		$sOrderBy = $this->getSessionOrderBy(); // Get ORDER BY from Session
		if ($sOrderBy == "") {
			if ($this->getSqlOrderBy() <> "") {
				$sOrderBy = $this->getSqlOrderBy();
				$this->setSessionOrderBy($sOrderBy);
			}
		}
	}

	// Reset command
	// - cmd=reset (Reset search parameters)
	// - cmd=resetall (Reset search and master/detail parameters)
	// - cmd=resetsort (Reset sort parameters)
	function ResetCmd() {

		// Check if reset command
		if (substr($this->Command,0,5) == "reset") {

			// Reset search criteria
			if ($this->Command == "reset" || $this->Command == "resetall")
				$this->ResetSearchParms();

			// Reset master/detail keys
			if ($this->Command == "resetall") {
				$this->setCurrentMasterTable(""); // Clear master table
				$this->DbMasterFilter = "";
				$this->DbDetailFilter = "";
				$this->staffID->setSessionValue("");
				$this->projID->setSessionValue("");
			}

			// Reset sorting order
			if ($this->Command == "resetsort") {
				$sOrderBy = "";
				$this->setSessionOrderBy($sOrderBy);
				$this->projID->setSort("");
				$this->staffID->setSort("");
				$this->role->setSort("");
				$this->TimeSpentProject->setSort("");
			}

			// Reset start position
			$this->StartRec = 1;
			$this->setStartRecordNumber($this->StartRec);
		}
	}

	// Set up list options
	function SetupListOptions() {
		global $Security, $Language;

		// "griddelete"
		if ($this->AllowAddDeleteRow) {
			$item = &$this->ListOptions->Add("griddelete");
			$item->CssStyle = "white-space: nowrap;";
			$item->OnLeft = FALSE;
			$item->Visible = FALSE; // Default hidden
		}

		// Add group option item
		$item = &$this->ListOptions->Add($this->ListOptions->GroupOptionName);
		$item->Body = "";
		$item->OnLeft = FALSE;
		$item->Visible = FALSE;

		// "view"
		$item = &$this->ListOptions->Add("view");
		$item->CssStyle = "white-space: nowrap;";
		$item->Visible = $Security->CanView();
		$item->OnLeft = FALSE;

		// "edit"
		$item = &$this->ListOptions->Add("edit");
		$item->CssStyle = "white-space: nowrap;";
		$item->Visible = $Security->CanEdit();
		$item->OnLeft = FALSE;

		// "copy"
		$item = &$this->ListOptions->Add("copy");
		$item->CssStyle = "white-space: nowrap;";
		$item->Visible = $Security->CanAdd();
		$item->OnLeft = FALSE;

		// "delete"
		$item = &$this->ListOptions->Add("delete");
		$item->CssStyle = "white-space: nowrap;";
		$item->Visible = $Security->CanDelete();
		$item->OnLeft = FALSE;

		// List actions
		$item = &$this->ListOptions->Add("listactions");
		$item->CssStyle = "white-space: nowrap;";
		$item->OnLeft = FALSE;
		$item->Visible = FALSE;
		$item->ShowInButtonGroup = FALSE;
		$item->ShowInDropDown = FALSE;

		// "checkbox"
		$item = &$this->ListOptions->Add("checkbox");
		$item->Visible = FALSE;
		$item->OnLeft = FALSE;
		$item->Header = "<input type=\"checkbox\" name=\"key\" id=\"key\" onclick=\"ew_SelectAllKey(this);\">";
		$item->ShowInDropDown = FALSE;
		$item->ShowInButtonGroup = FALSE;

		// Drop down button for ListOptions
		$this->ListOptions->UseImageAndText = TRUE;
		$this->ListOptions->UseDropDownButton = FALSE;
		$this->ListOptions->DropDownButtonPhrase = $Language->Phrase("ButtonListOptions");
		$this->ListOptions->UseButtonGroup = TRUE;
		if ($this->ListOptions->UseButtonGroup && ew_IsMobile())
			$this->ListOptions->UseDropDownButton = TRUE;
		$this->ListOptions->ButtonClass = "btn-sm"; // Class for button group

		// Call ListOptions_Load event
		$this->ListOptions_Load();
		$this->SetupListOptionsExt();
		$item = &$this->ListOptions->GetItem($this->ListOptions->GroupOptionName);
		$item->Visible = $this->ListOptions->GroupOptionVisible();
	}

	// Render list options
	function RenderListOptions() {
		global $Security, $Language, $objForm;
		$this->ListOptions->LoadDefault();

		// Set up row action and key
		if (is_numeric($this->RowIndex) && $this->CurrentMode <> "view") {
			$objForm->Index = $this->RowIndex;
			$ActionName = str_replace("k_", "k" . $this->RowIndex . "_", $this->FormActionName);
			$OldKeyName = str_replace("k_", "k" . $this->RowIndex . "_", $this->FormOldKeyName);
			$KeyName = str_replace("k_", "k" . $this->RowIndex . "_", $this->FormKeyName);
			$BlankRowName = str_replace("k_", "k" . $this->RowIndex . "_", $this->FormBlankRowName);
			if ($this->RowAction <> "")
				$this->MultiSelectKey .= "<input type=\"hidden\" name=\"" . $ActionName . "\" id=\"" . $ActionName . "\" value=\"" . $this->RowAction . "\">";
			if ($this->RowAction == "delete") {
				$rowkey = $objForm->GetValue($this->FormKeyName);
				$this->SetupKeyValues($rowkey);
			}
			if ($this->RowAction == "insert" && $this->CurrentAction == "F" && $this->EmptyRow())
				$this->MultiSelectKey .= "<input type=\"hidden\" name=\"" . $BlankRowName . "\" id=\"" . $BlankRowName . "\" value=\"1\">";
		}

		// "delete"
		if ($this->AllowAddDeleteRow) {
			if ($this->CurrentAction == "gridadd" || $this->CurrentAction == "gridedit") {
				$option = &$this->ListOptions;
				$option->UseButtonGroup = TRUE; // Use button group for grid delete button
				$option->UseImageAndText = TRUE; // Use image and text for grid delete button
				$oListOpt = &$option->Items["griddelete"];
				if (!$Security->CanDelete() && is_numeric($this->RowIndex) && ($this->RowAction == "" || $this->RowAction == "edit")) { // Do not allow delete existing record
					$oListOpt->Body = "&nbsp;";
				} else {
					$oListOpt->Body = "<a class=\"ewGridLink ewGridDelete\" title=\"" . ew_HtmlTitle($Language->Phrase("DeleteLink")) . "\" data-caption=\"" . ew_HtmlTitle($Language->Phrase("DeleteLink")) . "\" onclick=\"return ew_DeleteGridRow(this, " . $this->RowIndex . ");\">" . $Language->Phrase("DeleteLink") . "</a>";
				}
			}
		}

		// "copy"
		$oListOpt = &$this->ListOptions->Items["copy"];
		if (($this->CurrentAction == "add" || $this->CurrentAction == "copy") && $this->RowType == EW_ROWTYPE_ADD) { // Inline Add/Copy
			$this->ListOptions->CustomItem = "copy"; // Show copy column only
			$cancelurl = $this->AddMasterUrl($this->PageUrl() . "a=cancel");
			$oListOpt->Body = "<div" . (($oListOpt->OnLeft) ? " style=\"text-align: right\"" : "") . ">" .
				"<a class=\"ewGridLink ewInlineInsert\" title=\"" . ew_HtmlTitle($Language->Phrase("InsertLink")) . "\" data-caption=\"" . ew_HtmlTitle($Language->Phrase("InsertLink")) . "\" href=\"\" onclick=\"return ewForms(this).Submit('" . $this->PageName() . "');\">" . $Language->Phrase("InsertLink") . "</a>&nbsp;" .
				"<a class=\"ewGridLink ewInlineCancel\" title=\"" . ew_HtmlTitle($Language->Phrase("CancelLink")) . "\" data-caption=\"" . ew_HtmlTitle($Language->Phrase("CancelLink")) . "\" href=\"" . $cancelurl . "\">" . $Language->Phrase("CancelLink") . "</a>" .
				"<input type=\"hidden\" name=\"a_list\" id=\"a_list\" value=\"insert\"></div>";
			return;
		}

		// "edit"
		$oListOpt = &$this->ListOptions->Items["edit"];
		if ($this->CurrentAction == "edit" && $this->RowType == EW_ROWTYPE_EDIT) { // Inline-Edit
			$this->ListOptions->CustomItem = "edit"; // Show edit column only
			$cancelurl = $this->AddMasterUrl($this->PageUrl() . "a=cancel");
				$oListOpt->Body = "<div" . (($oListOpt->OnLeft) ? " style=\"text-align: right\"" : "") . ">" .
					"<a class=\"ewGridLink ewInlineUpdate\" title=\"" . ew_HtmlTitle($Language->Phrase("UpdateLink")) . "\" data-caption=\"" . ew_HtmlTitle($Language->Phrase("UpdateLink")) . "\" href=\"\" onclick=\"return ewForms(this).Submit('" . ew_GetHashUrl($this->PageName(), $this->PageObjName . "_row_" . $this->RowCnt) . "');\">" . $Language->Phrase("UpdateLink") . "</a>&nbsp;" .
					"<a class=\"ewGridLink ewInlineCancel\" title=\"" . ew_HtmlTitle($Language->Phrase("CancelLink")) . "\" data-caption=\"" . ew_HtmlTitle($Language->Phrase("CancelLink")) . "\" href=\"" . $cancelurl . "\">" . $Language->Phrase("CancelLink") . "</a>" .
					"<input type=\"hidden\" name=\"a_list\" id=\"a_list\" value=\"update\"></div>";
			$oListOpt->Body .= "<input type=\"hidden\" name=\"k" . $this->RowIndex . "_key\" id=\"k" . $this->RowIndex . "_key\" value=\"" . ew_HtmlEncode($this->projID->CurrentValue . $GLOBALS["EW_COMPOSITE_KEY_SEPARATOR"] . $this->staffID->CurrentValue) . "\">";
			return;
		}

		// "view"
		$oListOpt = &$this->ListOptions->Items["view"];
		if ($Security->CanView())
			$oListOpt->Body = "<a class=\"ewRowLink ewView\" title=\"" . ew_HtmlTitle($Language->Phrase("ViewLink")) . "\" data-caption=\"" . ew_HtmlTitle($Language->Phrase("ViewLink")) . "\" href=\"" . ew_HtmlEncode($this->ViewUrl) . "\">" . $Language->Phrase("ViewLink") . "</a>";
		else
			$oListOpt->Body = "";

		// "edit"
		$oListOpt = &$this->ListOptions->Items["edit"];
		if ($Security->CanEdit()) {
			$oListOpt->Body = "<a class=\"ewRowLink ewEdit\" title=\"" . ew_HtmlTitle($Language->Phrase("EditLink")) . "\" data-caption=\"" . ew_HtmlTitle($Language->Phrase("EditLink")) . "\" href=\"" . ew_HtmlEncode($this->EditUrl) . "\">" . $Language->Phrase("EditLink") . "</a>";
			$oListOpt->Body .= "<a class=\"ewRowLink ewInlineEdit\" title=\"" . ew_HtmlTitle($Language->Phrase("InlineEditLink")) . "\" data-caption=\"" . ew_HtmlTitle($Language->Phrase("InlineEditLink")) . "\" href=\"" . ew_HtmlEncode(ew_GetHashUrl($this->InlineEditUrl, $this->PageObjName . "_row_" . $this->RowCnt)) . "\">" . $Language->Phrase("InlineEditLink") . "</a>";
		} else {
			$oListOpt->Body = "";
		}

		// "copy"
		$oListOpt = &$this->ListOptions->Items["copy"];
		if ($Security->CanAdd()) {
			$oListOpt->Body = "<a class=\"ewRowLink ewCopy\" title=\"" . ew_HtmlTitle($Language->Phrase("CopyLink")) . "\" data-caption=\"" . ew_HtmlTitle($Language->Phrase("CopyLink")) . "\" href=\"" . ew_HtmlEncode($this->CopyUrl) . "\">" . $Language->Phrase("CopyLink") . "</a>";
		} else {
			$oListOpt->Body = "";
		}

		// "delete"
		$oListOpt = &$this->ListOptions->Items["delete"];
		if ($Security->CanDelete())
			$oListOpt->Body = "<a class=\"ewRowLink ewDelete\"" . "" . " title=\"" . ew_HtmlTitle($Language->Phrase("DeleteLink")) . "\" data-caption=\"" . ew_HtmlTitle($Language->Phrase("DeleteLink")) . "\" href=\"" . ew_HtmlEncode($this->DeleteUrl) . "\">" . $Language->Phrase("DeleteLink") . "</a>";
		else
			$oListOpt->Body = "";

		// Set up list action buttons
		$oListOpt = &$this->ListOptions->GetItem("listactions");
		if ($oListOpt && $this->Export == "" && $this->CurrentAction == "") {
			$body = "";
			$links = array();
			foreach ($this->ListActions->Items as $listaction) {
				if ($listaction->Select == EW_ACTION_SINGLE && $listaction->Allow) {
					$action = $listaction->Action;
					$caption = $listaction->Caption;
					$icon = ($listaction->Icon <> "") ? "<span class=\"" . ew_HtmlEncode(str_replace(" ewIcon", "", $listaction->Icon)) . "\" data-caption=\"" . ew_HtmlTitle($caption) . "\"></span> " : "";
					$links[] = "<li><a class=\"ewAction ewListAction\" data-action=\"" . ew_HtmlEncode($action) . "\" data-caption=\"" . ew_HtmlTitle($caption) . "\" href=\"\" onclick=\"ew_SubmitAction(event,jQuery.extend({key:" . $this->KeyToJson() . "}," . $listaction->ToJson(TRUE) . "));return false;\">" . $icon . $listaction->Caption . "</a></li>";
					if (count($links) == 1) // Single button
						$body = "<a class=\"ewAction ewListAction\" data-action=\"" . ew_HtmlEncode($action) . "\" title=\"" . ew_HtmlTitle($caption) . "\" data-caption=\"" . ew_HtmlTitle($caption) . "\" href=\"\" onclick=\"ew_SubmitAction(event,jQuery.extend({key:" . $this->KeyToJson() . "}," . $listaction->ToJson(TRUE) . "));return false;\">" . $Language->Phrase("ListActionButton") . "</a>";
				}
			}
			if (count($links) > 1) { // More than one buttons, use dropdown
				$body = "<button class=\"dropdown-toggle btn btn-default btn-sm ewActions\" title=\"" . ew_HtmlTitle($Language->Phrase("ListActionButton")) . "\" data-toggle=\"dropdown\">" . $Language->Phrase("ListActionButton") . "<b class=\"caret\"></b></button>";
				$content = "";
				foreach ($links as $link)
					$content .= "<li>" . $link . "</li>";
				$body .= "<ul class=\"dropdown-menu" . ($oListOpt->OnLeft ? "" : " dropdown-menu-right") . "\">". $content . "</ul>";
				$body = "<div class=\"btn-group\">" . $body . "</div>";
			}
			if (count($links) > 0) {
				$oListOpt->Body = $body;
				$oListOpt->Visible = TRUE;
			}
		}

		// "checkbox"
		$oListOpt = &$this->ListOptions->Items["checkbox"];
		$oListOpt->Body = "<input type=\"checkbox\" name=\"key_m[]\" value=\"" . ew_HtmlEncode($this->projID->CurrentValue . $GLOBALS["EW_COMPOSITE_KEY_SEPARATOR"] . $this->staffID->CurrentValue) . "\" onclick='ew_ClickMultiCheckbox(event);'>";
		if ($this->CurrentAction == "gridedit" && is_numeric($this->RowIndex)) {
			$this->MultiSelectKey .= "<input type=\"hidden\" name=\"" . $KeyName . "\" id=\"" . $KeyName . "\" value=\"" . $this->projID->CurrentValue . $GLOBALS["EW_COMPOSITE_KEY_SEPARATOR"] . $this->staffID->CurrentValue . "\">";
		}
		$this->RenderListOptionsExt();

		// Call ListOptions_Rendered event
		$this->ListOptions_Rendered();
	}

	// Set up other options
	function SetupOtherOptions() {
		global $Language, $Security;
		$options = &$this->OtherOptions;
		$option = $options["addedit"];

		// Add
		$item = &$option->Add("add");
		$item->Body = "<a class=\"ewAddEdit ewAdd\" title=\"" . ew_HtmlTitle($Language->Phrase("AddLink")) . "\" data-caption=\"" . ew_HtmlTitle($Language->Phrase("AddLink")) . "\" href=\"" . ew_HtmlEncode($this->AddUrl) . "\">" . $Language->Phrase("AddLink") . "</a>";
		$item->Visible = ($this->AddUrl <> "" && $Security->CanAdd());
		$item = &$option->Add("gridadd");
		$item->Body = "<a class=\"ewAddEdit ewGridAdd\" title=\"" . ew_HtmlTitle($Language->Phrase("GridAddLink")) . "\" data-caption=\"" . ew_HtmlTitle($Language->Phrase("GridAddLink")) . "\" href=\"" . ew_HtmlEncode($this->GridAddUrl) . "\">" . $Language->Phrase("GridAddLink") . "</a>";
		$item->Visible = ($this->GridAddUrl <> "" && $Security->CanAdd());

		// Add grid edit
		$option = $options["addedit"];
		$item = &$option->Add("gridedit");
		$item->Body = "<a class=\"ewAddEdit ewGridEdit\" title=\"" . ew_HtmlTitle($Language->Phrase("GridEditLink")) . "\" data-caption=\"" . ew_HtmlTitle($Language->Phrase("GridEditLink")) . "\" href=\"" . ew_HtmlEncode($this->GridEditUrl) . "\">" . $Language->Phrase("GridEditLink") . "</a>";
		$item->Visible = ($this->GridEditUrl <> "" && $Security->CanEdit());
		$option = $options["action"];

		// Set up options default
		foreach ($options as &$option) {
			$option->UseImageAndText = TRUE;
			$option->UseDropDownButton = TRUE;
			$option->UseButtonGroup = TRUE;
			$option->ButtonClass = "btn-sm"; // Class for button group
			$item = &$option->Add($option->GroupOptionName);
			$item->Body = "";
			$item->Visible = FALSE;
		}
		$options["addedit"]->DropDownButtonPhrase = $Language->Phrase("ButtonAddEdit");
		$options["detail"]->DropDownButtonPhrase = $Language->Phrase("ButtonDetails");
		$options["action"]->DropDownButtonPhrase = $Language->Phrase("ButtonActions");

		// Filter button
		$item = &$this->FilterOptions->Add("savecurrentfilter");
		$item->Body = "<a class=\"ewSaveFilter\" data-form=\"fmtm_staff_projectlistsrch\" href=\"#\">" . $Language->Phrase("SaveCurrentFilter") . "</a>";
		$item->Visible = TRUE;
		$item = &$this->FilterOptions->Add("deletefilter");
		$item->Body = "<a class=\"ewDeleteFilter\" data-form=\"fmtm_staff_projectlistsrch\" href=\"#\">" . $Language->Phrase("DeleteFilter") . "</a>";
		$item->Visible = TRUE;
		$this->FilterOptions->UseDropDownButton = TRUE;
		$this->FilterOptions->UseButtonGroup = !$this->FilterOptions->UseDropDownButton;
		$this->FilterOptions->DropDownButtonPhrase = $Language->Phrase("Filters");

		// Add group option item
		$item = &$this->FilterOptions->Add($this->FilterOptions->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;
	}

	// Render other options
	function RenderOtherOptions() {
		global $Language, $Security;
		$options = &$this->OtherOptions;
		if ($this->CurrentAction <> "gridadd" && $this->CurrentAction <> "gridedit") { // Not grid add/edit mode
			$option = &$options["action"];

			// Set up list action buttons
			foreach ($this->ListActions->Items as $listaction) {
				if ($listaction->Select == EW_ACTION_MULTIPLE) {
					$item = &$option->Add("custom_" . $listaction->Action);
					$caption = $listaction->Caption;
					$icon = ($listaction->Icon <> "") ? "<span class=\"" . ew_HtmlEncode($listaction->Icon) . "\" data-caption=\"" . ew_HtmlEncode($caption) . "\"></span> " : $caption;
					$item->Body = "<a class=\"ewAction ewListAction\" title=\"" . ew_HtmlEncode($caption) . "\" data-caption=\"" . ew_HtmlEncode($caption) . "\" href=\"\" onclick=\"ew_SubmitAction(event,jQuery.extend({f:document.fmtm_staff_projectlist}," . $listaction->ToJson(TRUE) . "));return false;\">" . $icon . "</a>";
					$item->Visible = $listaction->Allow;
				}
			}

			// Hide grid edit and other options
			if ($this->TotalRecs <= 0) {
				$option = &$options["addedit"];
				$item = &$option->GetItem("gridedit");
				if ($item) $item->Visible = FALSE;
				$option = &$options["action"];
				$option->HideAllOptions();
			}
		} else { // Grid add/edit mode

			// Hide all options first
			foreach ($options as &$option)
				$option->HideAllOptions();
			if ($this->CurrentAction == "gridadd") {
				if ($this->AllowAddDeleteRow) {

					// Add add blank row
					$option = &$options["addedit"];
					$option->UseDropDownButton = FALSE;
					$option->UseImageAndText = TRUE;
					$item = &$option->Add("addblankrow");
					$item->Body = "<a class=\"ewAddEdit ewAddBlankRow\" title=\"" . ew_HtmlTitle($Language->Phrase("AddBlankRow")) . "\" data-caption=\"" . ew_HtmlTitle($Language->Phrase("AddBlankRow")) . "\" href=\"javascript:void(0);\" onclick=\"ew_AddGridRow(this);\">" . $Language->Phrase("AddBlankRow") . "</a>";
					$item->Visible = $Security->CanAdd();
				}
				$option = &$options["action"];
				$option->UseDropDownButton = FALSE;
				$option->UseImageAndText = TRUE;

				// Add grid insert
				$item = &$option->Add("gridinsert");
				$item->Body = "<a class=\"ewAction ewGridInsert\" title=\"" . ew_HtmlTitle($Language->Phrase("GridInsertLink")) . "\" data-caption=\"" . ew_HtmlTitle($Language->Phrase("GridInsertLink")) . "\" href=\"\" onclick=\"return ewForms(this).Submit('" . $this->PageName() . "');\">" . $Language->Phrase("GridInsertLink") . "</a>";

				// Add grid cancel
				$item = &$option->Add("gridcancel");
				$cancelurl = $this->AddMasterUrl($this->PageUrl() . "a=cancel");
				$item->Body = "<a class=\"ewAction ewGridCancel\" title=\"" . ew_HtmlTitle($Language->Phrase("GridCancelLink")) . "\" data-caption=\"" . ew_HtmlTitle($Language->Phrase("GridCancelLink")) . "\" href=\"" . $cancelurl . "\">" . $Language->Phrase("GridCancelLink") . "</a>";
			}
			if ($this->CurrentAction == "gridedit") {
				if ($this->AllowAddDeleteRow) {

					// Add add blank row
					$option = &$options["addedit"];
					$option->UseDropDownButton = FALSE;
					$option->UseImageAndText = TRUE;
					$item = &$option->Add("addblankrow");
					$item->Body = "<a class=\"ewAddEdit ewAddBlankRow\" title=\"" . ew_HtmlTitle($Language->Phrase("AddBlankRow")) . "\" data-caption=\"" . ew_HtmlTitle($Language->Phrase("AddBlankRow")) . "\" href=\"javascript:void(0);\" onclick=\"ew_AddGridRow(this);\">" . $Language->Phrase("AddBlankRow") . "</a>";
					$item->Visible = $Security->CanAdd();
				}
				$option = &$options["action"];
				$option->UseDropDownButton = FALSE;
				$option->UseImageAndText = TRUE;
					$item = &$option->Add("gridsave");
					$item->Body = "<a class=\"ewAction ewGridSave\" title=\"" . ew_HtmlTitle($Language->Phrase("GridSaveLink")) . "\" data-caption=\"" . ew_HtmlTitle($Language->Phrase("GridSaveLink")) . "\" href=\"\" onclick=\"return ewForms(this).Submit('" . $this->PageName() . "');\">" . $Language->Phrase("GridSaveLink") . "</a>";
					$item = &$option->Add("gridcancel");
					$cancelurl = $this->AddMasterUrl($this->PageUrl() . "a=cancel");
					$item->Body = "<a class=\"ewAction ewGridCancel\" title=\"" . ew_HtmlTitle($Language->Phrase("GridCancelLink")) . "\" data-caption=\"" . ew_HtmlTitle($Language->Phrase("GridCancelLink")) . "\" href=\"" . $cancelurl . "\">" . $Language->Phrase("GridCancelLink") . "</a>";
			}
		}
	}

	// Process list action
	function ProcessListAction() {
		global $Language, $Security;
		$userlist = "";
		$user = "";
		$sFilter = $this->GetKeyFilter();
		$UserAction = @$_POST["useraction"];
		if ($sFilter <> "" && $UserAction <> "") {

			// Check permission first
			$ActionCaption = $UserAction;
			if (array_key_exists($UserAction, $this->ListActions->Items)) {
				$ActionCaption = $this->ListActions->Items[$UserAction]->Caption;
				if (!$this->ListActions->Items[$UserAction]->Allow) {
					$errmsg = str_replace('%s', $ActionCaption, $Language->Phrase("CustomActionNotAllowed"));
					if (@$_POST["ajax"] == $UserAction) // Ajax
						echo "<p class=\"text-danger\">" . $errmsg . "</p>";
					else
						$this->setFailureMessage($errmsg);
					return FALSE;
				}
			}
			$this->CurrentFilter = $sFilter;
			$sSql = $this->SQL();
			$conn = &$this->Connection();
			$conn->raiseErrorFn = $GLOBALS["EW_ERROR_FN"];
			$rs = $conn->Execute($sSql);
			$conn->raiseErrorFn = '';
			$this->CurrentAction = $UserAction;

			// Call row action event
			if ($rs && !$rs->EOF) {
				$conn->BeginTrans();
				$this->SelectedCount = $rs->RecordCount();
				$this->SelectedIndex = 0;
				while (!$rs->EOF) {
					$this->SelectedIndex++;
					$row = $rs->fields;
					$Processed = $this->Row_CustomAction($UserAction, $row);
					if (!$Processed) break;
					$rs->MoveNext();
				}
				if ($Processed) {
					$conn->CommitTrans(); // Commit the changes
					if ($this->getSuccessMessage() == "")
						$this->setSuccessMessage(str_replace('%s', $ActionCaption, $Language->Phrase("CustomActionCompleted"))); // Set up success message
				} else {
					$conn->RollbackTrans(); // Rollback changes

					// Set up error message
					if ($this->getSuccessMessage() <> "" || $this->getFailureMessage() <> "") {

						// Use the message, do nothing
					} elseif ($this->CancelMessage <> "") {
						$this->setFailureMessage($this->CancelMessage);
						$this->CancelMessage = "";
					} else {
						$this->setFailureMessage(str_replace('%s', $ActionCaption, $Language->Phrase("CustomActionFailed")));
					}
				}
			}
			if ($rs)
				$rs->Close();
			$this->CurrentAction = ""; // Clear action
			if (@$_POST["ajax"] == $UserAction) { // Ajax
				if ($this->getSuccessMessage() <> "") {
					echo "<p class=\"text-success\">" . $this->getSuccessMessage() . "</p>";
					$this->ClearSuccessMessage(); // Clear message
				}
				if ($this->getFailureMessage() <> "") {
					echo "<p class=\"text-danger\">" . $this->getFailureMessage() . "</p>";
					$this->ClearFailureMessage(); // Clear message
				}
				return TRUE;
			}
		}
		return FALSE; // Not ajax request
	}

	// Set up search options
	function SetupSearchOptions() {
		global $Language;
		$this->SearchOptions = new cListOptions();
		$this->SearchOptions->Tag = "div";
		$this->SearchOptions->TagClassName = "ewSearchOption";

		// Search button
		$item = &$this->SearchOptions->Add("searchtoggle");
		$SearchToggleClass = ($this->SearchWhere <> "") ? " active" : " active";
		$item->Body = "<button type=\"button\" class=\"btn btn-default ewSearchToggle" . $SearchToggleClass . "\" title=\"" . $Language->Phrase("SearchPanel") . "\" data-caption=\"" . $Language->Phrase("SearchPanel") . "\" data-toggle=\"button\" data-form=\"fmtm_staff_projectlistsrch\">" . $Language->Phrase("SearchBtn") . "</button>";
		$item->Visible = TRUE;

		// Show all button
		$item = &$this->SearchOptions->Add("showall");
		$item->Body = "<a class=\"btn btn-default ewShowAll\" title=\"" . $Language->Phrase("ShowAll") . "\" data-caption=\"" . $Language->Phrase("ShowAll") . "\" href=\"" . $this->PageUrl() . "cmd=reset\">" . $Language->Phrase("ShowAllBtn") . "</a>";
		$item->Visible = ($this->SearchWhere <> $this->DefaultSearchWhere && $this->SearchWhere <> "0=101");

		// Button group for search
		$this->SearchOptions->UseDropDownButton = FALSE;
		$this->SearchOptions->UseImageAndText = TRUE;
		$this->SearchOptions->UseButtonGroup = TRUE;
		$this->SearchOptions->DropDownButtonPhrase = $Language->Phrase("ButtonSearch");

		// Add group option item
		$item = &$this->SearchOptions->Add($this->SearchOptions->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;

		// Hide search options
		if ($this->Export <> "" || $this->CurrentAction <> "")
			$this->SearchOptions->HideAllOptions();
		global $Security;
		if (!$Security->CanSearch()) {
			$this->SearchOptions->HideAllOptions();
			$this->FilterOptions->HideAllOptions();
		}
	}

	function SetupListOptionsExt() {
		global $Security, $Language;

		// Hide detail items for dropdown if necessary
		$this->ListOptions->HideDetailItemsForDropDown();
	}

	function RenderListOptionsExt() {
		global $Security, $Language;
	}

	// Set up starting record parameters
	function SetUpStartRec() {
		if ($this->DisplayRecs == 0)
			return;
		if ($this->IsPageRequest()) { // Validate request
			if (@$_GET[EW_TABLE_START_REC] <> "") { // Check for "start" parameter
				$this->StartRec = $_GET[EW_TABLE_START_REC];
				$this->setStartRecordNumber($this->StartRec);
			} elseif (@$_GET[EW_TABLE_PAGE_NO] <> "") {
				$PageNo = $_GET[EW_TABLE_PAGE_NO];
				if (is_numeric($PageNo)) {
					$this->StartRec = ($PageNo-1)*$this->DisplayRecs+1;
					if ($this->StartRec <= 0) {
						$this->StartRec = 1;
					} elseif ($this->StartRec >= intval(($this->TotalRecs-1)/$this->DisplayRecs)*$this->DisplayRecs+1) {
						$this->StartRec = intval(($this->TotalRecs-1)/$this->DisplayRecs)*$this->DisplayRecs+1;
					}
					$this->setStartRecordNumber($this->StartRec);
				}
			}
		}
		$this->StartRec = $this->getStartRecordNumber();

		// Check if correct start record counter
		if (!is_numeric($this->StartRec) || $this->StartRec == "") { // Avoid invalid start record counter
			$this->StartRec = 1; // Reset start record counter
			$this->setStartRecordNumber($this->StartRec);
		} elseif (intval($this->StartRec) > intval($this->TotalRecs)) { // Avoid starting record > total records
			$this->StartRec = intval(($this->TotalRecs-1)/$this->DisplayRecs)*$this->DisplayRecs+1; // Point to last page first record
			$this->setStartRecordNumber($this->StartRec);
		} elseif (($this->StartRec-1) % $this->DisplayRecs <> 0) {
			$this->StartRec = intval(($this->StartRec-1)/$this->DisplayRecs)*$this->DisplayRecs+1; // Point to page boundary
			$this->setStartRecordNumber($this->StartRec);
		}
	}

	// Load default values
	function LoadDefaultValues() {
		$this->projID->CurrentValue = 0;
		$this->projID->OldValue = $this->projID->CurrentValue;
		$this->staffID->CurrentValue = 0;
		$this->staffID->OldValue = $this->staffID->CurrentValue;
		$this->role->CurrentValue = NULL;
		$this->role->OldValue = $this->role->CurrentValue;
		$this->TimeSpentProject->CurrentValue = NULL;
		$this->TimeSpentProject->OldValue = $this->TimeSpentProject->CurrentValue;
	}

	// Load basic search values
	function LoadBasicSearchValues() {
		$this->BasicSearch->Keyword = @$_GET[EW_TABLE_BASIC_SEARCH];
		if ($this->BasicSearch->Keyword <> "") $this->Command = "search";
		$this->BasicSearch->Type = @$_GET[EW_TABLE_BASIC_SEARCH_TYPE];
	}

	// Load form values
	function LoadFormValues() {

		// Load from form
		global $objForm;
		if (!$this->projID->FldIsDetailKey) {
			$this->projID->setFormValue($objForm->GetValue("x_projID"));
		}
		$this->projID->setOldValue($objForm->GetValue("o_projID"));
		if (!$this->staffID->FldIsDetailKey) {
			$this->staffID->setFormValue($objForm->GetValue("x_staffID"));
		}
		$this->staffID->setOldValue($objForm->GetValue("o_staffID"));
		if (!$this->role->FldIsDetailKey) {
			$this->role->setFormValue($objForm->GetValue("x_role"));
		}
		$this->role->setOldValue($objForm->GetValue("o_role"));
		if (!$this->TimeSpentProject->FldIsDetailKey) {
			$this->TimeSpentProject->setFormValue($objForm->GetValue("x_TimeSpentProject"));
		}
		$this->TimeSpentProject->setOldValue($objForm->GetValue("o_TimeSpentProject"));
	}

	// Restore form values
	function RestoreFormValues() {
		global $objForm;
		$this->projID->CurrentValue = $this->projID->FormValue;
		$this->staffID->CurrentValue = $this->staffID->FormValue;
		$this->role->CurrentValue = $this->role->FormValue;
		$this->TimeSpentProject->CurrentValue = $this->TimeSpentProject->FormValue;
	}

	// Load recordset
	function LoadRecordset($offset = -1, $rowcnt = -1) {

		// Load List page SQL
		$sSql = $this->SelectSQL();
		$conn = &$this->Connection();

		// Load recordset
		$dbtype = ew_GetConnectionType($this->DBID);
		if ($this->UseSelectLimit) {
			$conn->raiseErrorFn = $GLOBALS["EW_ERROR_FN"];
			if ($dbtype == "MSSQL") {
				$rs = $conn->SelectLimit($sSql, $rowcnt, $offset, array("_hasOrderBy" => trim($this->getOrderBy()) || trim($this->getSessionOrderBy())));
			} else {
				$rs = $conn->SelectLimit($sSql, $rowcnt, $offset);
			}
			$conn->raiseErrorFn = '';
		} else {
			$rs = ew_LoadRecordset($sSql, $conn);
		}

		// Call Recordset Selected event
		$this->Recordset_Selected($rs);
		return $rs;
	}

	// Load row based on key values
	function LoadRow() {
		global $Security, $Language;
		$sFilter = $this->KeyFilter();

		// Call Row Selecting event
		$this->Row_Selecting($sFilter);

		// Load SQL based on filter
		$this->CurrentFilter = $sFilter;
		$sSql = $this->SQL();
		$conn = &$this->Connection();
		$res = FALSE;
		$rs = ew_LoadRecordset($sSql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->LoadRowValues($rs); // Load row values
			$rs->Close();
		}
		return $res;
	}

	// Load row values from recordset
	function LoadRowValues(&$rs) {
		if (!$rs || $rs->EOF) return;

		// Call Row Selected event
		$row = &$rs->fields;
		$this->Row_Selected($row);
		$this->projID->setDbValue($rs->fields('projID'));
		$this->staffID->setDbValue($rs->fields('staffID'));
		$this->role->setDbValue($rs->fields('role'));
		$this->TimeSpentProject->setDbValue($rs->fields('TimeSpentProject'));
	}

	// Load DbValue from recordset
	function LoadDbValues(&$rs) {
		if (!$rs || !is_array($rs) && $rs->EOF) return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->projID->DbValue = $row['projID'];
		$this->staffID->DbValue = $row['staffID'];
		$this->role->DbValue = $row['role'];
		$this->TimeSpentProject->DbValue = $row['TimeSpentProject'];
	}

	// Load old record
	function LoadOldRecord() {

		// Load key values from Session
		$bValidKey = TRUE;
		if (strval($this->getKey("projID")) <> "")
			$this->projID->CurrentValue = $this->getKey("projID"); // projID
		else
			$bValidKey = FALSE;
		if (strval($this->getKey("staffID")) <> "")
			$this->staffID->CurrentValue = $this->getKey("staffID"); // staffID
		else
			$bValidKey = FALSE;

		// Load old recordset
		if ($bValidKey) {
			$this->CurrentFilter = $this->KeyFilter();
			$sSql = $this->SQL();
			$conn = &$this->Connection();
			$this->OldRecordset = ew_LoadRecordset($sSql, $conn);
			$this->LoadRowValues($this->OldRecordset); // Load row values
		} else {
			$this->OldRecordset = NULL;
		}
		return $bValidKey;
	}

	// Render row values based on field settings
	function RenderRow() {
		global $Security, $Language, $gsLanguage;

		// Initialize URLs
		$this->ViewUrl = $this->GetViewUrl();
		$this->EditUrl = $this->GetEditUrl();
		$this->InlineEditUrl = $this->GetInlineEditUrl();
		$this->CopyUrl = $this->GetCopyUrl();
		$this->InlineCopyUrl = $this->GetInlineCopyUrl();
		$this->DeleteUrl = $this->GetDeleteUrl();

		// Call Row_Rendering event
		$this->Row_Rendering();

		// Common render codes for all row types
		// projID
		// staffID
		// role
		// TimeSpentProject

		if ($this->RowType == EW_ROWTYPE_VIEW) { // View row

		// projID
		if (strval($this->projID->CurrentValue) <> "") {
			$sFilterWrk = "`id`" . ew_SearchString("=", $this->projID->CurrentValue, EW_DATATYPE_NUMBER, "");
		$sSqlWrk = "SELECT `id`, `name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `project`";
		$sWhereWrk = "";
		ew_AddFilter($sWhereWrk, $sFilterWrk);
		$this->Lookup_Selecting($this->projID, $sWhereWrk); // Call Lookup selecting
		if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
			$rswrk = Conn()->Execute($sSqlWrk);
			if ($rswrk && !$rswrk->EOF) { // Lookup values found
				$arwrk = array();
				$arwrk[1] = $rswrk->fields('DispFld');
				$this->projID->ViewValue = $this->projID->DisplayValue($arwrk);
				$rswrk->Close();
			} else {
				$this->projID->ViewValue = $this->projID->CurrentValue;
			}
		} else {
			$this->projID->ViewValue = NULL;
		}
		$this->projID->ViewCustomAttributes = "";

		// staffID
		if (strval($this->staffID->CurrentValue) <> "") {
			$sFilterWrk = "`id`" . ew_SearchString("=", $this->staffID->CurrentValue, EW_DATATYPE_NUMBER, "");
		$sSqlWrk = "SELECT `id`, `Name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `staff`";
		$sWhereWrk = "";
		ew_AddFilter($sWhereWrk, $sFilterWrk);
		$this->Lookup_Selecting($this->staffID, $sWhereWrk); // Call Lookup selecting
		if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
			$rswrk = Conn()->Execute($sSqlWrk);
			if ($rswrk && !$rswrk->EOF) { // Lookup values found
				$arwrk = array();
				$arwrk[1] = $rswrk->fields('DispFld');
				$this->staffID->ViewValue = $this->staffID->DisplayValue($arwrk);
				$rswrk->Close();
			} else {
				$this->staffID->ViewValue = $this->staffID->CurrentValue;
			}
		} else {
			$this->staffID->ViewValue = NULL;
		}
		$this->staffID->ViewCustomAttributes = "";

		// role
		if (strval($this->role->CurrentValue) <> "") {
			$this->role->ViewValue = $this->role->OptionCaption($this->role->CurrentValue);
		} else {
			$this->role->ViewValue = NULL;
		}
		$this->role->ViewCustomAttributes = "";

		// TimeSpentProject
		$this->TimeSpentProject->ViewValue = $this->TimeSpentProject->CurrentValue;
		$this->TimeSpentProject->ViewCustomAttributes = "";

			// projID
			$this->projID->LinkCustomAttributes = "";
			$this->projID->HrefValue = "";
			$this->projID->TooltipValue = "";

			// staffID
			$this->staffID->LinkCustomAttributes = "";
			$this->staffID->HrefValue = "";
			$this->staffID->TooltipValue = "";

			// role
			$this->role->LinkCustomAttributes = "";
			$this->role->HrefValue = "";
			$this->role->TooltipValue = "";

			// TimeSpentProject
			$this->TimeSpentProject->LinkCustomAttributes = "";
			$this->TimeSpentProject->HrefValue = "";
			$this->TimeSpentProject->TooltipValue = "";
		} elseif ($this->RowType == EW_ROWTYPE_ADD) { // Add row

			// projID
			$this->projID->EditAttrs["class"] = "form-control";
			$this->projID->EditCustomAttributes = "";
			if ($this->projID->getSessionValue() <> "") {
				$this->projID->CurrentValue = $this->projID->getSessionValue();
				$this->projID->OldValue = $this->projID->CurrentValue;
			if (strval($this->projID->CurrentValue) <> "") {
				$sFilterWrk = "`id`" . ew_SearchString("=", $this->projID->CurrentValue, EW_DATATYPE_NUMBER, "");
			$sSqlWrk = "SELECT `id`, `name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `project`";
			$sWhereWrk = "";
			ew_AddFilter($sWhereWrk, $sFilterWrk);
			$this->Lookup_Selecting($this->projID, $sWhereWrk); // Call Lookup selecting
			if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
				$rswrk = Conn()->Execute($sSqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = array();
					$arwrk[1] = $rswrk->fields('DispFld');
					$this->projID->ViewValue = $this->projID->DisplayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->projID->ViewValue = $this->projID->CurrentValue;
				}
			} else {
				$this->projID->ViewValue = NULL;
			}
			$this->projID->ViewCustomAttributes = "";
			} else {
			if (trim(strval($this->projID->CurrentValue)) == "") {
				$sFilterWrk = "0=1";
			} else {
				$sFilterWrk = "`id`" . ew_SearchString("=", $this->projID->CurrentValue, EW_DATATYPE_NUMBER, "");
			}
			$sSqlWrk = "SELECT `id`, `name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld`, '' AS `SelectFilterFld`, '' AS `SelectFilterFld2`, '' AS `SelectFilterFld3`, '' AS `SelectFilterFld4` FROM `project`";
			$sWhereWrk = "";
			ew_AddFilter($sWhereWrk, $sFilterWrk);
			$this->Lookup_Selecting($this->projID, $sWhereWrk); // Call Lookup selecting
			if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
			$rswrk = Conn()->Execute($sSqlWrk);
			$arwrk = ($rswrk) ? $rswrk->GetRows() : array();
			if ($rswrk) $rswrk->Close();
			array_unshift($arwrk, array("", $Language->Phrase("PleaseSelect"), "", "", "", "", "", "", ""));
			$this->projID->EditValue = $arwrk;
			}

			// staffID
			$this->staffID->EditAttrs["class"] = "form-control";
			$this->staffID->EditCustomAttributes = "";
			if ($this->staffID->getSessionValue() <> "") {
				$this->staffID->CurrentValue = $this->staffID->getSessionValue();
				$this->staffID->OldValue = $this->staffID->CurrentValue;
			if (strval($this->staffID->CurrentValue) <> "") {
				$sFilterWrk = "`id`" . ew_SearchString("=", $this->staffID->CurrentValue, EW_DATATYPE_NUMBER, "");
			$sSqlWrk = "SELECT `id`, `Name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `staff`";
			$sWhereWrk = "";
			ew_AddFilter($sWhereWrk, $sFilterWrk);
			$this->Lookup_Selecting($this->staffID, $sWhereWrk); // Call Lookup selecting
			if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
				$rswrk = Conn()->Execute($sSqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = array();
					$arwrk[1] = $rswrk->fields('DispFld');
					$this->staffID->ViewValue = $this->staffID->DisplayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->staffID->ViewValue = $this->staffID->CurrentValue;
				}
			} else {
				$this->staffID->ViewValue = NULL;
			}
			$this->staffID->ViewCustomAttributes = "";
			} else {
			if (trim(strval($this->staffID->CurrentValue)) == "") {
				$sFilterWrk = "0=1";
			} else {
				$sFilterWrk = "`id`" . ew_SearchString("=", $this->staffID->CurrentValue, EW_DATATYPE_NUMBER, "");
			}
			$sSqlWrk = "SELECT `id`, `Name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld`, '' AS `SelectFilterFld`, '' AS `SelectFilterFld2`, '' AS `SelectFilterFld3`, '' AS `SelectFilterFld4` FROM `staff`";
			$sWhereWrk = "";
			ew_AddFilter($sWhereWrk, $sFilterWrk);
			if (!$GLOBALS["mtm_staff_project"]->UserIDAllow($GLOBALS["mtm_staff_project"]->CurrentAction)) $sWhereWrk = $GLOBALS["staff"]->AddUserIDFilter($sWhereWrk);
			$this->Lookup_Selecting($this->staffID, $sWhereWrk); // Call Lookup selecting
			if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
			$rswrk = Conn()->Execute($sSqlWrk);
			$arwrk = ($rswrk) ? $rswrk->GetRows() : array();
			if ($rswrk) $rswrk->Close();
			array_unshift($arwrk, array("", $Language->Phrase("PleaseSelect"), "", "", "", "", "", "", ""));
			$this->staffID->EditValue = $arwrk;
			}

			// role
			$this->role->EditCustomAttributes = "";
			$this->role->EditValue = $this->role->Options(FALSE);

			// TimeSpentProject
			$this->TimeSpentProject->EditAttrs["class"] = "form-control";
			$this->TimeSpentProject->EditCustomAttributes = "";
			$this->TimeSpentProject->EditValue = ew_HtmlEncode($this->TimeSpentProject->CurrentValue);
			$this->TimeSpentProject->PlaceHolder = ew_RemoveHtml($this->TimeSpentProject->FldCaption());

			// Add refer script
			// projID

			$this->projID->LinkCustomAttributes = "";
			$this->projID->HrefValue = "";

			// staffID
			$this->staffID->LinkCustomAttributes = "";
			$this->staffID->HrefValue = "";

			// role
			$this->role->LinkCustomAttributes = "";
			$this->role->HrefValue = "";

			// TimeSpentProject
			$this->TimeSpentProject->LinkCustomAttributes = "";
			$this->TimeSpentProject->HrefValue = "";
		} elseif ($this->RowType == EW_ROWTYPE_EDIT) { // Edit row

			// projID
			$this->projID->EditAttrs["class"] = "form-control";
			$this->projID->EditCustomAttributes = "";
			if (strval($this->projID->CurrentValue) <> "") {
				$sFilterWrk = "`id`" . ew_SearchString("=", $this->projID->CurrentValue, EW_DATATYPE_NUMBER, "");
			$sSqlWrk = "SELECT `id`, `name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `project`";
			$sWhereWrk = "";
			ew_AddFilter($sWhereWrk, $sFilterWrk);
			$this->Lookup_Selecting($this->projID, $sWhereWrk); // Call Lookup selecting
			if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
				$rswrk = Conn()->Execute($sSqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = array();
					$arwrk[1] = $rswrk->fields('DispFld');
					$this->projID->EditValue = $this->projID->DisplayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->projID->EditValue = $this->projID->CurrentValue;
				}
			} else {
				$this->projID->EditValue = NULL;
			}
			$this->projID->ViewCustomAttributes = "";

			// staffID
			$this->staffID->EditAttrs["class"] = "form-control";
			$this->staffID->EditCustomAttributes = "";
			if (strval($this->staffID->CurrentValue) <> "") {
				$sFilterWrk = "`id`" . ew_SearchString("=", $this->staffID->CurrentValue, EW_DATATYPE_NUMBER, "");
			$sSqlWrk = "SELECT `id`, `Name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `staff`";
			$sWhereWrk = "";
			ew_AddFilter($sWhereWrk, $sFilterWrk);
			$this->Lookup_Selecting($this->staffID, $sWhereWrk); // Call Lookup selecting
			if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
				$rswrk = Conn()->Execute($sSqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = array();
					$arwrk[1] = $rswrk->fields('DispFld');
					$this->staffID->EditValue = $this->staffID->DisplayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->staffID->EditValue = $this->staffID->CurrentValue;
				}
			} else {
				$this->staffID->EditValue = NULL;
			}
			$this->staffID->ViewCustomAttributes = "";

			// role
			$this->role->EditCustomAttributes = "";
			$this->role->EditValue = $this->role->Options(FALSE);

			// TimeSpentProject
			$this->TimeSpentProject->EditAttrs["class"] = "form-control";
			$this->TimeSpentProject->EditCustomAttributes = "";
			$this->TimeSpentProject->EditValue = ew_HtmlEncode($this->TimeSpentProject->CurrentValue);
			$this->TimeSpentProject->PlaceHolder = ew_RemoveHtml($this->TimeSpentProject->FldCaption());

			// Edit refer script
			// projID

			$this->projID->LinkCustomAttributes = "";
			$this->projID->HrefValue = "";

			// staffID
			$this->staffID->LinkCustomAttributes = "";
			$this->staffID->HrefValue = "";

			// role
			$this->role->LinkCustomAttributes = "";
			$this->role->HrefValue = "";

			// TimeSpentProject
			$this->TimeSpentProject->LinkCustomAttributes = "";
			$this->TimeSpentProject->HrefValue = "";
		}
		if ($this->RowType == EW_ROWTYPE_ADD ||
			$this->RowType == EW_ROWTYPE_EDIT ||
			$this->RowType == EW_ROWTYPE_SEARCH) { // Add / Edit / Search row
			$this->SetupFieldTitles();
		}

		// Call Row Rendered event
		if ($this->RowType <> EW_ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate form
	function ValidateForm() {
		global $Language, $gsFormError;

		// Initialize form error message
		$gsFormError = "";

		// Check if validation required
		if (!EW_SERVER_VALIDATE)
			return ($gsFormError == "");
		if (!$this->projID->FldIsDetailKey && !is_null($this->projID->FormValue) && $this->projID->FormValue == "") {
			ew_AddMessage($gsFormError, str_replace("%s", $this->projID->FldCaption(), $this->projID->ReqErrMsg));
		}
		if (!$this->staffID->FldIsDetailKey && !is_null($this->staffID->FormValue) && $this->staffID->FormValue == "") {
			ew_AddMessage($gsFormError, str_replace("%s", $this->staffID->FldCaption(), $this->staffID->ReqErrMsg));
		}
		if (!ew_CheckInteger($this->TimeSpentProject->FormValue)) {
			ew_AddMessage($gsFormError, $this->TimeSpentProject->FldErrMsg());
		}

		// Return validate result
		$ValidateForm = ($gsFormError == "");

		// Call Form_CustomValidate event
		$sFormCustomError = "";
		$ValidateForm = $ValidateForm && $this->Form_CustomValidate($sFormCustomError);
		if ($sFormCustomError <> "") {
			ew_AddMessage($gsFormError, $sFormCustomError);
		}
		return $ValidateForm;
	}

	//
	// Delete records based on current filter
	//
	function DeleteRows() {
		global $Language, $Security;
		if (!$Security->CanDelete()) {
			$this->setFailureMessage($Language->Phrase("NoDeletePermission")); // No delete permission
			return FALSE;
		}
		$DeleteRows = TRUE;
		$sSql = $this->SQL();
		$conn = &$this->Connection();
		$conn->raiseErrorFn = $GLOBALS["EW_ERROR_FN"];
		$rs = $conn->Execute($sSql);
		$conn->raiseErrorFn = '';
		if ($rs === FALSE) {
			return FALSE;
		} elseif ($rs->EOF) {
			$this->setFailureMessage($Language->Phrase("NoRecord")); // No record found
			$rs->Close();
			return FALSE;

		//} else {
		//	$this->LoadRowValues($rs); // Load row values

		}
		$rows = ($rs) ? $rs->GetRows() : array();
		if ($this->AuditTrailOnDelete) $this->WriteAuditTrailDummy($Language->Phrase("BatchDeleteBegin")); // Batch delete begin

		// Clone old rows
		$rsold = $rows;
		if ($rs)
			$rs->Close();

		// Call row deleting event
		if ($DeleteRows) {
			foreach ($rsold as $row) {
				$DeleteRows = $this->Row_Deleting($row);
				if (!$DeleteRows) break;
			}
		}
		if ($DeleteRows) {
			$sKey = "";
			foreach ($rsold as $row) {
				$sThisKey = "";
				if ($sThisKey <> "") $sThisKey .= $GLOBALS["EW_COMPOSITE_KEY_SEPARATOR"];
				$sThisKey .= $row['projID'];
				if ($sThisKey <> "") $sThisKey .= $GLOBALS["EW_COMPOSITE_KEY_SEPARATOR"];
				$sThisKey .= $row['staffID'];
				$this->LoadDbValues($row);
				$conn->raiseErrorFn = $GLOBALS["EW_ERROR_FN"];
				$DeleteRows = $this->Delete($row); // Delete
				$conn->raiseErrorFn = '';
				if ($DeleteRows === FALSE)
					break;
				if ($sKey <> "") $sKey .= ", ";
				$sKey .= $sThisKey;
			}
		} else {

			// Set up error message
			if ($this->getSuccessMessage() <> "" || $this->getFailureMessage() <> "") {

				// Use the message, do nothing
			} elseif ($this->CancelMessage <> "") {
				$this->setFailureMessage($this->CancelMessage);
				$this->CancelMessage = "";
			} else {
				$this->setFailureMessage($Language->Phrase("DeleteCancelled"));
			}
		}
		if ($DeleteRows) {
			if ($DeleteRows) {
				foreach ($rsold as $row)
					$this->WriteAuditTrailOnDelete($row);
			}
			if ($this->AuditTrailOnDelete) $this->WriteAuditTrailDummy($Language->Phrase("BatchDeleteSuccess")); // Batch delete success
		} else {
		}

		// Call Row Deleted event
		if ($DeleteRows) {
			foreach ($rsold as $row) {
				$this->Row_Deleted($row);
			}
		}
		return $DeleteRows;
	}

	// Update record based on key values
	function EditRow() {
		global $Security, $Language;
		$sFilter = $this->KeyFilter();
		$sFilter = $this->ApplyUserIDFilters($sFilter);
		$conn = &$this->Connection();
		$this->CurrentFilter = $sFilter;
		$sSql = $this->SQL();
		$conn->raiseErrorFn = $GLOBALS["EW_ERROR_FN"];
		$rs = $conn->Execute($sSql);
		$conn->raiseErrorFn = '';
		if ($rs === FALSE)
			return FALSE;
		if ($rs->EOF) {
			$this->setFailureMessage($Language->Phrase("NoRecord")); // Set no record message
			$EditRow = FALSE; // Update Failed
		} else {

			// Save old values
			$rsold = &$rs->fields;
			$this->LoadDbValues($rsold);
			$rsnew = array();

			// projID
			// staffID
			// role

			$this->role->SetDbValueDef($rsnew, $this->role->CurrentValue, NULL, $this->role->ReadOnly);

			// TimeSpentProject
			$this->TimeSpentProject->SetDbValueDef($rsnew, $this->TimeSpentProject->CurrentValue, NULL, $this->TimeSpentProject->ReadOnly);

			// Check referential integrity for master table 'staff'
			$bValidMasterRecord = TRUE;
			$sMasterFilter = $this->SqlMasterFilter_staff();
			$KeyValue = isset($rsnew['staffID']) ? $rsnew['staffID'] : $rsold['staffID'];
			if (strval($KeyValue) <> "") {
				$sMasterFilter = str_replace("@id@", ew_AdjustSql($KeyValue), $sMasterFilter);
			} else {
				$bValidMasterRecord = FALSE;
			}
			if ($bValidMasterRecord) {
				$rsmaster = $GLOBALS["staff"]->LoadRs($sMasterFilter);
				$bValidMasterRecord = ($rsmaster && !$rsmaster->EOF);
				$rsmaster->Close();
			}
			if (!$bValidMasterRecord) {
				$sRelatedRecordMsg = str_replace("%t", "staff", $Language->Phrase("RelatedRecordRequired"));
				$this->setFailureMessage($sRelatedRecordMsg);
				$rs->Close();
				return FALSE;
			}

			// Check referential integrity for master table 'project'
			$bValidMasterRecord = TRUE;
			$sMasterFilter = $this->SqlMasterFilter_project();
			$KeyValue = isset($rsnew['projID']) ? $rsnew['projID'] : $rsold['projID'];
			if (strval($KeyValue) <> "") {
				$sMasterFilter = str_replace("@id@", ew_AdjustSql($KeyValue), $sMasterFilter);
			} else {
				$bValidMasterRecord = FALSE;
			}
			if ($bValidMasterRecord) {
				$rsmaster = $GLOBALS["project"]->LoadRs($sMasterFilter);
				$bValidMasterRecord = ($rsmaster && !$rsmaster->EOF);
				$rsmaster->Close();
			}
			if (!$bValidMasterRecord) {
				$sRelatedRecordMsg = str_replace("%t", "project", $Language->Phrase("RelatedRecordRequired"));
				$this->setFailureMessage($sRelatedRecordMsg);
				$rs->Close();
				return FALSE;
			}

			// Call Row Updating event
			$bUpdateRow = $this->Row_Updating($rsold, $rsnew);
			if ($bUpdateRow) {
				$conn->raiseErrorFn = $GLOBALS["EW_ERROR_FN"];
				if (count($rsnew) > 0)
					$EditRow = $this->Update($rsnew, "", $rsold);
				else
					$EditRow = TRUE; // No field to update
				$conn->raiseErrorFn = '';
				if ($EditRow) {
				}
			} else {
				if ($this->getSuccessMessage() <> "" || $this->getFailureMessage() <> "") {

					// Use the message, do nothing
				} elseif ($this->CancelMessage <> "") {
					$this->setFailureMessage($this->CancelMessage);
					$this->CancelMessage = "";
				} else {
					$this->setFailureMessage($Language->Phrase("UpdateCancelled"));
				}
				$EditRow = FALSE;
			}
		}

		// Call Row_Updated event
		if ($EditRow)
			$this->Row_Updated($rsold, $rsnew);
		if ($EditRow) {
			$this->WriteAuditTrailOnEdit($rsold, $rsnew);
		}
		$rs->Close();
		return $EditRow;
	}

	// Add record
	function AddRow($rsold = NULL) {
		global $Language, $Security;

		// Check if valid key values for master user
		if ($Security->CurrentUserID() <> "" && !$Security->IsAdmin()) { // Non system admin
			$sMasterFilter = $this->SqlMasterFilter_staff();
			if (strval($this->staffID->CurrentValue) <> "") {
				$sMasterFilter = str_replace("@id@", ew_AdjustSql($this->staffID->CurrentValue, "DB"), $sMasterFilter);
			} else {
				$sMasterFilter = "";
			}
			if ($sMasterFilter <> "") {
				$rsmaster = $GLOBALS["staff"]->LoadRs($sMasterFilter);
				$this->MasterRecordExists = ($rsmaster && !$rsmaster->EOF);
				$bValidMasterKey = TRUE;
				if ($this->MasterRecordExists) {
				$bValidMasterKey = $Security->IsValidUserID($rsmaster->fields['userid']);
				} elseif ($this->getCurrentMasterTable() == "staff") {
					$bValidMasterKey = FALSE;
				}
				if (!$bValidMasterKey) {
					$sMasterUserIdMsg = str_replace("%c", CurrentUserID(), $Language->Phrase("UnAuthorizedMasterUserID"));
					$sMasterUserIdMsg = str_replace("%f", $sMasterFilter, $sMasterUserIdMsg);
					$this->setFailureMessage($sMasterUserIdMsg);
					return FALSE;
				}
				if ($rsmaster) $rsmaster->Close();
			}
			$sMasterFilter = $this->SqlMasterFilter_project();
			if (strval($this->projID->CurrentValue) <> "") {
				$sMasterFilter = str_replace("@id@", ew_AdjustSql($this->projID->CurrentValue, "DB"), $sMasterFilter);
			} else {
				$sMasterFilter = "";
			}
			if ($sMasterFilter <> "") {
				$rsmaster = $GLOBALS["project"]->LoadRs($sMasterFilter);
				$this->MasterRecordExists = ($rsmaster && !$rsmaster->EOF);
				$bValidMasterKey = TRUE;
				if ($this->MasterRecordExists) {
				} elseif ($this->getCurrentMasterTable() == "project") {
					$bValidMasterKey = FALSE;
				}
				if (!$bValidMasterKey) {
					$sMasterUserIdMsg = str_replace("%c", CurrentUserID(), $Language->Phrase("UnAuthorizedMasterUserID"));
					$sMasterUserIdMsg = str_replace("%f", $sMasterFilter, $sMasterUserIdMsg);
					$this->setFailureMessage($sMasterUserIdMsg);
					return FALSE;
				}
				if ($rsmaster) $rsmaster->Close();
			}
		}

		// Check referential integrity for master table 'staff'
		$bValidMasterRecord = TRUE;
		$sMasterFilter = $this->SqlMasterFilter_staff();
		if (strval($this->staffID->CurrentValue) <> "") {
			$sMasterFilter = str_replace("@id@", ew_AdjustSql($this->staffID->CurrentValue, "DB"), $sMasterFilter);
		} else {
			$bValidMasterRecord = FALSE;
		}
		if ($bValidMasterRecord) {
			$rsmaster = $GLOBALS["staff"]->LoadRs($sMasterFilter);
			$bValidMasterRecord = ($rsmaster && !$rsmaster->EOF);
			$rsmaster->Close();
		}
		if (!$bValidMasterRecord) {
			$sRelatedRecordMsg = str_replace("%t", "staff", $Language->Phrase("RelatedRecordRequired"));
			$this->setFailureMessage($sRelatedRecordMsg);
			return FALSE;
		}

		// Check referential integrity for master table 'project'
		$bValidMasterRecord = TRUE;
		$sMasterFilter = $this->SqlMasterFilter_project();
		if (strval($this->projID->CurrentValue) <> "") {
			$sMasterFilter = str_replace("@id@", ew_AdjustSql($this->projID->CurrentValue, "DB"), $sMasterFilter);
		} else {
			$bValidMasterRecord = FALSE;
		}
		if ($bValidMasterRecord) {
			$rsmaster = $GLOBALS["project"]->LoadRs($sMasterFilter);
			$bValidMasterRecord = ($rsmaster && !$rsmaster->EOF);
			$rsmaster->Close();
		}
		if (!$bValidMasterRecord) {
			$sRelatedRecordMsg = str_replace("%t", "project", $Language->Phrase("RelatedRecordRequired"));
			$this->setFailureMessage($sRelatedRecordMsg);
			return FALSE;
		}
		$conn = &$this->Connection();

		// Load db values from rsold
		if ($rsold) {
			$this->LoadDbValues($rsold);
		}
		$rsnew = array();

		// projID
		$this->projID->SetDbValueDef($rsnew, $this->projID->CurrentValue, 0, strval($this->projID->CurrentValue) == "");

		// staffID
		$this->staffID->SetDbValueDef($rsnew, $this->staffID->CurrentValue, 0, strval($this->staffID->CurrentValue) == "");

		// role
		$this->role->SetDbValueDef($rsnew, $this->role->CurrentValue, NULL, FALSE);

		// TimeSpentProject
		$this->TimeSpentProject->SetDbValueDef($rsnew, $this->TimeSpentProject->CurrentValue, NULL, FALSE);

		// Call Row Inserting event
		$rs = ($rsold == NULL) ? NULL : $rsold->fields;
		$bInsertRow = $this->Row_Inserting($rs, $rsnew);

		// Check if key value entered
		if ($bInsertRow && $this->ValidateKey && strval($rsnew['projID']) == "") {
			$this->setFailureMessage($Language->Phrase("InvalidKeyValue"));
			$bInsertRow = FALSE;
		}

		// Check if key value entered
		if ($bInsertRow && $this->ValidateKey && strval($rsnew['staffID']) == "") {
			$this->setFailureMessage($Language->Phrase("InvalidKeyValue"));
			$bInsertRow = FALSE;
		}

		// Check for duplicate key
		if ($bInsertRow && $this->ValidateKey) {
			$sFilter = $this->KeyFilter();
			$rsChk = $this->LoadRs($sFilter);
			if ($rsChk && !$rsChk->EOF) {
				$sKeyErrMsg = str_replace("%f", $sFilter, $Language->Phrase("DupKey"));
				$this->setFailureMessage($sKeyErrMsg);
				$rsChk->Close();
				$bInsertRow = FALSE;
			}
		}
		if ($bInsertRow) {
			$conn->raiseErrorFn = $GLOBALS["EW_ERROR_FN"];
			$AddRow = $this->Insert($rsnew);
			$conn->raiseErrorFn = '';
			if ($AddRow) {
			}
		} else {
			if ($this->getSuccessMessage() <> "" || $this->getFailureMessage() <> "") {

				// Use the message, do nothing
			} elseif ($this->CancelMessage <> "") {
				$this->setFailureMessage($this->CancelMessage);
				$this->CancelMessage = "";
			} else {
				$this->setFailureMessage($Language->Phrase("InsertCancelled"));
			}
			$AddRow = FALSE;
		}
		if ($AddRow) {

			// Call Row Inserted event
			$rs = ($rsold == NULL) ? NULL : $rsold->fields;
			$this->Row_Inserted($rs, $rsnew);
			$this->WriteAuditTrailOnAdd($rsnew);
		}
		return $AddRow;
	}

	// Set up export options
	function SetupExportOptions() {
		global $Language;

		// Printer friendly
		$item = &$this->ExportOptions->Add("print");
		$item->Body = "<a href=\"" . $this->ExportPrintUrl . "\" class=\"ewExportLink ewPrint\" title=\"" . ew_HtmlEncode($Language->Phrase("PrinterFriendlyText")) . "\" data-caption=\"" . ew_HtmlEncode($Language->Phrase("PrinterFriendlyText")) . "\">" . $Language->Phrase("PrinterFriendly") . "</a>";
		$item->Visible = TRUE;

		// Export to Excel
		$item = &$this->ExportOptions->Add("excel");
		$item->Body = "<a href=\"" . $this->ExportExcelUrl . "\" class=\"ewExportLink ewExcel\" title=\"" . ew_HtmlEncode($Language->Phrase("ExportToExcelText")) . "\" data-caption=\"" . ew_HtmlEncode($Language->Phrase("ExportToExcelText")) . "\">" . $Language->Phrase("ExportToExcel") . "</a>";
		$item->Visible = TRUE;

		// Export to Word
		$item = &$this->ExportOptions->Add("word");
		$item->Body = "<a href=\"" . $this->ExportWordUrl . "\" class=\"ewExportLink ewWord\" title=\"" . ew_HtmlEncode($Language->Phrase("ExportToWordText")) . "\" data-caption=\"" . ew_HtmlEncode($Language->Phrase("ExportToWordText")) . "\">" . $Language->Phrase("ExportToWord") . "</a>";
		$item->Visible = TRUE;

		// Export to Html
		$item = &$this->ExportOptions->Add("html");
		$item->Body = "<a href=\"" . $this->ExportHtmlUrl . "\" class=\"ewExportLink ewHtml\" title=\"" . ew_HtmlEncode($Language->Phrase("ExportToHtmlText")) . "\" data-caption=\"" . ew_HtmlEncode($Language->Phrase("ExportToHtmlText")) . "\">" . $Language->Phrase("ExportToHtml") . "</a>";
		$item->Visible = TRUE;

		// Export to Xml
		$item = &$this->ExportOptions->Add("xml");
		$item->Body = "<a href=\"" . $this->ExportXmlUrl . "\" class=\"ewExportLink ewXml\" title=\"" . ew_HtmlEncode($Language->Phrase("ExportToXmlText")) . "\" data-caption=\"" . ew_HtmlEncode($Language->Phrase("ExportToXmlText")) . "\">" . $Language->Phrase("ExportToXml") . "</a>";
		$item->Visible = TRUE;

		// Export to Csv
		$item = &$this->ExportOptions->Add("csv");
		$item->Body = "<a href=\"" . $this->ExportCsvUrl . "\" class=\"ewExportLink ewCsv\" title=\"" . ew_HtmlEncode($Language->Phrase("ExportToCsvText")) . "\" data-caption=\"" . ew_HtmlEncode($Language->Phrase("ExportToCsvText")) . "\">" . $Language->Phrase("ExportToCsv") . "</a>";
		$item->Visible = TRUE;

		// Export to Pdf
		$item = &$this->ExportOptions->Add("pdf");
		$item->Body = "<a href=\"" . $this->ExportPdfUrl . "\" class=\"ewExportLink ewPdf\" title=\"" . ew_HtmlEncode($Language->Phrase("ExportToPDFText")) . "\" data-caption=\"" . ew_HtmlEncode($Language->Phrase("ExportToPDFText")) . "\">" . $Language->Phrase("ExportToPDF") . "</a>";
		$item->Visible = FALSE;

		// Export to Email
		$item = &$this->ExportOptions->Add("email");
		$url = "";
		$item->Body = "<button id=\"emf_mtm_staff_project\" class=\"ewExportLink ewEmail\" title=\"" . $Language->Phrase("ExportToEmailText") . "\" data-caption=\"" . $Language->Phrase("ExportToEmailText") . "\" onclick=\"ew_EmailDialogShow({lnk:'emf_mtm_staff_project',hdr:ewLanguage.Phrase('ExportToEmailText'),f:document.fmtm_staff_projectlist,sel:false" . $url . "});\">" . $Language->Phrase("ExportToEmail") . "</button>";
		$item->Visible = TRUE;

		// Drop down button for export
		$this->ExportOptions->UseButtonGroup = TRUE;
		$this->ExportOptions->UseImageAndText = TRUE;
		$this->ExportOptions->UseDropDownButton = TRUE;
		if ($this->ExportOptions->UseButtonGroup && ew_IsMobile())
			$this->ExportOptions->UseDropDownButton = TRUE;
		$this->ExportOptions->DropDownButtonPhrase = $Language->Phrase("ButtonExport");

		// Add group option item
		$item = &$this->ExportOptions->Add($this->ExportOptions->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;
	}

	// Export data in HTML/CSV/Word/Excel/XML/Email/PDF format
	function ExportData() {
		$utf8 = (strtolower(EW_CHARSET) == "utf-8");
		$bSelectLimit = $this->UseSelectLimit;

		// Load recordset
		if ($bSelectLimit) {
			$this->TotalRecs = $this->SelectRecordCount();
		} else {
			if (!$this->Recordset)
				$this->Recordset = $this->LoadRecordset();
			$rs = &$this->Recordset;
			if ($rs)
				$this->TotalRecs = $rs->RecordCount();
		}
		$this->StartRec = 1;

		// Export all
		if ($this->ExportAll) {
			set_time_limit(EW_EXPORT_ALL_TIME_LIMIT);
			$this->DisplayRecs = $this->TotalRecs;
			$this->StopRec = $this->TotalRecs;
		} else { // Export one page only
			$this->SetUpStartRec(); // Set up start record position

			// Set the last record to display
			if ($this->DisplayRecs <= 0) {
				$this->StopRec = $this->TotalRecs;
			} else {
				$this->StopRec = $this->StartRec + $this->DisplayRecs - 1;
			}
		}
		if ($bSelectLimit)
			$rs = $this->LoadRecordset($this->StartRec-1, $this->DisplayRecs <= 0 ? $this->TotalRecs : $this->DisplayRecs);
		if (!$rs) {
			header("Content-Type:"); // Remove header
			header("Content-Disposition:");
			$this->ShowMessage();
			return;
		}
		$this->ExportDoc = ew_ExportDocument($this, "h");
		$Doc = &$this->ExportDoc;
		if ($bSelectLimit) {
			$this->StartRec = 1;
			$this->StopRec = $this->DisplayRecs <= 0 ? $this->TotalRecs : $this->DisplayRecs;
		} else {

			//$this->StartRec = $this->StartRec;
			//$this->StopRec = $this->StopRec;

		}

		// Call Page Exporting server event
		$this->ExportDoc->ExportCustom = !$this->Page_Exporting();
		$ParentTable = "";

		// Export master record
		if (EW_EXPORT_MASTER_RECORD && $this->GetMasterFilter() <> "" && $this->getCurrentMasterTable() == "staff") {
			global $staff;
			if (!isset($staff)) $staff = new cstaff;
			$rsmaster = $staff->LoadRs($this->DbMasterFilter); // Load master record
			if ($rsmaster && !$rsmaster->EOF) {
				$ExportStyle = $Doc->Style;
				$Doc->SetStyle("v"); // Change to vertical
				if ($this->Export <> "csv" || EW_EXPORT_MASTER_RECORD_FOR_CSV) {
					$Doc->Table = &$staff;
					$staff->ExportDocument($Doc, $rsmaster, 1, 1);
					$Doc->ExportEmptyRow();
					$Doc->Table = &$this;
				}
				$Doc->SetStyle($ExportStyle); // Restore
				$rsmaster->Close();
			}
		}

		// Export master record
		if (EW_EXPORT_MASTER_RECORD && $this->GetMasterFilter() <> "" && $this->getCurrentMasterTable() == "project") {
			global $project;
			if (!isset($project)) $project = new cproject;
			$rsmaster = $project->LoadRs($this->DbMasterFilter); // Load master record
			if ($rsmaster && !$rsmaster->EOF) {
				$ExportStyle = $Doc->Style;
				$Doc->SetStyle("v"); // Change to vertical
				if ($this->Export <> "csv" || EW_EXPORT_MASTER_RECORD_FOR_CSV) {
					$Doc->Table = &$project;
					$project->ExportDocument($Doc, $rsmaster, 1, 1);
					$Doc->ExportEmptyRow();
					$Doc->Table = &$this;
				}
				$Doc->SetStyle($ExportStyle); // Restore
				$rsmaster->Close();
			}
		}
		$sHeader = $this->PageHeader;
		$this->Page_DataRendering($sHeader);
		$Doc->Text .= $sHeader;
		$this->ExportDocument($Doc, $rs, $this->StartRec, $this->StopRec, "");
		$sFooter = $this->PageFooter;
		$this->Page_DataRendered($sFooter);
		$Doc->Text .= $sFooter;

		// Close recordset
		$rs->Close();

		// Call Page Exported server event
		$this->Page_Exported();

		// Export header and footer
		$Doc->ExportHeaderAndFooter();

		// Clean output buffer
		if (!EW_DEBUG_ENABLED && ob_get_length())
			ob_end_clean();

		// Write debug message if enabled
		if (EW_DEBUG_ENABLED && $this->Export <> "pdf")
			echo ew_DebugMsg();

		// Output data
		if ($this->Export == "email") {
			echo $this->ExportEmail($Doc->Text);
		} else {
			$Doc->Export();
		}
	}

	// Export email
	function ExportEmail($EmailContent) {
		global $gTmpImages, $Language;
		$sSender = @$_POST["sender"];
		$sRecipient = @$_POST["recipient"];
		$sCc = @$_POST["cc"];
		$sBcc = @$_POST["bcc"];
		$sContentType = @$_POST["contenttype"];

		// Subject
		$sSubject = ew_StripSlashes(@$_POST["subject"]);
		$sEmailSubject = $sSubject;

		// Message
		$sContent = ew_StripSlashes(@$_POST["message"]);
		$sEmailMessage = $sContent;

		// Check sender
		if ($sSender == "") {
			return "<p class=\"text-danger\">" . $Language->Phrase("EnterSenderEmail") . "</p>";
		}
		if (!ew_CheckEmail($sSender)) {
			return "<p class=\"text-danger\">" . $Language->Phrase("EnterProperSenderEmail") . "</p>";
		}

		// Check recipient
		if (!ew_CheckEmailList($sRecipient, EW_MAX_EMAIL_RECIPIENT)) {
			return "<p class=\"text-danger\">" . $Language->Phrase("EnterProperRecipientEmail") . "</p>";
		}

		// Check cc
		if (!ew_CheckEmailList($sCc, EW_MAX_EMAIL_RECIPIENT)) {
			return "<p class=\"text-danger\">" . $Language->Phrase("EnterProperCcEmail") . "</p>";
		}

		// Check bcc
		if (!ew_CheckEmailList($sBcc, EW_MAX_EMAIL_RECIPIENT)) {
			return "<p class=\"text-danger\">" . $Language->Phrase("EnterProperBccEmail") . "</p>";
		}

		// Check email sent count
		if (!isset($_SESSION[EW_EXPORT_EMAIL_COUNTER]))
			$_SESSION[EW_EXPORT_EMAIL_COUNTER] = 0;
		if (intval($_SESSION[EW_EXPORT_EMAIL_COUNTER]) > EW_MAX_EMAIL_SENT_COUNT) {
			return "<p class=\"text-danger\">" . $Language->Phrase("ExceedMaxEmailExport") . "</p>";
		}

		// Send email
		$Email = new cEmail();
		$Email->Sender = $sSender; // Sender
		$Email->Recipient = $sRecipient; // Recipient
		$Email->Cc = $sCc; // Cc
		$Email->Bcc = $sBcc; // Bcc
		$Email->Subject = $sEmailSubject; // Subject
		$Email->Format = ($sContentType == "url") ? "text" : "html";
		if ($sEmailMessage <> "") {
			$sEmailMessage = ew_RemoveXSS($sEmailMessage);
			$sEmailMessage .= ($sContentType == "url") ? "\r\n\r\n" : "<br><br>";
		}
		if ($sContentType == "url") {
			$sUrl = ew_ConvertFullUrl(ew_CurrentPage() . "?" . $this->ExportQueryString());
			$sEmailMessage .= $sUrl; // Send URL only
		} else {
			foreach ($gTmpImages as $tmpimage)
				$Email->AddEmbeddedImage($tmpimage);
			$sEmailMessage .= ew_CleanEmailContent($EmailContent); // Send HTML
		}
		$Email->Content = $sEmailMessage; // Content
		$EventArgs = array();
		if ($this->Recordset) {
			$this->RecCnt = $this->StartRec - 1;
			$this->Recordset->MoveFirst();
			if ($this->StartRec > 1)
				$this->Recordset->Move($this->StartRec - 1);
			$EventArgs["rs"] = &$this->Recordset;
		}
		$bEmailSent = FALSE;
		if ($this->Email_Sending($Email, $EventArgs))
			$bEmailSent = $Email->Send();

		// Check email sent status
		if ($bEmailSent) {

			// Update email sent count
			$_SESSION[EW_EXPORT_EMAIL_COUNTER]++;

			// Sent email success
			return "<p class=\"text-success\">" . $Language->Phrase("SendEmailSuccess") . "</p>"; // Set up success message
		} else {

			// Sent email failure
			return "<p class=\"text-danger\">" . $Email->SendErrDescription . "</p>";
		}
	}

	// Export QueryString
	function ExportQueryString() {

		// Initialize
		$sQry = "export=html";

		// Build QueryString for search
		if ($this->BasicSearch->getKeyword() <> "") {
			$sQry .= "&" . EW_TABLE_BASIC_SEARCH . "=" . urlencode($this->BasicSearch->getKeyword()) . "&" . EW_TABLE_BASIC_SEARCH_TYPE . "=" . urlencode($this->BasicSearch->getType());
		}

		// Build QueryString for pager
		$sQry .= "&" . EW_TABLE_REC_PER_PAGE . "=" . urlencode($this->getRecordsPerPage()) . "&" . EW_TABLE_START_REC . "=" . urlencode($this->getStartRecordNumber());
		return $sQry;
	}

	// Add search QueryString
	function AddSearchQueryString(&$Qry, &$Fld) {
		$FldSearchValue = $Fld->AdvancedSearch->getValue("x");
		$FldParm = substr($Fld->FldVar,2);
		if (strval($FldSearchValue) <> "") {
			$Qry .= "&x_" . $FldParm . "=" . urlencode($FldSearchValue) .
				"&z_" . $FldParm . "=" . urlencode($Fld->AdvancedSearch->getValue("z"));
		}
		$FldSearchValue2 = $Fld->AdvancedSearch->getValue("y");
		if (strval($FldSearchValue2) <> "") {
			$Qry .= "&v_" . $FldParm . "=" . urlencode($Fld->AdvancedSearch->getValue("v")) .
				"&y_" . $FldParm . "=" . urlencode($FldSearchValue2) .
				"&w_" . $FldParm . "=" . urlencode($Fld->AdvancedSearch->getValue("w"));
		}
	}

	// Set up master/detail based on QueryString
	function SetUpMasterParms() {
		$bValidMaster = FALSE;

		// Get the keys for master table
		if (isset($_GET[EW_TABLE_SHOW_MASTER])) {
			$sMasterTblVar = $_GET[EW_TABLE_SHOW_MASTER];
			if ($sMasterTblVar == "") {
				$bValidMaster = TRUE;
				$this->DbMasterFilter = "";
				$this->DbDetailFilter = "";
			}
			if ($sMasterTblVar == "staff") {
				$bValidMaster = TRUE;
				if (@$_GET["fk_id"] <> "") {
					$GLOBALS["staff"]->id->setQueryStringValue($_GET["fk_id"]);
					$this->staffID->setQueryStringValue($GLOBALS["staff"]->id->QueryStringValue);
					$this->staffID->setSessionValue($this->staffID->QueryStringValue);
					if (!is_numeric($GLOBALS["staff"]->id->QueryStringValue)) $bValidMaster = FALSE;
				} else {
					$bValidMaster = FALSE;
				}
			}
			if ($sMasterTblVar == "project") {
				$bValidMaster = TRUE;
				if (@$_GET["fk_id"] <> "") {
					$GLOBALS["project"]->id->setQueryStringValue($_GET["fk_id"]);
					$this->projID->setQueryStringValue($GLOBALS["project"]->id->QueryStringValue);
					$this->projID->setSessionValue($this->projID->QueryStringValue);
					if (!is_numeric($GLOBALS["project"]->id->QueryStringValue)) $bValidMaster = FALSE;
				} else {
					$bValidMaster = FALSE;
				}
			}
		} elseif (isset($_POST[EW_TABLE_SHOW_MASTER])) {
			$sMasterTblVar = $_POST[EW_TABLE_SHOW_MASTER];
			if ($sMasterTblVar == "") {
				$bValidMaster = TRUE;
				$this->DbMasterFilter = "";
				$this->DbDetailFilter = "";
			}
			if ($sMasterTblVar == "staff") {
				$bValidMaster = TRUE;
				if (@$_POST["fk_id"] <> "") {
					$GLOBALS["staff"]->id->setFormValue($_POST["fk_id"]);
					$this->staffID->setFormValue($GLOBALS["staff"]->id->FormValue);
					$this->staffID->setSessionValue($this->staffID->FormValue);
					if (!is_numeric($GLOBALS["staff"]->id->FormValue)) $bValidMaster = FALSE;
				} else {
					$bValidMaster = FALSE;
				}
			}
			if ($sMasterTblVar == "project") {
				$bValidMaster = TRUE;
				if (@$_POST["fk_id"] <> "") {
					$GLOBALS["project"]->id->setFormValue($_POST["fk_id"]);
					$this->projID->setFormValue($GLOBALS["project"]->id->FormValue);
					$this->projID->setSessionValue($this->projID->FormValue);
					if (!is_numeric($GLOBALS["project"]->id->FormValue)) $bValidMaster = FALSE;
				} else {
					$bValidMaster = FALSE;
				}
			}
		}
		if ($bValidMaster) {

			// Update URL
			$this->AddUrl = $this->AddMasterUrl($this->AddUrl);
			$this->InlineAddUrl = $this->AddMasterUrl($this->InlineAddUrl);
			$this->GridAddUrl = $this->AddMasterUrl($this->GridAddUrl);
			$this->GridEditUrl = $this->AddMasterUrl($this->GridEditUrl);

			// Save current master table
			$this->setCurrentMasterTable($sMasterTblVar);

			// Reset start record counter (new master key)
			$this->StartRec = 1;
			$this->setStartRecordNumber($this->StartRec);

			// Clear previous master key from Session
			if ($sMasterTblVar <> "staff") {
				if ($this->staffID->CurrentValue == "") $this->staffID->setSessionValue("");
			}
			if ($sMasterTblVar <> "project") {
				if ($this->projID->CurrentValue == "") $this->projID->setSessionValue("");
			}
		}
		$this->DbMasterFilter = $this->GetMasterFilter(); // Get master filter
		$this->DbDetailFilter = $this->GetDetailFilter(); // Get detail filter
	}

	// Set up Breadcrumb
	function SetupBreadcrumb() {
		global $Breadcrumb, $Language;
		$Breadcrumb = new cBreadcrumb();
		$url = substr(ew_CurrentUrl(), strrpos(ew_CurrentUrl(), "/")+1);
		$url = preg_replace('/\?cmd=reset(all){0,1}$/i', '', $url); // Remove cmd=reset / cmd=resetall
		$Breadcrumb->Add("list", $this->TableVar, $url, "", $this->TableVar, TRUE);
	}

	// Write Audit Trail start/end for grid update
	function WriteAuditTrailDummy($typ) {
		$table = 'mtm_staff_project';
		$usr = CurrentUserID();
		ew_WriteAuditTrail("log", ew_StdCurrentDateTime(), ew_ScriptName(), $usr, $typ, $table, "", "", "", "");
	}

	// Write Audit Trail (add page)
	function WriteAuditTrailOnAdd(&$rs) {
		global $Language;
		if (!$this->AuditTrailOnAdd) return;
		$table = 'mtm_staff_project';

		// Get key value
		$key = "";
		if ($key <> "") $key .= $GLOBALS["EW_COMPOSITE_KEY_SEPARATOR"];
		$key .= $rs['projID'];
		if ($key <> "") $key .= $GLOBALS["EW_COMPOSITE_KEY_SEPARATOR"];
		$key .= $rs['staffID'];

		// Write Audit Trail
		$dt = ew_StdCurrentDateTime();
		$id = ew_ScriptName();
		$usr = CurrentUserID();
		foreach (array_keys($rs) as $fldname) {
			if ($this->fields[$fldname]->FldDataType <> EW_DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->FldHtmlTag == "PASSWORD") {
					$newvalue = $Language->Phrase("PasswordMask"); // Password Field
				} elseif ($this->fields[$fldname]->FldDataType == EW_DATATYPE_MEMO) {
					if (EW_AUDIT_TRAIL_TO_DATABASE)
						$newvalue = $rs[$fldname];
					else
						$newvalue = "[MEMO]"; // Memo Field
				} elseif ($this->fields[$fldname]->FldDataType == EW_DATATYPE_XML) {
					$newvalue = "[XML]"; // XML Field
				} else {
					$newvalue = $rs[$fldname];
				}
				ew_WriteAuditTrail("log", $dt, $id, $usr, "A", $table, $fldname, $key, "", $newvalue);
			}
		}
	}

	// Write Audit Trail (edit page)
	function WriteAuditTrailOnEdit(&$rsold, &$rsnew) {
		global $Language;
		if (!$this->AuditTrailOnEdit) return;
		$table = 'mtm_staff_project';

		// Get key value
		$key = "";
		if ($key <> "") $key .= $GLOBALS["EW_COMPOSITE_KEY_SEPARATOR"];
		$key .= $rsold['projID'];
		if ($key <> "") $key .= $GLOBALS["EW_COMPOSITE_KEY_SEPARATOR"];
		$key .= $rsold['staffID'];

		// Write Audit Trail
		$dt = ew_StdCurrentDateTime();
		$id = ew_ScriptName();
		$usr = CurrentUserID();
		foreach (array_keys($rsnew) as $fldname) {
			if ($this->fields[$fldname]->FldDataType <> EW_DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->FldDataType == EW_DATATYPE_DATE) { // DateTime field
					$modified = (ew_FormatDateTime($rsold[$fldname], 0) <> ew_FormatDateTime($rsnew[$fldname], 0));
				} else {
					$modified = !ew_CompareValue($rsold[$fldname], $rsnew[$fldname]);
				}
				if ($modified) {
					if ($this->fields[$fldname]->FldHtmlTag == "PASSWORD") { // Password Field
						$oldvalue = $Language->Phrase("PasswordMask");
						$newvalue = $Language->Phrase("PasswordMask");
					} elseif ($this->fields[$fldname]->FldDataType == EW_DATATYPE_MEMO) { // Memo field
						if (EW_AUDIT_TRAIL_TO_DATABASE) {
							$oldvalue = $rsold[$fldname];
							$newvalue = $rsnew[$fldname];
						} else {
							$oldvalue = "[MEMO]";
							$newvalue = "[MEMO]";
						}
					} elseif ($this->fields[$fldname]->FldDataType == EW_DATATYPE_XML) { // XML field
						$oldvalue = "[XML]";
						$newvalue = "[XML]";
					} else {
						$oldvalue = $rsold[$fldname];
						$newvalue = $rsnew[$fldname];
					}
					ew_WriteAuditTrail("log", $dt, $id, $usr, "U", $table, $fldname, $key, $oldvalue, $newvalue);
				}
			}
		}
	}

	// Write Audit Trail (delete page)
	function WriteAuditTrailOnDelete(&$rs) {
		global $Language;
		if (!$this->AuditTrailOnDelete) return;
		$table = 'mtm_staff_project';

		// Get key value
		$key = "";
		if ($key <> "")
			$key .= $GLOBALS["EW_COMPOSITE_KEY_SEPARATOR"];
		$key .= $rs['projID'];
		if ($key <> "")
			$key .= $GLOBALS["EW_COMPOSITE_KEY_SEPARATOR"];
		$key .= $rs['staffID'];

		// Write Audit Trail
		$dt = ew_StdCurrentDateTime();
		$id = ew_ScriptName();
		$curUser = CurrentUserID();
		foreach (array_keys($rs) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && $this->fields[$fldname]->FldDataType <> EW_DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->FldHtmlTag == "PASSWORD") {
					$oldvalue = $Language->Phrase("PasswordMask"); // Password Field
				} elseif ($this->fields[$fldname]->FldDataType == EW_DATATYPE_MEMO) {
					if (EW_AUDIT_TRAIL_TO_DATABASE)
						$oldvalue = $rs[$fldname];
					else
						$oldvalue = "[MEMO]"; // Memo field
				} elseif ($this->fields[$fldname]->FldDataType == EW_DATATYPE_XML) {
					$oldvalue = "[XML]"; // XML field
				} else {
					$oldvalue = $rs[$fldname];
				}
				ew_WriteAuditTrail("log", $dt, $id, $curUser, "D", $table, $fldname, $key, $oldvalue, "");
			}
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$CustomError) {

		// Return error message in CustomError
		return TRUE;
	}

	// ListOptions Load event
	function ListOptions_Load() {

		// Example:
		//$opt = &$this->ListOptions->Add("new");
		//$opt->Header = "xxx";
		//$opt->OnLeft = TRUE; // Link on left
		//$opt->MoveTo(0); // Move to first column

	}

	// ListOptions Rendered event
	function ListOptions_Rendered() {

		// Example: 
		//$this->ListOptions->Items["new"]->Body = "xxx";

	}

	// Row Custom Action event
	function Row_CustomAction($action, $row) {

		// Return FALSE to abort
		return TRUE;
	}

	// Page Exporting event
	// $this->ExportDoc = export document object
	function Page_Exporting() {

		//$this->ExportDoc->Text = "my header"; // Export header
		//return FALSE; // Return FALSE to skip default export and use Row_Export event

		return TRUE; // Return TRUE to use default export and skip Row_Export event
	}

	// Row Export event
	// $this->ExportDoc = export document object
	function Row_Export($rs) {

	    //$this->ExportDoc->Text .= "my content"; // Build HTML with field value: $rs["MyField"] or $this->MyField->ViewValue
	}

	// Page Exported event
	// $this->ExportDoc = export document object
	function Page_Exported() {

		//$this->ExportDoc->Text .= "my footer"; // Export footer
		//echo $this->ExportDoc->Text;

	}
}
?>
<?php ew_Header(FALSE) ?>
<?php

// Create page object
if (!isset($mtm_staff_project_list)) $mtm_staff_project_list = new cmtm_staff_project_list();

// Page init
$mtm_staff_project_list->Page_Init();

// Page main
$mtm_staff_project_list->Page_Main();

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$mtm_staff_project_list->Page_Render();
?>
<?php include_once "header.php" ?>
<?php if ($mtm_staff_project->Export == "") { ?>
<script type="text/javascript">

// Form object
var CurrentPageID = EW_PAGE_ID = "list";
var CurrentForm = fmtm_staff_projectlist = new ew_Form("fmtm_staff_projectlist", "list");
fmtm_staff_projectlist.FormKeyCountName = '<?php echo $mtm_staff_project_list->FormKeyCountName ?>';

// Validate form
fmtm_staff_projectlist.Validate = function() {
	if (!this.ValidateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.GetForm(), $fobj = $(fobj);
	if ($fobj.find("#a_confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.FormKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = $fobj.find("#a_list").val() == "gridinsert";
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
		var checkrow = (gridinsert) ? !this.EmptyRow(infix) : true;
		if (checkrow) {
			addcnt++;
			elm = this.GetElements("x" + infix + "_projID");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $mtm_staff_project->projID->FldCaption(), $mtm_staff_project->projID->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_staffID");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $mtm_staff_project->staffID->FldCaption(), $mtm_staff_project->staffID->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_TimeSpentProject");
			if (elm && !ew_CheckInteger(elm.value))
				return this.OnError(elm, "<?php echo ew_JsEncode2($mtm_staff_project->TimeSpentProject->FldErrMsg()) ?>");

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
		} // End Grid Add checking
	}
	if (gridinsert && addcnt == 0) { // No row added
		ew_Alert(ewLanguage.Phrase("NoAddRecord"));
		return false;
	}
	return true;
}

// Check empty row
fmtm_staff_projectlist.EmptyRow = function(infix) {
	var fobj = this.Form;
	if (ew_ValueChanged(fobj, infix, "projID", false)) return false;
	if (ew_ValueChanged(fobj, infix, "staffID", false)) return false;
	if (ew_ValueChanged(fobj, infix, "role", false)) return false;
	if (ew_ValueChanged(fobj, infix, "TimeSpentProject", false)) return false;
	return true;
}

// Form_CustomValidate event
fmtm_staff_projectlist.Form_CustomValidate = 
 function(fobj) { // DO NOT CHANGE THIS LINE!

 	// Your custom validation code here, return false if invalid. 
 	return true;
 }

// Use JavaScript validation or not
<?php if (EW_CLIENT_VALIDATE) { ?>
fmtm_staff_projectlist.ValidateRequired = true;
<?php } else { ?>
fmtm_staff_projectlist.ValidateRequired = false; 
<?php } ?>

// Dynamic selection lists
fmtm_staff_projectlist.Lists["x_projID"] = {"LinkField":"x_id","Ajax":true,"AutoFill":false,"DisplayFields":["x_name","","",""],"ParentFields":[],"ChildFields":[],"FilterFields":[],"Options":[],"Template":""};
fmtm_staff_projectlist.Lists["x_staffID"] = {"LinkField":"x_id","Ajax":true,"AutoFill":false,"DisplayFields":["x_Name","","",""],"ParentFields":[],"ChildFields":[],"FilterFields":[],"Options":[],"Template":""};
fmtm_staff_projectlist.Lists["x_role"] = {"LinkField":"","Ajax":null,"AutoFill":false,"DisplayFields":["","","",""],"ParentFields":[],"ChildFields":[],"FilterFields":[],"Options":[],"Template":""};
fmtm_staff_projectlist.Lists["x_role"].Options = <?php echo json_encode($mtm_staff_project->role->Options()) ?>;

// Form object for search
var CurrentSearchForm = fmtm_staff_projectlistsrch = new ew_Form("fmtm_staff_projectlistsrch");
</script>
<style type="text/css">
.ewTablePreviewRow { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ewTablePreviewRow .ewGrid {
	display: table;
}
.ewTablePreviewRow .ewGrid .ewTable {
	width: auto;
}
</style>
<div id="ewPreview" class="hide"><ul class="nav nav-tabs"></ul><div class="tab-content"><div class="tab-pane fade"></div></div></div>
<script type="text/javascript" src="phpjs/ewpreview.min.js"></script>
<script type="text/javascript">
var EW_PREVIEW_PLACEMENT = EW_CSS_FLIP ? "right" : "left";
var EW_PREVIEW_SINGLE_ROW = false;
var EW_PREVIEW_OVERLAY = false;
</script>
<script type="text/javascript">

// Write your client script here, no need to add script tags.
</script>
<?php } ?>
<?php if ($mtm_staff_project->Export == "") { ?>
<div class="ewToolbar">
<?php if ($mtm_staff_project->Export == "") { ?>
<?php $Breadcrumb->Render(); ?>
<?php } ?>
<?php if ($mtm_staff_project_list->TotalRecs > 0 && $mtm_staff_project_list->ExportOptions->Visible()) { ?>
<?php $mtm_staff_project_list->ExportOptions->Render("body") ?>
<?php } ?>
<?php if ($mtm_staff_project_list->SearchOptions->Visible()) { ?>
<?php $mtm_staff_project_list->SearchOptions->Render("body") ?>
<?php } ?>
<?php if ($mtm_staff_project_list->FilterOptions->Visible()) { ?>
<?php $mtm_staff_project_list->FilterOptions->Render("body") ?>
<?php } ?>
<?php if ($mtm_staff_project->Export == "") { ?>
<?php echo $Language->SelectionForm(); ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php if (($mtm_staff_project->Export == "") || (EW_EXPORT_MASTER_RECORD && $mtm_staff_project->Export == "print")) { ?>
<?php
$gsMasterReturnUrl = "stafflist.php";
if ($mtm_staff_project_list->DbMasterFilter <> "" && $mtm_staff_project->getCurrentMasterTable() == "staff") {
	if ($mtm_staff_project_list->MasterRecordExists) {
		if ($mtm_staff_project->getCurrentMasterTable() == $mtm_staff_project->TableVar) $gsMasterReturnUrl .= "?" . EW_TABLE_SHOW_MASTER . "=";
?>
<?php include_once "staffmaster.php" ?>
<?php
	}
}
?>
<?php
$gsMasterReturnUrl = "projectlist.php";
if ($mtm_staff_project_list->DbMasterFilter <> "" && $mtm_staff_project->getCurrentMasterTable() == "project") {
	if ($mtm_staff_project_list->MasterRecordExists) {
		if ($mtm_staff_project->getCurrentMasterTable() == $mtm_staff_project->TableVar) $gsMasterReturnUrl .= "?" . EW_TABLE_SHOW_MASTER . "=";
?>
<?php include_once "projectmaster.php" ?>
<?php
	}
}
?>
<?php } ?>
<?php
if ($mtm_staff_project->CurrentAction == "gridadd") {
	$mtm_staff_project->CurrentFilter = "0=1";
	$mtm_staff_project_list->StartRec = 1;
	$mtm_staff_project_list->DisplayRecs = $mtm_staff_project->GridAddRowCount;
	$mtm_staff_project_list->TotalRecs = $mtm_staff_project_list->DisplayRecs;
	$mtm_staff_project_list->StopRec = $mtm_staff_project_list->DisplayRecs;
} else {
	$bSelectLimit = $mtm_staff_project_list->UseSelectLimit;
	if ($bSelectLimit) {
		if ($mtm_staff_project_list->TotalRecs <= 0)
			$mtm_staff_project_list->TotalRecs = $mtm_staff_project->SelectRecordCount();
	} else {
		if (!$mtm_staff_project_list->Recordset && ($mtm_staff_project_list->Recordset = $mtm_staff_project_list->LoadRecordset()))
			$mtm_staff_project_list->TotalRecs = $mtm_staff_project_list->Recordset->RecordCount();
	}
	$mtm_staff_project_list->StartRec = 1;
	if ($mtm_staff_project_list->DisplayRecs <= 0 || ($mtm_staff_project->Export <> "" && $mtm_staff_project->ExportAll)) // Display all records
		$mtm_staff_project_list->DisplayRecs = $mtm_staff_project_list->TotalRecs;
	if (!($mtm_staff_project->Export <> "" && $mtm_staff_project->ExportAll))
		$mtm_staff_project_list->SetUpStartRec(); // Set up start record position
	if ($bSelectLimit)
		$mtm_staff_project_list->Recordset = $mtm_staff_project_list->LoadRecordset($mtm_staff_project_list->StartRec-1, $mtm_staff_project_list->DisplayRecs);

	// Set no record found message
	if ($mtm_staff_project->CurrentAction == "" && $mtm_staff_project_list->TotalRecs == 0) {
		if (!$Security->CanList())
			$mtm_staff_project_list->setWarningMessage(ew_DeniedMsg());
		if ($mtm_staff_project_list->SearchWhere == "0=101")
			$mtm_staff_project_list->setWarningMessage($Language->Phrase("EnterSearchCriteria"));
		else
			$mtm_staff_project_list->setWarningMessage($Language->Phrase("NoRecord"));
	}

	// Audit trail on search
	if ($mtm_staff_project_list->AuditTrailOnSearch && $mtm_staff_project_list->Command == "search" && !$mtm_staff_project_list->RestoreSearch) {
		$searchparm = ew_ServerVar("QUERY_STRING");
		$searchsql = $mtm_staff_project_list->getSessionWhere();
		$mtm_staff_project_list->WriteAuditTrailOnSearch($searchparm, $searchsql);
	}
}
$mtm_staff_project_list->RenderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if ($mtm_staff_project->Export == "" && $mtm_staff_project->CurrentAction == "") { ?>
<form name="fmtm_staff_projectlistsrch" id="fmtm_staff_projectlistsrch" class="form-inline ewForm" action="<?php echo ew_CurrentPage() ?>">
<?php $SearchPanelClass = ($mtm_staff_project_list->SearchWhere <> "") ? " in" : " in"; ?>
<div id="fmtm_staff_projectlistsrch_SearchPanel" class="ewSearchPanel collapse<?php echo $SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="mtm_staff_project">
	<div class="ewBasicSearch">
<div id="xsr_1" class="ewRow">
	<div class="ewQuickSearch input-group">
	<input type="text" name="<?php echo EW_TABLE_BASIC_SEARCH ?>" id="<?php echo EW_TABLE_BASIC_SEARCH ?>" class="form-control" value="<?php echo ew_HtmlEncode($mtm_staff_project_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo ew_HtmlEncode($Language->Phrase("Search")) ?>">
	<input type="hidden" name="<?php echo EW_TABLE_BASIC_SEARCH_TYPE ?>" id="<?php echo EW_TABLE_BASIC_SEARCH_TYPE ?>" value="<?php echo ew_HtmlEncode($mtm_staff_project_list->BasicSearch->getType()) ?>">
	<div class="input-group-btn">
		<button type="button" data-toggle="dropdown" class="btn btn-default"><span id="searchtype"><?php echo $mtm_staff_project_list->BasicSearch->getTypeNameShort() ?></span><span class="caret"></span></button>
		<ul class="dropdown-menu pull-right" role="menu">
			<li<?php if ($mtm_staff_project_list->BasicSearch->getType() == "") echo " class=\"active\""; ?>><a href="javascript:void(0);" onclick="ew_SetSearchType(this)"><?php echo $Language->Phrase("QuickSearchAuto") ?></a></li>
			<li<?php if ($mtm_staff_project_list->BasicSearch->getType() == "=") echo " class=\"active\""; ?>><a href="javascript:void(0);" onclick="ew_SetSearchType(this,'=')"><?php echo $Language->Phrase("QuickSearchExact") ?></a></li>
			<li<?php if ($mtm_staff_project_list->BasicSearch->getType() == "AND") echo " class=\"active\""; ?>><a href="javascript:void(0);" onclick="ew_SetSearchType(this,'AND')"><?php echo $Language->Phrase("QuickSearchAll") ?></a></li>
			<li<?php if ($mtm_staff_project_list->BasicSearch->getType() == "OR") echo " class=\"active\""; ?>><a href="javascript:void(0);" onclick="ew_SetSearchType(this,'OR')"><?php echo $Language->Phrase("QuickSearchAny") ?></a></li>
		</ul>
	<button class="btn btn-primary ewButton" name="btnsubmit" id="btnsubmit" type="submit"><?php echo $Language->Phrase("QuickSearchBtn") ?></button>
	</div>
	</div>
</div>
	</div>
</div>
</form>
<?php } ?>
<?php } ?>
<?php $mtm_staff_project_list->ShowPageHeader(); ?>
<?php
$mtm_staff_project_list->ShowMessage();
?>
<?php if ($mtm_staff_project_list->TotalRecs > 0 || $mtm_staff_project->CurrentAction <> "") { ?>
<div class="panel panel-default ewGrid">
<?php if ($mtm_staff_project->Export == "") { ?>
<div class="panel-heading ewGridUpperPanel">
<?php if ($mtm_staff_project->CurrentAction <> "gridadd" && $mtm_staff_project->CurrentAction <> "gridedit") { ?>
<form name="ewPagerForm" class="form-inline ewForm ewPagerForm" action="<?php echo ew_CurrentPage() ?>">
<?php if (!isset($mtm_staff_project_list->Pager)) $mtm_staff_project_list->Pager = new cPrevNextPager($mtm_staff_project_list->StartRec, $mtm_staff_project_list->DisplayRecs, $mtm_staff_project_list->TotalRecs) ?>
<?php if ($mtm_staff_project_list->Pager->RecordCount > 0) { ?>
<div class="ewPager">
<span><?php echo $Language->Phrase("Page") ?>&nbsp;</span>
<div class="ewPrevNext"><div class="input-group">
<div class="input-group-btn">
<!--first page button-->
	<?php if ($mtm_staff_project_list->Pager->FirstButton->Enabled) { ?>
	<a class="btn btn-default btn-sm" title="<?php echo $Language->Phrase("PagerFirst") ?>" href="<?php echo $mtm_staff_project_list->PageUrl() ?>start=<?php echo $mtm_staff_project_list->Pager->FirstButton->Start ?>"><span class="icon-first ewIcon"></span></a>
	<?php } else { ?>
	<a class="btn btn-default btn-sm disabled" title="<?php echo $Language->Phrase("PagerFirst") ?>"><span class="icon-first ewIcon"></span></a>
	<?php } ?>
<!--previous page button-->
	<?php if ($mtm_staff_project_list->Pager->PrevButton->Enabled) { ?>
	<a class="btn btn-default btn-sm" title="<?php echo $Language->Phrase("PagerPrevious") ?>" href="<?php echo $mtm_staff_project_list->PageUrl() ?>start=<?php echo $mtm_staff_project_list->Pager->PrevButton->Start ?>"><span class="icon-prev ewIcon"></span></a>
	<?php } else { ?>
	<a class="btn btn-default btn-sm disabled" title="<?php echo $Language->Phrase("PagerPrevious") ?>"><span class="icon-prev ewIcon"></span></a>
	<?php } ?>
</div>
<!--current page number-->
	<input class="form-control input-sm" type="text" name="<?php echo EW_TABLE_PAGE_NO ?>" value="<?php echo $mtm_staff_project_list->Pager->CurrentPage ?>">
<div class="input-group-btn">
<!--next page button-->
	<?php if ($mtm_staff_project_list->Pager->NextButton->Enabled) { ?>
	<a class="btn btn-default btn-sm" title="<?php echo $Language->Phrase("PagerNext") ?>" href="<?php echo $mtm_staff_project_list->PageUrl() ?>start=<?php echo $mtm_staff_project_list->Pager->NextButton->Start ?>"><span class="icon-next ewIcon"></span></a>
	<?php } else { ?>
	<a class="btn btn-default btn-sm disabled" title="<?php echo $Language->Phrase("PagerNext") ?>"><span class="icon-next ewIcon"></span></a>
	<?php } ?>
<!--last page button-->
	<?php if ($mtm_staff_project_list->Pager->LastButton->Enabled) { ?>
	<a class="btn btn-default btn-sm" title="<?php echo $Language->Phrase("PagerLast") ?>" href="<?php echo $mtm_staff_project_list->PageUrl() ?>start=<?php echo $mtm_staff_project_list->Pager->LastButton->Start ?>"><span class="icon-last ewIcon"></span></a>
	<?php } else { ?>
	<a class="btn btn-default btn-sm disabled" title="<?php echo $Language->Phrase("PagerLast") ?>"><span class="icon-last ewIcon"></span></a>
	<?php } ?>
</div>
</div>
</div>
<span>&nbsp;<?php echo $Language->Phrase("of") ?>&nbsp;<?php echo $mtm_staff_project_list->Pager->PageCount ?></span>
</div>
<div class="ewPager ewRec">
	<span><?php echo $Language->Phrase("Record") ?>&nbsp;<?php echo $mtm_staff_project_list->Pager->FromIndex ?>&nbsp;<?php echo $Language->Phrase("To") ?>&nbsp;<?php echo $mtm_staff_project_list->Pager->ToIndex ?>&nbsp;<?php echo $Language->Phrase("Of") ?>&nbsp;<?php echo $mtm_staff_project_list->Pager->RecordCount ?></span>
</div>
<?php } ?>
<?php if ($mtm_staff_project_list->TotalRecs > 0) { ?>
<div class="ewPager">
<input type="hidden" name="t" value="mtm_staff_project">
<select name="<?php echo EW_TABLE_REC_PER_PAGE ?>" class="form-control input-sm" onchange="this.form.submit();">
<option value="20"<?php if ($mtm_staff_project_list->DisplayRecs == 20) { ?> selected<?php } ?>>20</option>
<option value="40"<?php if ($mtm_staff_project_list->DisplayRecs == 40) { ?> selected<?php } ?>>40</option>
<option value="50"<?php if ($mtm_staff_project_list->DisplayRecs == 50) { ?> selected<?php } ?>>50</option>
<option value="60"<?php if ($mtm_staff_project_list->DisplayRecs == 60) { ?> selected<?php } ?>>60</option>
<option value="80"<?php if ($mtm_staff_project_list->DisplayRecs == 80) { ?> selected<?php } ?>>80</option>
<option value="ALL"<?php if ($mtm_staff_project->getRecordsPerPage() == -1) { ?> selected<?php } ?>><?php echo $Language->Phrase("AllRecords") ?></option>
</select>
</div>
<?php } ?>
</form>
<?php } ?>
<div class="ewListOtherOptions">
<?php
	foreach ($mtm_staff_project_list->OtherOptions as &$option)
		$option->Render("body");
?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
<form name="fmtm_staff_projectlist" id="fmtm_staff_projectlist" class="form-inline ewForm ewListForm" action="<?php echo ew_CurrentPage() ?>" method="post">
<?php if ($mtm_staff_project_list->CheckToken) { ?>
<input type="hidden" name="<?php echo EW_TOKEN_NAME ?>" value="<?php echo $mtm_staff_project_list->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="mtm_staff_project">
<?php if ($mtm_staff_project->getCurrentMasterTable() == "staff" && $mtm_staff_project->CurrentAction <> "") { ?>
<input type="hidden" name="<?php echo EW_TABLE_SHOW_MASTER ?>" value="staff">
<input type="hidden" name="fk_id" value="<?php echo $mtm_staff_project->staffID->getSessionValue() ?>">
<?php } ?>
<?php if ($mtm_staff_project->getCurrentMasterTable() == "project" && $mtm_staff_project->CurrentAction <> "") { ?>
<input type="hidden" name="<?php echo EW_TABLE_SHOW_MASTER ?>" value="project">
<input type="hidden" name="fk_id" value="<?php echo $mtm_staff_project->projID->getSessionValue() ?>">
<?php } ?>
<div id="gmp_mtm_staff_project" class="<?php if (ew_IsResponsiveLayout()) { echo "table-responsive "; } ?>ewGridMiddlePanel">
<?php if ($mtm_staff_project_list->TotalRecs > 0 || $mtm_staff_project->CurrentAction == "add" || $mtm_staff_project->CurrentAction == "copy") { ?>
<table id="tbl_mtm_staff_projectlist" class="table ewTable">
<?php echo $mtm_staff_project->TableCustomInnerHtml ?>
<thead><!-- Table header -->
	<tr class="ewTableHeader">
<?php

// Header row
$mtm_staff_project_list->RowType = EW_ROWTYPE_HEADER;

// Render list options
$mtm_staff_project_list->RenderListOptions();

// Render list options (header, left)
$mtm_staff_project_list->ListOptions->Render("header", "left");
?>
<?php if ($mtm_staff_project->projID->Visible) { // projID ?>
	<?php if ($mtm_staff_project->SortUrl($mtm_staff_project->projID) == "") { ?>
		<th data-name="projID"><div id="elh_mtm_staff_project_projID" class="mtm_staff_project_projID"><div class="ewTableHeaderCaption"><?php echo $mtm_staff_project->projID->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="projID"><div class="ewPointer" onclick="ew_Sort(event,'<?php echo $mtm_staff_project->SortUrl($mtm_staff_project->projID) ?>',2);"><div id="elh_mtm_staff_project_projID" class="mtm_staff_project_projID">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $mtm_staff_project->projID->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($mtm_staff_project->projID->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($mtm_staff_project->projID->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($mtm_staff_project->staffID->Visible) { // staffID ?>
	<?php if ($mtm_staff_project->SortUrl($mtm_staff_project->staffID) == "") { ?>
		<th data-name="staffID"><div id="elh_mtm_staff_project_staffID" class="mtm_staff_project_staffID"><div class="ewTableHeaderCaption"><?php echo $mtm_staff_project->staffID->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="staffID"><div class="ewPointer" onclick="ew_Sort(event,'<?php echo $mtm_staff_project->SortUrl($mtm_staff_project->staffID) ?>',2);"><div id="elh_mtm_staff_project_staffID" class="mtm_staff_project_staffID">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $mtm_staff_project->staffID->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($mtm_staff_project->staffID->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($mtm_staff_project->staffID->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($mtm_staff_project->role->Visible) { // role ?>
	<?php if ($mtm_staff_project->SortUrl($mtm_staff_project->role) == "") { ?>
		<th data-name="role"><div id="elh_mtm_staff_project_role" class="mtm_staff_project_role"><div class="ewTableHeaderCaption"><?php echo $mtm_staff_project->role->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="role"><div class="ewPointer" onclick="ew_Sort(event,'<?php echo $mtm_staff_project->SortUrl($mtm_staff_project->role) ?>',2);"><div id="elh_mtm_staff_project_role" class="mtm_staff_project_role">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $mtm_staff_project->role->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($mtm_staff_project->role->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($mtm_staff_project->role->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($mtm_staff_project->TimeSpentProject->Visible) { // TimeSpentProject ?>
	<?php if ($mtm_staff_project->SortUrl($mtm_staff_project->TimeSpentProject) == "") { ?>
		<th data-name="TimeSpentProject"><div id="elh_mtm_staff_project_TimeSpentProject" class="mtm_staff_project_TimeSpentProject"><div class="ewTableHeaderCaption"><?php echo $mtm_staff_project->TimeSpentProject->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="TimeSpentProject"><div class="ewPointer" onclick="ew_Sort(event,'<?php echo $mtm_staff_project->SortUrl($mtm_staff_project->TimeSpentProject) ?>',2);"><div id="elh_mtm_staff_project_TimeSpentProject" class="mtm_staff_project_TimeSpentProject">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $mtm_staff_project->TimeSpentProject->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($mtm_staff_project->TimeSpentProject->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($mtm_staff_project->TimeSpentProject->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php

// Render list options (header, right)
$mtm_staff_project_list->ListOptions->Render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
	if ($mtm_staff_project->CurrentAction == "add" || $mtm_staff_project->CurrentAction == "copy") {
		$mtm_staff_project_list->RowIndex = 0;
		$mtm_staff_project_list->KeyCount = $mtm_staff_project_list->RowIndex;
		if ($mtm_staff_project->CurrentAction == "copy" && !$mtm_staff_project_list->LoadRow())
				$mtm_staff_project->CurrentAction = "add";
		if ($mtm_staff_project->CurrentAction == "add")
			$mtm_staff_project_list->LoadDefaultValues();
		if ($mtm_staff_project->EventCancelled) // Insert failed
			$mtm_staff_project_list->RestoreFormValues(); // Restore form values

		// Set row properties
		$mtm_staff_project->ResetAttrs();
		$mtm_staff_project->RowAttrs = array_merge($mtm_staff_project->RowAttrs, array('data-rowindex'=>0, 'id'=>'r0_mtm_staff_project', 'data-rowtype'=>EW_ROWTYPE_ADD));
		$mtm_staff_project->RowType = EW_ROWTYPE_ADD;

		// Render row
		$mtm_staff_project_list->RenderRow();

		// Render list options
		$mtm_staff_project_list->RenderListOptions();
		$mtm_staff_project_list->StartRowCnt = 0;
?>
	<tr<?php echo $mtm_staff_project->RowAttributes() ?>>
<?php

// Render list options (body, left)
$mtm_staff_project_list->ListOptions->Render("body", "left", $mtm_staff_project_list->RowCnt);
?>
	<?php if ($mtm_staff_project->projID->Visible) { // projID ?>
		<td data-name="projID">
<?php if ($mtm_staff_project->projID->getSessionValue() <> "") { ?>
<span id="el<?php echo $mtm_staff_project_list->RowCnt ?>_mtm_staff_project_projID" class="form-group mtm_staff_project_projID">
<span<?php echo $mtm_staff_project->projID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_project->projID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_projID" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_projID" value="<?php echo ew_HtmlEncode($mtm_staff_project->projID->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $mtm_staff_project_list->RowCnt ?>_mtm_staff_project_projID" class="form-group mtm_staff_project_projID">
<select data-table="mtm_staff_project" data-field="x_projID" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_project->projID->DisplayValueSeparator) ? json_encode($mtm_staff_project->projID->DisplayValueSeparator) : $mtm_staff_project->projID->DisplayValueSeparator) ?>" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_projID" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_projID"<?php echo $mtm_staff_project->projID->EditAttributes() ?>>
<?php
if (is_array($mtm_staff_project->projID->EditValue)) {
	$arwrk = $mtm_staff_project->projID->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = ew_SameStr($mtm_staff_project->projID->CurrentValue, $arwrk[$rowcntwrk][0]) ? " selected" : "";
		if ($selwrk <> "") $emptywrk = FALSE;		
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $mtm_staff_project->projID->DisplayValue($arwrk[$rowcntwrk]) ?>
</option>
<?php
	}
	if ($emptywrk && strval($mtm_staff_project->projID->CurrentValue) <> "") {
?>
<option value="<?php echo ew_HtmlEncode($mtm_staff_project->projID->CurrentValue) ?>" selected><?php echo $mtm_staff_project->projID->CurrentValue ?></option>
<?php
    }
}
if (@$emptywrk) $mtm_staff_project->projID->OldValue = "";
?>
</select>
<?php
$sSqlWrk = "SELECT `id`, `name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `project`";
$sWhereWrk = "";
$mtm_staff_project->projID->LookupFilters = array("s" => $sSqlWrk, "d" => "");
$mtm_staff_project->projID->LookupFilters += array("f0" => "`id` = {filter_value}", "t0" => "16", "fn0" => "");
$sSqlWrk = "";
$mtm_staff_project->Lookup_Selecting($mtm_staff_project->projID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
if ($sSqlWrk <> "") $mtm_staff_project->projID->LookupFilters["s"] .= $sSqlWrk;
?>
<input type="hidden" name="s_x<?php echo $mtm_staff_project_list->RowIndex ?>_projID" id="s_x<?php echo $mtm_staff_project_list->RowIndex ?>_projID" value="<?php echo $mtm_staff_project->projID->LookupFilterQuery() ?>">
</span>
<?php } ?>
<input type="hidden" data-table="mtm_staff_project" data-field="x_projID" name="o<?php echo $mtm_staff_project_list->RowIndex ?>_projID" id="o<?php echo $mtm_staff_project_list->RowIndex ?>_projID" value="<?php echo ew_HtmlEncode($mtm_staff_project->projID->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mtm_staff_project->staffID->Visible) { // staffID ?>
		<td data-name="staffID">
<?php if ($mtm_staff_project->staffID->getSessionValue() <> "") { ?>
<span id="el<?php echo $mtm_staff_project_list->RowCnt ?>_mtm_staff_project_staffID" class="form-group mtm_staff_project_staffID">
<span<?php echo $mtm_staff_project->staffID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_project->staffID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_project->staffID->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $mtm_staff_project_list->RowCnt ?>_mtm_staff_project_staffID" class="form-group mtm_staff_project_staffID">
<select data-table="mtm_staff_project" data-field="x_staffID" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_project->staffID->DisplayValueSeparator) ? json_encode($mtm_staff_project->staffID->DisplayValueSeparator) : $mtm_staff_project->staffID->DisplayValueSeparator) ?>" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_staffID"<?php echo $mtm_staff_project->staffID->EditAttributes() ?>>
<?php
if (is_array($mtm_staff_project->staffID->EditValue)) {
	$arwrk = $mtm_staff_project->staffID->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = ew_SameStr($mtm_staff_project->staffID->CurrentValue, $arwrk[$rowcntwrk][0]) ? " selected" : "";
		if ($selwrk <> "") $emptywrk = FALSE;		
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $mtm_staff_project->staffID->DisplayValue($arwrk[$rowcntwrk]) ?>
</option>
<?php
	}
	if ($emptywrk && strval($mtm_staff_project->staffID->CurrentValue) <> "") {
?>
<option value="<?php echo ew_HtmlEncode($mtm_staff_project->staffID->CurrentValue) ?>" selected><?php echo $mtm_staff_project->staffID->CurrentValue ?></option>
<?php
    }
}
if (@$emptywrk) $mtm_staff_project->staffID->OldValue = "";
?>
</select>
<?php
$sSqlWrk = "SELECT `id`, `Name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `staff`";
$sWhereWrk = "";
if (!$GLOBALS["mtm_staff_project"]->UserIDAllow($GLOBALS["mtm_staff_project"]->CurrentAction)) $sWhereWrk = $GLOBALS["staff"]->AddUserIDFilter($sWhereWrk);
$mtm_staff_project->staffID->LookupFilters = array("s" => $sSqlWrk, "d" => "");
$mtm_staff_project->staffID->LookupFilters += array("f0" => "`id` = {filter_value}", "t0" => "3", "fn0" => "");
$sSqlWrk = "";
$mtm_staff_project->Lookup_Selecting($mtm_staff_project->staffID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
if ($sSqlWrk <> "") $mtm_staff_project->staffID->LookupFilters["s"] .= $sSqlWrk;
?>
<input type="hidden" name="s_x<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" id="s_x<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" value="<?php echo $mtm_staff_project->staffID->LookupFilterQuery() ?>">
</span>
<?php } ?>
<input type="hidden" data-table="mtm_staff_project" data-field="x_staffID" name="o<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" id="o<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_project->staffID->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mtm_staff_project->role->Visible) { // role ?>
		<td data-name="role">
<span id="el<?php echo $mtm_staff_project_list->RowCnt ?>_mtm_staff_project_role" class="form-group mtm_staff_project_role">
<div id="tp_x<?php echo $mtm_staff_project_list->RowIndex ?>_role" class="ewTemplate"><input type="radio" data-table="mtm_staff_project" data-field="x_role" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_project->role->DisplayValueSeparator) ? json_encode($mtm_staff_project->role->DisplayValueSeparator) : $mtm_staff_project->role->DisplayValueSeparator) ?>" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_role" value="{value}"<?php echo $mtm_staff_project->role->EditAttributes() ?>></div>
<div id="dsl_x<?php echo $mtm_staff_project_list->RowIndex ?>_role" data-repeatcolumn="5" class="ewItemList" style="display: none;"><div>
<?php
$arwrk = $mtm_staff_project->role->EditValue;
if (is_array($arwrk)) {
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = (strval($mtm_staff_project->role->CurrentValue) == strval($arwrk[$rowcntwrk][0])) ? " checked" : "";
		if ($selwrk <> "")
			$emptywrk = FALSE;
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_project" data-field="x_role" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_role_<?php echo $rowcntwrk ?>" value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?><?php echo $mtm_staff_project->role->EditAttributes() ?>><?php echo $mtm_staff_project->role->DisplayValue($arwrk[$rowcntwrk]) ?></label>
<?php
	}
	if ($emptywrk && strval($mtm_staff_project->role->CurrentValue) <> "") {
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_project" data-field="x_role" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_role_<?php echo $rowswrk ?>" value="<?php echo ew_HtmlEncode($mtm_staff_project->role->CurrentValue) ?>" checked<?php echo $mtm_staff_project->role->EditAttributes() ?>><?php echo $mtm_staff_project->role->CurrentValue ?></label>
<?php
    }
}
if (@$emptywrk) $mtm_staff_project->role->OldValue = "";
?>
</div></div>
</span>
<input type="hidden" data-table="mtm_staff_project" data-field="x_role" name="o<?php echo $mtm_staff_project_list->RowIndex ?>_role" id="o<?php echo $mtm_staff_project_list->RowIndex ?>_role" value="<?php echo ew_HtmlEncode($mtm_staff_project->role->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mtm_staff_project->TimeSpentProject->Visible) { // TimeSpentProject ?>
		<td data-name="TimeSpentProject">
<span id="el<?php echo $mtm_staff_project_list->RowCnt ?>_mtm_staff_project_TimeSpentProject" class="form-group mtm_staff_project_TimeSpentProject">
<input type="text" data-table="mtm_staff_project" data-field="x_TimeSpentProject" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_TimeSpentProject" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_TimeSpentProject" size="30" placeholder="<?php echo ew_HtmlEncode($mtm_staff_project->TimeSpentProject->getPlaceHolder()) ?>" value="<?php echo $mtm_staff_project->TimeSpentProject->EditValue ?>"<?php echo $mtm_staff_project->TimeSpentProject->EditAttributes() ?>>
</span>
<input type="hidden" data-table="mtm_staff_project" data-field="x_TimeSpentProject" name="o<?php echo $mtm_staff_project_list->RowIndex ?>_TimeSpentProject" id="o<?php echo $mtm_staff_project_list->RowIndex ?>_TimeSpentProject" value="<?php echo ew_HtmlEncode($mtm_staff_project->TimeSpentProject->OldValue) ?>">
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$mtm_staff_project_list->ListOptions->Render("body", "right", $mtm_staff_project_list->RowCnt);
?>
<script type="text/javascript">
fmtm_staff_projectlist.UpdateOpts(<?php echo $mtm_staff_project_list->RowIndex ?>);
</script>
	</tr>
<?php
}
?>
<?php
if ($mtm_staff_project->ExportAll && $mtm_staff_project->Export <> "") {
	$mtm_staff_project_list->StopRec = $mtm_staff_project_list->TotalRecs;
} else {

	// Set the last record to display
	if ($mtm_staff_project_list->TotalRecs > $mtm_staff_project_list->StartRec + $mtm_staff_project_list->DisplayRecs - 1)
		$mtm_staff_project_list->StopRec = $mtm_staff_project_list->StartRec + $mtm_staff_project_list->DisplayRecs - 1;
	else
		$mtm_staff_project_list->StopRec = $mtm_staff_project_list->TotalRecs;
}

// Restore number of post back records
if ($objForm) {
	$objForm->Index = -1;
	if ($objForm->HasValue($mtm_staff_project_list->FormKeyCountName) && ($mtm_staff_project->CurrentAction == "gridadd" || $mtm_staff_project->CurrentAction == "gridedit" || $mtm_staff_project->CurrentAction == "F")) {
		$mtm_staff_project_list->KeyCount = $objForm->GetValue($mtm_staff_project_list->FormKeyCountName);
		$mtm_staff_project_list->StopRec = $mtm_staff_project_list->StartRec + $mtm_staff_project_list->KeyCount - 1;
	}
}
$mtm_staff_project_list->RecCnt = $mtm_staff_project_list->StartRec - 1;
if ($mtm_staff_project_list->Recordset && !$mtm_staff_project_list->Recordset->EOF) {
	$mtm_staff_project_list->Recordset->MoveFirst();
	$bSelectLimit = $mtm_staff_project_list->UseSelectLimit;
	if (!$bSelectLimit && $mtm_staff_project_list->StartRec > 1)
		$mtm_staff_project_list->Recordset->Move($mtm_staff_project_list->StartRec - 1);
} elseif (!$mtm_staff_project->AllowAddDeleteRow && $mtm_staff_project_list->StopRec == 0) {
	$mtm_staff_project_list->StopRec = $mtm_staff_project->GridAddRowCount;
}

// Initialize aggregate
$mtm_staff_project->RowType = EW_ROWTYPE_AGGREGATEINIT;
$mtm_staff_project->ResetAttrs();
$mtm_staff_project_list->RenderRow();
$mtm_staff_project_list->EditRowCnt = 0;
if ($mtm_staff_project->CurrentAction == "edit")
	$mtm_staff_project_list->RowIndex = 1;
if ($mtm_staff_project->CurrentAction == "gridadd")
	$mtm_staff_project_list->RowIndex = 0;
if ($mtm_staff_project->CurrentAction == "gridedit")
	$mtm_staff_project_list->RowIndex = 0;
while ($mtm_staff_project_list->RecCnt < $mtm_staff_project_list->StopRec) {
	$mtm_staff_project_list->RecCnt++;
	if (intval($mtm_staff_project_list->RecCnt) >= intval($mtm_staff_project_list->StartRec)) {
		$mtm_staff_project_list->RowCnt++;
		if ($mtm_staff_project->CurrentAction == "gridadd" || $mtm_staff_project->CurrentAction == "gridedit" || $mtm_staff_project->CurrentAction == "F") {
			$mtm_staff_project_list->RowIndex++;
			$objForm->Index = $mtm_staff_project_list->RowIndex;
			if ($objForm->HasValue($mtm_staff_project_list->FormActionName))
				$mtm_staff_project_list->RowAction = strval($objForm->GetValue($mtm_staff_project_list->FormActionName));
			elseif ($mtm_staff_project->CurrentAction == "gridadd")
				$mtm_staff_project_list->RowAction = "insert";
			else
				$mtm_staff_project_list->RowAction = "";
		}

		// Set up key count
		$mtm_staff_project_list->KeyCount = $mtm_staff_project_list->RowIndex;

		// Init row class and style
		$mtm_staff_project->ResetAttrs();
		$mtm_staff_project->CssClass = "";
		if ($mtm_staff_project->CurrentAction == "gridadd") {
			$mtm_staff_project_list->LoadDefaultValues(); // Load default values
		} else {
			$mtm_staff_project_list->LoadRowValues($mtm_staff_project_list->Recordset); // Load row values
		}
		$mtm_staff_project->RowType = EW_ROWTYPE_VIEW; // Render view
		if ($mtm_staff_project->CurrentAction == "gridadd") // Grid add
			$mtm_staff_project->RowType = EW_ROWTYPE_ADD; // Render add
		if ($mtm_staff_project->CurrentAction == "gridadd" && $mtm_staff_project->EventCancelled && !$objForm->HasValue("k_blankrow")) // Insert failed
			$mtm_staff_project_list->RestoreCurrentRowFormValues($mtm_staff_project_list->RowIndex); // Restore form values
		if ($mtm_staff_project->CurrentAction == "edit") {
			if ($mtm_staff_project_list->CheckInlineEditKey() && $mtm_staff_project_list->EditRowCnt == 0) { // Inline edit
				$mtm_staff_project->RowType = EW_ROWTYPE_EDIT; // Render edit
			}
		}
		if ($mtm_staff_project->CurrentAction == "gridedit") { // Grid edit
			if ($mtm_staff_project->EventCancelled) {
				$mtm_staff_project_list->RestoreCurrentRowFormValues($mtm_staff_project_list->RowIndex); // Restore form values
			}
			if ($mtm_staff_project_list->RowAction == "insert")
				$mtm_staff_project->RowType = EW_ROWTYPE_ADD; // Render add
			else
				$mtm_staff_project->RowType = EW_ROWTYPE_EDIT; // Render edit
		}
		if ($mtm_staff_project->CurrentAction == "edit" && $mtm_staff_project->RowType == EW_ROWTYPE_EDIT && $mtm_staff_project->EventCancelled) { // Update failed
			$objForm->Index = 1;
			$mtm_staff_project_list->RestoreFormValues(); // Restore form values
		}
		if ($mtm_staff_project->CurrentAction == "gridedit" && ($mtm_staff_project->RowType == EW_ROWTYPE_EDIT || $mtm_staff_project->RowType == EW_ROWTYPE_ADD) && $mtm_staff_project->EventCancelled) // Update failed
			$mtm_staff_project_list->RestoreCurrentRowFormValues($mtm_staff_project_list->RowIndex); // Restore form values
		if ($mtm_staff_project->RowType == EW_ROWTYPE_EDIT) // Edit row
			$mtm_staff_project_list->EditRowCnt++;

		// Set up row id / data-rowindex
		$mtm_staff_project->RowAttrs = array_merge($mtm_staff_project->RowAttrs, array('data-rowindex'=>$mtm_staff_project_list->RowCnt, 'id'=>'r' . $mtm_staff_project_list->RowCnt . '_mtm_staff_project', 'data-rowtype'=>$mtm_staff_project->RowType));

		// Render row
		$mtm_staff_project_list->RenderRow();

		// Render list options
		$mtm_staff_project_list->RenderListOptions();

		// Skip delete row / empty row for confirm page
		if ($mtm_staff_project_list->RowAction <> "delete" && $mtm_staff_project_list->RowAction <> "insertdelete" && !($mtm_staff_project_list->RowAction == "insert" && $mtm_staff_project->CurrentAction == "F" && $mtm_staff_project_list->EmptyRow())) {
?>
	<tr<?php echo $mtm_staff_project->RowAttributes() ?>>
<?php

// Render list options (body, left)
$mtm_staff_project_list->ListOptions->Render("body", "left", $mtm_staff_project_list->RowCnt);
?>
	<?php if ($mtm_staff_project->projID->Visible) { // projID ?>
		<td data-name="projID"<?php echo $mtm_staff_project->projID->CellAttributes() ?>>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<?php if ($mtm_staff_project->projID->getSessionValue() <> "") { ?>
<span id="el<?php echo $mtm_staff_project_list->RowCnt ?>_mtm_staff_project_projID" class="form-group mtm_staff_project_projID">
<span<?php echo $mtm_staff_project->projID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_project->projID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_projID" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_projID" value="<?php echo ew_HtmlEncode($mtm_staff_project->projID->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $mtm_staff_project_list->RowCnt ?>_mtm_staff_project_projID" class="form-group mtm_staff_project_projID">
<select data-table="mtm_staff_project" data-field="x_projID" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_project->projID->DisplayValueSeparator) ? json_encode($mtm_staff_project->projID->DisplayValueSeparator) : $mtm_staff_project->projID->DisplayValueSeparator) ?>" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_projID" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_projID"<?php echo $mtm_staff_project->projID->EditAttributes() ?>>
<?php
if (is_array($mtm_staff_project->projID->EditValue)) {
	$arwrk = $mtm_staff_project->projID->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = ew_SameStr($mtm_staff_project->projID->CurrentValue, $arwrk[$rowcntwrk][0]) ? " selected" : "";
		if ($selwrk <> "") $emptywrk = FALSE;		
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $mtm_staff_project->projID->DisplayValue($arwrk[$rowcntwrk]) ?>
</option>
<?php
	}
	if ($emptywrk && strval($mtm_staff_project->projID->CurrentValue) <> "") {
?>
<option value="<?php echo ew_HtmlEncode($mtm_staff_project->projID->CurrentValue) ?>" selected><?php echo $mtm_staff_project->projID->CurrentValue ?></option>
<?php
    }
}
if (@$emptywrk) $mtm_staff_project->projID->OldValue = "";
?>
</select>
<?php
$sSqlWrk = "SELECT `id`, `name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `project`";
$sWhereWrk = "";
$mtm_staff_project->projID->LookupFilters = array("s" => $sSqlWrk, "d" => "");
$mtm_staff_project->projID->LookupFilters += array("f0" => "`id` = {filter_value}", "t0" => "16", "fn0" => "");
$sSqlWrk = "";
$mtm_staff_project->Lookup_Selecting($mtm_staff_project->projID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
if ($sSqlWrk <> "") $mtm_staff_project->projID->LookupFilters["s"] .= $sSqlWrk;
?>
<input type="hidden" name="s_x<?php echo $mtm_staff_project_list->RowIndex ?>_projID" id="s_x<?php echo $mtm_staff_project_list->RowIndex ?>_projID" value="<?php echo $mtm_staff_project->projID->LookupFilterQuery() ?>">
</span>
<?php } ?>
<input type="hidden" data-table="mtm_staff_project" data-field="x_projID" name="o<?php echo $mtm_staff_project_list->RowIndex ?>_projID" id="o<?php echo $mtm_staff_project_list->RowIndex ?>_projID" value="<?php echo ew_HtmlEncode($mtm_staff_project->projID->OldValue) ?>">
<?php } ?>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mtm_staff_project_list->RowCnt ?>_mtm_staff_project_projID" class="form-group mtm_staff_project_projID">
<span<?php echo $mtm_staff_project->projID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_project->projID->EditValue ?></p></span>
</span>
<input type="hidden" data-table="mtm_staff_project" data-field="x_projID" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_projID" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_projID" value="<?php echo ew_HtmlEncode($mtm_staff_project->projID->CurrentValue) ?>">
<?php } ?>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mtm_staff_project_list->RowCnt ?>_mtm_staff_project_projID" class="mtm_staff_project_projID">
<span<?php echo $mtm_staff_project->projID->ViewAttributes() ?>>
<?php echo $mtm_staff_project->projID->ListViewValue() ?></span>
</span>
<?php } ?>
<a id="<?php echo $mtm_staff_project_list->PageObjName . "_row_" . $mtm_staff_project_list->RowCnt ?>"></a></td>
	<?php } ?>
	<?php if ($mtm_staff_project->staffID->Visible) { // staffID ?>
		<td data-name="staffID"<?php echo $mtm_staff_project->staffID->CellAttributes() ?>>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<?php if ($mtm_staff_project->staffID->getSessionValue() <> "") { ?>
<span id="el<?php echo $mtm_staff_project_list->RowCnt ?>_mtm_staff_project_staffID" class="form-group mtm_staff_project_staffID">
<span<?php echo $mtm_staff_project->staffID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_project->staffID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_project->staffID->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $mtm_staff_project_list->RowCnt ?>_mtm_staff_project_staffID" class="form-group mtm_staff_project_staffID">
<select data-table="mtm_staff_project" data-field="x_staffID" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_project->staffID->DisplayValueSeparator) ? json_encode($mtm_staff_project->staffID->DisplayValueSeparator) : $mtm_staff_project->staffID->DisplayValueSeparator) ?>" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_staffID"<?php echo $mtm_staff_project->staffID->EditAttributes() ?>>
<?php
if (is_array($mtm_staff_project->staffID->EditValue)) {
	$arwrk = $mtm_staff_project->staffID->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = ew_SameStr($mtm_staff_project->staffID->CurrentValue, $arwrk[$rowcntwrk][0]) ? " selected" : "";
		if ($selwrk <> "") $emptywrk = FALSE;		
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $mtm_staff_project->staffID->DisplayValue($arwrk[$rowcntwrk]) ?>
</option>
<?php
	}
	if ($emptywrk && strval($mtm_staff_project->staffID->CurrentValue) <> "") {
?>
<option value="<?php echo ew_HtmlEncode($mtm_staff_project->staffID->CurrentValue) ?>" selected><?php echo $mtm_staff_project->staffID->CurrentValue ?></option>
<?php
    }
}
if (@$emptywrk) $mtm_staff_project->staffID->OldValue = "";
?>
</select>
<?php
$sSqlWrk = "SELECT `id`, `Name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `staff`";
$sWhereWrk = "";
if (!$GLOBALS["mtm_staff_project"]->UserIDAllow($GLOBALS["mtm_staff_project"]->CurrentAction)) $sWhereWrk = $GLOBALS["staff"]->AddUserIDFilter($sWhereWrk);
$mtm_staff_project->staffID->LookupFilters = array("s" => $sSqlWrk, "d" => "");
$mtm_staff_project->staffID->LookupFilters += array("f0" => "`id` = {filter_value}", "t0" => "3", "fn0" => "");
$sSqlWrk = "";
$mtm_staff_project->Lookup_Selecting($mtm_staff_project->staffID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
if ($sSqlWrk <> "") $mtm_staff_project->staffID->LookupFilters["s"] .= $sSqlWrk;
?>
<input type="hidden" name="s_x<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" id="s_x<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" value="<?php echo $mtm_staff_project->staffID->LookupFilterQuery() ?>">
</span>
<?php } ?>
<input type="hidden" data-table="mtm_staff_project" data-field="x_staffID" name="o<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" id="o<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_project->staffID->OldValue) ?>">
<?php } ?>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mtm_staff_project_list->RowCnt ?>_mtm_staff_project_staffID" class="form-group mtm_staff_project_staffID">
<span<?php echo $mtm_staff_project->staffID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_project->staffID->EditValue ?></p></span>
</span>
<input type="hidden" data-table="mtm_staff_project" data-field="x_staffID" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_project->staffID->CurrentValue) ?>">
<?php } ?>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mtm_staff_project_list->RowCnt ?>_mtm_staff_project_staffID" class="mtm_staff_project_staffID">
<span<?php echo $mtm_staff_project->staffID->ViewAttributes() ?>>
<?php echo $mtm_staff_project->staffID->ListViewValue() ?></span>
</span>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($mtm_staff_project->role->Visible) { // role ?>
		<td data-name="role"<?php echo $mtm_staff_project->role->CellAttributes() ?>>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $mtm_staff_project_list->RowCnt ?>_mtm_staff_project_role" class="form-group mtm_staff_project_role">
<div id="tp_x<?php echo $mtm_staff_project_list->RowIndex ?>_role" class="ewTemplate"><input type="radio" data-table="mtm_staff_project" data-field="x_role" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_project->role->DisplayValueSeparator) ? json_encode($mtm_staff_project->role->DisplayValueSeparator) : $mtm_staff_project->role->DisplayValueSeparator) ?>" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_role" value="{value}"<?php echo $mtm_staff_project->role->EditAttributes() ?>></div>
<div id="dsl_x<?php echo $mtm_staff_project_list->RowIndex ?>_role" data-repeatcolumn="5" class="ewItemList" style="display: none;"><div>
<?php
$arwrk = $mtm_staff_project->role->EditValue;
if (is_array($arwrk)) {
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = (strval($mtm_staff_project->role->CurrentValue) == strval($arwrk[$rowcntwrk][0])) ? " checked" : "";
		if ($selwrk <> "")
			$emptywrk = FALSE;
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_project" data-field="x_role" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_role_<?php echo $rowcntwrk ?>" value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?><?php echo $mtm_staff_project->role->EditAttributes() ?>><?php echo $mtm_staff_project->role->DisplayValue($arwrk[$rowcntwrk]) ?></label>
<?php
	}
	if ($emptywrk && strval($mtm_staff_project->role->CurrentValue) <> "") {
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_project" data-field="x_role" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_role_<?php echo $rowswrk ?>" value="<?php echo ew_HtmlEncode($mtm_staff_project->role->CurrentValue) ?>" checked<?php echo $mtm_staff_project->role->EditAttributes() ?>><?php echo $mtm_staff_project->role->CurrentValue ?></label>
<?php
    }
}
if (@$emptywrk) $mtm_staff_project->role->OldValue = "";
?>
</div></div>
</span>
<input type="hidden" data-table="mtm_staff_project" data-field="x_role" name="o<?php echo $mtm_staff_project_list->RowIndex ?>_role" id="o<?php echo $mtm_staff_project_list->RowIndex ?>_role" value="<?php echo ew_HtmlEncode($mtm_staff_project->role->OldValue) ?>">
<?php } ?>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mtm_staff_project_list->RowCnt ?>_mtm_staff_project_role" class="form-group mtm_staff_project_role">
<div id="tp_x<?php echo $mtm_staff_project_list->RowIndex ?>_role" class="ewTemplate"><input type="radio" data-table="mtm_staff_project" data-field="x_role" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_project->role->DisplayValueSeparator) ? json_encode($mtm_staff_project->role->DisplayValueSeparator) : $mtm_staff_project->role->DisplayValueSeparator) ?>" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_role" value="{value}"<?php echo $mtm_staff_project->role->EditAttributes() ?>></div>
<div id="dsl_x<?php echo $mtm_staff_project_list->RowIndex ?>_role" data-repeatcolumn="5" class="ewItemList" style="display: none;"><div>
<?php
$arwrk = $mtm_staff_project->role->EditValue;
if (is_array($arwrk)) {
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = (strval($mtm_staff_project->role->CurrentValue) == strval($arwrk[$rowcntwrk][0])) ? " checked" : "";
		if ($selwrk <> "")
			$emptywrk = FALSE;
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_project" data-field="x_role" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_role_<?php echo $rowcntwrk ?>" value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?><?php echo $mtm_staff_project->role->EditAttributes() ?>><?php echo $mtm_staff_project->role->DisplayValue($arwrk[$rowcntwrk]) ?></label>
<?php
	}
	if ($emptywrk && strval($mtm_staff_project->role->CurrentValue) <> "") {
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_project" data-field="x_role" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_role_<?php echo $rowswrk ?>" value="<?php echo ew_HtmlEncode($mtm_staff_project->role->CurrentValue) ?>" checked<?php echo $mtm_staff_project->role->EditAttributes() ?>><?php echo $mtm_staff_project->role->CurrentValue ?></label>
<?php
    }
}
if (@$emptywrk) $mtm_staff_project->role->OldValue = "";
?>
</div></div>
</span>
<?php } ?>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mtm_staff_project_list->RowCnt ?>_mtm_staff_project_role" class="mtm_staff_project_role">
<span<?php echo $mtm_staff_project->role->ViewAttributes() ?>>
<?php echo $mtm_staff_project->role->ListViewValue() ?></span>
</span>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($mtm_staff_project->TimeSpentProject->Visible) { // TimeSpentProject ?>
		<td data-name="TimeSpentProject"<?php echo $mtm_staff_project->TimeSpentProject->CellAttributes() ?>>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $mtm_staff_project_list->RowCnt ?>_mtm_staff_project_TimeSpentProject" class="form-group mtm_staff_project_TimeSpentProject">
<input type="text" data-table="mtm_staff_project" data-field="x_TimeSpentProject" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_TimeSpentProject" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_TimeSpentProject" size="30" placeholder="<?php echo ew_HtmlEncode($mtm_staff_project->TimeSpentProject->getPlaceHolder()) ?>" value="<?php echo $mtm_staff_project->TimeSpentProject->EditValue ?>"<?php echo $mtm_staff_project->TimeSpentProject->EditAttributes() ?>>
</span>
<input type="hidden" data-table="mtm_staff_project" data-field="x_TimeSpentProject" name="o<?php echo $mtm_staff_project_list->RowIndex ?>_TimeSpentProject" id="o<?php echo $mtm_staff_project_list->RowIndex ?>_TimeSpentProject" value="<?php echo ew_HtmlEncode($mtm_staff_project->TimeSpentProject->OldValue) ?>">
<?php } ?>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mtm_staff_project_list->RowCnt ?>_mtm_staff_project_TimeSpentProject" class="form-group mtm_staff_project_TimeSpentProject">
<input type="text" data-table="mtm_staff_project" data-field="x_TimeSpentProject" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_TimeSpentProject" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_TimeSpentProject" size="30" placeholder="<?php echo ew_HtmlEncode($mtm_staff_project->TimeSpentProject->getPlaceHolder()) ?>" value="<?php echo $mtm_staff_project->TimeSpentProject->EditValue ?>"<?php echo $mtm_staff_project->TimeSpentProject->EditAttributes() ?>>
</span>
<?php } ?>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mtm_staff_project_list->RowCnt ?>_mtm_staff_project_TimeSpentProject" class="mtm_staff_project_TimeSpentProject">
<span<?php echo $mtm_staff_project->TimeSpentProject->ViewAttributes() ?>>
<?php echo $mtm_staff_project->TimeSpentProject->ListViewValue() ?></span>
</span>
<?php } ?>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$mtm_staff_project_list->ListOptions->Render("body", "right", $mtm_staff_project_list->RowCnt);
?>
	</tr>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_ADD || $mtm_staff_project->RowType == EW_ROWTYPE_EDIT) { ?>
<script type="text/javascript">
fmtm_staff_projectlist.UpdateOpts(<?php echo $mtm_staff_project_list->RowIndex ?>);
</script>
<?php } ?>
<?php
	}
	} // End delete row checking
	if ($mtm_staff_project->CurrentAction <> "gridadd")
		if (!$mtm_staff_project_list->Recordset->EOF) $mtm_staff_project_list->Recordset->MoveNext();
}
?>
<?php
	if ($mtm_staff_project->CurrentAction == "gridadd" || $mtm_staff_project->CurrentAction == "gridedit") {
		$mtm_staff_project_list->RowIndex = '$rowindex$';
		$mtm_staff_project_list->LoadDefaultValues();

		// Set row properties
		$mtm_staff_project->ResetAttrs();
		$mtm_staff_project->RowAttrs = array_merge($mtm_staff_project->RowAttrs, array('data-rowindex'=>$mtm_staff_project_list->RowIndex, 'id'=>'r0_mtm_staff_project', 'data-rowtype'=>EW_ROWTYPE_ADD));
		ew_AppendClass($mtm_staff_project->RowAttrs["class"], "ewTemplate");
		$mtm_staff_project->RowType = EW_ROWTYPE_ADD;

		// Render row
		$mtm_staff_project_list->RenderRow();

		// Render list options
		$mtm_staff_project_list->RenderListOptions();
		$mtm_staff_project_list->StartRowCnt = 0;
?>
	<tr<?php echo $mtm_staff_project->RowAttributes() ?>>
<?php

// Render list options (body, left)
$mtm_staff_project_list->ListOptions->Render("body", "left", $mtm_staff_project_list->RowIndex);
?>
	<?php if ($mtm_staff_project->projID->Visible) { // projID ?>
		<td data-name="projID">
<?php if ($mtm_staff_project->projID->getSessionValue() <> "") { ?>
<span id="el$rowindex$_mtm_staff_project_projID" class="form-group mtm_staff_project_projID">
<span<?php echo $mtm_staff_project->projID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_project->projID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_projID" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_projID" value="<?php echo ew_HtmlEncode($mtm_staff_project->projID->CurrentValue) ?>">
<?php } else { ?>
<span id="el$rowindex$_mtm_staff_project_projID" class="form-group mtm_staff_project_projID">
<select data-table="mtm_staff_project" data-field="x_projID" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_project->projID->DisplayValueSeparator) ? json_encode($mtm_staff_project->projID->DisplayValueSeparator) : $mtm_staff_project->projID->DisplayValueSeparator) ?>" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_projID" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_projID"<?php echo $mtm_staff_project->projID->EditAttributes() ?>>
<?php
if (is_array($mtm_staff_project->projID->EditValue)) {
	$arwrk = $mtm_staff_project->projID->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = ew_SameStr($mtm_staff_project->projID->CurrentValue, $arwrk[$rowcntwrk][0]) ? " selected" : "";
		if ($selwrk <> "") $emptywrk = FALSE;		
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $mtm_staff_project->projID->DisplayValue($arwrk[$rowcntwrk]) ?>
</option>
<?php
	}
	if ($emptywrk && strval($mtm_staff_project->projID->CurrentValue) <> "") {
?>
<option value="<?php echo ew_HtmlEncode($mtm_staff_project->projID->CurrentValue) ?>" selected><?php echo $mtm_staff_project->projID->CurrentValue ?></option>
<?php
    }
}
if (@$emptywrk) $mtm_staff_project->projID->OldValue = "";
?>
</select>
<?php
$sSqlWrk = "SELECT `id`, `name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `project`";
$sWhereWrk = "";
$mtm_staff_project->projID->LookupFilters = array("s" => $sSqlWrk, "d" => "");
$mtm_staff_project->projID->LookupFilters += array("f0" => "`id` = {filter_value}", "t0" => "16", "fn0" => "");
$sSqlWrk = "";
$mtm_staff_project->Lookup_Selecting($mtm_staff_project->projID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
if ($sSqlWrk <> "") $mtm_staff_project->projID->LookupFilters["s"] .= $sSqlWrk;
?>
<input type="hidden" name="s_x<?php echo $mtm_staff_project_list->RowIndex ?>_projID" id="s_x<?php echo $mtm_staff_project_list->RowIndex ?>_projID" value="<?php echo $mtm_staff_project->projID->LookupFilterQuery() ?>">
</span>
<?php } ?>
<input type="hidden" data-table="mtm_staff_project" data-field="x_projID" name="o<?php echo $mtm_staff_project_list->RowIndex ?>_projID" id="o<?php echo $mtm_staff_project_list->RowIndex ?>_projID" value="<?php echo ew_HtmlEncode($mtm_staff_project->projID->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mtm_staff_project->staffID->Visible) { // staffID ?>
		<td data-name="staffID">
<?php if ($mtm_staff_project->staffID->getSessionValue() <> "") { ?>
<span id="el$rowindex$_mtm_staff_project_staffID" class="form-group mtm_staff_project_staffID">
<span<?php echo $mtm_staff_project->staffID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_project->staffID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_project->staffID->CurrentValue) ?>">
<?php } else { ?>
<span id="el$rowindex$_mtm_staff_project_staffID" class="form-group mtm_staff_project_staffID">
<select data-table="mtm_staff_project" data-field="x_staffID" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_project->staffID->DisplayValueSeparator) ? json_encode($mtm_staff_project->staffID->DisplayValueSeparator) : $mtm_staff_project->staffID->DisplayValueSeparator) ?>" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_staffID"<?php echo $mtm_staff_project->staffID->EditAttributes() ?>>
<?php
if (is_array($mtm_staff_project->staffID->EditValue)) {
	$arwrk = $mtm_staff_project->staffID->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = ew_SameStr($mtm_staff_project->staffID->CurrentValue, $arwrk[$rowcntwrk][0]) ? " selected" : "";
		if ($selwrk <> "") $emptywrk = FALSE;		
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $mtm_staff_project->staffID->DisplayValue($arwrk[$rowcntwrk]) ?>
</option>
<?php
	}
	if ($emptywrk && strval($mtm_staff_project->staffID->CurrentValue) <> "") {
?>
<option value="<?php echo ew_HtmlEncode($mtm_staff_project->staffID->CurrentValue) ?>" selected><?php echo $mtm_staff_project->staffID->CurrentValue ?></option>
<?php
    }
}
if (@$emptywrk) $mtm_staff_project->staffID->OldValue = "";
?>
</select>
<?php
$sSqlWrk = "SELECT `id`, `Name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `staff`";
$sWhereWrk = "";
if (!$GLOBALS["mtm_staff_project"]->UserIDAllow($GLOBALS["mtm_staff_project"]->CurrentAction)) $sWhereWrk = $GLOBALS["staff"]->AddUserIDFilter($sWhereWrk);
$mtm_staff_project->staffID->LookupFilters = array("s" => $sSqlWrk, "d" => "");
$mtm_staff_project->staffID->LookupFilters += array("f0" => "`id` = {filter_value}", "t0" => "3", "fn0" => "");
$sSqlWrk = "";
$mtm_staff_project->Lookup_Selecting($mtm_staff_project->staffID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
if ($sSqlWrk <> "") $mtm_staff_project->staffID->LookupFilters["s"] .= $sSqlWrk;
?>
<input type="hidden" name="s_x<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" id="s_x<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" value="<?php echo $mtm_staff_project->staffID->LookupFilterQuery() ?>">
</span>
<?php } ?>
<input type="hidden" data-table="mtm_staff_project" data-field="x_staffID" name="o<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" id="o<?php echo $mtm_staff_project_list->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_project->staffID->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mtm_staff_project->role->Visible) { // role ?>
		<td data-name="role">
<span id="el$rowindex$_mtm_staff_project_role" class="form-group mtm_staff_project_role">
<div id="tp_x<?php echo $mtm_staff_project_list->RowIndex ?>_role" class="ewTemplate"><input type="radio" data-table="mtm_staff_project" data-field="x_role" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_project->role->DisplayValueSeparator) ? json_encode($mtm_staff_project->role->DisplayValueSeparator) : $mtm_staff_project->role->DisplayValueSeparator) ?>" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_role" value="{value}"<?php echo $mtm_staff_project->role->EditAttributes() ?>></div>
<div id="dsl_x<?php echo $mtm_staff_project_list->RowIndex ?>_role" data-repeatcolumn="5" class="ewItemList" style="display: none;"><div>
<?php
$arwrk = $mtm_staff_project->role->EditValue;
if (is_array($arwrk)) {
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = (strval($mtm_staff_project->role->CurrentValue) == strval($arwrk[$rowcntwrk][0])) ? " checked" : "";
		if ($selwrk <> "")
			$emptywrk = FALSE;
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_project" data-field="x_role" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_role_<?php echo $rowcntwrk ?>" value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?><?php echo $mtm_staff_project->role->EditAttributes() ?>><?php echo $mtm_staff_project->role->DisplayValue($arwrk[$rowcntwrk]) ?></label>
<?php
	}
	if ($emptywrk && strval($mtm_staff_project->role->CurrentValue) <> "") {
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_project" data-field="x_role" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_role_<?php echo $rowswrk ?>" value="<?php echo ew_HtmlEncode($mtm_staff_project->role->CurrentValue) ?>" checked<?php echo $mtm_staff_project->role->EditAttributes() ?>><?php echo $mtm_staff_project->role->CurrentValue ?></label>
<?php
    }
}
if (@$emptywrk) $mtm_staff_project->role->OldValue = "";
?>
</div></div>
</span>
<input type="hidden" data-table="mtm_staff_project" data-field="x_role" name="o<?php echo $mtm_staff_project_list->RowIndex ?>_role" id="o<?php echo $mtm_staff_project_list->RowIndex ?>_role" value="<?php echo ew_HtmlEncode($mtm_staff_project->role->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mtm_staff_project->TimeSpentProject->Visible) { // TimeSpentProject ?>
		<td data-name="TimeSpentProject">
<span id="el$rowindex$_mtm_staff_project_TimeSpentProject" class="form-group mtm_staff_project_TimeSpentProject">
<input type="text" data-table="mtm_staff_project" data-field="x_TimeSpentProject" name="x<?php echo $mtm_staff_project_list->RowIndex ?>_TimeSpentProject" id="x<?php echo $mtm_staff_project_list->RowIndex ?>_TimeSpentProject" size="30" placeholder="<?php echo ew_HtmlEncode($mtm_staff_project->TimeSpentProject->getPlaceHolder()) ?>" value="<?php echo $mtm_staff_project->TimeSpentProject->EditValue ?>"<?php echo $mtm_staff_project->TimeSpentProject->EditAttributes() ?>>
</span>
<input type="hidden" data-table="mtm_staff_project" data-field="x_TimeSpentProject" name="o<?php echo $mtm_staff_project_list->RowIndex ?>_TimeSpentProject" id="o<?php echo $mtm_staff_project_list->RowIndex ?>_TimeSpentProject" value="<?php echo ew_HtmlEncode($mtm_staff_project->TimeSpentProject->OldValue) ?>">
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$mtm_staff_project_list->ListOptions->Render("body", "right", $mtm_staff_project_list->RowCnt);
?>
<script type="text/javascript">
fmtm_staff_projectlist.UpdateOpts(<?php echo $mtm_staff_project_list->RowIndex ?>);
</script>
	</tr>
<?php
}
?>
</tbody>
</table>
<?php } ?>
<?php if ($mtm_staff_project->CurrentAction == "add" || $mtm_staff_project->CurrentAction == "copy") { ?>
<input type="hidden" name="<?php echo $mtm_staff_project_list->FormKeyCountName ?>" id="<?php echo $mtm_staff_project_list->FormKeyCountName ?>" value="<?php echo $mtm_staff_project_list->KeyCount ?>">
<?php } ?>
<?php if ($mtm_staff_project->CurrentAction == "gridadd") { ?>
<input type="hidden" name="a_list" id="a_list" value="gridinsert">
<input type="hidden" name="<?php echo $mtm_staff_project_list->FormKeyCountName ?>" id="<?php echo $mtm_staff_project_list->FormKeyCountName ?>" value="<?php echo $mtm_staff_project_list->KeyCount ?>">
<?php echo $mtm_staff_project_list->MultiSelectKey ?>
<?php } ?>
<?php if ($mtm_staff_project->CurrentAction == "edit") { ?>
<input type="hidden" name="<?php echo $mtm_staff_project_list->FormKeyCountName ?>" id="<?php echo $mtm_staff_project_list->FormKeyCountName ?>" value="<?php echo $mtm_staff_project_list->KeyCount ?>">
<?php } ?>
<?php if ($mtm_staff_project->CurrentAction == "gridedit") { ?>
<input type="hidden" name="a_list" id="a_list" value="gridupdate">
<input type="hidden" name="<?php echo $mtm_staff_project_list->FormKeyCountName ?>" id="<?php echo $mtm_staff_project_list->FormKeyCountName ?>" value="<?php echo $mtm_staff_project_list->KeyCount ?>">
<?php echo $mtm_staff_project_list->MultiSelectKey ?>
<?php } ?>
<?php if ($mtm_staff_project->CurrentAction == "") { ?>
<input type="hidden" name="a_list" id="a_list" value="">
<?php } ?>
</div>
</form>
<?php

// Close recordset
if ($mtm_staff_project_list->Recordset)
	$mtm_staff_project_list->Recordset->Close();
?>
<?php if ($mtm_staff_project->Export == "") { ?>
<div class="panel-footer ewGridLowerPanel">
<?php if ($mtm_staff_project->CurrentAction <> "gridadd" && $mtm_staff_project->CurrentAction <> "gridedit") { ?>
<form name="ewPagerForm" class="ewForm form-inline ewPagerForm" action="<?php echo ew_CurrentPage() ?>">
<?php if (!isset($mtm_staff_project_list->Pager)) $mtm_staff_project_list->Pager = new cPrevNextPager($mtm_staff_project_list->StartRec, $mtm_staff_project_list->DisplayRecs, $mtm_staff_project_list->TotalRecs) ?>
<?php if ($mtm_staff_project_list->Pager->RecordCount > 0) { ?>
<div class="ewPager">
<span><?php echo $Language->Phrase("Page") ?>&nbsp;</span>
<div class="ewPrevNext"><div class="input-group">
<div class="input-group-btn">
<!--first page button-->
	<?php if ($mtm_staff_project_list->Pager->FirstButton->Enabled) { ?>
	<a class="btn btn-default btn-sm" title="<?php echo $Language->Phrase("PagerFirst") ?>" href="<?php echo $mtm_staff_project_list->PageUrl() ?>start=<?php echo $mtm_staff_project_list->Pager->FirstButton->Start ?>"><span class="icon-first ewIcon"></span></a>
	<?php } else { ?>
	<a class="btn btn-default btn-sm disabled" title="<?php echo $Language->Phrase("PagerFirst") ?>"><span class="icon-first ewIcon"></span></a>
	<?php } ?>
<!--previous page button-->
	<?php if ($mtm_staff_project_list->Pager->PrevButton->Enabled) { ?>
	<a class="btn btn-default btn-sm" title="<?php echo $Language->Phrase("PagerPrevious") ?>" href="<?php echo $mtm_staff_project_list->PageUrl() ?>start=<?php echo $mtm_staff_project_list->Pager->PrevButton->Start ?>"><span class="icon-prev ewIcon"></span></a>
	<?php } else { ?>
	<a class="btn btn-default btn-sm disabled" title="<?php echo $Language->Phrase("PagerPrevious") ?>"><span class="icon-prev ewIcon"></span></a>
	<?php } ?>
</div>
<!--current page number-->
	<input class="form-control input-sm" type="text" name="<?php echo EW_TABLE_PAGE_NO ?>" value="<?php echo $mtm_staff_project_list->Pager->CurrentPage ?>">
<div class="input-group-btn">
<!--next page button-->
	<?php if ($mtm_staff_project_list->Pager->NextButton->Enabled) { ?>
	<a class="btn btn-default btn-sm" title="<?php echo $Language->Phrase("PagerNext") ?>" href="<?php echo $mtm_staff_project_list->PageUrl() ?>start=<?php echo $mtm_staff_project_list->Pager->NextButton->Start ?>"><span class="icon-next ewIcon"></span></a>
	<?php } else { ?>
	<a class="btn btn-default btn-sm disabled" title="<?php echo $Language->Phrase("PagerNext") ?>"><span class="icon-next ewIcon"></span></a>
	<?php } ?>
<!--last page button-->
	<?php if ($mtm_staff_project_list->Pager->LastButton->Enabled) { ?>
	<a class="btn btn-default btn-sm" title="<?php echo $Language->Phrase("PagerLast") ?>" href="<?php echo $mtm_staff_project_list->PageUrl() ?>start=<?php echo $mtm_staff_project_list->Pager->LastButton->Start ?>"><span class="icon-last ewIcon"></span></a>
	<?php } else { ?>
	<a class="btn btn-default btn-sm disabled" title="<?php echo $Language->Phrase("PagerLast") ?>"><span class="icon-last ewIcon"></span></a>
	<?php } ?>
</div>
</div>
</div>
<span>&nbsp;<?php echo $Language->Phrase("of") ?>&nbsp;<?php echo $mtm_staff_project_list->Pager->PageCount ?></span>
</div>
<div class="ewPager ewRec">
	<span><?php echo $Language->Phrase("Record") ?>&nbsp;<?php echo $mtm_staff_project_list->Pager->FromIndex ?>&nbsp;<?php echo $Language->Phrase("To") ?>&nbsp;<?php echo $mtm_staff_project_list->Pager->ToIndex ?>&nbsp;<?php echo $Language->Phrase("Of") ?>&nbsp;<?php echo $mtm_staff_project_list->Pager->RecordCount ?></span>
</div>
<?php } ?>
<?php if ($mtm_staff_project_list->TotalRecs > 0) { ?>
<div class="ewPager">
<input type="hidden" name="t" value="mtm_staff_project">
<select name="<?php echo EW_TABLE_REC_PER_PAGE ?>" class="form-control input-sm" onchange="this.form.submit();">
<option value="20"<?php if ($mtm_staff_project_list->DisplayRecs == 20) { ?> selected<?php } ?>>20</option>
<option value="40"<?php if ($mtm_staff_project_list->DisplayRecs == 40) { ?> selected<?php } ?>>40</option>
<option value="50"<?php if ($mtm_staff_project_list->DisplayRecs == 50) { ?> selected<?php } ?>>50</option>
<option value="60"<?php if ($mtm_staff_project_list->DisplayRecs == 60) { ?> selected<?php } ?>>60</option>
<option value="80"<?php if ($mtm_staff_project_list->DisplayRecs == 80) { ?> selected<?php } ?>>80</option>
<option value="ALL"<?php if ($mtm_staff_project->getRecordsPerPage() == -1) { ?> selected<?php } ?>><?php echo $Language->Phrase("AllRecords") ?></option>
</select>
</div>
<?php } ?>
</form>
<?php } ?>
<div class="ewListOtherOptions">
<?php
	foreach ($mtm_staff_project_list->OtherOptions as &$option)
		$option->Render("body", "bottom");
?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div>
<?php } ?>
<?php if ($mtm_staff_project_list->TotalRecs == 0 && $mtm_staff_project->CurrentAction == "") { // Show other options ?>
<div class="ewListOtherOptions">
<?php
	foreach ($mtm_staff_project_list->OtherOptions as &$option) {
		$option->ButtonClass = "";
		$option->Render("body", "");
	}
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php if ($mtm_staff_project->Export == "") { ?>
<script type="text/javascript">
fmtm_staff_projectlistsrch.Init();
fmtm_staff_projectlistsrch.FilterList = <?php echo $mtm_staff_project_list->GetFilterList() ?>;
fmtm_staff_projectlist.Init();
</script>
<?php } ?>
<?php
$mtm_staff_project_list->ShowPageFooter();
if (EW_DEBUG_ENABLED)
	echo ew_DebugMsg();
?>
<?php if ($mtm_staff_project->Export == "") { ?>
<script type="text/javascript">

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php } ?>
<?php include_once "footer.php" ?>
<?php
$mtm_staff_project_list->Page_Terminate();
?>
