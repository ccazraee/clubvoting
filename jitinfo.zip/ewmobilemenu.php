<!-- Begin Main Menu -->
<?php

// Generate all menu items
$RootMenu->IsRoot = TRUE;
$RootMenu->AddMenuItem(26, "mmci_Staff_Related", $Language->MenuPhrase("26", "MenuText"), "", -1, "", TRUE, FALSE, TRUE);
$RootMenu->AddMenuItem(3, "mmi_staff", $Language->MenuPhrase("3", "MenuText"), "stafflist.php", 26, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}staff'), FALSE);
$RootMenu->AddMenuItem(8, "mmi_class", $Language->MenuPhrase("8", "MenuText"), "classlist.php", 26, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}class'), FALSE);
$RootMenu->AddMenuItem(18, "mmi_plannedleave", $Language->MenuPhrase("18", "MenuText"), "plannedleavelist.php", 26, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}plannedleave'), FALSE);
$RootMenu->AddMenuItem(15, "mmi_mtm_staff_class", $Language->MenuPhrase("15", "MenuText"), "mtm_staff_classlist.php?cmd=resetall", 26, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}mtm_staff_class'), FALSE);
$RootMenu->AddMenuItem(32, "mmci_Vendor_Related", $Language->MenuPhrase("32", "MenuText"), "", -1, "", TRUE, FALSE, TRUE);
$RootMenu->AddMenuItem(22, "mmi_vendor", $Language->MenuPhrase("22", "MenuText"), "vendorlist.php", 32, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}vendor'), FALSE);
$RootMenu->AddMenuItem(23, "mmi_vendoragreement", $Language->MenuPhrase("23", "MenuText"), "vendoragreementlist.php?cmd=resetall", 32, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}vendoragreement'), FALSE);
$RootMenu->AddMenuItem(24, "mmi_vendorassessment", $Language->MenuPhrase("24", "MenuText"), "vendorassessmentlist.php?cmd=resetall", 32, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}vendorassessment'), FALSE);
$RootMenu->AddMenuItem(25, "mmi_vendorvariation", $Language->MenuPhrase("25", "MenuText"), "vendorvariationlist.php?cmd=resetall", 32, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}vendorvariation'), FALSE);
$RootMenu->AddMenuItem(27, "mmci_TPEC_Related", $Language->MenuPhrase("27", "MenuText"), "", -1, "", TRUE, FALSE, TRUE);
$RootMenu->AddMenuItem(20, "mmi_tpec", $Language->MenuPhrase("20", "MenuText"), "tpeclist.php", 27, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}tpec'), FALSE);
$RootMenu->AddMenuItem(21, "mmi_tpecitems", $Language->MenuPhrase("21", "MenuText"), "tpecitemslist.php?cmd=resetall", 27, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}tpecitems'), FALSE);
$RootMenu->AddMenuItem(28, "mmci_Audit_Related", $Language->MenuPhrase("28", "MenuText"), "", -1, "", TRUE, FALSE, TRUE);
$RootMenu->AddMenuItem(4, "mmi_audit", $Language->MenuPhrase("4", "MenuText"), "auditlist.php", 28, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}audit'), FALSE);
$RootMenu->AddMenuItem(30, "mmci_Project_Related", $Language->MenuPhrase("30", "MenuText"), "", -1, "", TRUE, FALSE, TRUE);
$RootMenu->AddMenuItem(1, "mmi_project", $Language->MenuPhrase("1", "MenuText"), "projectlist.php", 30, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}project'), FALSE);
$RootMenu->AddMenuItem(2, "mmi_status", $Language->MenuPhrase("2", "MenuText"), "statuslist.php?cmd=resetall", 30, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}status'), FALSE);
$RootMenu->AddMenuItem(14, "mmi_milestones", $Language->MenuPhrase("14", "MenuText"), "milestoneslist.php?cmd=resetall", 30, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}milestones'), FALSE);
$RootMenu->AddMenuItem(6, "mmi_budget", $Language->MenuPhrase("6", "MenuText"), "budgetlist.php?cmd=resetall", 30, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}budget'), FALSE);
$RootMenu->AddMenuItem(10, "mmi_invoices", $Language->MenuPhrase("10", "MenuText"), "invoiceslist.php?cmd=resetall", 30, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}invoices'), FALSE);
$RootMenu->AddMenuItem(17, "mmi_mtm_staff_project", $Language->MenuPhrase("17", "MenuText"), "mtm_staff_projectlist.php?cmd=resetall", 30, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}mtm_staff_project'), FALSE);
$RootMenu->AddMenuItem(31, "mmci_Committee_Related", $Language->MenuPhrase("31", "MenuText"), "", -1, "", TRUE, FALSE, TRUE);
$RootMenu->AddMenuItem(9, "mmi_committee", $Language->MenuPhrase("9", "MenuText"), "committeelist.php", 31, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}committee'), FALSE);
$RootMenu->AddMenuItem(16, "mmi_mtm_staff_committee", $Language->MenuPhrase("16", "MenuText"), "mtm_staff_committeelist.php?cmd=resetall", 31, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}mtm_staff_committee'), FALSE);
$RootMenu->AddMenuItem(66, "mmci_Reports", $Language->MenuPhrase("66", "MenuText"), "", -1, "", TRUE, FALSE, TRUE);
$RootMenu->AddMenuItem(67, "mmci_Staff", $Language->MenuPhrase("67", "MenuText"), "", 66, "", TRUE, FALSE, TRUE);
$RootMenu->AddMenuItem(73, "mmi_Staff_Listing", $Language->MenuPhrase("73", "MenuText"), "Staff_Listingreport.php", 67, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}Staff Listing'), FALSE);
$RootMenu->AddMenuItem(76, "mmi_Staff_and_Class", $Language->MenuPhrase("76", "MenuText"), "Staff_and_Classreport.php", 67, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}Staff and Class'), FALSE);
$RootMenu->AddMenuItem(68, "mmci_Project", $Language->MenuPhrase("68", "MenuText"), "", 66, "", TRUE, FALSE, TRUE);
$RootMenu->AddMenuItem(83, "mmi_Project_Listing", $Language->MenuPhrase("83", "MenuText"), "Project_Listingreport.php", 68, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}Project Listing'), FALSE);
$RootMenu->AddMenuItem(69, "mmci_Committee", $Language->MenuPhrase("69", "MenuText"), "", 66, "", TRUE, FALSE, TRUE);
$RootMenu->AddMenuItem(70, "mmci_TPEC", $Language->MenuPhrase("70", "MenuText"), "", 66, "", TRUE, FALSE, TRUE);
$RootMenu->AddMenuItem(78, "mmi_TPEC_Listing", $Language->MenuPhrase("78", "MenuText"), "TPEC_Listingreport.php", 70, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}TPEC Listing'), FALSE);
$RootMenu->AddMenuItem(29, "mmci_DB_Admin", $Language->MenuPhrase("29", "MenuText"), "", -1, "", TRUE, FALSE, TRUE);
$RootMenu->AddMenuItem(11, "mmi_lkp_class_categories", $Language->MenuPhrase("11", "MenuText"), "lkp_class_categorieslist.php", 29, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}lkp_class_categories'), FALSE);
$RootMenu->AddMenuItem(12, "mmi_lkp_project_categories", $Language->MenuPhrase("12", "MenuText"), "lkp_project_categorieslist.php", 29, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}lkp_project_categories'), FALSE);
$RootMenu->AddMenuItem(13, "mmi_lkp_status_categories", $Language->MenuPhrase("13", "MenuText"), "lkp_status_categorieslist.php", 29, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}lkp_status_categories'), FALSE);
$RootMenu->AddMenuItem(7, "mmi_bugreport", $Language->MenuPhrase("7", "MenuText"), "bugreportlist.php", 29, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}bugreport'), FALSE);
$RootMenu->AddMenuItem(5, "mmi_audittrail", $Language->MenuPhrase("5", "MenuText"), "audittraillist.php", 29, "", AllowListMenu('{E654CCD7-163B-4B2E-BFA7-AC8697684A42}audittrail'), FALSE);
$RootMenu->AddMenuItem(80, "mmi_userlevels", $Language->MenuPhrase("80", "MenuText"), "userlevelslist.php", 29, "", (@$_SESSION[EW_SESSION_USER_LEVEL] & EW_ALLOW_ADMIN) == EW_ALLOW_ADMIN, FALSE);
$RootMenu->AddMenuItem(81, "mmi_userlevelpermissions", $Language->MenuPhrase("81", "MenuText"), "userlevelpermissionslist.php", 29, "", (@$_SESSION[EW_SESSION_USER_LEVEL] & EW_ALLOW_ADMIN) == EW_ALLOW_ADMIN, FALSE);
$RootMenu->AddMenuItem(-2, "mmi_changepwd", $Language->Phrase("ChangePwd"), "changepwd.php", -1, "", IsLoggedIn() && !IsSysAdmin());
$RootMenu->AddMenuItem(-1, "mmi_logout", $Language->Phrase("Logout"), "logout.php", -1, "", IsLoggedIn());
$RootMenu->AddMenuItem(-1, "mmi_login", $Language->Phrase("Login"), "login.php", -1, "", !IsLoggedIn() && substr(@$_SERVER["URL"], -1 * strlen("login.php")) <> "login.php");
$RootMenu->Render();
?>
<!-- End Main Menu -->
