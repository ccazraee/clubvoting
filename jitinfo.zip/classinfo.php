<?php

// Global variable for table object
$class = NULL;

//
// Table class for class
//
class cclass extends cTable {
	var $id;
	var $classname;
	var $StartDate;
	var $EndDate;
	var $allday;
	var $starttime;
	var $endtime;
	var $category;
	var $Venue;
	var $Organizer;
	var $Payment;
	var $Fees;
	var $notes;
	var $documents;

	//
	// Table class constructor
	//
	function __construct() {
		global $Language;

		// Language object
		if (!isset($Language)) $Language = new cLanguage();
		$this->TableVar = 'class';
		$this->TableName = 'class';
		$this->TableType = 'TABLE';

		// Update Table
		$this->UpdateTable = "`class`";
		$this->DBID = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = PHPExcel_Worksheet_PageSetup::ORIENTATION_DEFAULT; // Page orientation (PHPExcel only)
		$this->ExportExcelPageSize = PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4; // Page size (PHPExcel only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = FALSE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = ew_AllowAddDeleteRow(); // Allow add/delete row
		$this->UserIDAllowSecurity = 0; // User ID Allow
		$this->BasicSearch = new cBasicSearch($this->TableVar);
		$this->BasicSearch->TypeDefault = "OR";

		// id
		$this->id = new cField('class', 'class', 'x_id', 'id', '`id`', '`id`', 3, -1, FALSE, '`id`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'NO');
		$this->id->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['id'] = &$this->id;

		// classname
		$this->classname = new cField('class', 'class', 'x_classname', 'classname', '`classname`', '`classname`', 200, -1, FALSE, '`classname`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->fields['classname'] = &$this->classname;

		// StartDate
		$this->StartDate = new cField('class', 'class', 'x_StartDate', 'StartDate', '`StartDate`', 'DATE_FORMAT(`StartDate`, \'%d/%m/%Y\')', 133, 7, FALSE, '`StartDate`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->StartDate->FldDefaultErrMsg = str_replace("%s", "/", $Language->Phrase("IncorrectDateDMY"));
		$this->fields['StartDate'] = &$this->StartDate;

		// EndDate
		$this->EndDate = new cField('class', 'class', 'x_EndDate', 'EndDate', '`EndDate`', 'DATE_FORMAT(`EndDate`, \'%d/%m/%Y\')', 133, 7, FALSE, '`EndDate`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->EndDate->FldDefaultErrMsg = str_replace("%s", "/", $Language->Phrase("IncorrectDateDMY"));
		$this->fields['EndDate'] = &$this->EndDate;

		// allday
		$this->allday = new cField('class', 'class', 'x_allday', 'allday', '`allday`', '`allday`', 200, -1, FALSE, '`allday`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'CHECKBOX');
		$this->allday->OptionCount = 1;
		$this->fields['allday'] = &$this->allday;

		// starttime
		$this->starttime = new cField('class', 'class', 'x_starttime', 'starttime', '`starttime`', '`starttime`', 200, 4, FALSE, '`starttime`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->starttime->FldDefaultErrMsg = $Language->Phrase("IncorrectTime");
		$this->fields['starttime'] = &$this->starttime;

		// endtime
		$this->endtime = new cField('class', 'class', 'x_endtime', 'endtime', '`endtime`', 'DATE_FORMAT(`endtime`, \'%d/%m/%Y\')', 134, 7, FALSE, '`endtime`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->endtime->FldDefaultErrMsg = $Language->Phrase("IncorrectTime");
		$this->fields['endtime'] = &$this->endtime;

		// category
		$this->category = new cField('class', 'class', 'x_category', 'category', '`category`', '`category`', 3, -1, FALSE, '`category`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->category->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['category'] = &$this->category;

		// Venue
		$this->Venue = new cField('class', 'class', 'x_Venue', 'Venue', '`Venue`', '`Venue`', 200, -1, FALSE, '`Venue`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->fields['Venue'] = &$this->Venue;

		// Organizer
		$this->Organizer = new cField('class', 'class', 'x_Organizer', 'Organizer', '`Organizer`', '`Organizer`', 200, -1, FALSE, '`Organizer`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->fields['Organizer'] = &$this->Organizer;

		// Payment
		$this->Payment = new cField('class', 'class', 'x_Payment', 'Payment', '`Payment`', '`Payment`', 200, -1, FALSE, '`Payment`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'RADIO');
		$this->Payment->OptionCount = 2;
		$this->fields['Payment'] = &$this->Payment;

		// Fees
		$this->Fees = new cField('class', 'class', 'x_Fees', 'Fees', '`Fees`', '`Fees`', 131, -1, FALSE, '`Fees`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->Fees->FldDefaultErrMsg = $Language->Phrase("IncorrectFloat");
		$this->fields['Fees'] = &$this->Fees;

		// notes
		$this->notes = new cField('class', 'class', 'x_notes', 'notes', '`notes`', '`notes`', 201, -1, FALSE, '`notes`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->fields['notes'] = &$this->notes;

		// documents
		$this->documents = new cField('class', 'class', 'x_documents', 'documents', '`documents`', '`documents`', 200, -1, TRUE, '`documents`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'FILE');
		$this->documents->UploadMultiple = TRUE;
		$this->documents->Upload->UploadMultiple = TRUE;
		$this->fields['documents'] = &$this->documents;
	}

	// Multiple column sort
	function UpdateSort(&$ofld, $ctrl) {
		if ($this->CurrentOrder == $ofld->FldName) {
			$sSortField = $ofld->FldExpression;
			$sLastSort = $ofld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$sThisSort = $this->CurrentOrderType;
			} else {
				$sThisSort = ($sLastSort == "ASC") ? "DESC" : "ASC";
			}
			$ofld->setSort($sThisSort);
			if ($ctrl) {
				$sOrderBy = $this->getSessionOrderBy();
				if (strpos($sOrderBy, $sSortField . " " . $sLastSort) !== FALSE) {
					$sOrderBy = str_replace($sSortField . " " . $sLastSort, $sSortField . " " . $sThisSort, $sOrderBy);
				} else {
					if ($sOrderBy <> "") $sOrderBy .= ", ";
					$sOrderBy .= $sSortField . " " . $sThisSort;
				}
				$this->setSessionOrderBy($sOrderBy); // Save to Session
			} else {
				$this->setSessionOrderBy($sSortField . " " . $sThisSort); // Save to Session
			}
		} else {
			if (!$ctrl) $ofld->setSort("");
		}
	}

	// Current detail table name
	function getCurrentDetailTable() {
		return @$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_DETAIL_TABLE];
	}

	function setCurrentDetailTable($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_DETAIL_TABLE] = $v;
	}

	// Get detail url
	function GetDetailUrl() {

		// Detail url
		$sDetailUrl = "";
		if ($this->getCurrentDetailTable() == "mtm_staff_class") {
			$sDetailUrl = $GLOBALS["mtm_staff_class"]->GetListUrl() . "?" . EW_TABLE_SHOW_MASTER . "=" . $this->TableVar;
			$sDetailUrl .= "&fk_id=" . urlencode($this->id->CurrentValue);
		}
		if ($sDetailUrl == "") {
			$sDetailUrl = "classlist.php";
		}
		return $sDetailUrl;
	}

	// Table level SQL
	var $_SqlFrom = "";

	function getSqlFrom() { // From
		return ($this->_SqlFrom <> "") ? $this->_SqlFrom : "`class`";
	}

	function SqlFrom() { // For backward compatibility
    	return $this->getSqlFrom();
	}

	function setSqlFrom($v) {
    	$this->_SqlFrom = $v;
	}
	var $_SqlSelect = "";

	function getSqlSelect() { // Select
		return ($this->_SqlSelect <> "") ? $this->_SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}

	function SqlSelect() { // For backward compatibility
    	return $this->getSqlSelect();
	}

	function setSqlSelect($v) {
    	$this->_SqlSelect = $v;
	}
	var $_SqlWhere = "";

	function getSqlWhere() { // Where
		$sWhere = ($this->_SqlWhere <> "") ? $this->_SqlWhere : "";
		$this->TableFilter = "";
		ew_AddFilter($sWhere, $this->TableFilter);
		return $sWhere;
	}

	function SqlWhere() { // For backward compatibility
    	return $this->getSqlWhere();
	}

	function setSqlWhere($v) {
    	$this->_SqlWhere = $v;
	}
	var $_SqlGroupBy = "";

	function getSqlGroupBy() { // Group By
		return ($this->_SqlGroupBy <> "") ? $this->_SqlGroupBy : "";
	}

	function SqlGroupBy() { // For backward compatibility
    	return $this->getSqlGroupBy();
	}

	function setSqlGroupBy($v) {
    	$this->_SqlGroupBy = $v;
	}
	var $_SqlHaving = "";

	function getSqlHaving() { // Having
		return ($this->_SqlHaving <> "") ? $this->_SqlHaving : "";
	}

	function SqlHaving() { // For backward compatibility
    	return $this->getSqlHaving();
	}

	function setSqlHaving($v) {
    	$this->_SqlHaving = $v;
	}
	var $_SqlOrderBy = "";

	function getSqlOrderBy() { // Order By
		return ($this->_SqlOrderBy <> "") ? $this->_SqlOrderBy : "";
	}

	function SqlOrderBy() { // For backward compatibility
    	return $this->getSqlOrderBy();
	}

	function setSqlOrderBy($v) {
    	$this->_SqlOrderBy = $v;
	}

	// Apply User ID filters
	function ApplyUserIDFilters($sFilter) {
		return $sFilter;
	}

	// Check if User ID security allows view all
	function UserIDAllow($id = "") {
		$allow = EW_USER_ID_ALLOW;
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get SQL
	function GetSQL($where, $orderby) {
		return ew_BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderby);
	}

	// Table SQL
	function SQL() {
		$sFilter = $this->CurrentFilter;
		$sFilter = $this->ApplyUserIDFilters($sFilter);
		$sSort = $this->getSessionOrderBy();
		return ew_BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$sFilter, $sSort);
	}

	// Table SQL with List page filter
	function SelectSQL() {
		$sFilter = $this->getSessionWhere();
		ew_AddFilter($sFilter, $this->CurrentFilter);
		$sFilter = $this->ApplyUserIDFilters($sFilter);
		$this->Recordset_Selecting($sFilter);
		$sSort = $this->getSessionOrderBy();
		return ew_BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $sFilter, $sSort);
	}

	// Get ORDER BY clause
	function GetOrderBy() {
		$sSort = $this->getSessionOrderBy();
		return ew_BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sSort);
	}

	// Try to get record count
	function TryGetRecordCount($sSql) {
		$cnt = -1;
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') && preg_match("/^SELECT \* FROM/i", $sSql)) {
			$sSql = "SELECT COUNT(*) FROM" . preg_replace('/^SELECT\s([\s\S]+)?\*\sFROM/i', "", $sSql);
			$sOrderBy = $this->GetOrderBy();
			if (substr($sSql, strlen($sOrderBy) * -1) == $sOrderBy)
				$sSql = substr($sSql, 0, strlen($sSql) - strlen($sOrderBy)); // Remove ORDER BY clause
		} else {
			$sSql = "SELECT COUNT(*) FROM (" . $sSql . ") EW_COUNT_TABLE";
		}
		$conn = &$this->Connection();
		if ($rs = $conn->Execute($sSql)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->Close();
			}
		}
		return intval($cnt);
	}

	// Get record count based on filter (for detail record count in master table pages)
	function LoadRecordCount($sFilter) {
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $sFilter;
		$this->Recordset_Selecting($this->CurrentFilter);

		//$sSql = $this->SQL();
		$sSql = $this->GetSQL($this->CurrentFilter, "");
		$cnt = $this->TryGetRecordCount($sSql);
		if ($cnt == -1) {
			if ($rs = $this->LoadRs($this->CurrentFilter)) {
				$cnt = $rs->RecordCount();
				$rs->Close();
			}
		}
		$this->CurrentFilter = $origFilter;
		return intval($cnt);
	}

	// Get record count (for current List page)
	function SelectRecordCount() {
		$sSql = $this->SelectSQL();
		$cnt = $this->TryGetRecordCount($sSql);
		if ($cnt == -1) {
			$conn = &$this->Connection();
			if ($rs = $conn->Execute($sSql)) {
				$cnt = $rs->RecordCount();
				$rs->Close();
			}
		}
		return intval($cnt);
	}

	// INSERT statement
	function InsertSQL(&$rs) {
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->FldIsCustom)
				continue;
			$names .= $this->fields[$name]->FldExpression . ",";
			$values .= ew_QuotedValue($value, $this->fields[$name]->FldDataType, $this->DBID) . ",";
		}
		while (substr($names, -1) == ",")
			$names = substr($names, 0, -1);
		while (substr($values, -1) == ",")
			$values = substr($values, 0, -1);
		return "INSERT INTO " . $this->UpdateTable . " ($names) VALUES ($values)";
	}

	// Insert
	function Insert(&$rs) {
		$conn = &$this->Connection();
		return $conn->Execute($this->InsertSQL($rs));
	}

	// UPDATE statement
	function UpdateSQL(&$rs, $where = "", $curfilter = TRUE) {
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->FldIsCustom)
				continue;
			$sql .= $this->fields[$name]->FldExpression . "=";
			$sql .= ew_QuotedValue($value, $this->fields[$name]->FldDataType, $this->DBID) . ",";
		}
		while (substr($sql, -1) == ",")
			$sql = substr($sql, 0, -1);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->ArrayToFilter($where);
		ew_AddFilter($filter, $where);
		if ($filter <> "")	$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	function Update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE) {
		$conn = &$this->Connection();

		// Cascade Update detail table 'mtm_staff_class'
		$bCascadeUpdate = FALSE;
		$rscascade = array();
		if (!is_null($rsold) && (isset($rs['id']) && $rsold['id'] <> $rs['id'])) { // Update detail field 'classID'
			$bCascadeUpdate = TRUE;
			$rscascade['classID'] = $rs['id']; 
		}
		if ($bCascadeUpdate) {
			if (!isset($GLOBALS["mtm_staff_class"])) $GLOBALS["mtm_staff_class"] = new cmtm_staff_class();
			$rswrk = $GLOBALS["mtm_staff_class"]->LoadRs("`classID` = " . ew_QuotedValue($rsold['id'], EW_DATATYPE_NUMBER, 'DB')); 
			while ($rswrk && !$rswrk->EOF) {
				$GLOBALS["mtm_staff_class"]->Update($rscascade, "`classID` = " . ew_QuotedValue($rsold['id'], EW_DATATYPE_NUMBER, 'DB'), $rswrk->fields);
				$rswrk->MoveNext();
			}
		}
		return $conn->Execute($this->UpdateSQL($rs, $where, $curfilter));
	}

	// DELETE statement
	function DeleteSQL(&$rs, $where = "", $curfilter = TRUE) {
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->ArrayToFilter($where);
		if ($rs) {
			if (array_key_exists('id', $rs))
				ew_AddFilter($where, ew_QuotedName('id', $this->DBID) . '=' . ew_QuotedValue($rs['id'], $this->id->FldDataType, $this->DBID));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		ew_AddFilter($filter, $where);
		if ($filter <> "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	function Delete(&$rs, $where = "", $curfilter = TRUE) {
		$conn = &$this->Connection();

		// Cascade delete detail table 'mtm_staff_class'
		if (!isset($GLOBALS["mtm_staff_class"])) $GLOBALS["mtm_staff_class"] = new cmtm_staff_class();
		$rscascade = $GLOBALS["mtm_staff_class"]->LoadRs("`classID` = " . ew_QuotedValue($rs['id'], EW_DATATYPE_NUMBER, "DB")); 
		while ($rscascade && !$rscascade->EOF) {
			$GLOBALS["mtm_staff_class"]->Delete($rscascade->fields);
			$rscascade->MoveNext();
		}
		return $conn->Execute($this->DeleteSQL($rs, $where, $curfilter));
	}

	// Key filter WHERE clause
	function SqlKeyFilter() {
		return "`id` = @id@";
	}

	// Key filter
	function KeyFilter() {
		$sKeyFilter = $this->SqlKeyFilter();
		if (!is_numeric($this->id->CurrentValue))
			$sKeyFilter = "0=1"; // Invalid key
		$sKeyFilter = str_replace("@id@", ew_AdjustSql($this->id->CurrentValue, $this->DBID), $sKeyFilter); // Replace key value
		return $sKeyFilter;
	}

	// Return page URL
	function getReturnUrl() {
		$name = EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_RETURN_URL;

		// Get referer URL automatically
		if (ew_ServerVar("HTTP_REFERER") <> "" && ew_ReferPage() <> ew_CurrentPage() && ew_ReferPage() <> "login.php") // Referer not same page or login page
			$_SESSION[$name] = ew_ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] <> "") {
			return $_SESSION[$name];
		} else {
			return "classlist.php";
		}
	}

	function setReturnUrl($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_RETURN_URL] = $v;
	}

	// List URL
	function GetListUrl() {
		return "classlist.php";
	}

	// View URL
	function GetViewUrl($parm = "") {
		if ($parm <> "")
			$url = $this->KeyUrl("classview.php", $this->UrlParm($parm));
		else
			$url = $this->KeyUrl("classview.php", $this->UrlParm(EW_TABLE_SHOW_DETAIL . "="));
		return $this->AddMasterUrl($url);
	}

	// Add URL
	function GetAddUrl($parm = "") {
		if ($parm <> "")
			$url = "classadd.php?" . $this->UrlParm($parm);
		else
			$url = "classadd.php";
		return $this->AddMasterUrl($url);
	}

	// Edit URL
	function GetEditUrl($parm = "") {
		if ($parm <> "")
			$url = $this->KeyUrl("classedit.php", $this->UrlParm($parm));
		else
			$url = $this->KeyUrl("classedit.php", $this->UrlParm(EW_TABLE_SHOW_DETAIL . "="));
		return $this->AddMasterUrl($url);
	}

	// Inline edit URL
	function GetInlineEditUrl() {
		$url = $this->KeyUrl(ew_CurrentPage(), $this->UrlParm("a=edit"));
		return $this->AddMasterUrl($url);
	}

	// Copy URL
	function GetCopyUrl($parm = "") {
		if ($parm <> "")
			$url = $this->KeyUrl("classadd.php", $this->UrlParm($parm));
		else
			$url = $this->KeyUrl("classadd.php", $this->UrlParm(EW_TABLE_SHOW_DETAIL . "="));
		return $this->AddMasterUrl($url);
	}

	// Inline copy URL
	function GetInlineCopyUrl() {
		$url = $this->KeyUrl(ew_CurrentPage(), $this->UrlParm("a=copy"));
		return $this->AddMasterUrl($url);
	}

	// Delete URL
	function GetDeleteUrl() {
		return $this->KeyUrl("classdelete.php", $this->UrlParm());
	}

	// Add master url
	function AddMasterUrl($url) {
		return $url;
	}

	function KeyToJson() {
		$json = "";
		$json .= "id:" . ew_VarToJson($this->id->CurrentValue, "number", "'");
		return "{" . $json . "}";
	}

	// Add key value to URL
	function KeyUrl($url, $parm = "") {
		$sUrl = $url . "?";
		if ($parm <> "") $sUrl .= $parm . "&";
		if (!is_null($this->id->CurrentValue)) {
			$sUrl .= "id=" . urlencode($this->id->CurrentValue);
		} else {
			return "javascript:ew_Alert(ewLanguage.Phrase('InvalidRecord'));";
		}
		return $sUrl;
	}

	// Sort URL
	function SortUrl(&$fld) {
		if ($this->CurrentAction <> "" || $this->Export <> "" ||
			in_array($fld->FldType, array(128, 204, 205))) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$sUrlParm = $this->UrlParm("order=" . urlencode($fld->FldName) . "&amp;ordertype=" . $fld->ReverseSort());
			return ew_CurrentPage() . "?" . $sUrlParm;
		} else {
			return "";
		}
	}

	// Get record keys from $_POST/$_GET/$_SESSION
	function GetRecordKeys() {
		global $EW_COMPOSITE_KEY_SEPARATOR;
		$arKeys = array();
		$arKey = array();
		if (isset($_POST["key_m"])) {
			$arKeys = ew_StripSlashes($_POST["key_m"]);
			$cnt = count($arKeys);
		} elseif (isset($_GET["key_m"])) {
			$arKeys = ew_StripSlashes($_GET["key_m"]);
			$cnt = count($arKeys);
		} elseif (!empty($_GET) || !empty($_POST)) {
			$isPost = ew_IsHttpPost();
			if ($isPost && isset($_POST["id"]))
				$arKeys[] = ew_StripSlashes($_POST["id"]);
			elseif (isset($_GET["id"]))
				$arKeys[] = ew_StripSlashes($_GET["id"]);
			else
				$arKeys = NULL; // Do not setup

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = array();
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				if (!is_numeric($key))
					continue;
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get key filter
	function GetKeyFilter() {
		$arKeys = $this->GetRecordKeys();
		$sKeyFilter = "";
		foreach ($arKeys as $key) {
			if ($sKeyFilter <> "") $sKeyFilter .= " OR ";
			$this->id->CurrentValue = $key;
			$sKeyFilter .= "(" . $this->KeyFilter() . ")";
		}
		return $sKeyFilter;
	}

	// Load rows based on filter
	function &LoadRs($sFilter) {

		// Set up filter (SQL WHERE clause) and get return SQL
		//$this->CurrentFilter = $sFilter;
		//$sSql = $this->SQL();

		$sSql = $this->GetSQL($sFilter, "");
		$conn = &$this->Connection();
		$rs = $conn->Execute($sSql);
		return $rs;
	}

	// Load row values from recordset
	function LoadListRowValues(&$rs) {
		$this->id->setDbValue($rs->fields('id'));
		$this->classname->setDbValue($rs->fields('classname'));
		$this->StartDate->setDbValue($rs->fields('StartDate'));
		$this->EndDate->setDbValue($rs->fields('EndDate'));
		$this->allday->setDbValue($rs->fields('allday'));
		$this->starttime->setDbValue($rs->fields('starttime'));
		$this->endtime->setDbValue($rs->fields('endtime'));
		$this->category->setDbValue($rs->fields('category'));
		$this->Venue->setDbValue($rs->fields('Venue'));
		$this->Organizer->setDbValue($rs->fields('Organizer'));
		$this->Payment->setDbValue($rs->fields('Payment'));
		$this->Fees->setDbValue($rs->fields('Fees'));
		$this->notes->setDbValue($rs->fields('notes'));
		$this->documents->Upload->DbValue = $rs->fields('documents');
	}

	// Render list row values
	function RenderListRow() {
		global $Security, $gsLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

   // Common render codes
		// id
		// classname
		// StartDate
		// EndDate
		// allday
		// starttime
		// endtime
		// category
		// Venue
		// Organizer
		// Payment
		// Fees
		// notes
		// documents
		// id

		$this->id->ViewValue = $this->id->CurrentValue;
		$this->id->ViewCustomAttributes = "";

		// classname
		$this->classname->ViewValue = $this->classname->CurrentValue;
		$this->classname->ViewCustomAttributes = "";

		// StartDate
		$this->StartDate->ViewValue = $this->StartDate->CurrentValue;
		$this->StartDate->ViewValue = ew_FormatDateTime($this->StartDate->ViewValue, 7);
		$this->StartDate->ViewCustomAttributes = "";

		// EndDate
		$this->EndDate->ViewValue = $this->EndDate->CurrentValue;
		$this->EndDate->ViewValue = ew_FormatDateTime($this->EndDate->ViewValue, 7);
		$this->EndDate->ViewCustomAttributes = "";

		// allday
		if (strval($this->allday->CurrentValue) <> "") {
			$this->allday->ViewValue = "";
			$arwrk = explode(",", strval($this->allday->CurrentValue));
			$cnt = count($arwrk);
			for ($ari = 0; $ari < $cnt; $ari++) {
				$this->allday->ViewValue .= $this->allday->OptionCaption(trim($arwrk[$ari]));
				if ($ari < $cnt-1) $this->allday->ViewValue .= ew_ViewOptionSeparator($ari);
			}
		} else {
			$this->allday->ViewValue = NULL;
		}
		$this->allday->ViewCustomAttributes = "";

		// starttime
		$this->starttime->ViewValue = $this->starttime->CurrentValue;
		$this->starttime->ViewValue = ew_FormatDateTime($this->starttime->ViewValue, 4);
		$this->starttime->ViewCustomAttributes = "";

		// endtime
		$this->endtime->ViewValue = $this->endtime->CurrentValue;
		$this->endtime->ViewValue = ew_FormatDateTime($this->endtime->ViewValue, 7);
		$this->endtime->ViewCustomAttributes = "";

		// category
		if (strval($this->category->CurrentValue) <> "") {
			$sFilterWrk = "`id`" . ew_SearchString("=", $this->category->CurrentValue, EW_DATATYPE_NUMBER, "");
		$sSqlWrk = "SELECT `id`, `ClassCategories` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `lkp_class_categories`";
		$sWhereWrk = "";
		ew_AddFilter($sWhereWrk, $sFilterWrk);
		$this->Lookup_Selecting($this->category, $sWhereWrk); // Call Lookup selecting
		if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
			$rswrk = Conn()->Execute($sSqlWrk);
			if ($rswrk && !$rswrk->EOF) { // Lookup values found
				$arwrk = array();
				$arwrk[1] = $rswrk->fields('DispFld');
				$this->category->ViewValue = $this->category->DisplayValue($arwrk);
				$rswrk->Close();
			} else {
				$this->category->ViewValue = $this->category->CurrentValue;
			}
		} else {
			$this->category->ViewValue = NULL;
		}
		$this->category->ViewCustomAttributes = "";

		// Venue
		$this->Venue->ViewValue = $this->Venue->CurrentValue;
		$this->Venue->ViewCustomAttributes = "";

		// Organizer
		$this->Organizer->ViewValue = $this->Organizer->CurrentValue;
		$this->Organizer->ViewCustomAttributes = "";

		// Payment
		if (strval($this->Payment->CurrentValue) <> "") {
			$this->Payment->ViewValue = $this->Payment->OptionCaption($this->Payment->CurrentValue);
		} else {
			$this->Payment->ViewValue = NULL;
		}
		$this->Payment->ViewCustomAttributes = "";

		// Fees
		$this->Fees->ViewValue = $this->Fees->CurrentValue;
		$this->Fees->ViewValue = ew_FormatCurrency($this->Fees->ViewValue, 0, -2, -2, -2);
		$this->Fees->ViewCustomAttributes = "";

		// notes
		$this->notes->ViewValue = $this->notes->CurrentValue;
		$this->notes->ViewCustomAttributes = "";

		// documents
		$this->documents->UploadPath = "uploads/trainingdocuments";
		if (!ew_Empty($this->documents->Upload->DbValue)) {
			$this->documents->ViewValue = $this->documents->Upload->DbValue;
		} else {
			$this->documents->ViewValue = "";
		}
		$this->documents->ViewCustomAttributes = "";

		// id
		$this->id->LinkCustomAttributes = "";
		$this->id->HrefValue = "";
		$this->id->TooltipValue = "";

		// classname
		$this->classname->LinkCustomAttributes = "";
		$this->classname->HrefValue = "";
		$this->classname->TooltipValue = "";

		// StartDate
		$this->StartDate->LinkCustomAttributes = "";
		$this->StartDate->HrefValue = "";
		$this->StartDate->TooltipValue = "";

		// EndDate
		$this->EndDate->LinkCustomAttributes = "";
		$this->EndDate->HrefValue = "";
		$this->EndDate->TooltipValue = "";

		// allday
		$this->allday->LinkCustomAttributes = "";
		$this->allday->HrefValue = "";
		$this->allday->TooltipValue = "";

		// starttime
		$this->starttime->LinkCustomAttributes = "";
		$this->starttime->HrefValue = "";
		$this->starttime->TooltipValue = "";

		// endtime
		$this->endtime->LinkCustomAttributes = "";
		$this->endtime->HrefValue = "";
		$this->endtime->TooltipValue = "";

		// category
		$this->category->LinkCustomAttributes = "";
		$this->category->HrefValue = "";
		$this->category->TooltipValue = "";

		// Venue
		$this->Venue->LinkCustomAttributes = "";
		$this->Venue->HrefValue = "";
		$this->Venue->TooltipValue = "";

		// Organizer
		$this->Organizer->LinkCustomAttributes = "";
		$this->Organizer->HrefValue = "";
		$this->Organizer->TooltipValue = "";

		// Payment
		$this->Payment->LinkCustomAttributes = "";
		$this->Payment->HrefValue = "";
		$this->Payment->TooltipValue = "";

		// Fees
		$this->Fees->LinkCustomAttributes = "";
		$this->Fees->HrefValue = "";
		$this->Fees->TooltipValue = "";

		// notes
		$this->notes->LinkCustomAttributes = "";
		$this->notes->HrefValue = "";
		$this->notes->TooltipValue = "";

		// documents
		$this->documents->LinkCustomAttributes = "";
		$this->documents->HrefValue = "";
		$this->documents->HrefValue2 = $this->documents->UploadPath . $this->documents->Upload->DbValue;
		$this->documents->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Render edit row values
	function RenderEditRow() {
		global $Security, $gsLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// id
		$this->id->EditAttrs["class"] = "form-control";
		$this->id->EditCustomAttributes = "";
		$this->id->EditValue = $this->id->CurrentValue;
		$this->id->ViewCustomAttributes = "";

		// classname
		$this->classname->EditAttrs["class"] = "form-control";
		$this->classname->EditCustomAttributes = "";
		$this->classname->EditValue = $this->classname->CurrentValue;
		$this->classname->PlaceHolder = ew_RemoveHtml($this->classname->FldCaption());

		// StartDate
		$this->StartDate->EditAttrs["class"] = "form-control";
		$this->StartDate->EditCustomAttributes = "";
		$this->StartDate->EditValue = ew_FormatDateTime($this->StartDate->CurrentValue, 7);
		$this->StartDate->PlaceHolder = ew_RemoveHtml($this->StartDate->FldCaption());

		// EndDate
		$this->EndDate->EditAttrs["class"] = "form-control";
		$this->EndDate->EditCustomAttributes = "";
		$this->EndDate->EditValue = ew_FormatDateTime($this->EndDate->CurrentValue, 7);
		$this->EndDate->PlaceHolder = ew_RemoveHtml($this->EndDate->FldCaption());

		// allday
		$this->allday->EditCustomAttributes = "";
		$this->allday->EditValue = $this->allday->Options(FALSE);

		// starttime
		$this->starttime->EditAttrs["class"] = "form-control";
		$this->starttime->EditCustomAttributes = "";
		$this->starttime->EditValue = $this->starttime->CurrentValue;
		$this->starttime->PlaceHolder = ew_RemoveHtml($this->starttime->FldCaption());

		// endtime
		$this->endtime->EditAttrs["class"] = "form-control";
		$this->endtime->EditCustomAttributes = "";
		$this->endtime->EditValue = $this->endtime->CurrentValue;
		$this->endtime->PlaceHolder = ew_RemoveHtml($this->endtime->FldCaption());

		// category
		$this->category->EditAttrs["class"] = "form-control";
		$this->category->EditCustomAttributes = "";

		// Venue
		$this->Venue->EditAttrs["class"] = "form-control";
		$this->Venue->EditCustomAttributes = "";
		$this->Venue->EditValue = $this->Venue->CurrentValue;
		$this->Venue->PlaceHolder = ew_RemoveHtml($this->Venue->FldCaption());

		// Organizer
		$this->Organizer->EditAttrs["class"] = "form-control";
		$this->Organizer->EditCustomAttributes = "";
		$this->Organizer->EditValue = $this->Organizer->CurrentValue;
		$this->Organizer->PlaceHolder = ew_RemoveHtml($this->Organizer->FldCaption());

		// Payment
		$this->Payment->EditCustomAttributes = "";
		$this->Payment->EditValue = $this->Payment->Options(FALSE);

		// Fees
		$this->Fees->EditAttrs["class"] = "form-control";
		$this->Fees->EditCustomAttributes = "";
		$this->Fees->EditValue = $this->Fees->CurrentValue;
		$this->Fees->PlaceHolder = ew_RemoveHtml($this->Fees->FldCaption());
		if (strval($this->Fees->EditValue) <> "" && is_numeric($this->Fees->EditValue)) $this->Fees->EditValue = ew_FormatNumber($this->Fees->EditValue, 0, -2, -2, -2);

		// notes
		$this->notes->EditAttrs["class"] = "form-control";
		$this->notes->EditCustomAttributes = "";
		$this->notes->EditValue = $this->notes->CurrentValue;
		$this->notes->PlaceHolder = ew_RemoveHtml($this->notes->FldCaption());

		// documents
		$this->documents->EditAttrs["class"] = "form-control";
		$this->documents->EditCustomAttributes = "";
		$this->documents->UploadPath = "uploads/trainingdocuments";
		if (!ew_Empty($this->documents->Upload->DbValue)) {
			$this->documents->EditValue = $this->documents->Upload->DbValue;
		} else {
			$this->documents->EditValue = "";
		}
		if (!ew_Empty($this->documents->CurrentValue))
			$this->documents->Upload->FileName = $this->documents->CurrentValue;

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	function AggregateListRowValues() {
	}

	// Aggregate list row (for rendering)
	function AggregateListRow() {

		// Call Row Rendered event
		$this->Row_Rendered();
	}
	var $ExportDoc;

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	function ExportDocument(&$Doc, &$Recordset, $StartRec, $StopRec, $ExportPageType = "") {
		if (!$Recordset || !$Doc)
			return;
		if (!$Doc->ExportCustom) {

			// Write header
			$Doc->ExportTableHeader();
			if ($Doc->Horizontal) { // Horizontal format, write header
				$Doc->BeginExportRow();
				if ($ExportPageType == "view") {
					if ($this->id->Exportable) $Doc->ExportCaption($this->id);
					if ($this->classname->Exportable) $Doc->ExportCaption($this->classname);
					if ($this->StartDate->Exportable) $Doc->ExportCaption($this->StartDate);
					if ($this->EndDate->Exportable) $Doc->ExportCaption($this->EndDate);
					if ($this->allday->Exportable) $Doc->ExportCaption($this->allday);
					if ($this->starttime->Exportable) $Doc->ExportCaption($this->starttime);
					if ($this->endtime->Exportable) $Doc->ExportCaption($this->endtime);
					if ($this->category->Exportable) $Doc->ExportCaption($this->category);
					if ($this->Venue->Exportable) $Doc->ExportCaption($this->Venue);
					if ($this->Organizer->Exportable) $Doc->ExportCaption($this->Organizer);
					if ($this->Payment->Exportable) $Doc->ExportCaption($this->Payment);
					if ($this->Fees->Exportable) $Doc->ExportCaption($this->Fees);
					if ($this->notes->Exportable) $Doc->ExportCaption($this->notes);
					if ($this->documents->Exportable) $Doc->ExportCaption($this->documents);
				} else {
					if ($this->id->Exportable) $Doc->ExportCaption($this->id);
					if ($this->classname->Exportable) $Doc->ExportCaption($this->classname);
					if ($this->StartDate->Exportable) $Doc->ExportCaption($this->StartDate);
					if ($this->EndDate->Exportable) $Doc->ExportCaption($this->EndDate);
					if ($this->allday->Exportable) $Doc->ExportCaption($this->allday);
					if ($this->starttime->Exportable) $Doc->ExportCaption($this->starttime);
					if ($this->endtime->Exportable) $Doc->ExportCaption($this->endtime);
					if ($this->category->Exportable) $Doc->ExportCaption($this->category);
					if ($this->Venue->Exportable) $Doc->ExportCaption($this->Venue);
					if ($this->Organizer->Exportable) $Doc->ExportCaption($this->Organizer);
					if ($this->Payment->Exportable) $Doc->ExportCaption($this->Payment);
					if ($this->Fees->Exportable) $Doc->ExportCaption($this->Fees);
					if ($this->documents->Exportable) $Doc->ExportCaption($this->documents);
				}
				$Doc->EndExportRow();
			}
		}

		// Move to first record
		$RecCnt = $StartRec - 1;
		if (!$Recordset->EOF) {
			$Recordset->MoveFirst();
			if ($StartRec > 1)
				$Recordset->Move($StartRec - 1);
		}
		while (!$Recordset->EOF && $RecCnt < $StopRec) {
			$RecCnt++;
			if (intval($RecCnt) >= intval($StartRec)) {
				$RowCnt = intval($RecCnt) - intval($StartRec) + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($RowCnt > 1 && ($RowCnt - 1) % $this->ExportPageBreakCount == 0)
						$Doc->ExportPageBreak();
				}
				$this->LoadListRowValues($Recordset);

				// Render row
				$this->RowType = EW_ROWTYPE_VIEW; // Render view
				$this->ResetAttrs();
				$this->RenderListRow();
				if (!$Doc->ExportCustom) {
					$Doc->BeginExportRow($RowCnt); // Allow CSS styles if enabled
					if ($ExportPageType == "view") {
						if ($this->id->Exportable) $Doc->ExportField($this->id);
						if ($this->classname->Exportable) $Doc->ExportField($this->classname);
						if ($this->StartDate->Exportable) $Doc->ExportField($this->StartDate);
						if ($this->EndDate->Exportable) $Doc->ExportField($this->EndDate);
						if ($this->allday->Exportable) $Doc->ExportField($this->allday);
						if ($this->starttime->Exportable) $Doc->ExportField($this->starttime);
						if ($this->endtime->Exportable) $Doc->ExportField($this->endtime);
						if ($this->category->Exportable) $Doc->ExportField($this->category);
						if ($this->Venue->Exportable) $Doc->ExportField($this->Venue);
						if ($this->Organizer->Exportable) $Doc->ExportField($this->Organizer);
						if ($this->Payment->Exportable) $Doc->ExportField($this->Payment);
						if ($this->Fees->Exportable) $Doc->ExportField($this->Fees);
						if ($this->notes->Exportable) $Doc->ExportField($this->notes);
						if ($this->documents->Exportable) $Doc->ExportField($this->documents);
					} else {
						if ($this->id->Exportable) $Doc->ExportField($this->id);
						if ($this->classname->Exportable) $Doc->ExportField($this->classname);
						if ($this->StartDate->Exportable) $Doc->ExportField($this->StartDate);
						if ($this->EndDate->Exportable) $Doc->ExportField($this->EndDate);
						if ($this->allday->Exportable) $Doc->ExportField($this->allday);
						if ($this->starttime->Exportable) $Doc->ExportField($this->starttime);
						if ($this->endtime->Exportable) $Doc->ExportField($this->endtime);
						if ($this->category->Exportable) $Doc->ExportField($this->category);
						if ($this->Venue->Exportable) $Doc->ExportField($this->Venue);
						if ($this->Organizer->Exportable) $Doc->ExportField($this->Organizer);
						if ($this->Payment->Exportable) $Doc->ExportField($this->Payment);
						if ($this->Fees->Exportable) $Doc->ExportField($this->Fees);
						if ($this->documents->Exportable) $Doc->ExportField($this->documents);
					}
					$Doc->EndExportRow();
				}
			}

			// Call Row Export server event
			if ($Doc->ExportCustom)
				$this->Row_Export($Recordset->fields);
			$Recordset->MoveNext();
		}
		if (!$Doc->ExportCustom) {
			$Doc->ExportTableFooter();
		}
	}

	// Get auto fill value
	function GetAutoFill($id, $val) {
		$rsarr = array();
		$rowcnt = 0;

		// Output
		if (is_array($rsarr) && $rowcnt > 0) {
			$fldcnt = count($rsarr[0]);
			for ($i = 0; $i < $rowcnt; $i++) {
				for ($j = 0; $j < $fldcnt; $j++) {
					$str = strval($rsarr[$i][$j]);
					$str = ew_ConvertToUtf8($str);
					if (isset($post["keepCRLF"])) {
						$str = str_replace(array("\r", "\n"), array("\\r", "\\n"), $str);
					} else {
						$str = str_replace(array("\r", "\n"), array(" ", " "), $str);
					}
					$rsarr[$i][$j] = $str;
				}
			}
			return ew_ArrayToJson($rsarr);
		} else {
			return FALSE;
		}
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here	
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here	
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here	
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending(&$Email, &$Args) {

		//var_dump($Email); var_dump($Args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->FldName, $fld->LookupFilters, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here	
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>); 

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>
