<?php include_once "staffinfo.php" ?>
<?php

// Create page object
if (!isset($invoices_grid)) $invoices_grid = new cinvoices_grid();

// Page init
$invoices_grid->Page_Init();

// Page main
$invoices_grid->Page_Main();

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$invoices_grid->Page_Render();
?>
<?php if ($invoices->Export == "") { ?>
<script type="text/javascript">

// Form object
var finvoicesgrid = new ew_Form("finvoicesgrid", "grid");
finvoicesgrid.FormKeyCountName = '<?php echo $invoices_grid->FormKeyCountName ?>';

// Validate form
finvoicesgrid.Validate = function() {
	if (!this.ValidateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.GetForm(), $fobj = $(fobj);
	if ($fobj.find("#a_confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.FormKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = $fobj.find("#a_list").val() == "gridinsert";
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
		var checkrow = (gridinsert) ? !this.EmptyRow(infix) : true;
		if (checkrow) {
			addcnt++;
			elm = this.GetElements("x" + infix + "_invoicedate");
			if (elm && !ew_CheckEuroDate(elm.value))
				return this.OnError(elm, "<?php echo ew_JsEncode2($invoices->invoicedate->FldErrMsg()) ?>");
			elm = this.GetElements("x" + infix + "_amount");
			if (elm && !ew_CheckNumber(elm.value))
				return this.OnError(elm, "<?php echo ew_JsEncode2($invoices->amount->FldErrMsg()) ?>");

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
		} // End Grid Add checking
	}
	return true;
}

// Check empty row
finvoicesgrid.EmptyRow = function(infix) {
	var fobj = this.Form;
	if (ew_ValueChanged(fobj, infix, "budget_id", false)) return false;
	if (ew_ValueChanged(fobj, infix, "invoicedate", false)) return false;
	if (ew_ValueChanged(fobj, infix, "amount", false)) return false;
	return true;
}

// Form_CustomValidate event
finvoicesgrid.Form_CustomValidate = 
 function(fobj) { // DO NOT CHANGE THIS LINE!

 	// Your custom validation code here, return false if invalid. 
 	return true;
 }

// Use JavaScript validation or not
<?php if (EW_CLIENT_VALIDATE) { ?>
finvoicesgrid.ValidateRequired = true;
<?php } else { ?>
finvoicesgrid.ValidateRequired = false; 
<?php } ?>

// Dynamic selection lists
finvoicesgrid.Lists["x_budget_id"] = {"LinkField":"x_id","Ajax":true,"AutoFill":false,"DisplayFields":["x_BudgetYear","","",""],"ParentFields":[],"ChildFields":[],"FilterFields":[],"Options":[],"Template":""};

// Form object for search
</script>
<?php } ?>
<?php
if ($invoices->CurrentAction == "gridadd") {
	if ($invoices->CurrentMode == "copy") {
		$bSelectLimit = $invoices_grid->UseSelectLimit;
		if ($bSelectLimit) {
			$invoices_grid->TotalRecs = $invoices->SelectRecordCount();
			$invoices_grid->Recordset = $invoices_grid->LoadRecordset($invoices_grid->StartRec-1, $invoices_grid->DisplayRecs);
		} else {
			if ($invoices_grid->Recordset = $invoices_grid->LoadRecordset())
				$invoices_grid->TotalRecs = $invoices_grid->Recordset->RecordCount();
		}
		$invoices_grid->StartRec = 1;
		$invoices_grid->DisplayRecs = $invoices_grid->TotalRecs;
	} else {
		$invoices->CurrentFilter = "0=1";
		$invoices_grid->StartRec = 1;
		$invoices_grid->DisplayRecs = $invoices->GridAddRowCount;
	}
	$invoices_grid->TotalRecs = $invoices_grid->DisplayRecs;
	$invoices_grid->StopRec = $invoices_grid->DisplayRecs;
} else {
	$bSelectLimit = $invoices_grid->UseSelectLimit;
	if ($bSelectLimit) {
		if ($invoices_grid->TotalRecs <= 0)
			$invoices_grid->TotalRecs = $invoices->SelectRecordCount();
	} else {
		if (!$invoices_grid->Recordset && ($invoices_grid->Recordset = $invoices_grid->LoadRecordset()))
			$invoices_grid->TotalRecs = $invoices_grid->Recordset->RecordCount();
	}
	$invoices_grid->StartRec = 1;
	$invoices_grid->DisplayRecs = $invoices_grid->TotalRecs; // Display all records
	if ($bSelectLimit)
		$invoices_grid->Recordset = $invoices_grid->LoadRecordset($invoices_grid->StartRec-1, $invoices_grid->DisplayRecs);

	// Set no record found message
	if ($invoices->CurrentAction == "" && $invoices_grid->TotalRecs == 0) {
		if (!$Security->CanList())
			$invoices_grid->setWarningMessage(ew_DeniedMsg());
		if ($invoices_grid->SearchWhere == "0=101")
			$invoices_grid->setWarningMessage($Language->Phrase("EnterSearchCriteria"));
		else
			$invoices_grid->setWarningMessage($Language->Phrase("NoRecord"));
	}
}
$invoices_grid->RenderOtherOptions();
?>
<?php $invoices_grid->ShowPageHeader(); ?>
<?php
$invoices_grid->ShowMessage();
?>
<?php if ($invoices_grid->TotalRecs > 0 || $invoices->CurrentAction <> "") { ?>
<div class="panel panel-default ewGrid">
<div id="finvoicesgrid" class="ewForm form-inline">
<?php if ($invoices_grid->ShowOtherOptions) { ?>
<div class="panel-heading ewGridUpperPanel">
<?php
	foreach ($invoices_grid->OtherOptions as &$option)
		$option->Render("body");
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<div id="gmp_invoices" class="<?php if (ew_IsResponsiveLayout()) { echo "table-responsive "; } ?>ewGridMiddlePanel">
<table id="tbl_invoicesgrid" class="table ewTable">
<?php echo $invoices->TableCustomInnerHtml ?>
<thead><!-- Table header -->
	<tr class="ewTableHeader">
<?php

// Header row
$invoices_grid->RowType = EW_ROWTYPE_HEADER;

// Render list options
$invoices_grid->RenderListOptions();

// Render list options (header, left)
$invoices_grid->ListOptions->Render("header", "left");
?>
<?php if ($invoices->id->Visible) { // id ?>
	<?php if ($invoices->SortUrl($invoices->id) == "") { ?>
		<th data-name="id"><div id="elh_invoices_id" class="invoices_id"><div class="ewTableHeaderCaption"><?php echo $invoices->id->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="id"><div><div id="elh_invoices_id" class="invoices_id">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $invoices->id->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($invoices->id->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($invoices->id->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($invoices->budget_id->Visible) { // budget_id ?>
	<?php if ($invoices->SortUrl($invoices->budget_id) == "") { ?>
		<th data-name="budget_id"><div id="elh_invoices_budget_id" class="invoices_budget_id"><div class="ewTableHeaderCaption"><?php echo $invoices->budget_id->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="budget_id"><div><div id="elh_invoices_budget_id" class="invoices_budget_id">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $invoices->budget_id->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($invoices->budget_id->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($invoices->budget_id->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($invoices->invoicedate->Visible) { // invoicedate ?>
	<?php if ($invoices->SortUrl($invoices->invoicedate) == "") { ?>
		<th data-name="invoicedate"><div id="elh_invoices_invoicedate" class="invoices_invoicedate"><div class="ewTableHeaderCaption"><?php echo $invoices->invoicedate->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="invoicedate"><div><div id="elh_invoices_invoicedate" class="invoices_invoicedate">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $invoices->invoicedate->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($invoices->invoicedate->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($invoices->invoicedate->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($invoices->amount->Visible) { // amount ?>
	<?php if ($invoices->SortUrl($invoices->amount) == "") { ?>
		<th data-name="amount"><div id="elh_invoices_amount" class="invoices_amount"><div class="ewTableHeaderCaption"><?php echo $invoices->amount->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="amount"><div><div id="elh_invoices_amount" class="invoices_amount">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $invoices->amount->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($invoices->amount->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($invoices->amount->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php

// Render list options (header, right)
$invoices_grid->ListOptions->Render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
$invoices_grid->StartRec = 1;
$invoices_grid->StopRec = $invoices_grid->TotalRecs; // Show all records

// Restore number of post back records
if ($objForm) {
	$objForm->Index = -1;
	if ($objForm->HasValue($invoices_grid->FormKeyCountName) && ($invoices->CurrentAction == "gridadd" || $invoices->CurrentAction == "gridedit" || $invoices->CurrentAction == "F")) {
		$invoices_grid->KeyCount = $objForm->GetValue($invoices_grid->FormKeyCountName);
		$invoices_grid->StopRec = $invoices_grid->StartRec + $invoices_grid->KeyCount - 1;
	}
}
$invoices_grid->RecCnt = $invoices_grid->StartRec - 1;
if ($invoices_grid->Recordset && !$invoices_grid->Recordset->EOF) {
	$invoices_grid->Recordset->MoveFirst();
	$bSelectLimit = $invoices_grid->UseSelectLimit;
	if (!$bSelectLimit && $invoices_grid->StartRec > 1)
		$invoices_grid->Recordset->Move($invoices_grid->StartRec - 1);
} elseif (!$invoices->AllowAddDeleteRow && $invoices_grid->StopRec == 0) {
	$invoices_grid->StopRec = $invoices->GridAddRowCount;
}

// Initialize aggregate
$invoices->RowType = EW_ROWTYPE_AGGREGATEINIT;
$invoices->ResetAttrs();
$invoices_grid->RenderRow();
if ($invoices->CurrentAction == "gridadd")
	$invoices_grid->RowIndex = 0;
if ($invoices->CurrentAction == "gridedit")
	$invoices_grid->RowIndex = 0;
while ($invoices_grid->RecCnt < $invoices_grid->StopRec) {
	$invoices_grid->RecCnt++;
	if (intval($invoices_grid->RecCnt) >= intval($invoices_grid->StartRec)) {
		$invoices_grid->RowCnt++;
		if ($invoices->CurrentAction == "gridadd" || $invoices->CurrentAction == "gridedit" || $invoices->CurrentAction == "F") {
			$invoices_grid->RowIndex++;
			$objForm->Index = $invoices_grid->RowIndex;
			if ($objForm->HasValue($invoices_grid->FormActionName))
				$invoices_grid->RowAction = strval($objForm->GetValue($invoices_grid->FormActionName));
			elseif ($invoices->CurrentAction == "gridadd")
				$invoices_grid->RowAction = "insert";
			else
				$invoices_grid->RowAction = "";
		}

		// Set up key count
		$invoices_grid->KeyCount = $invoices_grid->RowIndex;

		// Init row class and style
		$invoices->ResetAttrs();
		$invoices->CssClass = "";
		if ($invoices->CurrentAction == "gridadd") {
			if ($invoices->CurrentMode == "copy") {
				$invoices_grid->LoadRowValues($invoices_grid->Recordset); // Load row values
				$invoices_grid->SetRecordKey($invoices_grid->RowOldKey, $invoices_grid->Recordset); // Set old record key
			} else {
				$invoices_grid->LoadDefaultValues(); // Load default values
				$invoices_grid->RowOldKey = ""; // Clear old key value
			}
		} else {
			$invoices_grid->LoadRowValues($invoices_grid->Recordset); // Load row values
		}
		$invoices->RowType = EW_ROWTYPE_VIEW; // Render view
		if ($invoices->CurrentAction == "gridadd") // Grid add
			$invoices->RowType = EW_ROWTYPE_ADD; // Render add
		if ($invoices->CurrentAction == "gridadd" && $invoices->EventCancelled && !$objForm->HasValue("k_blankrow")) // Insert failed
			$invoices_grid->RestoreCurrentRowFormValues($invoices_grid->RowIndex); // Restore form values
		if ($invoices->CurrentAction == "gridedit") { // Grid edit
			if ($invoices->EventCancelled) {
				$invoices_grid->RestoreCurrentRowFormValues($invoices_grid->RowIndex); // Restore form values
			}
			if ($invoices_grid->RowAction == "insert")
				$invoices->RowType = EW_ROWTYPE_ADD; // Render add
			else
				$invoices->RowType = EW_ROWTYPE_EDIT; // Render edit
		}
		if ($invoices->CurrentAction == "gridedit" && ($invoices->RowType == EW_ROWTYPE_EDIT || $invoices->RowType == EW_ROWTYPE_ADD) && $invoices->EventCancelled) // Update failed
			$invoices_grid->RestoreCurrentRowFormValues($invoices_grid->RowIndex); // Restore form values
		if ($invoices->RowType == EW_ROWTYPE_EDIT) // Edit row
			$invoices_grid->EditRowCnt++;
		if ($invoices->CurrentAction == "F") // Confirm row
			$invoices_grid->RestoreCurrentRowFormValues($invoices_grid->RowIndex); // Restore form values

		// Set up row id / data-rowindex
		$invoices->RowAttrs = array_merge($invoices->RowAttrs, array('data-rowindex'=>$invoices_grid->RowCnt, 'id'=>'r' . $invoices_grid->RowCnt . '_invoices', 'data-rowtype'=>$invoices->RowType));

		// Render row
		$invoices_grid->RenderRow();

		// Render list options
		$invoices_grid->RenderListOptions();

		// Skip delete row / empty row for confirm page
		if ($invoices_grid->RowAction <> "delete" && $invoices_grid->RowAction <> "insertdelete" && !($invoices_grid->RowAction == "insert" && $invoices->CurrentAction == "F" && $invoices_grid->EmptyRow())) {
?>
	<tr<?php echo $invoices->RowAttributes() ?>>
<?php

// Render list options (body, left)
$invoices_grid->ListOptions->Render("body", "left", $invoices_grid->RowCnt);
?>
	<?php if ($invoices->id->Visible) { // id ?>
		<td data-name="id"<?php echo $invoices->id->CellAttributes() ?>>
<?php if ($invoices->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<input type="hidden" data-table="invoices" data-field="x_id" name="o<?php echo $invoices_grid->RowIndex ?>_id" id="o<?php echo $invoices_grid->RowIndex ?>_id" value="<?php echo ew_HtmlEncode($invoices->id->OldValue) ?>">
<?php } ?>
<?php if ($invoices->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $invoices_grid->RowCnt ?>_invoices_id" class="form-group invoices_id">
<span<?php echo $invoices->id->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $invoices->id->EditValue ?></p></span>
</span>
<input type="hidden" data-table="invoices" data-field="x_id" name="x<?php echo $invoices_grid->RowIndex ?>_id" id="x<?php echo $invoices_grid->RowIndex ?>_id" value="<?php echo ew_HtmlEncode($invoices->id->CurrentValue) ?>">
<?php } ?>
<?php if ($invoices->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $invoices_grid->RowCnt ?>_invoices_id" class="invoices_id">
<span<?php echo $invoices->id->ViewAttributes() ?>>
<?php echo $invoices->id->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="invoices" data-field="x_id" name="x<?php echo $invoices_grid->RowIndex ?>_id" id="x<?php echo $invoices_grid->RowIndex ?>_id" value="<?php echo ew_HtmlEncode($invoices->id->FormValue) ?>">
<input type="hidden" data-table="invoices" data-field="x_id" name="o<?php echo $invoices_grid->RowIndex ?>_id" id="o<?php echo $invoices_grid->RowIndex ?>_id" value="<?php echo ew_HtmlEncode($invoices->id->OldValue) ?>">
<?php } ?>
<a id="<?php echo $invoices_grid->PageObjName . "_row_" . $invoices_grid->RowCnt ?>"></a></td>
	<?php } ?>
	<?php if ($invoices->budget_id->Visible) { // budget_id ?>
		<td data-name="budget_id"<?php echo $invoices->budget_id->CellAttributes() ?>>
<?php if ($invoices->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<?php if ($invoices->budget_id->getSessionValue() <> "") { ?>
<span id="el<?php echo $invoices_grid->RowCnt ?>_invoices_budget_id" class="form-group invoices_budget_id">
<span<?php echo $invoices->budget_id->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $invoices->budget_id->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $invoices_grid->RowIndex ?>_budget_id" name="x<?php echo $invoices_grid->RowIndex ?>_budget_id" value="<?php echo ew_HtmlEncode($invoices->budget_id->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $invoices_grid->RowCnt ?>_invoices_budget_id" class="form-group invoices_budget_id">
<select data-table="invoices" data-field="x_budget_id" data-value-separator="<?php echo ew_HtmlEncode(is_array($invoices->budget_id->DisplayValueSeparator) ? json_encode($invoices->budget_id->DisplayValueSeparator) : $invoices->budget_id->DisplayValueSeparator) ?>" id="x<?php echo $invoices_grid->RowIndex ?>_budget_id" name="x<?php echo $invoices_grid->RowIndex ?>_budget_id"<?php echo $invoices->budget_id->EditAttributes() ?>>
<?php
if (is_array($invoices->budget_id->EditValue)) {
	$arwrk = $invoices->budget_id->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = ew_SameStr($invoices->budget_id->CurrentValue, $arwrk[$rowcntwrk][0]) ? " selected" : "";
		if ($selwrk <> "") $emptywrk = FALSE;		
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $invoices->budget_id->DisplayValue($arwrk[$rowcntwrk]) ?>
</option>
<?php
	}
	if ($emptywrk && strval($invoices->budget_id->CurrentValue) <> "") {
?>
<option value="<?php echo ew_HtmlEncode($invoices->budget_id->CurrentValue) ?>" selected><?php echo $invoices->budget_id->CurrentValue ?></option>
<?php
    }
}
if (@$emptywrk) $invoices->budget_id->OldValue = "";
?>
</select>
<?php
$sSqlWrk = "SELECT `id`, `BudgetYear` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `budget`";
$sWhereWrk = "";
$invoices->budget_id->LookupFilters = array("s" => $sSqlWrk, "d" => "");
$invoices->budget_id->LookupFilters += array("f0" => "`id` = {filter_value}", "t0" => "3", "fn0" => "");
$sSqlWrk = "";
$invoices->Lookup_Selecting($invoices->budget_id, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
if ($sSqlWrk <> "") $invoices->budget_id->LookupFilters["s"] .= $sSqlWrk;
?>
<input type="hidden" name="s_x<?php echo $invoices_grid->RowIndex ?>_budget_id" id="s_x<?php echo $invoices_grid->RowIndex ?>_budget_id" value="<?php echo $invoices->budget_id->LookupFilterQuery() ?>">
</span>
<?php } ?>
<input type="hidden" data-table="invoices" data-field="x_budget_id" name="o<?php echo $invoices_grid->RowIndex ?>_budget_id" id="o<?php echo $invoices_grid->RowIndex ?>_budget_id" value="<?php echo ew_HtmlEncode($invoices->budget_id->OldValue) ?>">
<?php } ?>
<?php if ($invoices->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<?php if ($invoices->budget_id->getSessionValue() <> "") { ?>
<span id="el<?php echo $invoices_grid->RowCnt ?>_invoices_budget_id" class="form-group invoices_budget_id">
<span<?php echo $invoices->budget_id->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $invoices->budget_id->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $invoices_grid->RowIndex ?>_budget_id" name="x<?php echo $invoices_grid->RowIndex ?>_budget_id" value="<?php echo ew_HtmlEncode($invoices->budget_id->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $invoices_grid->RowCnt ?>_invoices_budget_id" class="form-group invoices_budget_id">
<select data-table="invoices" data-field="x_budget_id" data-value-separator="<?php echo ew_HtmlEncode(is_array($invoices->budget_id->DisplayValueSeparator) ? json_encode($invoices->budget_id->DisplayValueSeparator) : $invoices->budget_id->DisplayValueSeparator) ?>" id="x<?php echo $invoices_grid->RowIndex ?>_budget_id" name="x<?php echo $invoices_grid->RowIndex ?>_budget_id"<?php echo $invoices->budget_id->EditAttributes() ?>>
<?php
if (is_array($invoices->budget_id->EditValue)) {
	$arwrk = $invoices->budget_id->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = ew_SameStr($invoices->budget_id->CurrentValue, $arwrk[$rowcntwrk][0]) ? " selected" : "";
		if ($selwrk <> "") $emptywrk = FALSE;		
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $invoices->budget_id->DisplayValue($arwrk[$rowcntwrk]) ?>
</option>
<?php
	}
	if ($emptywrk && strval($invoices->budget_id->CurrentValue) <> "") {
?>
<option value="<?php echo ew_HtmlEncode($invoices->budget_id->CurrentValue) ?>" selected><?php echo $invoices->budget_id->CurrentValue ?></option>
<?php
    }
}
if (@$emptywrk) $invoices->budget_id->OldValue = "";
?>
</select>
<?php
$sSqlWrk = "SELECT `id`, `BudgetYear` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `budget`";
$sWhereWrk = "";
$invoices->budget_id->LookupFilters = array("s" => $sSqlWrk, "d" => "");
$invoices->budget_id->LookupFilters += array("f0" => "`id` = {filter_value}", "t0" => "3", "fn0" => "");
$sSqlWrk = "";
$invoices->Lookup_Selecting($invoices->budget_id, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
if ($sSqlWrk <> "") $invoices->budget_id->LookupFilters["s"] .= $sSqlWrk;
?>
<input type="hidden" name="s_x<?php echo $invoices_grid->RowIndex ?>_budget_id" id="s_x<?php echo $invoices_grid->RowIndex ?>_budget_id" value="<?php echo $invoices->budget_id->LookupFilterQuery() ?>">
</span>
<?php } ?>
<?php } ?>
<?php if ($invoices->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $invoices_grid->RowCnt ?>_invoices_budget_id" class="invoices_budget_id">
<span<?php echo $invoices->budget_id->ViewAttributes() ?>>
<?php echo $invoices->budget_id->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="invoices" data-field="x_budget_id" name="x<?php echo $invoices_grid->RowIndex ?>_budget_id" id="x<?php echo $invoices_grid->RowIndex ?>_budget_id" value="<?php echo ew_HtmlEncode($invoices->budget_id->FormValue) ?>">
<input type="hidden" data-table="invoices" data-field="x_budget_id" name="o<?php echo $invoices_grid->RowIndex ?>_budget_id" id="o<?php echo $invoices_grid->RowIndex ?>_budget_id" value="<?php echo ew_HtmlEncode($invoices->budget_id->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($invoices->invoicedate->Visible) { // invoicedate ?>
		<td data-name="invoicedate"<?php echo $invoices->invoicedate->CellAttributes() ?>>
<?php if ($invoices->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $invoices_grid->RowCnt ?>_invoices_invoicedate" class="form-group invoices_invoicedate">
<input type="text" data-table="invoices" data-field="x_invoicedate" data-format="7" name="x<?php echo $invoices_grid->RowIndex ?>_invoicedate" id="x<?php echo $invoices_grid->RowIndex ?>_invoicedate" placeholder="<?php echo ew_HtmlEncode($invoices->invoicedate->getPlaceHolder()) ?>" value="<?php echo $invoices->invoicedate->EditValue ?>"<?php echo $invoices->invoicedate->EditAttributes() ?>>
<?php if (!$invoices->invoicedate->ReadOnly && !$invoices->invoicedate->Disabled && !isset($invoices->invoicedate->EditAttrs["readonly"]) && !isset($invoices->invoicedate->EditAttrs["disabled"])) { ?>
<script type="text/javascript">
ew_CreateCalendar("finvoicesgrid", "x<?php echo $invoices_grid->RowIndex ?>_invoicedate", "%d/%m/%Y");
</script>
<?php } ?>
</span>
<input type="hidden" data-table="invoices" data-field="x_invoicedate" name="o<?php echo $invoices_grid->RowIndex ?>_invoicedate" id="o<?php echo $invoices_grid->RowIndex ?>_invoicedate" value="<?php echo ew_HtmlEncode($invoices->invoicedate->OldValue) ?>">
<?php } ?>
<?php if ($invoices->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $invoices_grid->RowCnt ?>_invoices_invoicedate" class="form-group invoices_invoicedate">
<input type="text" data-table="invoices" data-field="x_invoicedate" data-format="7" name="x<?php echo $invoices_grid->RowIndex ?>_invoicedate" id="x<?php echo $invoices_grid->RowIndex ?>_invoicedate" placeholder="<?php echo ew_HtmlEncode($invoices->invoicedate->getPlaceHolder()) ?>" value="<?php echo $invoices->invoicedate->EditValue ?>"<?php echo $invoices->invoicedate->EditAttributes() ?>>
<?php if (!$invoices->invoicedate->ReadOnly && !$invoices->invoicedate->Disabled && !isset($invoices->invoicedate->EditAttrs["readonly"]) && !isset($invoices->invoicedate->EditAttrs["disabled"])) { ?>
<script type="text/javascript">
ew_CreateCalendar("finvoicesgrid", "x<?php echo $invoices_grid->RowIndex ?>_invoicedate", "%d/%m/%Y");
</script>
<?php } ?>
</span>
<?php } ?>
<?php if ($invoices->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $invoices_grid->RowCnt ?>_invoices_invoicedate" class="invoices_invoicedate">
<span<?php echo $invoices->invoicedate->ViewAttributes() ?>>
<?php echo $invoices->invoicedate->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="invoices" data-field="x_invoicedate" name="x<?php echo $invoices_grid->RowIndex ?>_invoicedate" id="x<?php echo $invoices_grid->RowIndex ?>_invoicedate" value="<?php echo ew_HtmlEncode($invoices->invoicedate->FormValue) ?>">
<input type="hidden" data-table="invoices" data-field="x_invoicedate" name="o<?php echo $invoices_grid->RowIndex ?>_invoicedate" id="o<?php echo $invoices_grid->RowIndex ?>_invoicedate" value="<?php echo ew_HtmlEncode($invoices->invoicedate->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($invoices->amount->Visible) { // amount ?>
		<td data-name="amount"<?php echo $invoices->amount->CellAttributes() ?>>
<?php if ($invoices->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $invoices_grid->RowCnt ?>_invoices_amount" class="form-group invoices_amount">
<input type="text" data-table="invoices" data-field="x_amount" name="x<?php echo $invoices_grid->RowIndex ?>_amount" id="x<?php echo $invoices_grid->RowIndex ?>_amount" size="30" placeholder="<?php echo ew_HtmlEncode($invoices->amount->getPlaceHolder()) ?>" value="<?php echo $invoices->amount->EditValue ?>"<?php echo $invoices->amount->EditAttributes() ?>>
</span>
<input type="hidden" data-table="invoices" data-field="x_amount" name="o<?php echo $invoices_grid->RowIndex ?>_amount" id="o<?php echo $invoices_grid->RowIndex ?>_amount" value="<?php echo ew_HtmlEncode($invoices->amount->OldValue) ?>">
<?php } ?>
<?php if ($invoices->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $invoices_grid->RowCnt ?>_invoices_amount" class="form-group invoices_amount">
<input type="text" data-table="invoices" data-field="x_amount" name="x<?php echo $invoices_grid->RowIndex ?>_amount" id="x<?php echo $invoices_grid->RowIndex ?>_amount" size="30" placeholder="<?php echo ew_HtmlEncode($invoices->amount->getPlaceHolder()) ?>" value="<?php echo $invoices->amount->EditValue ?>"<?php echo $invoices->amount->EditAttributes() ?>>
</span>
<?php } ?>
<?php if ($invoices->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $invoices_grid->RowCnt ?>_invoices_amount" class="invoices_amount">
<span<?php echo $invoices->amount->ViewAttributes() ?>>
<?php echo $invoices->amount->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="invoices" data-field="x_amount" name="x<?php echo $invoices_grid->RowIndex ?>_amount" id="x<?php echo $invoices_grid->RowIndex ?>_amount" value="<?php echo ew_HtmlEncode($invoices->amount->FormValue) ?>">
<input type="hidden" data-table="invoices" data-field="x_amount" name="o<?php echo $invoices_grid->RowIndex ?>_amount" id="o<?php echo $invoices_grid->RowIndex ?>_amount" value="<?php echo ew_HtmlEncode($invoices->amount->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$invoices_grid->ListOptions->Render("body", "right", $invoices_grid->RowCnt);
?>
	</tr>
<?php if ($invoices->RowType == EW_ROWTYPE_ADD || $invoices->RowType == EW_ROWTYPE_EDIT) { ?>
<script type="text/javascript">
finvoicesgrid.UpdateOpts(<?php echo $invoices_grid->RowIndex ?>);
</script>
<?php } ?>
<?php
	}
	} // End delete row checking
	if ($invoices->CurrentAction <> "gridadd" || $invoices->CurrentMode == "copy")
		if (!$invoices_grid->Recordset->EOF) $invoices_grid->Recordset->MoveNext();
}
?>
<?php
	if ($invoices->CurrentMode == "add" || $invoices->CurrentMode == "copy" || $invoices->CurrentMode == "edit") {
		$invoices_grid->RowIndex = '$rowindex$';
		$invoices_grid->LoadDefaultValues();

		// Set row properties
		$invoices->ResetAttrs();
		$invoices->RowAttrs = array_merge($invoices->RowAttrs, array('data-rowindex'=>$invoices_grid->RowIndex, 'id'=>'r0_invoices', 'data-rowtype'=>EW_ROWTYPE_ADD));
		ew_AppendClass($invoices->RowAttrs["class"], "ewTemplate");
		$invoices->RowType = EW_ROWTYPE_ADD;

		// Render row
		$invoices_grid->RenderRow();

		// Render list options
		$invoices_grid->RenderListOptions();
		$invoices_grid->StartRowCnt = 0;
?>
	<tr<?php echo $invoices->RowAttributes() ?>>
<?php

// Render list options (body, left)
$invoices_grid->ListOptions->Render("body", "left", $invoices_grid->RowIndex);
?>
	<?php if ($invoices->id->Visible) { // id ?>
		<td data-name="id">
<?php if ($invoices->CurrentAction <> "F") { ?>
<?php } else { ?>
<span id="el$rowindex$_invoices_id" class="form-group invoices_id">
<span<?php echo $invoices->id->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $invoices->id->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="invoices" data-field="x_id" name="x<?php echo $invoices_grid->RowIndex ?>_id" id="x<?php echo $invoices_grid->RowIndex ?>_id" value="<?php echo ew_HtmlEncode($invoices->id->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="invoices" data-field="x_id" name="o<?php echo $invoices_grid->RowIndex ?>_id" id="o<?php echo $invoices_grid->RowIndex ?>_id" value="<?php echo ew_HtmlEncode($invoices->id->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($invoices->budget_id->Visible) { // budget_id ?>
		<td data-name="budget_id">
<?php if ($invoices->CurrentAction <> "F") { ?>
<?php if ($invoices->budget_id->getSessionValue() <> "") { ?>
<span id="el$rowindex$_invoices_budget_id" class="form-group invoices_budget_id">
<span<?php echo $invoices->budget_id->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $invoices->budget_id->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $invoices_grid->RowIndex ?>_budget_id" name="x<?php echo $invoices_grid->RowIndex ?>_budget_id" value="<?php echo ew_HtmlEncode($invoices->budget_id->CurrentValue) ?>">
<?php } else { ?>
<span id="el$rowindex$_invoices_budget_id" class="form-group invoices_budget_id">
<select data-table="invoices" data-field="x_budget_id" data-value-separator="<?php echo ew_HtmlEncode(is_array($invoices->budget_id->DisplayValueSeparator) ? json_encode($invoices->budget_id->DisplayValueSeparator) : $invoices->budget_id->DisplayValueSeparator) ?>" id="x<?php echo $invoices_grid->RowIndex ?>_budget_id" name="x<?php echo $invoices_grid->RowIndex ?>_budget_id"<?php echo $invoices->budget_id->EditAttributes() ?>>
<?php
if (is_array($invoices->budget_id->EditValue)) {
	$arwrk = $invoices->budget_id->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = ew_SameStr($invoices->budget_id->CurrentValue, $arwrk[$rowcntwrk][0]) ? " selected" : "";
		if ($selwrk <> "") $emptywrk = FALSE;		
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $invoices->budget_id->DisplayValue($arwrk[$rowcntwrk]) ?>
</option>
<?php
	}
	if ($emptywrk && strval($invoices->budget_id->CurrentValue) <> "") {
?>
<option value="<?php echo ew_HtmlEncode($invoices->budget_id->CurrentValue) ?>" selected><?php echo $invoices->budget_id->CurrentValue ?></option>
<?php
    }
}
if (@$emptywrk) $invoices->budget_id->OldValue = "";
?>
</select>
<?php
$sSqlWrk = "SELECT `id`, `BudgetYear` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `budget`";
$sWhereWrk = "";
$invoices->budget_id->LookupFilters = array("s" => $sSqlWrk, "d" => "");
$invoices->budget_id->LookupFilters += array("f0" => "`id` = {filter_value}", "t0" => "3", "fn0" => "");
$sSqlWrk = "";
$invoices->Lookup_Selecting($invoices->budget_id, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
if ($sSqlWrk <> "") $invoices->budget_id->LookupFilters["s"] .= $sSqlWrk;
?>
<input type="hidden" name="s_x<?php echo $invoices_grid->RowIndex ?>_budget_id" id="s_x<?php echo $invoices_grid->RowIndex ?>_budget_id" value="<?php echo $invoices->budget_id->LookupFilterQuery() ?>">
</span>
<?php } ?>
<?php } else { ?>
<span id="el$rowindex$_invoices_budget_id" class="form-group invoices_budget_id">
<span<?php echo $invoices->budget_id->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $invoices->budget_id->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="invoices" data-field="x_budget_id" name="x<?php echo $invoices_grid->RowIndex ?>_budget_id" id="x<?php echo $invoices_grid->RowIndex ?>_budget_id" value="<?php echo ew_HtmlEncode($invoices->budget_id->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="invoices" data-field="x_budget_id" name="o<?php echo $invoices_grid->RowIndex ?>_budget_id" id="o<?php echo $invoices_grid->RowIndex ?>_budget_id" value="<?php echo ew_HtmlEncode($invoices->budget_id->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($invoices->invoicedate->Visible) { // invoicedate ?>
		<td data-name="invoicedate">
<?php if ($invoices->CurrentAction <> "F") { ?>
<span id="el$rowindex$_invoices_invoicedate" class="form-group invoices_invoicedate">
<input type="text" data-table="invoices" data-field="x_invoicedate" data-format="7" name="x<?php echo $invoices_grid->RowIndex ?>_invoicedate" id="x<?php echo $invoices_grid->RowIndex ?>_invoicedate" placeholder="<?php echo ew_HtmlEncode($invoices->invoicedate->getPlaceHolder()) ?>" value="<?php echo $invoices->invoicedate->EditValue ?>"<?php echo $invoices->invoicedate->EditAttributes() ?>>
<?php if (!$invoices->invoicedate->ReadOnly && !$invoices->invoicedate->Disabled && !isset($invoices->invoicedate->EditAttrs["readonly"]) && !isset($invoices->invoicedate->EditAttrs["disabled"])) { ?>
<script type="text/javascript">
ew_CreateCalendar("finvoicesgrid", "x<?php echo $invoices_grid->RowIndex ?>_invoicedate", "%d/%m/%Y");
</script>
<?php } ?>
</span>
<?php } else { ?>
<span id="el$rowindex$_invoices_invoicedate" class="form-group invoices_invoicedate">
<span<?php echo $invoices->invoicedate->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $invoices->invoicedate->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="invoices" data-field="x_invoicedate" name="x<?php echo $invoices_grid->RowIndex ?>_invoicedate" id="x<?php echo $invoices_grid->RowIndex ?>_invoicedate" value="<?php echo ew_HtmlEncode($invoices->invoicedate->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="invoices" data-field="x_invoicedate" name="o<?php echo $invoices_grid->RowIndex ?>_invoicedate" id="o<?php echo $invoices_grid->RowIndex ?>_invoicedate" value="<?php echo ew_HtmlEncode($invoices->invoicedate->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($invoices->amount->Visible) { // amount ?>
		<td data-name="amount">
<?php if ($invoices->CurrentAction <> "F") { ?>
<span id="el$rowindex$_invoices_amount" class="form-group invoices_amount">
<input type="text" data-table="invoices" data-field="x_amount" name="x<?php echo $invoices_grid->RowIndex ?>_amount" id="x<?php echo $invoices_grid->RowIndex ?>_amount" size="30" placeholder="<?php echo ew_HtmlEncode($invoices->amount->getPlaceHolder()) ?>" value="<?php echo $invoices->amount->EditValue ?>"<?php echo $invoices->amount->EditAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_invoices_amount" class="form-group invoices_amount">
<span<?php echo $invoices->amount->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $invoices->amount->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="invoices" data-field="x_amount" name="x<?php echo $invoices_grid->RowIndex ?>_amount" id="x<?php echo $invoices_grid->RowIndex ?>_amount" value="<?php echo ew_HtmlEncode($invoices->amount->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="invoices" data-field="x_amount" name="o<?php echo $invoices_grid->RowIndex ?>_amount" id="o<?php echo $invoices_grid->RowIndex ?>_amount" value="<?php echo ew_HtmlEncode($invoices->amount->OldValue) ?>">
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$invoices_grid->ListOptions->Render("body", "right", $invoices_grid->RowCnt);
?>
<script type="text/javascript">
finvoicesgrid.UpdateOpts(<?php echo $invoices_grid->RowIndex ?>);
</script>
	</tr>
<?php
}
?>
</tbody>
</table>
<?php if ($invoices->CurrentMode == "add" || $invoices->CurrentMode == "copy") { ?>
<input type="hidden" name="a_list" id="a_list" value="gridinsert">
<input type="hidden" name="<?php echo $invoices_grid->FormKeyCountName ?>" id="<?php echo $invoices_grid->FormKeyCountName ?>" value="<?php echo $invoices_grid->KeyCount ?>">
<?php echo $invoices_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($invoices->CurrentMode == "edit") { ?>
<input type="hidden" name="a_list" id="a_list" value="gridupdate">
<input type="hidden" name="<?php echo $invoices_grid->FormKeyCountName ?>" id="<?php echo $invoices_grid->FormKeyCountName ?>" value="<?php echo $invoices_grid->KeyCount ?>">
<?php echo $invoices_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($invoices->CurrentMode == "") { ?>
<input type="hidden" name="a_list" id="a_list" value="">
<?php } ?>
<input type="hidden" name="detailpage" value="finvoicesgrid">
</div>
<?php

// Close recordset
if ($invoices_grid->Recordset)
	$invoices_grid->Recordset->Close();
?>
<?php if ($invoices_grid->ShowOtherOptions) { ?>
<div class="panel-footer ewGridLowerPanel">
<?php
	foreach ($invoices_grid->OtherOptions as &$option)
		$option->Render("body", "bottom");
?>
</div>
<div class="clearfix"></div>
<?php } ?>
</div>
</div>
<?php } ?>
<?php if ($invoices_grid->TotalRecs == 0 && $invoices->CurrentAction == "") { // Show other options ?>
<div class="ewListOtherOptions">
<?php
	foreach ($invoices_grid->OtherOptions as &$option) {
		$option->ButtonClass = "";
		$option->Render("body", "");
	}
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php if ($invoices->Export == "") { ?>
<script type="text/javascript">
finvoicesgrid.Init();
</script>
<?php } ?>
<?php
$invoices_grid->ShowPageFooter();
if (EW_DEBUG_ENABLED)
	echo ew_DebugMsg();
?>
<?php
$invoices_grid->Page_Terminate();
?>
