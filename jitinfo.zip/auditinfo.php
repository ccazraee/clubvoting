<?php

// Global variable for table object
$audit = NULL;

//
// Table class for audit
//
class caudit extends cTable {
	var $auditID;
	var $audityear;
	var $issue;
	var $description;
	var $risktype;
	var $risklevel;
	var $jadrecommend;
	var $jitresponse;
	var $ActionPlan;
	var $oic1;
	var $oic2;
	var $oic3;
	var $targetdate;
	var $status;
	var $Attachment;

	//
	// Table class constructor
	//
	function __construct() {
		global $Language;

		// Language object
		if (!isset($Language)) $Language = new cLanguage();
		$this->TableVar = 'audit';
		$this->TableName = 'audit';
		$this->TableType = 'TABLE';

		// Update Table
		$this->UpdateTable = "`audit`";
		$this->DBID = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = PHPExcel_Worksheet_PageSetup::ORIENTATION_DEFAULT; // Page orientation (PHPExcel only)
		$this->ExportExcelPageSize = PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4; // Page size (PHPExcel only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = FALSE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = ew_AllowAddDeleteRow(); // Allow add/delete row
		$this->UserIDAllowSecurity = 0; // User ID Allow
		$this->BasicSearch = new cBasicSearch($this->TableVar);
		$this->BasicSearch->TypeDefault = "OR";

		// auditID
		$this->auditID = new cField('audit', 'audit', 'x_auditID', 'auditID', '`auditID`', '`auditID`', 3, -1, FALSE, '`auditID`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'NO');
		$this->auditID->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['auditID'] = &$this->auditID;

		// audityear
		$this->audityear = new cField('audit', 'audit', 'x_audityear', 'audityear', '`audityear`', '`audityear`', 3, -1, FALSE, '`audityear`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->audityear->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['audityear'] = &$this->audityear;

		// issue
		$this->issue = new cField('audit', 'audit', 'x_issue', 'issue', '`issue`', '`issue`', 201, -1, FALSE, '`issue`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->fields['issue'] = &$this->issue;

		// description
		$this->description = new cField('audit', 'audit', 'x_description', 'description', '`description`', '`description`', 201, -1, FALSE, '`description`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->fields['description'] = &$this->description;

		// risktype
		$this->risktype = new cField('audit', 'audit', 'x_risktype', 'risktype', '`risktype`', '`risktype`', 200, -1, FALSE, '`risktype`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->fields['risktype'] = &$this->risktype;

		// risklevel
		$this->risklevel = new cField('audit', 'audit', 'x_risklevel', 'risklevel', '`risklevel`', '`risklevel`', 200, -1, FALSE, '`risklevel`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'RADIO');
		$this->risklevel->OptionCount = 3;
		$this->fields['risklevel'] = &$this->risklevel;

		// jadrecommend
		$this->jadrecommend = new cField('audit', 'audit', 'x_jadrecommend', 'jadrecommend', '`jadrecommend`', '`jadrecommend`', 201, -1, FALSE, '`jadrecommend`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->fields['jadrecommend'] = &$this->jadrecommend;

		// jitresponse
		$this->jitresponse = new cField('audit', 'audit', 'x_jitresponse', 'jitresponse', '`jitresponse`', '`jitresponse`', 201, -1, FALSE, '`jitresponse`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->fields['jitresponse'] = &$this->jitresponse;

		// ActionPlan
		$this->ActionPlan = new cField('audit', 'audit', 'x_ActionPlan', 'ActionPlan', '`ActionPlan`', '`ActionPlan`', 201, -1, FALSE, '`ActionPlan`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->fields['ActionPlan'] = &$this->ActionPlan;

		// oic1
		$this->oic1 = new cField('audit', 'audit', 'x_oic1', 'oic1', '`oic1`', '`oic1`', 3, -1, FALSE, '`oic1`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->oic1->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['oic1'] = &$this->oic1;

		// oic2
		$this->oic2 = new cField('audit', 'audit', 'x_oic2', 'oic2', '`oic2`', '`oic2`', 3, -1, FALSE, '`oic2`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->oic2->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['oic2'] = &$this->oic2;

		// oic3
		$this->oic3 = new cField('audit', 'audit', 'x_oic3', 'oic3', '`oic3`', '`oic3`', 3, -1, FALSE, '`oic3`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->oic3->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['oic3'] = &$this->oic3;

		// targetdate
		$this->targetdate = new cField('audit', 'audit', 'x_targetdate', 'targetdate', '`targetdate`', 'DATE_FORMAT(`targetdate`, \'%d/%m/%Y\')', 133, 7, FALSE, '`targetdate`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->targetdate->FldDefaultErrMsg = str_replace("%s", "/", $Language->Phrase("IncorrectDateDMY"));
		$this->fields['targetdate'] = &$this->targetdate;

		// status
		$this->status = new cField('audit', 'audit', 'x_status', 'status', '`status`', '`status`', 200, -1, FALSE, '`status`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'RADIO');
		$this->status->OptionCount = 3;
		$this->fields['status'] = &$this->status;

		// Attachment
		$this->Attachment = new cField('audit', 'audit', 'x_Attachment', 'Attachment', '`Attachment`', '`Attachment`', 200, -1, TRUE, '`Attachment`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'FILE');
		$this->Attachment->UploadMultiple = TRUE;
		$this->Attachment->Upload->UploadMultiple = TRUE;
		$this->fields['Attachment'] = &$this->Attachment;
	}

	// Multiple column sort
	function UpdateSort(&$ofld, $ctrl) {
		if ($this->CurrentOrder == $ofld->FldName) {
			$sSortField = $ofld->FldExpression;
			$sLastSort = $ofld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$sThisSort = $this->CurrentOrderType;
			} else {
				$sThisSort = ($sLastSort == "ASC") ? "DESC" : "ASC";
			}
			$ofld->setSort($sThisSort);
			if ($ctrl) {
				$sOrderBy = $this->getSessionOrderBy();
				if (strpos($sOrderBy, $sSortField . " " . $sLastSort) !== FALSE) {
					$sOrderBy = str_replace($sSortField . " " . $sLastSort, $sSortField . " " . $sThisSort, $sOrderBy);
				} else {
					if ($sOrderBy <> "") $sOrderBy .= ", ";
					$sOrderBy .= $sSortField . " " . $sThisSort;
				}
				$this->setSessionOrderBy($sOrderBy); // Save to Session
			} else {
				$this->setSessionOrderBy($sSortField . " " . $sThisSort); // Save to Session
			}
		} else {
			if (!$ctrl) $ofld->setSort("");
		}
	}

	// Table level SQL
	var $_SqlFrom = "";

	function getSqlFrom() { // From
		return ($this->_SqlFrom <> "") ? $this->_SqlFrom : "`audit`";
	}

	function SqlFrom() { // For backward compatibility
    	return $this->getSqlFrom();
	}

	function setSqlFrom($v) {
    	$this->_SqlFrom = $v;
	}
	var $_SqlSelect = "";

	function getSqlSelect() { // Select
		return ($this->_SqlSelect <> "") ? $this->_SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}

	function SqlSelect() { // For backward compatibility
    	return $this->getSqlSelect();
	}

	function setSqlSelect($v) {
    	$this->_SqlSelect = $v;
	}
	var $_SqlWhere = "";

	function getSqlWhere() { // Where
		$sWhere = ($this->_SqlWhere <> "") ? $this->_SqlWhere : "";
		$this->TableFilter = "";
		ew_AddFilter($sWhere, $this->TableFilter);
		return $sWhere;
	}

	function SqlWhere() { // For backward compatibility
    	return $this->getSqlWhere();
	}

	function setSqlWhere($v) {
    	$this->_SqlWhere = $v;
	}
	var $_SqlGroupBy = "";

	function getSqlGroupBy() { // Group By
		return ($this->_SqlGroupBy <> "") ? $this->_SqlGroupBy : "";
	}

	function SqlGroupBy() { // For backward compatibility
    	return $this->getSqlGroupBy();
	}

	function setSqlGroupBy($v) {
    	$this->_SqlGroupBy = $v;
	}
	var $_SqlHaving = "";

	function getSqlHaving() { // Having
		return ($this->_SqlHaving <> "") ? $this->_SqlHaving : "";
	}

	function SqlHaving() { // For backward compatibility
    	return $this->getSqlHaving();
	}

	function setSqlHaving($v) {
    	$this->_SqlHaving = $v;
	}
	var $_SqlOrderBy = "";

	function getSqlOrderBy() { // Order By
		return ($this->_SqlOrderBy <> "") ? $this->_SqlOrderBy : "";
	}

	function SqlOrderBy() { // For backward compatibility
    	return $this->getSqlOrderBy();
	}

	function setSqlOrderBy($v) {
    	$this->_SqlOrderBy = $v;
	}

	// Apply User ID filters
	function ApplyUserIDFilters($sFilter) {
		return $sFilter;
	}

	// Check if User ID security allows view all
	function UserIDAllow($id = "") {
		$allow = EW_USER_ID_ALLOW;
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get SQL
	function GetSQL($where, $orderby) {
		return ew_BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderby);
	}

	// Table SQL
	function SQL() {
		$sFilter = $this->CurrentFilter;
		$sFilter = $this->ApplyUserIDFilters($sFilter);
		$sSort = $this->getSessionOrderBy();
		return ew_BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$sFilter, $sSort);
	}

	// Table SQL with List page filter
	function SelectSQL() {
		$sFilter = $this->getSessionWhere();
		ew_AddFilter($sFilter, $this->CurrentFilter);
		$sFilter = $this->ApplyUserIDFilters($sFilter);
		$this->Recordset_Selecting($sFilter);
		$sSort = $this->getSessionOrderBy();
		return ew_BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $sFilter, $sSort);
	}

	// Get ORDER BY clause
	function GetOrderBy() {
		$sSort = $this->getSessionOrderBy();
		return ew_BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sSort);
	}

	// Try to get record count
	function TryGetRecordCount($sSql) {
		$cnt = -1;
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') && preg_match("/^SELECT \* FROM/i", $sSql)) {
			$sSql = "SELECT COUNT(*) FROM" . preg_replace('/^SELECT\s([\s\S]+)?\*\sFROM/i', "", $sSql);
			$sOrderBy = $this->GetOrderBy();
			if (substr($sSql, strlen($sOrderBy) * -1) == $sOrderBy)
				$sSql = substr($sSql, 0, strlen($sSql) - strlen($sOrderBy)); // Remove ORDER BY clause
		} else {
			$sSql = "SELECT COUNT(*) FROM (" . $sSql . ") EW_COUNT_TABLE";
		}
		$conn = &$this->Connection();
		if ($rs = $conn->Execute($sSql)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->Close();
			}
		}
		return intval($cnt);
	}

	// Get record count based on filter (for detail record count in master table pages)
	function LoadRecordCount($sFilter) {
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $sFilter;
		$this->Recordset_Selecting($this->CurrentFilter);

		//$sSql = $this->SQL();
		$sSql = $this->GetSQL($this->CurrentFilter, "");
		$cnt = $this->TryGetRecordCount($sSql);
		if ($cnt == -1) {
			if ($rs = $this->LoadRs($this->CurrentFilter)) {
				$cnt = $rs->RecordCount();
				$rs->Close();
			}
		}
		$this->CurrentFilter = $origFilter;
		return intval($cnt);
	}

	// Get record count (for current List page)
	function SelectRecordCount() {
		$sSql = $this->SelectSQL();
		$cnt = $this->TryGetRecordCount($sSql);
		if ($cnt == -1) {
			$conn = &$this->Connection();
			if ($rs = $conn->Execute($sSql)) {
				$cnt = $rs->RecordCount();
				$rs->Close();
			}
		}
		return intval($cnt);
	}

	// INSERT statement
	function InsertSQL(&$rs) {
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->FldIsCustom)
				continue;
			$names .= $this->fields[$name]->FldExpression . ",";
			$values .= ew_QuotedValue($value, $this->fields[$name]->FldDataType, $this->DBID) . ",";
		}
		while (substr($names, -1) == ",")
			$names = substr($names, 0, -1);
		while (substr($values, -1) == ",")
			$values = substr($values, 0, -1);
		return "INSERT INTO " . $this->UpdateTable . " ($names) VALUES ($values)";
	}

	// Insert
	function Insert(&$rs) {
		$conn = &$this->Connection();
		return $conn->Execute($this->InsertSQL($rs));
	}

	// UPDATE statement
	function UpdateSQL(&$rs, $where = "", $curfilter = TRUE) {
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->FldIsCustom)
				continue;
			$sql .= $this->fields[$name]->FldExpression . "=";
			$sql .= ew_QuotedValue($value, $this->fields[$name]->FldDataType, $this->DBID) . ",";
		}
		while (substr($sql, -1) == ",")
			$sql = substr($sql, 0, -1);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->ArrayToFilter($where);
		ew_AddFilter($filter, $where);
		if ($filter <> "")	$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	function Update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE) {
		$conn = &$this->Connection();
		return $conn->Execute($this->UpdateSQL($rs, $where, $curfilter));
	}

	// DELETE statement
	function DeleteSQL(&$rs, $where = "", $curfilter = TRUE) {
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->ArrayToFilter($where);
		if ($rs) {
			if (array_key_exists('auditID', $rs))
				ew_AddFilter($where, ew_QuotedName('auditID', $this->DBID) . '=' . ew_QuotedValue($rs['auditID'], $this->auditID->FldDataType, $this->DBID));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		ew_AddFilter($filter, $where);
		if ($filter <> "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	function Delete(&$rs, $where = "", $curfilter = TRUE) {
		$conn = &$this->Connection();
		return $conn->Execute($this->DeleteSQL($rs, $where, $curfilter));
	}

	// Key filter WHERE clause
	function SqlKeyFilter() {
		return "`auditID` = @auditID@";
	}

	// Key filter
	function KeyFilter() {
		$sKeyFilter = $this->SqlKeyFilter();
		if (!is_numeric($this->auditID->CurrentValue))
			$sKeyFilter = "0=1"; // Invalid key
		$sKeyFilter = str_replace("@auditID@", ew_AdjustSql($this->auditID->CurrentValue, $this->DBID), $sKeyFilter); // Replace key value
		return $sKeyFilter;
	}

	// Return page URL
	function getReturnUrl() {
		$name = EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_RETURN_URL;

		// Get referer URL automatically
		if (ew_ServerVar("HTTP_REFERER") <> "" && ew_ReferPage() <> ew_CurrentPage() && ew_ReferPage() <> "login.php") // Referer not same page or login page
			$_SESSION[$name] = ew_ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] <> "") {
			return $_SESSION[$name];
		} else {
			return "auditlist.php";
		}
	}

	function setReturnUrl($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_RETURN_URL] = $v;
	}

	// List URL
	function GetListUrl() {
		return "auditlist.php";
	}

	// View URL
	function GetViewUrl($parm = "") {
		if ($parm <> "")
			$url = $this->KeyUrl("auditview.php", $this->UrlParm($parm));
		else
			$url = $this->KeyUrl("auditview.php", $this->UrlParm(EW_TABLE_SHOW_DETAIL . "="));
		return $this->AddMasterUrl($url);
	}

	// Add URL
	function GetAddUrl($parm = "") {
		if ($parm <> "")
			$url = "auditadd.php?" . $this->UrlParm($parm);
		else
			$url = "auditadd.php";
		return $this->AddMasterUrl($url);
	}

	// Edit URL
	function GetEditUrl($parm = "") {
		$url = $this->KeyUrl("auditedit.php", $this->UrlParm($parm));
		return $this->AddMasterUrl($url);
	}

	// Inline edit URL
	function GetInlineEditUrl() {
		$url = $this->KeyUrl(ew_CurrentPage(), $this->UrlParm("a=edit"));
		return $this->AddMasterUrl($url);
	}

	// Copy URL
	function GetCopyUrl($parm = "") {
		$url = $this->KeyUrl("auditadd.php", $this->UrlParm($parm));
		return $this->AddMasterUrl($url);
	}

	// Inline copy URL
	function GetInlineCopyUrl() {
		$url = $this->KeyUrl(ew_CurrentPage(), $this->UrlParm("a=copy"));
		return $this->AddMasterUrl($url);
	}

	// Delete URL
	function GetDeleteUrl() {
		return $this->KeyUrl("auditdelete.php", $this->UrlParm());
	}

	// Add master url
	function AddMasterUrl($url) {
		return $url;
	}

	function KeyToJson() {
		$json = "";
		$json .= "auditID:" . ew_VarToJson($this->auditID->CurrentValue, "number", "'");
		return "{" . $json . "}";
	}

	// Add key value to URL
	function KeyUrl($url, $parm = "") {
		$sUrl = $url . "?";
		if ($parm <> "") $sUrl .= $parm . "&";
		if (!is_null($this->auditID->CurrentValue)) {
			$sUrl .= "auditID=" . urlencode($this->auditID->CurrentValue);
		} else {
			return "javascript:ew_Alert(ewLanguage.Phrase('InvalidRecord'));";
		}
		return $sUrl;
	}

	// Sort URL
	function SortUrl(&$fld) {
		if ($this->CurrentAction <> "" || $this->Export <> "" ||
			in_array($fld->FldType, array(128, 204, 205))) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$sUrlParm = $this->UrlParm("order=" . urlencode($fld->FldName) . "&amp;ordertype=" . $fld->ReverseSort());
			return ew_CurrentPage() . "?" . $sUrlParm;
		} else {
			return "";
		}
	}

	// Get record keys from $_POST/$_GET/$_SESSION
	function GetRecordKeys() {
		global $EW_COMPOSITE_KEY_SEPARATOR;
		$arKeys = array();
		$arKey = array();
		if (isset($_POST["key_m"])) {
			$arKeys = ew_StripSlashes($_POST["key_m"]);
			$cnt = count($arKeys);
		} elseif (isset($_GET["key_m"])) {
			$arKeys = ew_StripSlashes($_GET["key_m"]);
			$cnt = count($arKeys);
		} elseif (!empty($_GET) || !empty($_POST)) {
			$isPost = ew_IsHttpPost();
			if ($isPost && isset($_POST["auditID"]))
				$arKeys[] = ew_StripSlashes($_POST["auditID"]);
			elseif (isset($_GET["auditID"]))
				$arKeys[] = ew_StripSlashes($_GET["auditID"]);
			else
				$arKeys = NULL; // Do not setup

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = array();
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				if (!is_numeric($key))
					continue;
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get key filter
	function GetKeyFilter() {
		$arKeys = $this->GetRecordKeys();
		$sKeyFilter = "";
		foreach ($arKeys as $key) {
			if ($sKeyFilter <> "") $sKeyFilter .= " OR ";
			$this->auditID->CurrentValue = $key;
			$sKeyFilter .= "(" . $this->KeyFilter() . ")";
		}
		return $sKeyFilter;
	}

	// Load rows based on filter
	function &LoadRs($sFilter) {

		// Set up filter (SQL WHERE clause) and get return SQL
		//$this->CurrentFilter = $sFilter;
		//$sSql = $this->SQL();

		$sSql = $this->GetSQL($sFilter, "");
		$conn = &$this->Connection();
		$rs = $conn->Execute($sSql);
		return $rs;
	}

	// Load row values from recordset
	function LoadListRowValues(&$rs) {
		$this->auditID->setDbValue($rs->fields('auditID'));
		$this->audityear->setDbValue($rs->fields('audityear'));
		$this->issue->setDbValue($rs->fields('issue'));
		$this->description->setDbValue($rs->fields('description'));
		$this->risktype->setDbValue($rs->fields('risktype'));
		$this->risklevel->setDbValue($rs->fields('risklevel'));
		$this->jadrecommend->setDbValue($rs->fields('jadrecommend'));
		$this->jitresponse->setDbValue($rs->fields('jitresponse'));
		$this->ActionPlan->setDbValue($rs->fields('ActionPlan'));
		$this->oic1->setDbValue($rs->fields('oic1'));
		$this->oic2->setDbValue($rs->fields('oic2'));
		$this->oic3->setDbValue($rs->fields('oic3'));
		$this->targetdate->setDbValue($rs->fields('targetdate'));
		$this->status->setDbValue($rs->fields('status'));
		$this->Attachment->Upload->DbValue = $rs->fields('Attachment');
	}

	// Render list row values
	function RenderListRow() {
		global $Security, $gsLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

   // Common render codes
		// auditID
		// audityear
		// issue
		// description
		// risktype
		// risklevel
		// jadrecommend
		// jitresponse
		// ActionPlan
		// oic1
		// oic2
		// oic3
		// targetdate
		// status
		// Attachment
		// auditID

		$this->auditID->ViewValue = $this->auditID->CurrentValue;
		$this->auditID->ViewCustomAttributes = "";

		// audityear
		$this->audityear->ViewValue = $this->audityear->CurrentValue;
		$this->audityear->ViewCustomAttributes = "";

		// issue
		$this->issue->ViewValue = $this->issue->CurrentValue;
		$this->issue->ViewCustomAttributes = "";

		// description
		$this->description->ViewValue = $this->description->CurrentValue;
		$this->description->ViewCustomAttributes = "";

		// risktype
		$this->risktype->ViewValue = $this->risktype->CurrentValue;
		$this->risktype->ViewCustomAttributes = "";

		// risklevel
		if (strval($this->risklevel->CurrentValue) <> "") {
			$this->risklevel->ViewValue = $this->risklevel->OptionCaption($this->risklevel->CurrentValue);
		} else {
			$this->risklevel->ViewValue = NULL;
		}
		$this->risklevel->ViewCustomAttributes = "";

		// jadrecommend
		$this->jadrecommend->ViewValue = $this->jadrecommend->CurrentValue;
		$this->jadrecommend->ViewCustomAttributes = "";

		// jitresponse
		$this->jitresponse->ViewValue = $this->jitresponse->CurrentValue;
		$this->jitresponse->ViewCustomAttributes = "";

		// ActionPlan
		$this->ActionPlan->ViewValue = $this->ActionPlan->CurrentValue;
		$this->ActionPlan->ViewCustomAttributes = "";

		// oic1
		if (strval($this->oic1->CurrentValue) <> "") {
			$sFilterWrk = "`id`" . ew_SearchString("=", $this->oic1->CurrentValue, EW_DATATYPE_NUMBER, "");
		$sSqlWrk = "SELECT `id`, `Name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `staff`";
		$sWhereWrk = "";
		ew_AddFilter($sWhereWrk, $sFilterWrk);
		$this->Lookup_Selecting($this->oic1, $sWhereWrk); // Call Lookup selecting
		if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
			$rswrk = Conn()->Execute($sSqlWrk);
			if ($rswrk && !$rswrk->EOF) { // Lookup values found
				$arwrk = array();
				$arwrk[1] = $rswrk->fields('DispFld');
				$this->oic1->ViewValue = $this->oic1->DisplayValue($arwrk);
				$rswrk->Close();
			} else {
				$this->oic1->ViewValue = $this->oic1->CurrentValue;
			}
		} else {
			$this->oic1->ViewValue = NULL;
		}
		$this->oic1->ViewCustomAttributes = "";

		// oic2
		if (strval($this->oic2->CurrentValue) <> "") {
			$sFilterWrk = "`id`" . ew_SearchString("=", $this->oic2->CurrentValue, EW_DATATYPE_NUMBER, "");
		$sSqlWrk = "SELECT `id`, `Name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `staff`";
		$sWhereWrk = "";
		ew_AddFilter($sWhereWrk, $sFilterWrk);
		$this->Lookup_Selecting($this->oic2, $sWhereWrk); // Call Lookup selecting
		if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
			$rswrk = Conn()->Execute($sSqlWrk);
			if ($rswrk && !$rswrk->EOF) { // Lookup values found
				$arwrk = array();
				$arwrk[1] = $rswrk->fields('DispFld');
				$this->oic2->ViewValue = $this->oic2->DisplayValue($arwrk);
				$rswrk->Close();
			} else {
				$this->oic2->ViewValue = $this->oic2->CurrentValue;
			}
		} else {
			$this->oic2->ViewValue = NULL;
		}
		$this->oic2->ViewCustomAttributes = "";

		// oic3
		if (strval($this->oic3->CurrentValue) <> "") {
			$sFilterWrk = "`id`" . ew_SearchString("=", $this->oic3->CurrentValue, EW_DATATYPE_NUMBER, "");
		$sSqlWrk = "SELECT `id`, `Name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `staff`";
		$sWhereWrk = "";
		ew_AddFilter($sWhereWrk, $sFilterWrk);
		$this->Lookup_Selecting($this->oic3, $sWhereWrk); // Call Lookup selecting
		if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
			$rswrk = Conn()->Execute($sSqlWrk);
			if ($rswrk && !$rswrk->EOF) { // Lookup values found
				$arwrk = array();
				$arwrk[1] = $rswrk->fields('DispFld');
				$this->oic3->ViewValue = $this->oic3->DisplayValue($arwrk);
				$rswrk->Close();
			} else {
				$this->oic3->ViewValue = $this->oic3->CurrentValue;
			}
		} else {
			$this->oic3->ViewValue = NULL;
		}
		$this->oic3->ViewCustomAttributes = "";

		// targetdate
		$this->targetdate->ViewValue = $this->targetdate->CurrentValue;
		$this->targetdate->ViewValue = ew_FormatDateTime($this->targetdate->ViewValue, 7);
		$this->targetdate->ViewCustomAttributes = "";

		// status
		if (strval($this->status->CurrentValue) <> "") {
			$this->status->ViewValue = $this->status->OptionCaption($this->status->CurrentValue);
		} else {
			$this->status->ViewValue = NULL;
		}
		$this->status->ViewCustomAttributes = "";

		// Attachment
		$this->Attachment->UploadPath = "uploads/audit";
		if (!ew_Empty($this->Attachment->Upload->DbValue)) {
			$this->Attachment->ViewValue = $this->Attachment->Upload->DbValue;
		} else {
			$this->Attachment->ViewValue = "";
		}
		$this->Attachment->ViewCustomAttributes = "";

		// auditID
		$this->auditID->LinkCustomAttributes = "";
		$this->auditID->HrefValue = "";
		$this->auditID->TooltipValue = "";

		// audityear
		$this->audityear->LinkCustomAttributes = "";
		$this->audityear->HrefValue = "";
		$this->audityear->TooltipValue = "";

		// issue
		$this->issue->LinkCustomAttributes = "";
		$this->issue->HrefValue = "";
		$this->issue->TooltipValue = "";

		// description
		$this->description->LinkCustomAttributes = "";
		$this->description->HrefValue = "";
		$this->description->TooltipValue = "";

		// risktype
		$this->risktype->LinkCustomAttributes = "";
		$this->risktype->HrefValue = "";
		$this->risktype->TooltipValue = "";

		// risklevel
		$this->risklevel->LinkCustomAttributes = "";
		$this->risklevel->HrefValue = "";
		$this->risklevel->TooltipValue = "";

		// jadrecommend
		$this->jadrecommend->LinkCustomAttributes = "";
		$this->jadrecommend->HrefValue = "";
		$this->jadrecommend->TooltipValue = "";

		// jitresponse
		$this->jitresponse->LinkCustomAttributes = "";
		$this->jitresponse->HrefValue = "";
		$this->jitresponse->TooltipValue = "";

		// ActionPlan
		$this->ActionPlan->LinkCustomAttributes = "";
		$this->ActionPlan->HrefValue = "";
		$this->ActionPlan->TooltipValue = "";

		// oic1
		$this->oic1->LinkCustomAttributes = "";
		$this->oic1->HrefValue = "";
		$this->oic1->TooltipValue = "";

		// oic2
		$this->oic2->LinkCustomAttributes = "";
		$this->oic2->HrefValue = "";
		$this->oic2->TooltipValue = "";

		// oic3
		$this->oic3->LinkCustomAttributes = "";
		$this->oic3->HrefValue = "";
		$this->oic3->TooltipValue = "";

		// targetdate
		$this->targetdate->LinkCustomAttributes = "";
		$this->targetdate->HrefValue = "";
		$this->targetdate->TooltipValue = "";

		// status
		$this->status->LinkCustomAttributes = "";
		$this->status->HrefValue = "";
		$this->status->TooltipValue = "";

		// Attachment
		$this->Attachment->LinkCustomAttributes = "";
		$this->Attachment->HrefValue = "";
		$this->Attachment->HrefValue2 = $this->Attachment->UploadPath . $this->Attachment->Upload->DbValue;
		$this->Attachment->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Render edit row values
	function RenderEditRow() {
		global $Security, $gsLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// auditID
		$this->auditID->EditAttrs["class"] = "form-control";
		$this->auditID->EditCustomAttributes = "";
		$this->auditID->EditValue = $this->auditID->CurrentValue;
		$this->auditID->ViewCustomAttributes = "";

		// audityear
		$this->audityear->EditAttrs["class"] = "form-control";
		$this->audityear->EditCustomAttributes = "";
		$this->audityear->EditValue = $this->audityear->CurrentValue;
		$this->audityear->PlaceHolder = ew_RemoveHtml($this->audityear->FldCaption());

		// issue
		$this->issue->EditAttrs["class"] = "form-control";
		$this->issue->EditCustomAttributes = "";
		$this->issue->EditValue = $this->issue->CurrentValue;
		$this->issue->PlaceHolder = ew_RemoveHtml($this->issue->FldCaption());

		// description
		$this->description->EditAttrs["class"] = "form-control";
		$this->description->EditCustomAttributes = "";
		$this->description->EditValue = $this->description->CurrentValue;
		$this->description->PlaceHolder = ew_RemoveHtml($this->description->FldCaption());

		// risktype
		$this->risktype->EditAttrs["class"] = "form-control";
		$this->risktype->EditCustomAttributes = "";
		$this->risktype->EditValue = $this->risktype->CurrentValue;
		$this->risktype->PlaceHolder = ew_RemoveHtml($this->risktype->FldCaption());

		// risklevel
		$this->risklevel->EditCustomAttributes = "";
		$this->risklevel->EditValue = $this->risklevel->Options(FALSE);

		// jadrecommend
		$this->jadrecommend->EditAttrs["class"] = "form-control";
		$this->jadrecommend->EditCustomAttributes = "";
		$this->jadrecommend->EditValue = $this->jadrecommend->CurrentValue;
		$this->jadrecommend->PlaceHolder = ew_RemoveHtml($this->jadrecommend->FldCaption());

		// jitresponse
		$this->jitresponse->EditAttrs["class"] = "form-control";
		$this->jitresponse->EditCustomAttributes = "";
		$this->jitresponse->EditValue = $this->jitresponse->CurrentValue;
		$this->jitresponse->PlaceHolder = ew_RemoveHtml($this->jitresponse->FldCaption());

		// ActionPlan
		$this->ActionPlan->EditAttrs["class"] = "form-control";
		$this->ActionPlan->EditCustomAttributes = "";
		$this->ActionPlan->EditValue = $this->ActionPlan->CurrentValue;
		$this->ActionPlan->PlaceHolder = ew_RemoveHtml($this->ActionPlan->FldCaption());

		// oic1
		$this->oic1->EditAttrs["class"] = "form-control";
		$this->oic1->EditCustomAttributes = "";

		// oic2
		$this->oic2->EditAttrs["class"] = "form-control";
		$this->oic2->EditCustomAttributes = "";

		// oic3
		$this->oic3->EditAttrs["class"] = "form-control";
		$this->oic3->EditCustomAttributes = "";

		// targetdate
		$this->targetdate->EditAttrs["class"] = "form-control";
		$this->targetdate->EditCustomAttributes = "";
		$this->targetdate->EditValue = ew_FormatDateTime($this->targetdate->CurrentValue, 7);
		$this->targetdate->PlaceHolder = ew_RemoveHtml($this->targetdate->FldCaption());

		// status
		$this->status->EditCustomAttributes = "";
		$this->status->EditValue = $this->status->Options(FALSE);

		// Attachment
		$this->Attachment->EditAttrs["class"] = "form-control";
		$this->Attachment->EditCustomAttributes = "";
		$this->Attachment->UploadPath = "uploads/audit";
		if (!ew_Empty($this->Attachment->Upload->DbValue)) {
			$this->Attachment->EditValue = $this->Attachment->Upload->DbValue;
		} else {
			$this->Attachment->EditValue = "";
		}
		if (!ew_Empty($this->Attachment->CurrentValue))
			$this->Attachment->Upload->FileName = $this->Attachment->CurrentValue;

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	function AggregateListRowValues() {
	}

	// Aggregate list row (for rendering)
	function AggregateListRow() {

		// Call Row Rendered event
		$this->Row_Rendered();
	}
	var $ExportDoc;

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	function ExportDocument(&$Doc, &$Recordset, $StartRec, $StopRec, $ExportPageType = "") {
		if (!$Recordset || !$Doc)
			return;
		if (!$Doc->ExportCustom) {

			// Write header
			$Doc->ExportTableHeader();
			if ($Doc->Horizontal) { // Horizontal format, write header
				$Doc->BeginExportRow();
				if ($ExportPageType == "view") {
					if ($this->auditID->Exportable) $Doc->ExportCaption($this->auditID);
					if ($this->audityear->Exportable) $Doc->ExportCaption($this->audityear);
					if ($this->issue->Exportable) $Doc->ExportCaption($this->issue);
					if ($this->description->Exportable) $Doc->ExportCaption($this->description);
					if ($this->risktype->Exportable) $Doc->ExportCaption($this->risktype);
					if ($this->risklevel->Exportable) $Doc->ExportCaption($this->risklevel);
					if ($this->jadrecommend->Exportable) $Doc->ExportCaption($this->jadrecommend);
					if ($this->jitresponse->Exportable) $Doc->ExportCaption($this->jitresponse);
					if ($this->ActionPlan->Exportable) $Doc->ExportCaption($this->ActionPlan);
					if ($this->oic1->Exportable) $Doc->ExportCaption($this->oic1);
					if ($this->oic2->Exportable) $Doc->ExportCaption($this->oic2);
					if ($this->oic3->Exportable) $Doc->ExportCaption($this->oic3);
					if ($this->targetdate->Exportable) $Doc->ExportCaption($this->targetdate);
					if ($this->status->Exportable) $Doc->ExportCaption($this->status);
					if ($this->Attachment->Exportable) $Doc->ExportCaption($this->Attachment);
				} else {
					if ($this->auditID->Exportable) $Doc->ExportCaption($this->auditID);
					if ($this->audityear->Exportable) $Doc->ExportCaption($this->audityear);
					if ($this->risktype->Exportable) $Doc->ExportCaption($this->risktype);
					if ($this->risklevel->Exportable) $Doc->ExportCaption($this->risklevel);
					if ($this->oic1->Exportable) $Doc->ExportCaption($this->oic1);
					if ($this->oic2->Exportable) $Doc->ExportCaption($this->oic2);
					if ($this->oic3->Exportable) $Doc->ExportCaption($this->oic3);
					if ($this->targetdate->Exportable) $Doc->ExportCaption($this->targetdate);
					if ($this->status->Exportable) $Doc->ExportCaption($this->status);
					if ($this->Attachment->Exportable) $Doc->ExportCaption($this->Attachment);
				}
				$Doc->EndExportRow();
			}
		}

		// Move to first record
		$RecCnt = $StartRec - 1;
		if (!$Recordset->EOF) {
			$Recordset->MoveFirst();
			if ($StartRec > 1)
				$Recordset->Move($StartRec - 1);
		}
		while (!$Recordset->EOF && $RecCnt < $StopRec) {
			$RecCnt++;
			if (intval($RecCnt) >= intval($StartRec)) {
				$RowCnt = intval($RecCnt) - intval($StartRec) + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($RowCnt > 1 && ($RowCnt - 1) % $this->ExportPageBreakCount == 0)
						$Doc->ExportPageBreak();
				}
				$this->LoadListRowValues($Recordset);

				// Render row
				$this->RowType = EW_ROWTYPE_VIEW; // Render view
				$this->ResetAttrs();
				$this->RenderListRow();
				if (!$Doc->ExportCustom) {
					$Doc->BeginExportRow($RowCnt); // Allow CSS styles if enabled
					if ($ExportPageType == "view") {
						if ($this->auditID->Exportable) $Doc->ExportField($this->auditID);
						if ($this->audityear->Exportable) $Doc->ExportField($this->audityear);
						if ($this->issue->Exportable) $Doc->ExportField($this->issue);
						if ($this->description->Exportable) $Doc->ExportField($this->description);
						if ($this->risktype->Exportable) $Doc->ExportField($this->risktype);
						if ($this->risklevel->Exportable) $Doc->ExportField($this->risklevel);
						if ($this->jadrecommend->Exportable) $Doc->ExportField($this->jadrecommend);
						if ($this->jitresponse->Exportable) $Doc->ExportField($this->jitresponse);
						if ($this->ActionPlan->Exportable) $Doc->ExportField($this->ActionPlan);
						if ($this->oic1->Exportable) $Doc->ExportField($this->oic1);
						if ($this->oic2->Exportable) $Doc->ExportField($this->oic2);
						if ($this->oic3->Exportable) $Doc->ExportField($this->oic3);
						if ($this->targetdate->Exportable) $Doc->ExportField($this->targetdate);
						if ($this->status->Exportable) $Doc->ExportField($this->status);
						if ($this->Attachment->Exportable) $Doc->ExportField($this->Attachment);
					} else {
						if ($this->auditID->Exportable) $Doc->ExportField($this->auditID);
						if ($this->audityear->Exportable) $Doc->ExportField($this->audityear);
						if ($this->risktype->Exportable) $Doc->ExportField($this->risktype);
						if ($this->risklevel->Exportable) $Doc->ExportField($this->risklevel);
						if ($this->oic1->Exportable) $Doc->ExportField($this->oic1);
						if ($this->oic2->Exportable) $Doc->ExportField($this->oic2);
						if ($this->oic3->Exportable) $Doc->ExportField($this->oic3);
						if ($this->targetdate->Exportable) $Doc->ExportField($this->targetdate);
						if ($this->status->Exportable) $Doc->ExportField($this->status);
						if ($this->Attachment->Exportable) $Doc->ExportField($this->Attachment);
					}
					$Doc->EndExportRow();
				}
			}

			// Call Row Export server event
			if ($Doc->ExportCustom)
				$this->Row_Export($Recordset->fields);
			$Recordset->MoveNext();
		}
		if (!$Doc->ExportCustom) {
			$Doc->ExportTableFooter();
		}
	}

	// Get auto fill value
	function GetAutoFill($id, $val) {
		$rsarr = array();
		$rowcnt = 0;

		// Output
		if (is_array($rsarr) && $rowcnt > 0) {
			$fldcnt = count($rsarr[0]);
			for ($i = 0; $i < $rowcnt; $i++) {
				for ($j = 0; $j < $fldcnt; $j++) {
					$str = strval($rsarr[$i][$j]);
					$str = ew_ConvertToUtf8($str);
					if (isset($post["keepCRLF"])) {
						$str = str_replace(array("\r", "\n"), array("\\r", "\\n"), $str);
					} else {
						$str = str_replace(array("\r", "\n"), array(" ", " "), $str);
					}
					$rsarr[$i][$j] = $str;
				}
			}
			return ew_ArrayToJson($rsarr);
		} else {
			return FALSE;
		}
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here	
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here	
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here	
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending(&$Email, &$Args) {

		//var_dump($Email); var_dump($Args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->FldName, $fld->LookupFilters, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here	
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>); 

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>
