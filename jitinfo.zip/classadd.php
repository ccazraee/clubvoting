<?php
if (session_id() == "") session_start(); // Initialize Session data
ob_start(); // Turn on output buffering
?>
<?php include_once "ewcfg12.php" ?>
<?php include_once ((EW_USE_ADODB) ? "adodb5/adodb.inc.php" : "ewmysql12.php") ?>
<?php include_once "phpfn12.php" ?>
<?php include_once "classinfo.php" ?>
<?php include_once "staffinfo.php" ?>
<?php include_once "mtm_staff_classgridcls.php" ?>
<?php include_once "userfn12.php" ?>
<?php

//
// Page class
//

$class_add = NULL; // Initialize page object first

class cclass_add extends cclass {

	// Page ID
	var $PageID = 'add';

	// Project ID
	var $ProjectID = "{E654CCD7-163B-4B2E-BFA7-AC8697684A42}";

	// Table name
	var $TableName = 'class';

	// Page object name
	var $PageObjName = 'class_add';

	// Page name
	function PageName() {
		return ew_CurrentPage();
	}

	// Page URL
	function PageUrl() {
		$PageUrl = ew_CurrentPage() . "?";
		if ($this->UseTokenInUrl) $PageUrl .= "t=" . $this->TableVar . "&"; // Add page token
		return $PageUrl;
	}
    var $AuditTrailOnAdd = TRUE;
    var $AuditTrailOnEdit = FALSE;
    var $AuditTrailOnDelete = FALSE;
    var $AuditTrailOnView = FALSE;
    var $AuditTrailOnViewData = FALSE;
    var $AuditTrailOnSearch = FALSE;

	// Message
	function getMessage() {
		return @$_SESSION[EW_SESSION_MESSAGE];
	}

	function setMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_MESSAGE], $v);
	}

	function getFailureMessage() {
		return @$_SESSION[EW_SESSION_FAILURE_MESSAGE];
	}

	function setFailureMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_FAILURE_MESSAGE], $v);
	}

	function getSuccessMessage() {
		return @$_SESSION[EW_SESSION_SUCCESS_MESSAGE];
	}

	function setSuccessMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_SUCCESS_MESSAGE], $v);
	}

	function getWarningMessage() {
		return @$_SESSION[EW_SESSION_WARNING_MESSAGE];
	}

	function setWarningMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_WARNING_MESSAGE], $v);
	}

	// Methods to clear message
	function ClearMessage() {
		$_SESSION[EW_SESSION_MESSAGE] = "";
	}

	function ClearFailureMessage() {
		$_SESSION[EW_SESSION_FAILURE_MESSAGE] = "";
	}

	function ClearSuccessMessage() {
		$_SESSION[EW_SESSION_SUCCESS_MESSAGE] = "";
	}

	function ClearWarningMessage() {
		$_SESSION[EW_SESSION_WARNING_MESSAGE] = "";
	}

	function ClearMessages() {
		$_SESSION[EW_SESSION_MESSAGE] = "";
		$_SESSION[EW_SESSION_FAILURE_MESSAGE] = "";
		$_SESSION[EW_SESSION_SUCCESS_MESSAGE] = "";
		$_SESSION[EW_SESSION_WARNING_MESSAGE] = "";
	}

	// Show message
	function ShowMessage() {
		$hidden = FALSE;
		$html = "";

		// Message
		$sMessage = $this->getMessage();
		$this->Message_Showing($sMessage, "");
		if ($sMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sMessage;
			$html .= "<div class=\"alert alert-info ewInfo\">" . $sMessage . "</div>";
			$_SESSION[EW_SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$sWarningMessage = $this->getWarningMessage();
		$this->Message_Showing($sWarningMessage, "warning");
		if ($sWarningMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sWarningMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sWarningMessage;
			$html .= "<div class=\"alert alert-warning ewWarning\">" . $sWarningMessage . "</div>";
			$_SESSION[EW_SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$sSuccessMessage = $this->getSuccessMessage();
		$this->Message_Showing($sSuccessMessage, "success");
		if ($sSuccessMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sSuccessMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sSuccessMessage;
			$html .= "<div class=\"alert alert-success ewSuccess\">" . $sSuccessMessage . "</div>";
			$_SESSION[EW_SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$sErrorMessage = $this->getFailureMessage();
		$this->Message_Showing($sErrorMessage, "failure");
		if ($sErrorMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sErrorMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sErrorMessage;
			$html .= "<div class=\"alert alert-danger ewError\">" . $sErrorMessage . "</div>";
			$_SESSION[EW_SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo "<div class=\"ewMessageDialog\"" . (($hidden) ? " style=\"display: none;\"" : "") . ">" . $html . "</div>";
	}
	var $PageHeader;
	var $PageFooter;

	// Show Page Header
	function ShowPageHeader() {
		$sHeader = $this->PageHeader;
		$this->Page_DataRendering($sHeader);
		if ($sHeader <> "") { // Header exists, display
			echo "<p>" . $sHeader . "</p>";
		}
	}

	// Show Page Footer
	function ShowPageFooter() {
		$sFooter = $this->PageFooter;
		$this->Page_DataRendered($sFooter);
		if ($sFooter <> "") { // Footer exists, display
			echo "<p>" . $sFooter . "</p>";
		}
	}

	// Validate page request
	function IsPageRequest() {
		global $objForm;
		if ($this->UseTokenInUrl) {
			if ($objForm)
				return ($this->TableVar == $objForm->GetValue("t"));
			if (@$_GET["t"] <> "")
				return ($this->TableVar == $_GET["t"]);
		} else {
			return TRUE;
		}
	}
	var $Token = "";
	var $TokenTimeout = 0;
	var $CheckToken = EW_CHECK_TOKEN;
	var $CheckTokenFn = "ew_CheckToken";
	var $CreateTokenFn = "ew_CreateToken";

	// Valid Post
	function ValidPost() {
		if (!$this->CheckToken || !ew_IsHttpPost())
			return TRUE;
		if (!isset($_POST[EW_TOKEN_NAME]))
			return FALSE;
		$fn = $this->CheckTokenFn;
		if (is_callable($fn))
			return $fn($_POST[EW_TOKEN_NAME], $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	function CreateToken() {
		global $gsToken;
		if ($this->CheckToken) {
			$fn = $this->CreateTokenFn;
			if ($this->Token == "" && is_callable($fn)) // Create token
				$this->Token = $fn();
			$gsToken = $this->Token; // Save to global variable
		}
	}

	//
	// Page class constructor
	//
	function __construct() {
		global $conn, $Language;
		global $UserTable, $UserTableConn;
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = ew_SessionTimeoutTime();

		// Language object
		if (!isset($Language)) $Language = new cLanguage();

		// Parent constuctor
		parent::__construct();

		// Table object (class)
		if (!isset($GLOBALS["class"]) || get_class($GLOBALS["class"]) == "cclass") {
			$GLOBALS["class"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["class"];
		}

		// Table object (staff)
		if (!isset($GLOBALS['staff'])) $GLOBALS['staff'] = new cstaff();

		// Page ID
		if (!defined("EW_PAGE_ID"))
			define("EW_PAGE_ID", 'add', TRUE);

		// Table name (for backward compatibility)
		if (!defined("EW_TABLE_NAME"))
			define("EW_TABLE_NAME", 'class', TRUE);

		// Start timer
		if (!isset($GLOBALS["gTimer"])) $GLOBALS["gTimer"] = new cTimer();

		// Open connection
		if (!isset($conn)) $conn = ew_Connect($this->DBID);

		// User table object (staff)
		if (!isset($UserTable)) {
			$UserTable = new cstaff();
			$UserTableConn = Conn($UserTable->DBID);
		}
	}

	// 
	//  Page_Init
	//
	function Page_Init() {
		global $gsExport, $gsCustomExport, $gsExportFile, $UserProfile, $Language, $Security, $objForm;

		// Security
		$Security = new cAdvancedSecurity();
		if (!$Security->IsLoggedIn()) $Security->AutoLogin();
		if ($Security->IsLoggedIn()) $Security->TablePermission_Loading();
		$Security->LoadCurrentUserLevel($this->ProjectID . $this->TableName);
		if ($Security->IsLoggedIn()) $Security->TablePermission_Loaded();
		if (!$Security->CanAdd()) {
			$Security->SaveLastUrl();
			$this->setFailureMessage(ew_DeniedMsg()); // Set no permission
			$this->Page_Terminate(ew_GetUrl("classlist.php"));
		}
		if ($Security->IsLoggedIn()) {
			$Security->UserID_Loading();
			$Security->LoadUserID();
			$Security->UserID_Loaded();
		}

		// Create form object
		$objForm = new cFormObj();
		$this->CurrentAction = (@$_GET["a"] <> "") ? $_GET["a"] : @$_POST["a_list"]; // Set up current action

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->ValidPost()) {
			echo $Language->Phrase("InvalidPostRequest");
			$this->Page_Terminate();
			exit();
		}

		// Process auto fill
		if (@$_POST["ajax"] == "autofill") {

			// Process auto fill for detail table 'mtm_staff_class'
			if (@$_POST["grid"] == "fmtm_staff_classgrid") {
				if (!isset($GLOBALS["mtm_staff_class_grid"])) $GLOBALS["mtm_staff_class_grid"] = new cmtm_staff_class_grid;
				$GLOBALS["mtm_staff_class_grid"]->Page_Init();
				$this->Page_Terminate();
				exit();
			}
			$results = $this->GetAutoFill(@$_POST["name"], @$_POST["q"]);
			if ($results) {

				// Clean output buffer
				if (!EW_DEBUG_ENABLED && ob_get_length())
					ob_end_clean();
				echo $results;
				$this->Page_Terminate();
				exit();
			}
		}

		// Create Token
		$this->CreateToken();
	}

	//
	// Page_Terminate
	//
	function Page_Terminate($url = "") {
		global $gsExportFile, $gTmpImages;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $EW_EXPORT, $class;
		if ($this->CustomExport <> "" && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, $EW_EXPORT)) {
				$sContent = ob_get_contents();
			if ($gsExportFile == "") $gsExportFile = $this->TableVar;
			$class = $EW_EXPORT[$this->CustomExport];
			if (class_exists($class)) {
				$doc = new $class($class);
				$doc->Text = $sContent;
				if ($this->Export == "email")
					echo $this->ExportEmail($doc->Text);
				else
					$doc->Export();
				ew_DeleteTmpImages(); // Delete temp images
				exit();
			}
		}
		$this->Page_Redirecting($url);

		 // Close connection
		ew_CloseConn();

		// Go to URL if specified
		if ($url <> "") {
			if (!EW_DEBUG_ENABLED && ob_get_length())
				ob_end_clean();
			header("Location: " . $url);
		}
		exit();
	}
	var $FormClassName = "form-horizontal ewForm ewAddForm";
	var $DbMasterFilter = "";
	var $DbDetailFilter = "";
	var $StartRec;
	var $Priv = 0;
	var $OldRecordset;
	var $CopyRecord;

	// 
	// Page main
	//
	function Page_Main() {
		global $objForm, $Language, $gsFormError;

		// Process form if post back
		if (@$_POST["a_add"] <> "") {
			$this->CurrentAction = $_POST["a_add"]; // Get form action
			$this->CopyRecord = $this->LoadOldRecord(); // Load old recordset
			$this->LoadFormValues(); // Load form values
		} else { // Not post back

			// Load key values from QueryString
			$this->CopyRecord = TRUE;
			if (@$_GET["id"] != "") {
				$this->id->setQueryStringValue($_GET["id"]);
				$this->setKey("id", $this->id->CurrentValue); // Set up key
			} else {
				$this->setKey("id", ""); // Clear key
				$this->CopyRecord = FALSE;
			}
			if ($this->CopyRecord) {
				$this->CurrentAction = "C"; // Copy record
			} else {
				$this->CurrentAction = "I"; // Display blank record
			}
		}

		// Set up Breadcrumb
		$this->SetupBreadcrumb();

		// Set up detail parameters
		$this->SetUpDetailParms();

		// Validate form if post back
		if (@$_POST["a_add"] <> "") {
			if (!$this->ValidateForm()) {
				$this->CurrentAction = "I"; // Form error, reset action
				$this->EventCancelled = TRUE; // Event cancelled
				$this->RestoreFormValues(); // Restore form values
				$this->setFailureMessage($gsFormError);
			}
		} else {
			if ($this->CurrentAction == "I") // Load default values for blank record
				$this->LoadDefaultValues();
		}

		// Perform action based on action code
		switch ($this->CurrentAction) {
			case "I": // Blank record, no action required
				break;
			case "C": // Copy an existing record
				if (!$this->LoadRow()) { // Load record based on key
					if ($this->getFailureMessage() == "") $this->setFailureMessage($Language->Phrase("NoRecord")); // No record found
					$this->Page_Terminate("classlist.php"); // No matching record, return to list
				}

				// Set up detail parameters
				$this->SetUpDetailParms();
				break;
			case "A": // Add new record
				$this->SendEmail = TRUE; // Send email on add success
				if ($this->AddRow($this->OldRecordset)) { // Add successful
					if ($this->getSuccessMessage() == "")
						$this->setSuccessMessage($Language->Phrase("AddSuccess")); // Set up success message
					$sReturnUrl = $this->GetViewUrl();
					if (ew_GetPageName($sReturnUrl) == "classlist.php")
						$sReturnUrl = $this->AddMasterUrl($sReturnUrl); // List page, return to list page with correct master key if necessary
					elseif (ew_GetPageName($sReturnUrl) == "classview.php")
						$sReturnUrl = $this->GetViewUrl(); // View page, return to view page with keyurl directly
					$this->Page_Terminate($sReturnUrl); // Clean up and return
				} else {
					$this->EventCancelled = TRUE; // Event cancelled
					$this->RestoreFormValues(); // Add failed, restore form values

					// Set up detail parameters
					$this->SetUpDetailParms();
				}
		}

		// Render row based on row type
		$this->RowType = EW_ROWTYPE_ADD; // Render add type

		// Render row
		$this->ResetAttrs();
		$this->RenderRow();
	}

	// Get upload files
	function GetUploadFiles() {
		global $objForm, $Language;

		// Get upload data
		$this->documents->Upload->Index = $objForm->Index;
		$this->documents->Upload->UploadFile();
		$this->documents->CurrentValue = $this->documents->Upload->FileName;
	}

	// Load default values
	function LoadDefaultValues() {
		$this->classname->CurrentValue = NULL;
		$this->classname->OldValue = $this->classname->CurrentValue;
		$this->StartDate->CurrentValue = NULL;
		$this->StartDate->OldValue = $this->StartDate->CurrentValue;
		$this->EndDate->CurrentValue = NULL;
		$this->EndDate->OldValue = $this->EndDate->CurrentValue;
		$this->allday->CurrentValue = "YES";
		$this->starttime->CurrentValue = "09:00:00";
		$this->endtime->CurrentValue = "17:00:00";
		$this->category->CurrentValue = NULL;
		$this->category->OldValue = $this->category->CurrentValue;
		$this->Venue->CurrentValue = NULL;
		$this->Venue->OldValue = $this->Venue->CurrentValue;
		$this->Organizer->CurrentValue = NULL;
		$this->Organizer->OldValue = $this->Organizer->CurrentValue;
		$this->Payment->CurrentValue = NULL;
		$this->Payment->OldValue = $this->Payment->CurrentValue;
		$this->Fees->CurrentValue = NULL;
		$this->Fees->OldValue = $this->Fees->CurrentValue;
		$this->notes->CurrentValue = NULL;
		$this->notes->OldValue = $this->notes->CurrentValue;
		$this->documents->Upload->DbValue = NULL;
		$this->documents->OldValue = $this->documents->Upload->DbValue;
		$this->documents->CurrentValue = NULL; // Clear file related field
	}

	// Load form values
	function LoadFormValues() {

		// Load from form
		global $objForm;
		$this->GetUploadFiles(); // Get upload files
		if (!$this->classname->FldIsDetailKey) {
			$this->classname->setFormValue($objForm->GetValue("x_classname"));
		}
		if (!$this->StartDate->FldIsDetailKey) {
			$this->StartDate->setFormValue($objForm->GetValue("x_StartDate"));
			$this->StartDate->CurrentValue = ew_UnFormatDateTime($this->StartDate->CurrentValue, 7);
		}
		if (!$this->EndDate->FldIsDetailKey) {
			$this->EndDate->setFormValue($objForm->GetValue("x_EndDate"));
			$this->EndDate->CurrentValue = ew_UnFormatDateTime($this->EndDate->CurrentValue, 7);
		}
		if (!$this->allday->FldIsDetailKey) {
			$this->allday->setFormValue($objForm->GetValue("x_allday"));
		}
		if (!$this->starttime->FldIsDetailKey) {
			$this->starttime->setFormValue($objForm->GetValue("x_starttime"));
		}
		if (!$this->endtime->FldIsDetailKey) {
			$this->endtime->setFormValue($objForm->GetValue("x_endtime"));
		}
		if (!$this->category->FldIsDetailKey) {
			$this->category->setFormValue($objForm->GetValue("x_category"));
		}
		if (!$this->Venue->FldIsDetailKey) {
			$this->Venue->setFormValue($objForm->GetValue("x_Venue"));
		}
		if (!$this->Organizer->FldIsDetailKey) {
			$this->Organizer->setFormValue($objForm->GetValue("x_Organizer"));
		}
		if (!$this->Payment->FldIsDetailKey) {
			$this->Payment->setFormValue($objForm->GetValue("x_Payment"));
		}
		if (!$this->Fees->FldIsDetailKey) {
			$this->Fees->setFormValue($objForm->GetValue("x_Fees"));
		}
		if (!$this->notes->FldIsDetailKey) {
			$this->notes->setFormValue($objForm->GetValue("x_notes"));
		}
	}

	// Restore form values
	function RestoreFormValues() {
		global $objForm;
		$this->LoadOldRecord();
		$this->classname->CurrentValue = $this->classname->FormValue;
		$this->StartDate->CurrentValue = $this->StartDate->FormValue;
		$this->StartDate->CurrentValue = ew_UnFormatDateTime($this->StartDate->CurrentValue, 7);
		$this->EndDate->CurrentValue = $this->EndDate->FormValue;
		$this->EndDate->CurrentValue = ew_UnFormatDateTime($this->EndDate->CurrentValue, 7);
		$this->allday->CurrentValue = $this->allday->FormValue;
		$this->starttime->CurrentValue = $this->starttime->FormValue;
		$this->endtime->CurrentValue = $this->endtime->FormValue;
		$this->category->CurrentValue = $this->category->FormValue;
		$this->Venue->CurrentValue = $this->Venue->FormValue;
		$this->Organizer->CurrentValue = $this->Organizer->FormValue;
		$this->Payment->CurrentValue = $this->Payment->FormValue;
		$this->Fees->CurrentValue = $this->Fees->FormValue;
		$this->notes->CurrentValue = $this->notes->FormValue;
	}

	// Load row based on key values
	function LoadRow() {
		global $Security, $Language;
		$sFilter = $this->KeyFilter();

		// Call Row Selecting event
		$this->Row_Selecting($sFilter);

		// Load SQL based on filter
		$this->CurrentFilter = $sFilter;
		$sSql = $this->SQL();
		$conn = &$this->Connection();
		$res = FALSE;
		$rs = ew_LoadRecordset($sSql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->LoadRowValues($rs); // Load row values
			$rs->Close();
		}
		return $res;
	}

	// Load row values from recordset
	function LoadRowValues(&$rs) {
		if (!$rs || $rs->EOF) return;

		// Call Row Selected event
		$row = &$rs->fields;
		$this->Row_Selected($row);
		$this->id->setDbValue($rs->fields('id'));
		$this->classname->setDbValue($rs->fields('classname'));
		$this->StartDate->setDbValue($rs->fields('StartDate'));
		$this->EndDate->setDbValue($rs->fields('EndDate'));
		$this->allday->setDbValue($rs->fields('allday'));
		$this->starttime->setDbValue($rs->fields('starttime'));
		$this->endtime->setDbValue($rs->fields('endtime'));
		$this->category->setDbValue($rs->fields('category'));
		$this->Venue->setDbValue($rs->fields('Venue'));
		$this->Organizer->setDbValue($rs->fields('Organizer'));
		$this->Payment->setDbValue($rs->fields('Payment'));
		$this->Fees->setDbValue($rs->fields('Fees'));
		$this->notes->setDbValue($rs->fields('notes'));
		$this->documents->Upload->DbValue = $rs->fields('documents');
		$this->documents->CurrentValue = $this->documents->Upload->DbValue;
	}

	// Load DbValue from recordset
	function LoadDbValues(&$rs) {
		if (!$rs || !is_array($rs) && $rs->EOF) return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->id->DbValue = $row['id'];
		$this->classname->DbValue = $row['classname'];
		$this->StartDate->DbValue = $row['StartDate'];
		$this->EndDate->DbValue = $row['EndDate'];
		$this->allday->DbValue = $row['allday'];
		$this->starttime->DbValue = $row['starttime'];
		$this->endtime->DbValue = $row['endtime'];
		$this->category->DbValue = $row['category'];
		$this->Venue->DbValue = $row['Venue'];
		$this->Organizer->DbValue = $row['Organizer'];
		$this->Payment->DbValue = $row['Payment'];
		$this->Fees->DbValue = $row['Fees'];
		$this->notes->DbValue = $row['notes'];
		$this->documents->Upload->DbValue = $row['documents'];
	}

	// Load old record
	function LoadOldRecord() {

		// Load key values from Session
		$bValidKey = TRUE;
		if (strval($this->getKey("id")) <> "")
			$this->id->CurrentValue = $this->getKey("id"); // id
		else
			$bValidKey = FALSE;

		// Load old recordset
		if ($bValidKey) {
			$this->CurrentFilter = $this->KeyFilter();
			$sSql = $this->SQL();
			$conn = &$this->Connection();
			$this->OldRecordset = ew_LoadRecordset($sSql, $conn);
			$this->LoadRowValues($this->OldRecordset); // Load row values
		} else {
			$this->OldRecordset = NULL;
		}
		return $bValidKey;
	}

	// Render row values based on field settings
	function RenderRow() {
		global $Security, $Language, $gsLanguage;

		// Initialize URLs
		// Convert decimal values if posted back

		if ($this->Fees->FormValue == $this->Fees->CurrentValue && is_numeric(ew_StrToFloat($this->Fees->CurrentValue)))
			$this->Fees->CurrentValue = ew_StrToFloat($this->Fees->CurrentValue);

		// Call Row_Rendering event
		$this->Row_Rendering();

		// Common render codes for all row types
		// id
		// classname
		// StartDate
		// EndDate
		// allday
		// starttime
		// endtime
		// category
		// Venue
		// Organizer
		// Payment
		// Fees
		// notes
		// documents

		if ($this->RowType == EW_ROWTYPE_VIEW) { // View row

		// id
		$this->id->ViewValue = $this->id->CurrentValue;
		$this->id->ViewCustomAttributes = "";

		// classname
		$this->classname->ViewValue = $this->classname->CurrentValue;
		$this->classname->ViewCustomAttributes = "";

		// StartDate
		$this->StartDate->ViewValue = $this->StartDate->CurrentValue;
		$this->StartDate->ViewValue = ew_FormatDateTime($this->StartDate->ViewValue, 7);
		$this->StartDate->ViewCustomAttributes = "";

		// EndDate
		$this->EndDate->ViewValue = $this->EndDate->CurrentValue;
		$this->EndDate->ViewValue = ew_FormatDateTime($this->EndDate->ViewValue, 7);
		$this->EndDate->ViewCustomAttributes = "";

		// allday
		if (strval($this->allday->CurrentValue) <> "") {
			$this->allday->ViewValue = "";
			$arwrk = explode(",", strval($this->allday->CurrentValue));
			$cnt = count($arwrk);
			for ($ari = 0; $ari < $cnt; $ari++) {
				$this->allday->ViewValue .= $this->allday->OptionCaption(trim($arwrk[$ari]));
				if ($ari < $cnt-1) $this->allday->ViewValue .= ew_ViewOptionSeparator($ari);
			}
		} else {
			$this->allday->ViewValue = NULL;
		}
		$this->allday->ViewCustomAttributes = "";

		// starttime
		$this->starttime->ViewValue = $this->starttime->CurrentValue;
		$this->starttime->ViewValue = ew_FormatDateTime($this->starttime->ViewValue, 4);
		$this->starttime->ViewCustomAttributes = "";

		// endtime
		$this->endtime->ViewValue = $this->endtime->CurrentValue;
		$this->endtime->ViewValue = ew_FormatDateTime($this->endtime->ViewValue, 7);
		$this->endtime->ViewCustomAttributes = "";

		// category
		if (strval($this->category->CurrentValue) <> "") {
			$sFilterWrk = "`id`" . ew_SearchString("=", $this->category->CurrentValue, EW_DATATYPE_NUMBER, "");
		$sSqlWrk = "SELECT `id`, `ClassCategories` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `lkp_class_categories`";
		$sWhereWrk = "";
		ew_AddFilter($sWhereWrk, $sFilterWrk);
		$this->Lookup_Selecting($this->category, $sWhereWrk); // Call Lookup selecting
		if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
			$rswrk = Conn()->Execute($sSqlWrk);
			if ($rswrk && !$rswrk->EOF) { // Lookup values found
				$arwrk = array();
				$arwrk[1] = $rswrk->fields('DispFld');
				$this->category->ViewValue = $this->category->DisplayValue($arwrk);
				$rswrk->Close();
			} else {
				$this->category->ViewValue = $this->category->CurrentValue;
			}
		} else {
			$this->category->ViewValue = NULL;
		}
		$this->category->ViewCustomAttributes = "";

		// Venue
		$this->Venue->ViewValue = $this->Venue->CurrentValue;
		$this->Venue->ViewCustomAttributes = "";

		// Organizer
		$this->Organizer->ViewValue = $this->Organizer->CurrentValue;
		$this->Organizer->ViewCustomAttributes = "";

		// Payment
		if (strval($this->Payment->CurrentValue) <> "") {
			$this->Payment->ViewValue = $this->Payment->OptionCaption($this->Payment->CurrentValue);
		} else {
			$this->Payment->ViewValue = NULL;
		}
		$this->Payment->ViewCustomAttributes = "";

		// Fees
		$this->Fees->ViewValue = $this->Fees->CurrentValue;
		$this->Fees->ViewValue = ew_FormatCurrency($this->Fees->ViewValue, 0, -2, -2, -2);
		$this->Fees->ViewCustomAttributes = "";

		// notes
		$this->notes->ViewValue = $this->notes->CurrentValue;
		$this->notes->ViewCustomAttributes = "";

		// documents
		$this->documents->UploadPath = "uploads/trainingdocuments";
		if (!ew_Empty($this->documents->Upload->DbValue)) {
			$this->documents->ViewValue = $this->documents->Upload->DbValue;
		} else {
			$this->documents->ViewValue = "";
		}
		$this->documents->ViewCustomAttributes = "";

			// classname
			$this->classname->LinkCustomAttributes = "";
			$this->classname->HrefValue = "";
			$this->classname->TooltipValue = "";

			// StartDate
			$this->StartDate->LinkCustomAttributes = "";
			$this->StartDate->HrefValue = "";
			$this->StartDate->TooltipValue = "";

			// EndDate
			$this->EndDate->LinkCustomAttributes = "";
			$this->EndDate->HrefValue = "";
			$this->EndDate->TooltipValue = "";

			// allday
			$this->allday->LinkCustomAttributes = "";
			$this->allday->HrefValue = "";
			$this->allday->TooltipValue = "";

			// starttime
			$this->starttime->LinkCustomAttributes = "";
			$this->starttime->HrefValue = "";
			$this->starttime->TooltipValue = "";

			// endtime
			$this->endtime->LinkCustomAttributes = "";
			$this->endtime->HrefValue = "";
			$this->endtime->TooltipValue = "";

			// category
			$this->category->LinkCustomAttributes = "";
			$this->category->HrefValue = "";
			$this->category->TooltipValue = "";

			// Venue
			$this->Venue->LinkCustomAttributes = "";
			$this->Venue->HrefValue = "";
			$this->Venue->TooltipValue = "";

			// Organizer
			$this->Organizer->LinkCustomAttributes = "";
			$this->Organizer->HrefValue = "";
			$this->Organizer->TooltipValue = "";

			// Payment
			$this->Payment->LinkCustomAttributes = "";
			$this->Payment->HrefValue = "";
			$this->Payment->TooltipValue = "";

			// Fees
			$this->Fees->LinkCustomAttributes = "";
			$this->Fees->HrefValue = "";
			$this->Fees->TooltipValue = "";

			// notes
			$this->notes->LinkCustomAttributes = "";
			$this->notes->HrefValue = "";
			$this->notes->TooltipValue = "";

			// documents
			$this->documents->LinkCustomAttributes = "";
			$this->documents->HrefValue = "";
			$this->documents->HrefValue2 = $this->documents->UploadPath . $this->documents->Upload->DbValue;
			$this->documents->TooltipValue = "";
		} elseif ($this->RowType == EW_ROWTYPE_ADD) { // Add row

			// classname
			$this->classname->EditAttrs["class"] = "form-control";
			$this->classname->EditCustomAttributes = "";
			$this->classname->EditValue = ew_HtmlEncode($this->classname->CurrentValue);
			$this->classname->PlaceHolder = ew_RemoveHtml($this->classname->FldCaption());

			// StartDate
			$this->StartDate->EditAttrs["class"] = "form-control";
			$this->StartDate->EditCustomAttributes = "";
			$this->StartDate->EditValue = ew_HtmlEncode(ew_FormatDateTime($this->StartDate->CurrentValue, 7));
			$this->StartDate->PlaceHolder = ew_RemoveHtml($this->StartDate->FldCaption());

			// EndDate
			$this->EndDate->EditAttrs["class"] = "form-control";
			$this->EndDate->EditCustomAttributes = "";
			$this->EndDate->EditValue = ew_HtmlEncode(ew_FormatDateTime($this->EndDate->CurrentValue, 7));
			$this->EndDate->PlaceHolder = ew_RemoveHtml($this->EndDate->FldCaption());

			// allday
			$this->allday->EditCustomAttributes = "";
			$this->allday->EditValue = $this->allday->Options(FALSE);

			// starttime
			$this->starttime->EditAttrs["class"] = "form-control";
			$this->starttime->EditCustomAttributes = "";
			$this->starttime->EditValue = ew_HtmlEncode($this->starttime->CurrentValue);
			$this->starttime->PlaceHolder = ew_RemoveHtml($this->starttime->FldCaption());

			// endtime
			$this->endtime->EditAttrs["class"] = "form-control";
			$this->endtime->EditCustomAttributes = "";
			$this->endtime->EditValue = ew_HtmlEncode($this->endtime->CurrentValue);
			$this->endtime->PlaceHolder = ew_RemoveHtml($this->endtime->FldCaption());

			// category
			$this->category->EditAttrs["class"] = "form-control";
			$this->category->EditCustomAttributes = "";
			if (trim(strval($this->category->CurrentValue)) == "") {
				$sFilterWrk = "0=1";
			} else {
				$sFilterWrk = "`id`" . ew_SearchString("=", $this->category->CurrentValue, EW_DATATYPE_NUMBER, "");
			}
			$sSqlWrk = "SELECT `id`, `ClassCategories` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld`, '' AS `SelectFilterFld`, '' AS `SelectFilterFld2`, '' AS `SelectFilterFld3`, '' AS `SelectFilterFld4` FROM `lkp_class_categories`";
			$sWhereWrk = "";
			ew_AddFilter($sWhereWrk, $sFilterWrk);
			$this->Lookup_Selecting($this->category, $sWhereWrk); // Call Lookup selecting
			if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
			$rswrk = Conn()->Execute($sSqlWrk);
			$arwrk = ($rswrk) ? $rswrk->GetRows() : array();
			if ($rswrk) $rswrk->Close();
			array_unshift($arwrk, array("", $Language->Phrase("PleaseSelect"), "", "", "", "", "", "", ""));
			$this->category->EditValue = $arwrk;

			// Venue
			$this->Venue->EditAttrs["class"] = "form-control";
			$this->Venue->EditCustomAttributes = "";
			$this->Venue->EditValue = ew_HtmlEncode($this->Venue->CurrentValue);
			$this->Venue->PlaceHolder = ew_RemoveHtml($this->Venue->FldCaption());

			// Organizer
			$this->Organizer->EditAttrs["class"] = "form-control";
			$this->Organizer->EditCustomAttributes = "";
			$this->Organizer->EditValue = ew_HtmlEncode($this->Organizer->CurrentValue);
			$this->Organizer->PlaceHolder = ew_RemoveHtml($this->Organizer->FldCaption());

			// Payment
			$this->Payment->EditCustomAttributes = "";
			$this->Payment->EditValue = $this->Payment->Options(FALSE);

			// Fees
			$this->Fees->EditAttrs["class"] = "form-control";
			$this->Fees->EditCustomAttributes = "";
			$this->Fees->EditValue = ew_HtmlEncode($this->Fees->CurrentValue);
			$this->Fees->PlaceHolder = ew_RemoveHtml($this->Fees->FldCaption());
			if (strval($this->Fees->EditValue) <> "" && is_numeric($this->Fees->EditValue)) $this->Fees->EditValue = ew_FormatNumber($this->Fees->EditValue, 0, -2, -2, -2);

			// notes
			$this->notes->EditAttrs["class"] = "form-control";
			$this->notes->EditCustomAttributes = "";
			$this->notes->EditValue = ew_HtmlEncode($this->notes->CurrentValue);
			$this->notes->PlaceHolder = ew_RemoveHtml($this->notes->FldCaption());

			// documents
			$this->documents->EditAttrs["class"] = "form-control";
			$this->documents->EditCustomAttributes = "";
			$this->documents->UploadPath = "uploads/trainingdocuments";
			if (!ew_Empty($this->documents->Upload->DbValue)) {
				$this->documents->EditValue = $this->documents->Upload->DbValue;
			} else {
				$this->documents->EditValue = "";
			}
			if (!ew_Empty($this->documents->CurrentValue))
				$this->documents->Upload->FileName = $this->documents->CurrentValue;
			if (($this->CurrentAction == "I" || $this->CurrentAction == "C") && !$this->EventCancelled) ew_RenderUploadField($this->documents);

			// Add refer script
			// classname

			$this->classname->LinkCustomAttributes = "";
			$this->classname->HrefValue = "";

			// StartDate
			$this->StartDate->LinkCustomAttributes = "";
			$this->StartDate->HrefValue = "";

			// EndDate
			$this->EndDate->LinkCustomAttributes = "";
			$this->EndDate->HrefValue = "";

			// allday
			$this->allday->LinkCustomAttributes = "";
			$this->allday->HrefValue = "";

			// starttime
			$this->starttime->LinkCustomAttributes = "";
			$this->starttime->HrefValue = "";

			// endtime
			$this->endtime->LinkCustomAttributes = "";
			$this->endtime->HrefValue = "";

			// category
			$this->category->LinkCustomAttributes = "";
			$this->category->HrefValue = "";

			// Venue
			$this->Venue->LinkCustomAttributes = "";
			$this->Venue->HrefValue = "";

			// Organizer
			$this->Organizer->LinkCustomAttributes = "";
			$this->Organizer->HrefValue = "";

			// Payment
			$this->Payment->LinkCustomAttributes = "";
			$this->Payment->HrefValue = "";

			// Fees
			$this->Fees->LinkCustomAttributes = "";
			$this->Fees->HrefValue = "";

			// notes
			$this->notes->LinkCustomAttributes = "";
			$this->notes->HrefValue = "";

			// documents
			$this->documents->LinkCustomAttributes = "";
			$this->documents->HrefValue = "";
			$this->documents->HrefValue2 = $this->documents->UploadPath . $this->documents->Upload->DbValue;
		}
		if ($this->RowType == EW_ROWTYPE_ADD ||
			$this->RowType == EW_ROWTYPE_EDIT ||
			$this->RowType == EW_ROWTYPE_SEARCH) { // Add / Edit / Search row
			$this->SetupFieldTitles();
		}

		// Call Row Rendered event
		if ($this->RowType <> EW_ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate form
	function ValidateForm() {
		global $Language, $gsFormError;

		// Initialize form error message
		$gsFormError = "";

		// Check if validation required
		if (!EW_SERVER_VALIDATE)
			return ($gsFormError == "");
		if (!ew_CheckEuroDate($this->StartDate->FormValue)) {
			ew_AddMessage($gsFormError, $this->StartDate->FldErrMsg());
		}
		if (!ew_CheckEuroDate($this->EndDate->FormValue)) {
			ew_AddMessage($gsFormError, $this->EndDate->FldErrMsg());
		}
		if (!ew_CheckTime($this->starttime->FormValue)) {
			ew_AddMessage($gsFormError, $this->starttime->FldErrMsg());
		}
		if (!ew_CheckTime($this->endtime->FormValue)) {
			ew_AddMessage($gsFormError, $this->endtime->FldErrMsg());
		}
		if (!ew_CheckNumber($this->Fees->FormValue)) {
			ew_AddMessage($gsFormError, $this->Fees->FldErrMsg());
		}

		// Validate detail grid
		$DetailTblVar = explode(",", $this->getCurrentDetailTable());
		if (in_array("mtm_staff_class", $DetailTblVar) && $GLOBALS["mtm_staff_class"]->DetailAdd) {
			if (!isset($GLOBALS["mtm_staff_class_grid"])) $GLOBALS["mtm_staff_class_grid"] = new cmtm_staff_class_grid(); // get detail page object
			$GLOBALS["mtm_staff_class_grid"]->ValidateGridForm();
		}

		// Return validate result
		$ValidateForm = ($gsFormError == "");

		// Call Form_CustomValidate event
		$sFormCustomError = "";
		$ValidateForm = $ValidateForm && $this->Form_CustomValidate($sFormCustomError);
		if ($sFormCustomError <> "") {
			ew_AddMessage($gsFormError, $sFormCustomError);
		}
		return $ValidateForm;
	}

	// Add record
	function AddRow($rsold = NULL) {
		global $Language, $Security;
		$conn = &$this->Connection();

		// Begin transaction
		if ($this->getCurrentDetailTable() <> "")
			$conn->BeginTrans();

		// Load db values from rsold
		if ($rsold) {
			$this->LoadDbValues($rsold);
			$this->documents->OldUploadPath = "uploads/trainingdocuments";
			$this->documents->UploadPath = $this->documents->OldUploadPath;
		}
		$rsnew = array();

		// classname
		$this->classname->SetDbValueDef($rsnew, $this->classname->CurrentValue, NULL, FALSE);

		// StartDate
		$this->StartDate->SetDbValueDef($rsnew, ew_UnFormatDateTime($this->StartDate->CurrentValue, 7), NULL, FALSE);

		// EndDate
		$this->EndDate->SetDbValueDef($rsnew, ew_UnFormatDateTime($this->EndDate->CurrentValue, 7), NULL, FALSE);

		// allday
		$this->allday->SetDbValueDef($rsnew, $this->allday->CurrentValue, NULL, FALSE);

		// starttime
		$this->starttime->SetDbValueDef($rsnew, $this->starttime->CurrentValue, NULL, FALSE);

		// endtime
		$this->endtime->SetDbValueDef($rsnew, $this->endtime->CurrentValue, NULL, FALSE);

		// category
		$this->category->SetDbValueDef($rsnew, $this->category->CurrentValue, NULL, FALSE);

		// Venue
		$this->Venue->SetDbValueDef($rsnew, $this->Venue->CurrentValue, NULL, FALSE);

		// Organizer
		$this->Organizer->SetDbValueDef($rsnew, $this->Organizer->CurrentValue, NULL, FALSE);

		// Payment
		$this->Payment->SetDbValueDef($rsnew, $this->Payment->CurrentValue, NULL, FALSE);

		// Fees
		$this->Fees->SetDbValueDef($rsnew, $this->Fees->CurrentValue, NULL, FALSE);

		// notes
		$this->notes->SetDbValueDef($rsnew, $this->notes->CurrentValue, NULL, FALSE);

		// documents
		if ($this->documents->Visible && !$this->documents->Upload->KeepFile) {
			$this->documents->Upload->DbValue = ""; // No need to delete old file
			if ($this->documents->Upload->FileName == "") {
				$rsnew['documents'] = NULL;
			} else {
				$rsnew['documents'] = $this->documents->Upload->FileName;
			}
		}
		if ($this->documents->Visible && !$this->documents->Upload->KeepFile) {
			$this->documents->UploadPath = "uploads/trainingdocuments";
			$OldFiles = explode(EW_MULTIPLE_UPLOAD_SEPARATOR, $this->documents->Upload->DbValue);
			if (!ew_Empty($this->documents->Upload->FileName)) {
				$NewFiles = explode(EW_MULTIPLE_UPLOAD_SEPARATOR, $this->documents->Upload->FileName);
				$FileCount = count($NewFiles);
				for ($i = 0; $i < $FileCount; $i++) {
					$fldvar = ($this->documents->Upload->Index < 0) ? $this->documents->FldVar : substr($this->documents->FldVar, 0, 1) . $this->documents->Upload->Index . substr($this->documents->FldVar, 1);
					if ($NewFiles[$i] <> "") {
						$file = $NewFiles[$i];
						if (file_exists(ew_UploadTempPath($fldvar, $this->documents->TblVar) . EW_PATH_DELIMITER . $file)) {
							if (!in_array($file, $OldFiles)) {
								$file1 = ew_UploadFileNameEx(ew_UploadPathEx(TRUE, $this->documents->UploadPath), $file); // Get new file name
								if ($file1 <> $file) { // Rename temp file
									while (file_exists(ew_UploadTempPath($fldvar, $this->documents->TblVar) . EW_PATH_DELIMITER . $file1)) // Make sure did not clash with existing upload file
										$file1 = ew_UniqueFilename(ew_UploadPathEx(TRUE, $this->documents->UploadPath), $file1, TRUE); // Use indexed name
									rename(ew_UploadTempPath($fldvar, $this->documents->TblVar) . EW_PATH_DELIMITER . $file, ew_UploadTempPath($fldvar, $this->documents->TblVar) . EW_PATH_DELIMITER . $file1);
									$NewFiles[$i] = $file1;
								}
							}
						}
					}
				}
				$this->documents->Upload->FileName = implode(EW_MULTIPLE_UPLOAD_SEPARATOR, $NewFiles);
				$rsnew['documents'] = $this->documents->Upload->FileName;
			} else {
				$NewFiles = array();
			}
		}

		// Call Row Inserting event
		$rs = ($rsold == NULL) ? NULL : $rsold->fields;
		$bInsertRow = $this->Row_Inserting($rs, $rsnew);
		if ($bInsertRow) {
			$conn->raiseErrorFn = $GLOBALS["EW_ERROR_FN"];
			$AddRow = $this->Insert($rsnew);
			$conn->raiseErrorFn = '';
			if ($AddRow) {

				// Get insert id if necessary
				$this->id->setDbValue($conn->Insert_ID());
				$rsnew['id'] = $this->id->DbValue;
				if ($this->documents->Visible && !$this->documents->Upload->KeepFile) {
					$OldFiles = explode(EW_MULTIPLE_UPLOAD_SEPARATOR, $this->documents->Upload->DbValue);
					if (!ew_Empty($this->documents->Upload->FileName)) {
						$NewFiles = explode(EW_MULTIPLE_UPLOAD_SEPARATOR, $this->documents->Upload->FileName);
						$NewFiles2 = explode(EW_MULTIPLE_UPLOAD_SEPARATOR, $rsnew['documents']);
						$FileCount = count($NewFiles);
						for ($i = 0; $i < $FileCount; $i++) {
							$fldvar = ($this->documents->Upload->Index < 0) ? $this->documents->FldVar : substr($this->documents->FldVar, 0, 1) . $this->documents->Upload->Index . substr($this->documents->FldVar, 1);
							if ($NewFiles[$i] <> "") {
								$file = ew_UploadTempPath($fldvar, $this->documents->TblVar) . EW_PATH_DELIMITER . $NewFiles[$i];
								if (file_exists($file)) {
									$this->documents->Upload->SaveToFile($this->documents->UploadPath, (@$NewFiles2[$i] <> "") ? $NewFiles2[$i] : $NewFiles[$i], TRUE, $i); // Just replace
								}
							}
						}
					} else {
						$NewFiles = array();
					}
					$FileCount = count($OldFiles);
					for ($i = 0; $i < $FileCount; $i++) {
						if ($OldFiles[$i] <> "" && !in_array($OldFiles[$i], $NewFiles))
							@unlink(ew_UploadPathEx(TRUE, $this->documents->OldUploadPath) . $OldFiles[$i]);
					}
				}
			}
		} else {
			if ($this->getSuccessMessage() <> "" || $this->getFailureMessage() <> "") {

				// Use the message, do nothing
			} elseif ($this->CancelMessage <> "") {
				$this->setFailureMessage($this->CancelMessage);
				$this->CancelMessage = "";
			} else {
				$this->setFailureMessage($Language->Phrase("InsertCancelled"));
			}
			$AddRow = FALSE;
		}

		// Add detail records
		if ($AddRow) {
			$DetailTblVar = explode(",", $this->getCurrentDetailTable());
			if (in_array("mtm_staff_class", $DetailTblVar) && $GLOBALS["mtm_staff_class"]->DetailAdd) {
				$GLOBALS["mtm_staff_class"]->classID->setSessionValue($this->id->CurrentValue); // Set master key
				if (!isset($GLOBALS["mtm_staff_class_grid"])) $GLOBALS["mtm_staff_class_grid"] = new cmtm_staff_class_grid(); // Get detail page object
				$AddRow = $GLOBALS["mtm_staff_class_grid"]->GridInsert();
				if (!$AddRow)
					$GLOBALS["mtm_staff_class"]->classID->setSessionValue(""); // Clear master key if insert failed
			}
		}

		// Commit/Rollback transaction
		if ($this->getCurrentDetailTable() <> "") {
			if ($AddRow) {
				$conn->CommitTrans(); // Commit transaction
			} else {
				$conn->RollbackTrans(); // Rollback transaction
			}
		}
		if ($AddRow) {

			// Call Row Inserted event
			$rs = ($rsold == NULL) ? NULL : $rsold->fields;
			$this->Row_Inserted($rs, $rsnew);
			$this->WriteAuditTrailOnAdd($rsnew);
		}

		// documents
		ew_CleanUploadTempPath($this->documents, $this->documents->Upload->Index);
		return $AddRow;
	}

	// Set up detail parms based on QueryString
	function SetUpDetailParms() {

		// Get the keys for master table
		if (isset($_GET[EW_TABLE_SHOW_DETAIL])) {
			$sDetailTblVar = $_GET[EW_TABLE_SHOW_DETAIL];
			$this->setCurrentDetailTable($sDetailTblVar);
		} else {
			$sDetailTblVar = $this->getCurrentDetailTable();
		}
		if ($sDetailTblVar <> "") {
			$DetailTblVar = explode(",", $sDetailTblVar);
			if (in_array("mtm_staff_class", $DetailTblVar)) {
				if (!isset($GLOBALS["mtm_staff_class_grid"]))
					$GLOBALS["mtm_staff_class_grid"] = new cmtm_staff_class_grid;
				if ($GLOBALS["mtm_staff_class_grid"]->DetailAdd) {
					if ($this->CopyRecord)
						$GLOBALS["mtm_staff_class_grid"]->CurrentMode = "copy";
					else
						$GLOBALS["mtm_staff_class_grid"]->CurrentMode = "add";
					$GLOBALS["mtm_staff_class_grid"]->CurrentAction = "gridadd";

					// Save current master table to detail table
					$GLOBALS["mtm_staff_class_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["mtm_staff_class_grid"]->setStartRecordNumber(1);
					$GLOBALS["mtm_staff_class_grid"]->classID->FldIsDetailKey = TRUE;
					$GLOBALS["mtm_staff_class_grid"]->classID->CurrentValue = $this->id->CurrentValue;
					$GLOBALS["mtm_staff_class_grid"]->classID->setSessionValue($GLOBALS["mtm_staff_class_grid"]->classID->CurrentValue);
				}
			}
		}
	}

	// Set up Breadcrumb
	function SetupBreadcrumb() {
		global $Breadcrumb, $Language;
		$Breadcrumb = new cBreadcrumb();
		$url = substr(ew_CurrentUrl(), strrpos(ew_CurrentUrl(), "/")+1);
		$Breadcrumb->Add("list", $this->TableVar, $this->AddMasterUrl("classlist.php"), "", $this->TableVar, TRUE);
		$PageId = ($this->CurrentAction == "C") ? "Copy" : "Add";
		$Breadcrumb->Add("add", $PageId, $url);
	}

	// Write Audit Trail start/end for grid update
	function WriteAuditTrailDummy($typ) {
		$table = 'class';
		$usr = CurrentUserID();
		ew_WriteAuditTrail("log", ew_StdCurrentDateTime(), ew_ScriptName(), $usr, $typ, $table, "", "", "", "");
	}

	// Write Audit Trail (add page)
	function WriteAuditTrailOnAdd(&$rs) {
		global $Language;
		if (!$this->AuditTrailOnAdd) return;
		$table = 'class';

		// Get key value
		$key = "";
		if ($key <> "") $key .= $GLOBALS["EW_COMPOSITE_KEY_SEPARATOR"];
		$key .= $rs['id'];

		// Write Audit Trail
		$dt = ew_StdCurrentDateTime();
		$id = ew_ScriptName();
		$usr = CurrentUserID();
		foreach (array_keys($rs) as $fldname) {
			if ($this->fields[$fldname]->FldDataType <> EW_DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->FldHtmlTag == "PASSWORD") {
					$newvalue = $Language->Phrase("PasswordMask"); // Password Field
				} elseif ($this->fields[$fldname]->FldDataType == EW_DATATYPE_MEMO) {
					if (EW_AUDIT_TRAIL_TO_DATABASE)
						$newvalue = $rs[$fldname];
					else
						$newvalue = "[MEMO]"; // Memo Field
				} elseif ($this->fields[$fldname]->FldDataType == EW_DATATYPE_XML) {
					$newvalue = "[XML]"; // XML Field
				} else {
					$newvalue = $rs[$fldname];
				}
				ew_WriteAuditTrail("log", $dt, $id, $usr, "A", $table, $fldname, $key, "", $newvalue);
			}
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$CustomError) {

		// Return error message in CustomError
		return TRUE;
	}
}
?>
<?php ew_Header(FALSE) ?>
<?php

// Create page object
if (!isset($class_add)) $class_add = new cclass_add();

// Page init
$class_add->Page_Init();

// Page main
$class_add->Page_Main();

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$class_add->Page_Render();
?>
<?php include_once "header.php" ?>
<script type="text/javascript">

// Form object
var CurrentPageID = EW_PAGE_ID = "add";
var CurrentForm = fclassadd = new ew_Form("fclassadd", "add");

// Validate form
fclassadd.Validate = function() {
	if (!this.ValidateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.GetForm(), $fobj = $(fobj);
	if ($fobj.find("#a_confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.FormKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = $fobj.find("#a_list").val() == "gridinsert";
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
			elm = this.GetElements("x" + infix + "_StartDate");
			if (elm && !ew_CheckEuroDate(elm.value))
				return this.OnError(elm, "<?php echo ew_JsEncode2($class->StartDate->FldErrMsg()) ?>");
			elm = this.GetElements("x" + infix + "_EndDate");
			if (elm && !ew_CheckEuroDate(elm.value))
				return this.OnError(elm, "<?php echo ew_JsEncode2($class->EndDate->FldErrMsg()) ?>");
			elm = this.GetElements("x" + infix + "_starttime");
			if (elm && !ew_CheckTime(elm.value))
				return this.OnError(elm, "<?php echo ew_JsEncode2($class->starttime->FldErrMsg()) ?>");
			elm = this.GetElements("x" + infix + "_endtime");
			if (elm && !ew_CheckTime(elm.value))
				return this.OnError(elm, "<?php echo ew_JsEncode2($class->endtime->FldErrMsg()) ?>");
			elm = this.GetElements("x" + infix + "_Fees");
			if (elm && !ew_CheckNumber(elm.value))
				return this.OnError(elm, "<?php echo ew_JsEncode2($class->Fees->FldErrMsg()) ?>");

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
	}

	// Process detail forms
	var dfs = $fobj.find("input[name='detailpage']").get();
	for (var i = 0; i < dfs.length; i++) {
		var df = dfs[i], val = df.value;
		if (val && ewForms[val])
			if (!ewForms[val].Validate())
				return false;
	}
	return true;
}

// Form_CustomValidate event
fclassadd.Form_CustomValidate = 
 function(fobj) { // DO NOT CHANGE THIS LINE!

 	// Your custom validation code here, return false if invalid. 
 	return true;
 }

// Use JavaScript validation or not
<?php if (EW_CLIENT_VALIDATE) { ?>
fclassadd.ValidateRequired = true;
<?php } else { ?>
fclassadd.ValidateRequired = false; 
<?php } ?>

// Dynamic selection lists
fclassadd.Lists["x_allday[]"] = {"LinkField":"","Ajax":null,"AutoFill":false,"DisplayFields":["","","",""],"ParentFields":[],"ChildFields":[],"FilterFields":[],"Options":[],"Template":""};
fclassadd.Lists["x_allday[]"].Options = <?php echo json_encode($class->allday->Options()) ?>;
fclassadd.Lists["x_category"] = {"LinkField":"x_id","Ajax":true,"AutoFill":false,"DisplayFields":["x_ClassCategories","","",""],"ParentFields":[],"ChildFields":[],"FilterFields":[],"Options":[],"Template":""};
fclassadd.Lists["x_Payment"] = {"LinkField":"","Ajax":null,"AutoFill":false,"DisplayFields":["","","",""],"ParentFields":[],"ChildFields":[],"FilterFields":[],"Options":[],"Template":""};
fclassadd.Lists["x_Payment"].Options = <?php echo json_encode($class->Payment->Options()) ?>;

// Form object for search
</script>
<script type="text/javascript">

// Write your client script here, no need to add script tags.
</script>
<div class="ewToolbar">
<?php $Breadcrumb->Render(); ?>
<?php echo $Language->SelectionForm(); ?>
<div class="clearfix"></div>
</div>
<?php $class_add->ShowPageHeader(); ?>
<?php
$class_add->ShowMessage();
?>
<form name="fclassadd" id="fclassadd" class="<?php echo $class_add->FormClassName ?>" action="<?php echo ew_CurrentPage() ?>" method="post">
<?php if ($class_add->CheckToken) { ?>
<input type="hidden" name="<?php echo EW_TOKEN_NAME ?>" value="<?php echo $class_add->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="class">
<input type="hidden" name="a_add" id="a_add" value="A">
<div>
<?php if ($class->classname->Visible) { // classname ?>
	<div id="r_classname" class="form-group">
		<label id="elh_class_classname" for="x_classname" class="col-sm-2 control-label ewLabel"><?php echo $class->classname->FldCaption() ?></label>
		<div class="col-sm-10"><div<?php echo $class->classname->CellAttributes() ?>>
<span id="el_class_classname">
<input type="text" data-table="class" data-field="x_classname" name="x_classname" id="x_classname" size="30" maxlength="250" placeholder="<?php echo ew_HtmlEncode($class->classname->getPlaceHolder()) ?>" value="<?php echo $class->classname->EditValue ?>"<?php echo $class->classname->EditAttributes() ?>>
</span>
<?php echo $class->classname->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($class->StartDate->Visible) { // StartDate ?>
	<div id="r_StartDate" class="form-group">
		<label id="elh_class_StartDate" for="x_StartDate" class="col-sm-2 control-label ewLabel"><?php echo $class->StartDate->FldCaption() ?></label>
		<div class="col-sm-10"><div<?php echo $class->StartDate->CellAttributes() ?>>
<span id="el_class_StartDate">
<input type="text" data-table="class" data-field="x_StartDate" data-format="7" name="x_StartDate" id="x_StartDate" placeholder="<?php echo ew_HtmlEncode($class->StartDate->getPlaceHolder()) ?>" value="<?php echo $class->StartDate->EditValue ?>"<?php echo $class->StartDate->EditAttributes() ?>>
<?php if (!$class->StartDate->ReadOnly && !$class->StartDate->Disabled && !isset($class->StartDate->EditAttrs["readonly"]) && !isset($class->StartDate->EditAttrs["disabled"])) { ?>
<script type="text/javascript">
ew_CreateCalendar("fclassadd", "x_StartDate", "%d/%m/%Y");
</script>
<?php } ?>
</span>
<?php echo $class->StartDate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($class->EndDate->Visible) { // EndDate ?>
	<div id="r_EndDate" class="form-group">
		<label id="elh_class_EndDate" for="x_EndDate" class="col-sm-2 control-label ewLabel"><?php echo $class->EndDate->FldCaption() ?></label>
		<div class="col-sm-10"><div<?php echo $class->EndDate->CellAttributes() ?>>
<span id="el_class_EndDate">
<input type="text" data-table="class" data-field="x_EndDate" data-format="7" name="x_EndDate" id="x_EndDate" placeholder="<?php echo ew_HtmlEncode($class->EndDate->getPlaceHolder()) ?>" value="<?php echo $class->EndDate->EditValue ?>"<?php echo $class->EndDate->EditAttributes() ?>>
<?php if (!$class->EndDate->ReadOnly && !$class->EndDate->Disabled && !isset($class->EndDate->EditAttrs["readonly"]) && !isset($class->EndDate->EditAttrs["disabled"])) { ?>
<script type="text/javascript">
ew_CreateCalendar("fclassadd", "x_EndDate", "%d/%m/%Y");
</script>
<?php } ?>
</span>
<?php echo $class->EndDate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($class->allday->Visible) { // allday ?>
	<div id="r_allday" class="form-group">
		<label id="elh_class_allday" class="col-sm-2 control-label ewLabel"><?php echo $class->allday->FldCaption() ?></label>
		<div class="col-sm-10"><div<?php echo $class->allday->CellAttributes() ?>>
<span id="el_class_allday">
<div id="tp_x_allday" class="ewTemplate"><input type="checkbox" data-table="class" data-field="x_allday" data-value-separator="<?php echo ew_HtmlEncode(is_array($class->allday->DisplayValueSeparator) ? json_encode($class->allday->DisplayValueSeparator) : $class->allday->DisplayValueSeparator) ?>" name="x_allday[]" id="x_allday[]" value="{value}"<?php echo $class->allday->EditAttributes() ?>></div>
<div id="dsl_x_allday" data-repeatcolumn="5" class="ewItemList" style="display: none;"><div>
<?php
$arwrk = $class->allday->EditValue;
if (is_array($arwrk)) {
	$armultiwrk = (strval($class->allday->CurrentValue) <> "") ? explode(",", strval($class->allday->CurrentValue)) : array();
	$cnt = count($armultiwrk);
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = "";
		for ($ari = 0; $ari < $cnt; $ari++) {
			if (ew_SameStr($arwrk[$rowcntwrk][0], $armultiwrk[$ari]) && !is_null($armultiwrk[$ari])) {
				$armultiwrk[$ari] = NULL; // Marked for removal
				$selwrk = " checked";
				if ($selwrk <> "") $emptywrk = FALSE;
				break;
			}
		}
?>
<label class="checkbox-inline"><input type="checkbox" data-table="class" data-field="x_allday" name="x_allday[]" id="x_allday_<?php echo $rowcntwrk ?>[]" value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?><?php echo $class->allday->EditAttributes() ?>><?php echo $class->allday->DisplayValue($arwrk[$rowcntwrk]) ?></label>
<?php
	}
	for ($ari = 0; $ari < $cnt; $ari++) {
		if (!is_null($armultiwrk[$ari])) {
?>
<label class="checkbox-inline"><input type="checkbox" data-table="class" data-field="x_allday" name="x_allday[]" value="<?php echo ew_HtmlEncode($armultiwrk[$ari]) ?>" checked<?php echo $class->allday->EditAttributes() ?>><?php echo $armultiwrk[$ari] ?></label>
<?php
		}
	}
}
?>
</div></div>
</span>
<?php echo $class->allday->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($class->starttime->Visible) { // starttime ?>
	<div id="r_starttime" class="form-group">
		<label id="elh_class_starttime" for="x_starttime" class="col-sm-2 control-label ewLabel"><?php echo $class->starttime->FldCaption() ?></label>
		<div class="col-sm-10"><div<?php echo $class->starttime->CellAttributes() ?>>
<span id="el_class_starttime">
<input type="text" data-table="class" data-field="x_starttime" name="x_starttime" id="x_starttime" size="30" maxlength="20" placeholder="<?php echo ew_HtmlEncode($class->starttime->getPlaceHolder()) ?>" value="<?php echo $class->starttime->EditValue ?>"<?php echo $class->starttime->EditAttributes() ?>>
<?php if (!$class->starttime->ReadOnly && !$class->starttime->Disabled && !isset($class->starttime->EditAttrs["readonly"]) && !isset($class->starttime->EditAttrs["disabled"])) { ?>
<script type="text/javascript">ew_CreateTimePicker("fclassadd", "x_starttime", {"timeFormat":"H:i:s"});</script><?php } ?>
</span>
<?php echo $class->starttime->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($class->endtime->Visible) { // endtime ?>
	<div id="r_endtime" class="form-group">
		<label id="elh_class_endtime" for="x_endtime" class="col-sm-2 control-label ewLabel"><?php echo $class->endtime->FldCaption() ?></label>
		<div class="col-sm-10"><div<?php echo $class->endtime->CellAttributes() ?>>
<span id="el_class_endtime">
<input type="text" data-table="class" data-field="x_endtime" name="x_endtime" id="x_endtime" size="30" placeholder="<?php echo ew_HtmlEncode($class->endtime->getPlaceHolder()) ?>" value="<?php echo $class->endtime->EditValue ?>"<?php echo $class->endtime->EditAttributes() ?>>
<?php if (!$class->endtime->ReadOnly && !$class->endtime->Disabled && !isset($class->endtime->EditAttrs["readonly"]) && !isset($class->endtime->EditAttrs["disabled"])) { ?>
<script type="text/javascript">ew_CreateTimePicker("fclassadd", "x_endtime", {"timeFormat":"H:i:s"});</script><?php } ?>
</span>
<?php echo $class->endtime->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($class->category->Visible) { // category ?>
	<div id="r_category" class="form-group">
		<label id="elh_class_category" for="x_category" class="col-sm-2 control-label ewLabel"><?php echo $class->category->FldCaption() ?></label>
		<div class="col-sm-10"><div<?php echo $class->category->CellAttributes() ?>>
<span id="el_class_category">
<select data-table="class" data-field="x_category" data-value-separator="<?php echo ew_HtmlEncode(is_array($class->category->DisplayValueSeparator) ? json_encode($class->category->DisplayValueSeparator) : $class->category->DisplayValueSeparator) ?>" id="x_category" name="x_category"<?php echo $class->category->EditAttributes() ?>>
<?php
if (is_array($class->category->EditValue)) {
	$arwrk = $class->category->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = ew_SameStr($class->category->CurrentValue, $arwrk[$rowcntwrk][0]) ? " selected" : "";
		if ($selwrk <> "") $emptywrk = FALSE;		
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $class->category->DisplayValue($arwrk[$rowcntwrk]) ?>
</option>
<?php
	}
	if ($emptywrk && strval($class->category->CurrentValue) <> "") {
?>
<option value="<?php echo ew_HtmlEncode($class->category->CurrentValue) ?>" selected><?php echo $class->category->CurrentValue ?></option>
<?php
    }
}
?>
</select>
<?php
$sSqlWrk = "SELECT `id`, `ClassCategories` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `lkp_class_categories`";
$sWhereWrk = "";
$class->category->LookupFilters = array("s" => $sSqlWrk, "d" => "");
$class->category->LookupFilters += array("f0" => "`id` = {filter_value}", "t0" => "3", "fn0" => "");
$sSqlWrk = "";
$class->Lookup_Selecting($class->category, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
if ($sSqlWrk <> "") $class->category->LookupFilters["s"] .= $sSqlWrk;
?>
<input type="hidden" name="s_x_category" id="s_x_category" value="<?php echo $class->category->LookupFilterQuery() ?>">
</span>
<?php echo $class->category->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($class->Venue->Visible) { // Venue ?>
	<div id="r_Venue" class="form-group">
		<label id="elh_class_Venue" for="x_Venue" class="col-sm-2 control-label ewLabel"><?php echo $class->Venue->FldCaption() ?></label>
		<div class="col-sm-10"><div<?php echo $class->Venue->CellAttributes() ?>>
<span id="el_class_Venue">
<input type="text" data-table="class" data-field="x_Venue" name="x_Venue" id="x_Venue" size="30" maxlength="35" placeholder="<?php echo ew_HtmlEncode($class->Venue->getPlaceHolder()) ?>" value="<?php echo $class->Venue->EditValue ?>"<?php echo $class->Venue->EditAttributes() ?>>
</span>
<?php echo $class->Venue->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($class->Organizer->Visible) { // Organizer ?>
	<div id="r_Organizer" class="form-group">
		<label id="elh_class_Organizer" for="x_Organizer" class="col-sm-2 control-label ewLabel"><?php echo $class->Organizer->FldCaption() ?></label>
		<div class="col-sm-10"><div<?php echo $class->Organizer->CellAttributes() ?>>
<span id="el_class_Organizer">
<input type="text" data-table="class" data-field="x_Organizer" name="x_Organizer" id="x_Organizer" size="30" maxlength="50" placeholder="<?php echo ew_HtmlEncode($class->Organizer->getPlaceHolder()) ?>" value="<?php echo $class->Organizer->EditValue ?>"<?php echo $class->Organizer->EditAttributes() ?>>
</span>
<?php echo $class->Organizer->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($class->Payment->Visible) { // Payment ?>
	<div id="r_Payment" class="form-group">
		<label id="elh_class_Payment" class="col-sm-2 control-label ewLabel"><?php echo $class->Payment->FldCaption() ?></label>
		<div class="col-sm-10"><div<?php echo $class->Payment->CellAttributes() ?>>
<span id="el_class_Payment">
<div id="tp_x_Payment" class="ewTemplate"><input type="radio" data-table="class" data-field="x_Payment" data-value-separator="<?php echo ew_HtmlEncode(is_array($class->Payment->DisplayValueSeparator) ? json_encode($class->Payment->DisplayValueSeparator) : $class->Payment->DisplayValueSeparator) ?>" name="x_Payment" id="x_Payment" value="{value}"<?php echo $class->Payment->EditAttributes() ?>></div>
<div id="dsl_x_Payment" data-repeatcolumn="5" class="ewItemList" style="display: none;"><div>
<?php
$arwrk = $class->Payment->EditValue;
if (is_array($arwrk)) {
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = (strval($class->Payment->CurrentValue) == strval($arwrk[$rowcntwrk][0])) ? " checked" : "";
		if ($selwrk <> "")
			$emptywrk = FALSE;
?>
<label class="radio-inline"><input type="radio" data-table="class" data-field="x_Payment" name="x_Payment" id="x_Payment_<?php echo $rowcntwrk ?>" value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?><?php echo $class->Payment->EditAttributes() ?>><?php echo $class->Payment->DisplayValue($arwrk[$rowcntwrk]) ?></label>
<?php
	}
	if ($emptywrk && strval($class->Payment->CurrentValue) <> "") {
?>
<label class="radio-inline"><input type="radio" data-table="class" data-field="x_Payment" name="x_Payment" id="x_Payment_<?php echo $rowswrk ?>" value="<?php echo ew_HtmlEncode($class->Payment->CurrentValue) ?>" checked<?php echo $class->Payment->EditAttributes() ?>><?php echo $class->Payment->CurrentValue ?></label>
<?php
    }
}
?>
</div></div>
</span>
<?php echo $class->Payment->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($class->Fees->Visible) { // Fees ?>
	<div id="r_Fees" class="form-group">
		<label id="elh_class_Fees" for="x_Fees" class="col-sm-2 control-label ewLabel"><?php echo $class->Fees->FldCaption() ?></label>
		<div class="col-sm-10"><div<?php echo $class->Fees->CellAttributes() ?>>
<span id="el_class_Fees">
<input type="text" data-table="class" data-field="x_Fees" name="x_Fees" id="x_Fees" size="30" placeholder="<?php echo ew_HtmlEncode($class->Fees->getPlaceHolder()) ?>" value="<?php echo $class->Fees->EditValue ?>"<?php echo $class->Fees->EditAttributes() ?>>
</span>
<?php echo $class->Fees->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($class->notes->Visible) { // notes ?>
	<div id="r_notes" class="form-group">
		<label id="elh_class_notes" class="col-sm-2 control-label ewLabel"><?php echo $class->notes->FldCaption() ?></label>
		<div class="col-sm-10"><div<?php echo $class->notes->CellAttributes() ?>>
<span id="el_class_notes">
<?php ew_AppendClass($class->notes->EditAttrs["class"], "editor"); ?>
<textarea data-table="class" data-field="x_notes" name="x_notes" id="x_notes" cols="35" rows="4" placeholder="<?php echo ew_HtmlEncode($class->notes->getPlaceHolder()) ?>"<?php echo $class->notes->EditAttributes() ?>><?php echo $class->notes->EditValue ?></textarea>
<script type="text/javascript">
ew_CreateEditor("fclassadd", "x_notes", 35, 4, <?php echo ($class->notes->ReadOnly || FALSE) ? "true" : "false" ?>);
</script>
</span>
<?php echo $class->notes->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($class->documents->Visible) { // documents ?>
	<div id="r_documents" class="form-group">
		<label id="elh_class_documents" class="col-sm-2 control-label ewLabel"><?php echo $class->documents->FldCaption() ?></label>
		<div class="col-sm-10"><div<?php echo $class->documents->CellAttributes() ?>>
<span id="el_class_documents">
<div id="fd_x_documents">
<span title="<?php echo $class->documents->FldTitle() ? $class->documents->FldTitle() : $Language->Phrase("ChooseFiles") ?>" class="btn btn-default btn-sm fileinput-button ewTooltip<?php if ($class->documents->ReadOnly || $class->documents->Disabled) echo " hide"; ?>">
	<span><?php echo $Language->Phrase("ChooseFileBtn") ?></span>
	<input type="file" title=" " data-table="class" data-field="x_documents" name="x_documents" id="x_documents" multiple="multiple"<?php echo $class->documents->EditAttributes() ?>>
</span>
<input type="hidden" name="fn_x_documents" id= "fn_x_documents" value="<?php echo $class->documents->Upload->FileName ?>">
<input type="hidden" name="fa_x_documents" id= "fa_x_documents" value="0">
<input type="hidden" name="fs_x_documents" id= "fs_x_documents" value="200">
<input type="hidden" name="fx_x_documents" id= "fx_x_documents" value="<?php echo $class->documents->UploadAllowedFileExt ?>">
<input type="hidden" name="fm_x_documents" id= "fm_x_documents" value="<?php echo $class->documents->UploadMaxFileSize ?>">
<input type="hidden" name="fc_x_documents" id= "fc_x_documents" value="<?php echo $class->documents->UploadMaxFileCount ?>">
</div>
<table id="ft_x_documents" class="table table-condensed pull-left ewUploadTable"><tbody class="files"></tbody></table>
</span>
<?php echo $class->documents->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div>
<?php
	if (in_array("mtm_staff_class", explode(",", $class->getCurrentDetailTable())) && $mtm_staff_class->DetailAdd) {
?>
<?php if ($class->getCurrentDetailTable() <> "") { ?>
<h4 class="ewDetailCaption"><?php echo $Language->TablePhrase("mtm_staff_class", "TblCaption") ?></h4>
<?php } ?>
<?php include_once "mtm_staff_classgrid.php" ?>
<?php } ?>
<div class="form-group">
	<div class="col-sm-offset-2 col-sm-10">
<button class="btn btn-primary ewButton" name="btnAction" id="btnAction" type="submit"><?php echo $Language->Phrase("AddBtn") ?></button>
<button class="btn btn-default ewButton" name="btnCancel" id="btnCancel" type="button" data-href="<?php echo $class_add->getReturnUrl() ?>"><?php echo $Language->Phrase("CancelBtn") ?></button>
	</div>
</div>
</form>
<script type="text/javascript">
fclassadd.Init();
</script>
<?php
$class_add->ShowPageFooter();
if (EW_DEBUG_ENABLED)
	echo ew_DebugMsg();
?>
<script type="text/javascript">

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$class_add->Page_Terminate();
?>
