<?php include_once "staffinfo.php" ?>
<?php

// Create page object
if (!isset($budget_grid)) $budget_grid = new cbudget_grid();

// Page init
$budget_grid->Page_Init();

// Page main
$budget_grid->Page_Main();

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$budget_grid->Page_Render();
?>
<?php if ($budget->Export == "") { ?>
<script type="text/javascript">

// Form object
var fbudgetgrid = new ew_Form("fbudgetgrid", "grid");
fbudgetgrid.FormKeyCountName = '<?php echo $budget_grid->FormKeyCountName ?>';

// Validate form
fbudgetgrid.Validate = function() {
	if (!this.ValidateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.GetForm(), $fobj = $(fobj);
	if ($fobj.find("#a_confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.FormKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = $fobj.find("#a_list").val() == "gridinsert";
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
		var checkrow = (gridinsert) ? !this.EmptyRow(infix) : true;
		if (checkrow) {
			addcnt++;
			elm = this.GetElements("x" + infix + "_BudgetYear");
			if (elm && !ew_CheckInteger(elm.value))
				return this.OnError(elm, "<?php echo ew_JsEncode2($budget->BudgetYear->FldErrMsg()) ?>");
			elm = this.GetElements("x" + infix + "_Amount");
			if (elm && !ew_CheckNumber(elm.value))
				return this.OnError(elm, "<?php echo ew_JsEncode2($budget->Amount->FldErrMsg()) ?>");

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
		} // End Grid Add checking
	}
	return true;
}

// Check empty row
fbudgetgrid.EmptyRow = function(infix) {
	var fobj = this.Form;
	if (ew_ValueChanged(fobj, infix, "ProjectID", false)) return false;
	if (ew_ValueChanged(fobj, infix, "BudgetYear", false)) return false;
	if (ew_ValueChanged(fobj, infix, "Amount", false)) return false;
	return true;
}

// Form_CustomValidate event
fbudgetgrid.Form_CustomValidate = 
 function(fobj) { // DO NOT CHANGE THIS LINE!

 	// Your custom validation code here, return false if invalid. 
 	return true;
 }

// Use JavaScript validation or not
<?php if (EW_CLIENT_VALIDATE) { ?>
fbudgetgrid.ValidateRequired = true;
<?php } else { ?>
fbudgetgrid.ValidateRequired = false; 
<?php } ?>

// Dynamic selection lists
fbudgetgrid.Lists["x_ProjectID"] = {"LinkField":"x_id","Ajax":true,"AutoFill":false,"DisplayFields":["x_name","","",""],"ParentFields":[],"ChildFields":[],"FilterFields":[],"Options":[],"Template":""};

// Form object for search
</script>
<?php } ?>
<?php
if ($budget->CurrentAction == "gridadd") {
	if ($budget->CurrentMode == "copy") {
		$bSelectLimit = $budget_grid->UseSelectLimit;
		if ($bSelectLimit) {
			$budget_grid->TotalRecs = $budget->SelectRecordCount();
			$budget_grid->Recordset = $budget_grid->LoadRecordset($budget_grid->StartRec-1, $budget_grid->DisplayRecs);
		} else {
			if ($budget_grid->Recordset = $budget_grid->LoadRecordset())
				$budget_grid->TotalRecs = $budget_grid->Recordset->RecordCount();
		}
		$budget_grid->StartRec = 1;
		$budget_grid->DisplayRecs = $budget_grid->TotalRecs;
	} else {
		$budget->CurrentFilter = "0=1";
		$budget_grid->StartRec = 1;
		$budget_grid->DisplayRecs = $budget->GridAddRowCount;
	}
	$budget_grid->TotalRecs = $budget_grid->DisplayRecs;
	$budget_grid->StopRec = $budget_grid->DisplayRecs;
} else {
	$bSelectLimit = $budget_grid->UseSelectLimit;
	if ($bSelectLimit) {
		if ($budget_grid->TotalRecs <= 0)
			$budget_grid->TotalRecs = $budget->SelectRecordCount();
	} else {
		if (!$budget_grid->Recordset && ($budget_grid->Recordset = $budget_grid->LoadRecordset()))
			$budget_grid->TotalRecs = $budget_grid->Recordset->RecordCount();
	}
	$budget_grid->StartRec = 1;
	$budget_grid->DisplayRecs = $budget_grid->TotalRecs; // Display all records
	if ($bSelectLimit)
		$budget_grid->Recordset = $budget_grid->LoadRecordset($budget_grid->StartRec-1, $budget_grid->DisplayRecs);

	// Set no record found message
	if ($budget->CurrentAction == "" && $budget_grid->TotalRecs == 0) {
		if (!$Security->CanList())
			$budget_grid->setWarningMessage(ew_DeniedMsg());
		if ($budget_grid->SearchWhere == "0=101")
			$budget_grid->setWarningMessage($Language->Phrase("EnterSearchCriteria"));
		else
			$budget_grid->setWarningMessage($Language->Phrase("NoRecord"));
	}
}
$budget_grid->RenderOtherOptions();
?>
<?php $budget_grid->ShowPageHeader(); ?>
<?php
$budget_grid->ShowMessage();
?>
<?php if ($budget_grid->TotalRecs > 0 || $budget->CurrentAction <> "") { ?>
<div class="panel panel-default ewGrid">
<div id="fbudgetgrid" class="ewForm form-inline">
<?php if ($budget_grid->ShowOtherOptions) { ?>
<div class="panel-heading ewGridUpperPanel">
<?php
	foreach ($budget_grid->OtherOptions as &$option)
		$option->Render("body");
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<div id="gmp_budget" class="<?php if (ew_IsResponsiveLayout()) { echo "table-responsive "; } ?>ewGridMiddlePanel">
<table id="tbl_budgetgrid" class="table ewTable">
<?php echo $budget->TableCustomInnerHtml ?>
<thead><!-- Table header -->
	<tr class="ewTableHeader">
<?php

// Header row
$budget_grid->RowType = EW_ROWTYPE_HEADER;

// Render list options
$budget_grid->RenderListOptions();

// Render list options (header, left)
$budget_grid->ListOptions->Render("header", "left");
?>
<?php if ($budget->id->Visible) { // id ?>
	<?php if ($budget->SortUrl($budget->id) == "") { ?>
		<th data-name="id"><div id="elh_budget_id" class="budget_id"><div class="ewTableHeaderCaption"><?php echo $budget->id->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="id"><div><div id="elh_budget_id" class="budget_id">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $budget->id->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($budget->id->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($budget->id->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($budget->ProjectID->Visible) { // ProjectID ?>
	<?php if ($budget->SortUrl($budget->ProjectID) == "") { ?>
		<th data-name="ProjectID"><div id="elh_budget_ProjectID" class="budget_ProjectID"><div class="ewTableHeaderCaption"><?php echo $budget->ProjectID->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="ProjectID"><div><div id="elh_budget_ProjectID" class="budget_ProjectID">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $budget->ProjectID->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($budget->ProjectID->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($budget->ProjectID->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($budget->BudgetYear->Visible) { // BudgetYear ?>
	<?php if ($budget->SortUrl($budget->BudgetYear) == "") { ?>
		<th data-name="BudgetYear"><div id="elh_budget_BudgetYear" class="budget_BudgetYear"><div class="ewTableHeaderCaption"><?php echo $budget->BudgetYear->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="BudgetYear"><div><div id="elh_budget_BudgetYear" class="budget_BudgetYear">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $budget->BudgetYear->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($budget->BudgetYear->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($budget->BudgetYear->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($budget->Amount->Visible) { // Amount ?>
	<?php if ($budget->SortUrl($budget->Amount) == "") { ?>
		<th data-name="Amount"><div id="elh_budget_Amount" class="budget_Amount"><div class="ewTableHeaderCaption"><?php echo $budget->Amount->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Amount"><div><div id="elh_budget_Amount" class="budget_Amount">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $budget->Amount->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($budget->Amount->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($budget->Amount->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php

// Render list options (header, right)
$budget_grid->ListOptions->Render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
$budget_grid->StartRec = 1;
$budget_grid->StopRec = $budget_grid->TotalRecs; // Show all records

// Restore number of post back records
if ($objForm) {
	$objForm->Index = -1;
	if ($objForm->HasValue($budget_grid->FormKeyCountName) && ($budget->CurrentAction == "gridadd" || $budget->CurrentAction == "gridedit" || $budget->CurrentAction == "F")) {
		$budget_grid->KeyCount = $objForm->GetValue($budget_grid->FormKeyCountName);
		$budget_grid->StopRec = $budget_grid->StartRec + $budget_grid->KeyCount - 1;
	}
}
$budget_grid->RecCnt = $budget_grid->StartRec - 1;
if ($budget_grid->Recordset && !$budget_grid->Recordset->EOF) {
	$budget_grid->Recordset->MoveFirst();
	$bSelectLimit = $budget_grid->UseSelectLimit;
	if (!$bSelectLimit && $budget_grid->StartRec > 1)
		$budget_grid->Recordset->Move($budget_grid->StartRec - 1);
} elseif (!$budget->AllowAddDeleteRow && $budget_grid->StopRec == 0) {
	$budget_grid->StopRec = $budget->GridAddRowCount;
}

// Initialize aggregate
$budget->RowType = EW_ROWTYPE_AGGREGATEINIT;
$budget->ResetAttrs();
$budget_grid->RenderRow();
if ($budget->CurrentAction == "gridadd")
	$budget_grid->RowIndex = 0;
if ($budget->CurrentAction == "gridedit")
	$budget_grid->RowIndex = 0;
while ($budget_grid->RecCnt < $budget_grid->StopRec) {
	$budget_grid->RecCnt++;
	if (intval($budget_grid->RecCnt) >= intval($budget_grid->StartRec)) {
		$budget_grid->RowCnt++;
		if ($budget->CurrentAction == "gridadd" || $budget->CurrentAction == "gridedit" || $budget->CurrentAction == "F") {
			$budget_grid->RowIndex++;
			$objForm->Index = $budget_grid->RowIndex;
			if ($objForm->HasValue($budget_grid->FormActionName))
				$budget_grid->RowAction = strval($objForm->GetValue($budget_grid->FormActionName));
			elseif ($budget->CurrentAction == "gridadd")
				$budget_grid->RowAction = "insert";
			else
				$budget_grid->RowAction = "";
		}

		// Set up key count
		$budget_grid->KeyCount = $budget_grid->RowIndex;

		// Init row class and style
		$budget->ResetAttrs();
		$budget->CssClass = "";
		if ($budget->CurrentAction == "gridadd") {
			if ($budget->CurrentMode == "copy") {
				$budget_grid->LoadRowValues($budget_grid->Recordset); // Load row values
				$budget_grid->SetRecordKey($budget_grid->RowOldKey, $budget_grid->Recordset); // Set old record key
			} else {
				$budget_grid->LoadDefaultValues(); // Load default values
				$budget_grid->RowOldKey = ""; // Clear old key value
			}
		} else {
			$budget_grid->LoadRowValues($budget_grid->Recordset); // Load row values
		}
		$budget->RowType = EW_ROWTYPE_VIEW; // Render view
		if ($budget->CurrentAction == "gridadd") // Grid add
			$budget->RowType = EW_ROWTYPE_ADD; // Render add
		if ($budget->CurrentAction == "gridadd" && $budget->EventCancelled && !$objForm->HasValue("k_blankrow")) // Insert failed
			$budget_grid->RestoreCurrentRowFormValues($budget_grid->RowIndex); // Restore form values
		if ($budget->CurrentAction == "gridedit") { // Grid edit
			if ($budget->EventCancelled) {
				$budget_grid->RestoreCurrentRowFormValues($budget_grid->RowIndex); // Restore form values
			}
			if ($budget_grid->RowAction == "insert")
				$budget->RowType = EW_ROWTYPE_ADD; // Render add
			else
				$budget->RowType = EW_ROWTYPE_EDIT; // Render edit
		}
		if ($budget->CurrentAction == "gridedit" && ($budget->RowType == EW_ROWTYPE_EDIT || $budget->RowType == EW_ROWTYPE_ADD) && $budget->EventCancelled) // Update failed
			$budget_grid->RestoreCurrentRowFormValues($budget_grid->RowIndex); // Restore form values
		if ($budget->RowType == EW_ROWTYPE_EDIT) // Edit row
			$budget_grid->EditRowCnt++;
		if ($budget->CurrentAction == "F") // Confirm row
			$budget_grid->RestoreCurrentRowFormValues($budget_grid->RowIndex); // Restore form values

		// Set up row id / data-rowindex
		$budget->RowAttrs = array_merge($budget->RowAttrs, array('data-rowindex'=>$budget_grid->RowCnt, 'id'=>'r' . $budget_grid->RowCnt . '_budget', 'data-rowtype'=>$budget->RowType));

		// Render row
		$budget_grid->RenderRow();

		// Render list options
		$budget_grid->RenderListOptions();

		// Skip delete row / empty row for confirm page
		if ($budget_grid->RowAction <> "delete" && $budget_grid->RowAction <> "insertdelete" && !($budget_grid->RowAction == "insert" && $budget->CurrentAction == "F" && $budget_grid->EmptyRow())) {
?>
	<tr<?php echo $budget->RowAttributes() ?>>
<?php

// Render list options (body, left)
$budget_grid->ListOptions->Render("body", "left", $budget_grid->RowCnt);
?>
	<?php if ($budget->id->Visible) { // id ?>
		<td data-name="id"<?php echo $budget->id->CellAttributes() ?>>
<?php if ($budget->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<input type="hidden" data-table="budget" data-field="x_id" name="o<?php echo $budget_grid->RowIndex ?>_id" id="o<?php echo $budget_grid->RowIndex ?>_id" value="<?php echo ew_HtmlEncode($budget->id->OldValue) ?>">
<?php } ?>
<?php if ($budget->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $budget_grid->RowCnt ?>_budget_id" class="form-group budget_id">
<span<?php echo $budget->id->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $budget->id->EditValue ?></p></span>
</span>
<input type="hidden" data-table="budget" data-field="x_id" name="x<?php echo $budget_grid->RowIndex ?>_id" id="x<?php echo $budget_grid->RowIndex ?>_id" value="<?php echo ew_HtmlEncode($budget->id->CurrentValue) ?>">
<?php } ?>
<?php if ($budget->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $budget_grid->RowCnt ?>_budget_id" class="budget_id">
<span<?php echo $budget->id->ViewAttributes() ?>>
<?php echo $budget->id->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="budget" data-field="x_id" name="x<?php echo $budget_grid->RowIndex ?>_id" id="x<?php echo $budget_grid->RowIndex ?>_id" value="<?php echo ew_HtmlEncode($budget->id->FormValue) ?>">
<input type="hidden" data-table="budget" data-field="x_id" name="o<?php echo $budget_grid->RowIndex ?>_id" id="o<?php echo $budget_grid->RowIndex ?>_id" value="<?php echo ew_HtmlEncode($budget->id->OldValue) ?>">
<?php } ?>
<a id="<?php echo $budget_grid->PageObjName . "_row_" . $budget_grid->RowCnt ?>"></a></td>
	<?php } ?>
	<?php if ($budget->ProjectID->Visible) { // ProjectID ?>
		<td data-name="ProjectID"<?php echo $budget->ProjectID->CellAttributes() ?>>
<?php if ($budget->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<?php if ($budget->ProjectID->getSessionValue() <> "") { ?>
<span id="el<?php echo $budget_grid->RowCnt ?>_budget_ProjectID" class="form-group budget_ProjectID">
<span<?php echo $budget->ProjectID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $budget->ProjectID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $budget_grid->RowIndex ?>_ProjectID" name="x<?php echo $budget_grid->RowIndex ?>_ProjectID" value="<?php echo ew_HtmlEncode($budget->ProjectID->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $budget_grid->RowCnt ?>_budget_ProjectID" class="form-group budget_ProjectID">
<?php
$wrkonchange = trim(" " . @$budget->ProjectID->EditAttrs["onchange"]);
if ($wrkonchange <> "") $wrkonchange = " onchange=\"" . ew_JsEncode2($wrkonchange) . "\"";
$budget->ProjectID->EditAttrs["onchange"] = "";
?>
<span id="as_x<?php echo $budget_grid->RowIndex ?>_ProjectID" style="white-space: nowrap; z-index: <?php echo (9000 - $budget_grid->RowCnt * 10) ?>">
	<input type="text" name="sv_x<?php echo $budget_grid->RowIndex ?>_ProjectID" id="sv_x<?php echo $budget_grid->RowIndex ?>_ProjectID" value="<?php echo $budget->ProjectID->EditValue ?>" size="30" placeholder="<?php echo ew_HtmlEncode($budget->ProjectID->getPlaceHolder()) ?>" data-placeholder="<?php echo ew_HtmlEncode($budget->ProjectID->getPlaceHolder()) ?>"<?php echo $budget->ProjectID->EditAttributes() ?>>
</span>
<input type="hidden" data-table="budget" data-field="x_ProjectID" data-value-separator="<?php echo ew_HtmlEncode(is_array($budget->ProjectID->DisplayValueSeparator) ? json_encode($budget->ProjectID->DisplayValueSeparator) : $budget->ProjectID->DisplayValueSeparator) ?>" name="x<?php echo $budget_grid->RowIndex ?>_ProjectID" id="x<?php echo $budget_grid->RowIndex ?>_ProjectID" value="<?php echo ew_HtmlEncode($budget->ProjectID->CurrentValue) ?>"<?php echo $wrkonchange ?>>
<?php
$sSqlWrk = "SELECT `id`, `name` AS `DispFld` FROM `project`";
$sWhereWrk = "`name` LIKE '%{query_value}%'";
$lookuptblfilter = "`Active` = 'Y'";
ew_AddFilter($sWhereWrk, $lookuptblfilter);
$budget->Lookup_Selecting($budget->ProjectID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
$sSqlWrk .= " LIMIT " . EW_AUTO_SUGGEST_MAX_ENTRIES;
?>
<input type="hidden" name="q_x<?php echo $budget_grid->RowIndex ?>_ProjectID" id="q_x<?php echo $budget_grid->RowIndex ?>_ProjectID" value="s=<?php echo ew_Encrypt($sSqlWrk) ?>&d=">
<script type="text/javascript">
fbudgetgrid.CreateAutoSuggest({"id":"x<?php echo $budget_grid->RowIndex ?>_ProjectID","forceSelect":false});
</script>
</span>
<?php } ?>
<input type="hidden" data-table="budget" data-field="x_ProjectID" name="o<?php echo $budget_grid->RowIndex ?>_ProjectID" id="o<?php echo $budget_grid->RowIndex ?>_ProjectID" value="<?php echo ew_HtmlEncode($budget->ProjectID->OldValue) ?>">
<?php } ?>
<?php if ($budget->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<?php if ($budget->ProjectID->getSessionValue() <> "") { ?>
<span id="el<?php echo $budget_grid->RowCnt ?>_budget_ProjectID" class="form-group budget_ProjectID">
<span<?php echo $budget->ProjectID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $budget->ProjectID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $budget_grid->RowIndex ?>_ProjectID" name="x<?php echo $budget_grid->RowIndex ?>_ProjectID" value="<?php echo ew_HtmlEncode($budget->ProjectID->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $budget_grid->RowCnt ?>_budget_ProjectID" class="form-group budget_ProjectID">
<?php
$wrkonchange = trim(" " . @$budget->ProjectID->EditAttrs["onchange"]);
if ($wrkonchange <> "") $wrkonchange = " onchange=\"" . ew_JsEncode2($wrkonchange) . "\"";
$budget->ProjectID->EditAttrs["onchange"] = "";
?>
<span id="as_x<?php echo $budget_grid->RowIndex ?>_ProjectID" style="white-space: nowrap; z-index: <?php echo (9000 - $budget_grid->RowCnt * 10) ?>">
	<input type="text" name="sv_x<?php echo $budget_grid->RowIndex ?>_ProjectID" id="sv_x<?php echo $budget_grid->RowIndex ?>_ProjectID" value="<?php echo $budget->ProjectID->EditValue ?>" size="30" placeholder="<?php echo ew_HtmlEncode($budget->ProjectID->getPlaceHolder()) ?>" data-placeholder="<?php echo ew_HtmlEncode($budget->ProjectID->getPlaceHolder()) ?>"<?php echo $budget->ProjectID->EditAttributes() ?>>
</span>
<input type="hidden" data-table="budget" data-field="x_ProjectID" data-value-separator="<?php echo ew_HtmlEncode(is_array($budget->ProjectID->DisplayValueSeparator) ? json_encode($budget->ProjectID->DisplayValueSeparator) : $budget->ProjectID->DisplayValueSeparator) ?>" name="x<?php echo $budget_grid->RowIndex ?>_ProjectID" id="x<?php echo $budget_grid->RowIndex ?>_ProjectID" value="<?php echo ew_HtmlEncode($budget->ProjectID->CurrentValue) ?>"<?php echo $wrkonchange ?>>
<?php
$sSqlWrk = "SELECT `id`, `name` AS `DispFld` FROM `project`";
$sWhereWrk = "`name` LIKE '%{query_value}%'";
$lookuptblfilter = "`Active` = 'Y'";
ew_AddFilter($sWhereWrk, $lookuptblfilter);
$budget->Lookup_Selecting($budget->ProjectID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
$sSqlWrk .= " LIMIT " . EW_AUTO_SUGGEST_MAX_ENTRIES;
?>
<input type="hidden" name="q_x<?php echo $budget_grid->RowIndex ?>_ProjectID" id="q_x<?php echo $budget_grid->RowIndex ?>_ProjectID" value="s=<?php echo ew_Encrypt($sSqlWrk) ?>&d=">
<script type="text/javascript">
fbudgetgrid.CreateAutoSuggest({"id":"x<?php echo $budget_grid->RowIndex ?>_ProjectID","forceSelect":false});
</script>
</span>
<?php } ?>
<?php } ?>
<?php if ($budget->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $budget_grid->RowCnt ?>_budget_ProjectID" class="budget_ProjectID">
<span<?php echo $budget->ProjectID->ViewAttributes() ?>>
<?php echo $budget->ProjectID->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="budget" data-field="x_ProjectID" name="x<?php echo $budget_grid->RowIndex ?>_ProjectID" id="x<?php echo $budget_grid->RowIndex ?>_ProjectID" value="<?php echo ew_HtmlEncode($budget->ProjectID->FormValue) ?>">
<input type="hidden" data-table="budget" data-field="x_ProjectID" name="o<?php echo $budget_grid->RowIndex ?>_ProjectID" id="o<?php echo $budget_grid->RowIndex ?>_ProjectID" value="<?php echo ew_HtmlEncode($budget->ProjectID->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($budget->BudgetYear->Visible) { // BudgetYear ?>
		<td data-name="BudgetYear"<?php echo $budget->BudgetYear->CellAttributes() ?>>
<?php if ($budget->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $budget_grid->RowCnt ?>_budget_BudgetYear" class="form-group budget_BudgetYear">
<input type="text" data-table="budget" data-field="x_BudgetYear" name="x<?php echo $budget_grid->RowIndex ?>_BudgetYear" id="x<?php echo $budget_grid->RowIndex ?>_BudgetYear" size="30" placeholder="<?php echo ew_HtmlEncode($budget->BudgetYear->getPlaceHolder()) ?>" value="<?php echo $budget->BudgetYear->EditValue ?>"<?php echo $budget->BudgetYear->EditAttributes() ?>>
</span>
<input type="hidden" data-table="budget" data-field="x_BudgetYear" name="o<?php echo $budget_grid->RowIndex ?>_BudgetYear" id="o<?php echo $budget_grid->RowIndex ?>_BudgetYear" value="<?php echo ew_HtmlEncode($budget->BudgetYear->OldValue) ?>">
<?php } ?>
<?php if ($budget->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $budget_grid->RowCnt ?>_budget_BudgetYear" class="form-group budget_BudgetYear">
<input type="text" data-table="budget" data-field="x_BudgetYear" name="x<?php echo $budget_grid->RowIndex ?>_BudgetYear" id="x<?php echo $budget_grid->RowIndex ?>_BudgetYear" size="30" placeholder="<?php echo ew_HtmlEncode($budget->BudgetYear->getPlaceHolder()) ?>" value="<?php echo $budget->BudgetYear->EditValue ?>"<?php echo $budget->BudgetYear->EditAttributes() ?>>
</span>
<?php } ?>
<?php if ($budget->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $budget_grid->RowCnt ?>_budget_BudgetYear" class="budget_BudgetYear">
<span<?php echo $budget->BudgetYear->ViewAttributes() ?>>
<?php echo $budget->BudgetYear->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="budget" data-field="x_BudgetYear" name="x<?php echo $budget_grid->RowIndex ?>_BudgetYear" id="x<?php echo $budget_grid->RowIndex ?>_BudgetYear" value="<?php echo ew_HtmlEncode($budget->BudgetYear->FormValue) ?>">
<input type="hidden" data-table="budget" data-field="x_BudgetYear" name="o<?php echo $budget_grid->RowIndex ?>_BudgetYear" id="o<?php echo $budget_grid->RowIndex ?>_BudgetYear" value="<?php echo ew_HtmlEncode($budget->BudgetYear->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($budget->Amount->Visible) { // Amount ?>
		<td data-name="Amount"<?php echo $budget->Amount->CellAttributes() ?>>
<?php if ($budget->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $budget_grid->RowCnt ?>_budget_Amount" class="form-group budget_Amount">
<input type="text" data-table="budget" data-field="x_Amount" name="x<?php echo $budget_grid->RowIndex ?>_Amount" id="x<?php echo $budget_grid->RowIndex ?>_Amount" size="30" placeholder="<?php echo ew_HtmlEncode($budget->Amount->getPlaceHolder()) ?>" value="<?php echo $budget->Amount->EditValue ?>"<?php echo $budget->Amount->EditAttributes() ?>>
</span>
<input type="hidden" data-table="budget" data-field="x_Amount" name="o<?php echo $budget_grid->RowIndex ?>_Amount" id="o<?php echo $budget_grid->RowIndex ?>_Amount" value="<?php echo ew_HtmlEncode($budget->Amount->OldValue) ?>">
<?php } ?>
<?php if ($budget->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $budget_grid->RowCnt ?>_budget_Amount" class="form-group budget_Amount">
<input type="text" data-table="budget" data-field="x_Amount" name="x<?php echo $budget_grid->RowIndex ?>_Amount" id="x<?php echo $budget_grid->RowIndex ?>_Amount" size="30" placeholder="<?php echo ew_HtmlEncode($budget->Amount->getPlaceHolder()) ?>" value="<?php echo $budget->Amount->EditValue ?>"<?php echo $budget->Amount->EditAttributes() ?>>
</span>
<?php } ?>
<?php if ($budget->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $budget_grid->RowCnt ?>_budget_Amount" class="budget_Amount">
<span<?php echo $budget->Amount->ViewAttributes() ?>>
<?php echo $budget->Amount->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="budget" data-field="x_Amount" name="x<?php echo $budget_grid->RowIndex ?>_Amount" id="x<?php echo $budget_grid->RowIndex ?>_Amount" value="<?php echo ew_HtmlEncode($budget->Amount->FormValue) ?>">
<input type="hidden" data-table="budget" data-field="x_Amount" name="o<?php echo $budget_grid->RowIndex ?>_Amount" id="o<?php echo $budget_grid->RowIndex ?>_Amount" value="<?php echo ew_HtmlEncode($budget->Amount->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$budget_grid->ListOptions->Render("body", "right", $budget_grid->RowCnt);
?>
	</tr>
<?php if ($budget->RowType == EW_ROWTYPE_ADD || $budget->RowType == EW_ROWTYPE_EDIT) { ?>
<script type="text/javascript">
fbudgetgrid.UpdateOpts(<?php echo $budget_grid->RowIndex ?>);
</script>
<?php } ?>
<?php
	}
	} // End delete row checking
	if ($budget->CurrentAction <> "gridadd" || $budget->CurrentMode == "copy")
		if (!$budget_grid->Recordset->EOF) $budget_grid->Recordset->MoveNext();
}
?>
<?php
	if ($budget->CurrentMode == "add" || $budget->CurrentMode == "copy" || $budget->CurrentMode == "edit") {
		$budget_grid->RowIndex = '$rowindex$';
		$budget_grid->LoadDefaultValues();

		// Set row properties
		$budget->ResetAttrs();
		$budget->RowAttrs = array_merge($budget->RowAttrs, array('data-rowindex'=>$budget_grid->RowIndex, 'id'=>'r0_budget', 'data-rowtype'=>EW_ROWTYPE_ADD));
		ew_AppendClass($budget->RowAttrs["class"], "ewTemplate");
		$budget->RowType = EW_ROWTYPE_ADD;

		// Render row
		$budget_grid->RenderRow();

		// Render list options
		$budget_grid->RenderListOptions();
		$budget_grid->StartRowCnt = 0;
?>
	<tr<?php echo $budget->RowAttributes() ?>>
<?php

// Render list options (body, left)
$budget_grid->ListOptions->Render("body", "left", $budget_grid->RowIndex);
?>
	<?php if ($budget->id->Visible) { // id ?>
		<td data-name="id">
<?php if ($budget->CurrentAction <> "F") { ?>
<?php } else { ?>
<span id="el$rowindex$_budget_id" class="form-group budget_id">
<span<?php echo $budget->id->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $budget->id->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="budget" data-field="x_id" name="x<?php echo $budget_grid->RowIndex ?>_id" id="x<?php echo $budget_grid->RowIndex ?>_id" value="<?php echo ew_HtmlEncode($budget->id->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="budget" data-field="x_id" name="o<?php echo $budget_grid->RowIndex ?>_id" id="o<?php echo $budget_grid->RowIndex ?>_id" value="<?php echo ew_HtmlEncode($budget->id->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($budget->ProjectID->Visible) { // ProjectID ?>
		<td data-name="ProjectID">
<?php if ($budget->CurrentAction <> "F") { ?>
<?php if ($budget->ProjectID->getSessionValue() <> "") { ?>
<span id="el$rowindex$_budget_ProjectID" class="form-group budget_ProjectID">
<span<?php echo $budget->ProjectID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $budget->ProjectID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $budget_grid->RowIndex ?>_ProjectID" name="x<?php echo $budget_grid->RowIndex ?>_ProjectID" value="<?php echo ew_HtmlEncode($budget->ProjectID->CurrentValue) ?>">
<?php } else { ?>
<span id="el$rowindex$_budget_ProjectID" class="form-group budget_ProjectID">
<?php
$wrkonchange = trim(" " . @$budget->ProjectID->EditAttrs["onchange"]);
if ($wrkonchange <> "") $wrkonchange = " onchange=\"" . ew_JsEncode2($wrkonchange) . "\"";
$budget->ProjectID->EditAttrs["onchange"] = "";
?>
<span id="as_x<?php echo $budget_grid->RowIndex ?>_ProjectID" style="white-space: nowrap; z-index: <?php echo (9000 - $budget_grid->RowCnt * 10) ?>">
	<input type="text" name="sv_x<?php echo $budget_grid->RowIndex ?>_ProjectID" id="sv_x<?php echo $budget_grid->RowIndex ?>_ProjectID" value="<?php echo $budget->ProjectID->EditValue ?>" size="30" placeholder="<?php echo ew_HtmlEncode($budget->ProjectID->getPlaceHolder()) ?>" data-placeholder="<?php echo ew_HtmlEncode($budget->ProjectID->getPlaceHolder()) ?>"<?php echo $budget->ProjectID->EditAttributes() ?>>
</span>
<input type="hidden" data-table="budget" data-field="x_ProjectID" data-value-separator="<?php echo ew_HtmlEncode(is_array($budget->ProjectID->DisplayValueSeparator) ? json_encode($budget->ProjectID->DisplayValueSeparator) : $budget->ProjectID->DisplayValueSeparator) ?>" name="x<?php echo $budget_grid->RowIndex ?>_ProjectID" id="x<?php echo $budget_grid->RowIndex ?>_ProjectID" value="<?php echo ew_HtmlEncode($budget->ProjectID->CurrentValue) ?>"<?php echo $wrkonchange ?>>
<?php
$sSqlWrk = "SELECT `id`, `name` AS `DispFld` FROM `project`";
$sWhereWrk = "`name` LIKE '%{query_value}%'";
$lookuptblfilter = "`Active` = 'Y'";
ew_AddFilter($sWhereWrk, $lookuptblfilter);
$budget->Lookup_Selecting($budget->ProjectID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
$sSqlWrk .= " LIMIT " . EW_AUTO_SUGGEST_MAX_ENTRIES;
?>
<input type="hidden" name="q_x<?php echo $budget_grid->RowIndex ?>_ProjectID" id="q_x<?php echo $budget_grid->RowIndex ?>_ProjectID" value="s=<?php echo ew_Encrypt($sSqlWrk) ?>&d=">
<script type="text/javascript">
fbudgetgrid.CreateAutoSuggest({"id":"x<?php echo $budget_grid->RowIndex ?>_ProjectID","forceSelect":false});
</script>
</span>
<?php } ?>
<?php } else { ?>
<span id="el$rowindex$_budget_ProjectID" class="form-group budget_ProjectID">
<span<?php echo $budget->ProjectID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $budget->ProjectID->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="budget" data-field="x_ProjectID" name="x<?php echo $budget_grid->RowIndex ?>_ProjectID" id="x<?php echo $budget_grid->RowIndex ?>_ProjectID" value="<?php echo ew_HtmlEncode($budget->ProjectID->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="budget" data-field="x_ProjectID" name="o<?php echo $budget_grid->RowIndex ?>_ProjectID" id="o<?php echo $budget_grid->RowIndex ?>_ProjectID" value="<?php echo ew_HtmlEncode($budget->ProjectID->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($budget->BudgetYear->Visible) { // BudgetYear ?>
		<td data-name="BudgetYear">
<?php if ($budget->CurrentAction <> "F") { ?>
<span id="el$rowindex$_budget_BudgetYear" class="form-group budget_BudgetYear">
<input type="text" data-table="budget" data-field="x_BudgetYear" name="x<?php echo $budget_grid->RowIndex ?>_BudgetYear" id="x<?php echo $budget_grid->RowIndex ?>_BudgetYear" size="30" placeholder="<?php echo ew_HtmlEncode($budget->BudgetYear->getPlaceHolder()) ?>" value="<?php echo $budget->BudgetYear->EditValue ?>"<?php echo $budget->BudgetYear->EditAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_budget_BudgetYear" class="form-group budget_BudgetYear">
<span<?php echo $budget->BudgetYear->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $budget->BudgetYear->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="budget" data-field="x_BudgetYear" name="x<?php echo $budget_grid->RowIndex ?>_BudgetYear" id="x<?php echo $budget_grid->RowIndex ?>_BudgetYear" value="<?php echo ew_HtmlEncode($budget->BudgetYear->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="budget" data-field="x_BudgetYear" name="o<?php echo $budget_grid->RowIndex ?>_BudgetYear" id="o<?php echo $budget_grid->RowIndex ?>_BudgetYear" value="<?php echo ew_HtmlEncode($budget->BudgetYear->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($budget->Amount->Visible) { // Amount ?>
		<td data-name="Amount">
<?php if ($budget->CurrentAction <> "F") { ?>
<span id="el$rowindex$_budget_Amount" class="form-group budget_Amount">
<input type="text" data-table="budget" data-field="x_Amount" name="x<?php echo $budget_grid->RowIndex ?>_Amount" id="x<?php echo $budget_grid->RowIndex ?>_Amount" size="30" placeholder="<?php echo ew_HtmlEncode($budget->Amount->getPlaceHolder()) ?>" value="<?php echo $budget->Amount->EditValue ?>"<?php echo $budget->Amount->EditAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_budget_Amount" class="form-group budget_Amount">
<span<?php echo $budget->Amount->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $budget->Amount->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="budget" data-field="x_Amount" name="x<?php echo $budget_grid->RowIndex ?>_Amount" id="x<?php echo $budget_grid->RowIndex ?>_Amount" value="<?php echo ew_HtmlEncode($budget->Amount->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="budget" data-field="x_Amount" name="o<?php echo $budget_grid->RowIndex ?>_Amount" id="o<?php echo $budget_grid->RowIndex ?>_Amount" value="<?php echo ew_HtmlEncode($budget->Amount->OldValue) ?>">
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$budget_grid->ListOptions->Render("body", "right", $budget_grid->RowCnt);
?>
<script type="text/javascript">
fbudgetgrid.UpdateOpts(<?php echo $budget_grid->RowIndex ?>);
</script>
	</tr>
<?php
}
?>
</tbody>
</table>
<?php if ($budget->CurrentMode == "add" || $budget->CurrentMode == "copy") { ?>
<input type="hidden" name="a_list" id="a_list" value="gridinsert">
<input type="hidden" name="<?php echo $budget_grid->FormKeyCountName ?>" id="<?php echo $budget_grid->FormKeyCountName ?>" value="<?php echo $budget_grid->KeyCount ?>">
<?php echo $budget_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($budget->CurrentMode == "edit") { ?>
<input type="hidden" name="a_list" id="a_list" value="gridupdate">
<input type="hidden" name="<?php echo $budget_grid->FormKeyCountName ?>" id="<?php echo $budget_grid->FormKeyCountName ?>" value="<?php echo $budget_grid->KeyCount ?>">
<?php echo $budget_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($budget->CurrentMode == "") { ?>
<input type="hidden" name="a_list" id="a_list" value="">
<?php } ?>
<input type="hidden" name="detailpage" value="fbudgetgrid">
</div>
<?php

// Close recordset
if ($budget_grid->Recordset)
	$budget_grid->Recordset->Close();
?>
<?php if ($budget_grid->ShowOtherOptions) { ?>
<div class="panel-footer ewGridLowerPanel">
<?php
	foreach ($budget_grid->OtherOptions as &$option)
		$option->Render("body", "bottom");
?>
</div>
<div class="clearfix"></div>
<?php } ?>
</div>
</div>
<?php } ?>
<?php if ($budget_grid->TotalRecs == 0 && $budget->CurrentAction == "") { // Show other options ?>
<div class="ewListOtherOptions">
<?php
	foreach ($budget_grid->OtherOptions as &$option) {
		$option->ButtonClass = "";
		$option->Render("body", "");
	}
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php if ($budget->Export == "") { ?>
<script type="text/javascript">
fbudgetgrid.Init();
</script>
<?php } ?>
<?php
$budget_grid->ShowPageFooter();
if (EW_DEBUG_ENABLED)
	echo ew_DebugMsg();
?>
<?php
$budget_grid->Page_Terminate();
?>
