<?php include_once "staffinfo.php" ?>
<?php

// Create page object
if (!isset($mtm_staff_project_grid)) $mtm_staff_project_grid = new cmtm_staff_project_grid();

// Page init
$mtm_staff_project_grid->Page_Init();

// Page main
$mtm_staff_project_grid->Page_Main();

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$mtm_staff_project_grid->Page_Render();
?>
<?php if ($mtm_staff_project->Export == "") { ?>
<script type="text/javascript">

// Form object
var fmtm_staff_projectgrid = new ew_Form("fmtm_staff_projectgrid", "grid");
fmtm_staff_projectgrid.FormKeyCountName = '<?php echo $mtm_staff_project_grid->FormKeyCountName ?>';

// Validate form
fmtm_staff_projectgrid.Validate = function() {
	if (!this.ValidateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.GetForm(), $fobj = $(fobj);
	if ($fobj.find("#a_confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.FormKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = $fobj.find("#a_list").val() == "gridinsert";
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
		var checkrow = (gridinsert) ? !this.EmptyRow(infix) : true;
		if (checkrow) {
			addcnt++;
			elm = this.GetElements("x" + infix + "_projID");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $mtm_staff_project->projID->FldCaption(), $mtm_staff_project->projID->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_staffID");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $mtm_staff_project->staffID->FldCaption(), $mtm_staff_project->staffID->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_TimeSpentProject");
			if (elm && !ew_CheckInteger(elm.value))
				return this.OnError(elm, "<?php echo ew_JsEncode2($mtm_staff_project->TimeSpentProject->FldErrMsg()) ?>");

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
		} // End Grid Add checking
	}
	return true;
}

// Check empty row
fmtm_staff_projectgrid.EmptyRow = function(infix) {
	var fobj = this.Form;
	if (ew_ValueChanged(fobj, infix, "projID", false)) return false;
	if (ew_ValueChanged(fobj, infix, "staffID", false)) return false;
	if (ew_ValueChanged(fobj, infix, "role", false)) return false;
	if (ew_ValueChanged(fobj, infix, "TimeSpentProject", false)) return false;
	return true;
}

// Form_CustomValidate event
fmtm_staff_projectgrid.Form_CustomValidate = 
 function(fobj) { // DO NOT CHANGE THIS LINE!

 	// Your custom validation code here, return false if invalid. 
 	return true;
 }

// Use JavaScript validation or not
<?php if (EW_CLIENT_VALIDATE) { ?>
fmtm_staff_projectgrid.ValidateRequired = true;
<?php } else { ?>
fmtm_staff_projectgrid.ValidateRequired = false; 
<?php } ?>

// Dynamic selection lists
fmtm_staff_projectgrid.Lists["x_projID"] = {"LinkField":"x_id","Ajax":true,"AutoFill":false,"DisplayFields":["x_name","","",""],"ParentFields":[],"ChildFields":[],"FilterFields":[],"Options":[],"Template":""};
fmtm_staff_projectgrid.Lists["x_staffID"] = {"LinkField":"x_id","Ajax":true,"AutoFill":false,"DisplayFields":["x_Name","","",""],"ParentFields":[],"ChildFields":[],"FilterFields":[],"Options":[],"Template":""};
fmtm_staff_projectgrid.Lists["x_role"] = {"LinkField":"","Ajax":null,"AutoFill":false,"DisplayFields":["","","",""],"ParentFields":[],"ChildFields":[],"FilterFields":[],"Options":[],"Template":""};
fmtm_staff_projectgrid.Lists["x_role"].Options = <?php echo json_encode($mtm_staff_project->role->Options()) ?>;

// Form object for search
</script>
<?php } ?>
<?php
if ($mtm_staff_project->CurrentAction == "gridadd") {
	if ($mtm_staff_project->CurrentMode == "copy") {
		$bSelectLimit = $mtm_staff_project_grid->UseSelectLimit;
		if ($bSelectLimit) {
			$mtm_staff_project_grid->TotalRecs = $mtm_staff_project->SelectRecordCount();
			$mtm_staff_project_grid->Recordset = $mtm_staff_project_grid->LoadRecordset($mtm_staff_project_grid->StartRec-1, $mtm_staff_project_grid->DisplayRecs);
		} else {
			if ($mtm_staff_project_grid->Recordset = $mtm_staff_project_grid->LoadRecordset())
				$mtm_staff_project_grid->TotalRecs = $mtm_staff_project_grid->Recordset->RecordCount();
		}
		$mtm_staff_project_grid->StartRec = 1;
		$mtm_staff_project_grid->DisplayRecs = $mtm_staff_project_grid->TotalRecs;
	} else {
		$mtm_staff_project->CurrentFilter = "0=1";
		$mtm_staff_project_grid->StartRec = 1;
		$mtm_staff_project_grid->DisplayRecs = $mtm_staff_project->GridAddRowCount;
	}
	$mtm_staff_project_grid->TotalRecs = $mtm_staff_project_grid->DisplayRecs;
	$mtm_staff_project_grid->StopRec = $mtm_staff_project_grid->DisplayRecs;
} else {
	$bSelectLimit = $mtm_staff_project_grid->UseSelectLimit;
	if ($bSelectLimit) {
		if ($mtm_staff_project_grid->TotalRecs <= 0)
			$mtm_staff_project_grid->TotalRecs = $mtm_staff_project->SelectRecordCount();
	} else {
		if (!$mtm_staff_project_grid->Recordset && ($mtm_staff_project_grid->Recordset = $mtm_staff_project_grid->LoadRecordset()))
			$mtm_staff_project_grid->TotalRecs = $mtm_staff_project_grid->Recordset->RecordCount();
	}
	$mtm_staff_project_grid->StartRec = 1;
	$mtm_staff_project_grid->DisplayRecs = $mtm_staff_project_grid->TotalRecs; // Display all records
	if ($bSelectLimit)
		$mtm_staff_project_grid->Recordset = $mtm_staff_project_grid->LoadRecordset($mtm_staff_project_grid->StartRec-1, $mtm_staff_project_grid->DisplayRecs);

	// Set no record found message
	if ($mtm_staff_project->CurrentAction == "" && $mtm_staff_project_grid->TotalRecs == 0) {
		if (!$Security->CanList())
			$mtm_staff_project_grid->setWarningMessage(ew_DeniedMsg());
		if ($mtm_staff_project_grid->SearchWhere == "0=101")
			$mtm_staff_project_grid->setWarningMessage($Language->Phrase("EnterSearchCriteria"));
		else
			$mtm_staff_project_grid->setWarningMessage($Language->Phrase("NoRecord"));
	}
}
$mtm_staff_project_grid->RenderOtherOptions();
?>
<?php $mtm_staff_project_grid->ShowPageHeader(); ?>
<?php
$mtm_staff_project_grid->ShowMessage();
?>
<?php if ($mtm_staff_project_grid->TotalRecs > 0 || $mtm_staff_project->CurrentAction <> "") { ?>
<div class="panel panel-default ewGrid">
<div id="fmtm_staff_projectgrid" class="ewForm form-inline">
<?php if ($mtm_staff_project_grid->ShowOtherOptions) { ?>
<div class="panel-heading ewGridUpperPanel">
<?php
	foreach ($mtm_staff_project_grid->OtherOptions as &$option)
		$option->Render("body");
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<div id="gmp_mtm_staff_project" class="<?php if (ew_IsResponsiveLayout()) { echo "table-responsive "; } ?>ewGridMiddlePanel">
<table id="tbl_mtm_staff_projectgrid" class="table ewTable">
<?php echo $mtm_staff_project->TableCustomInnerHtml ?>
<thead><!-- Table header -->
	<tr class="ewTableHeader">
<?php

// Header row
$mtm_staff_project_grid->RowType = EW_ROWTYPE_HEADER;

// Render list options
$mtm_staff_project_grid->RenderListOptions();

// Render list options (header, left)
$mtm_staff_project_grid->ListOptions->Render("header", "left");
?>
<?php if ($mtm_staff_project->projID->Visible) { // projID ?>
	<?php if ($mtm_staff_project->SortUrl($mtm_staff_project->projID) == "") { ?>
		<th data-name="projID"><div id="elh_mtm_staff_project_projID" class="mtm_staff_project_projID"><div class="ewTableHeaderCaption"><?php echo $mtm_staff_project->projID->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="projID"><div><div id="elh_mtm_staff_project_projID" class="mtm_staff_project_projID">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $mtm_staff_project->projID->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($mtm_staff_project->projID->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($mtm_staff_project->projID->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($mtm_staff_project->staffID->Visible) { // staffID ?>
	<?php if ($mtm_staff_project->SortUrl($mtm_staff_project->staffID) == "") { ?>
		<th data-name="staffID"><div id="elh_mtm_staff_project_staffID" class="mtm_staff_project_staffID"><div class="ewTableHeaderCaption"><?php echo $mtm_staff_project->staffID->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="staffID"><div><div id="elh_mtm_staff_project_staffID" class="mtm_staff_project_staffID">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $mtm_staff_project->staffID->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($mtm_staff_project->staffID->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($mtm_staff_project->staffID->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($mtm_staff_project->role->Visible) { // role ?>
	<?php if ($mtm_staff_project->SortUrl($mtm_staff_project->role) == "") { ?>
		<th data-name="role"><div id="elh_mtm_staff_project_role" class="mtm_staff_project_role"><div class="ewTableHeaderCaption"><?php echo $mtm_staff_project->role->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="role"><div><div id="elh_mtm_staff_project_role" class="mtm_staff_project_role">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $mtm_staff_project->role->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($mtm_staff_project->role->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($mtm_staff_project->role->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($mtm_staff_project->TimeSpentProject->Visible) { // TimeSpentProject ?>
	<?php if ($mtm_staff_project->SortUrl($mtm_staff_project->TimeSpentProject) == "") { ?>
		<th data-name="TimeSpentProject"><div id="elh_mtm_staff_project_TimeSpentProject" class="mtm_staff_project_TimeSpentProject"><div class="ewTableHeaderCaption"><?php echo $mtm_staff_project->TimeSpentProject->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="TimeSpentProject"><div><div id="elh_mtm_staff_project_TimeSpentProject" class="mtm_staff_project_TimeSpentProject">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $mtm_staff_project->TimeSpentProject->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($mtm_staff_project->TimeSpentProject->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($mtm_staff_project->TimeSpentProject->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php

// Render list options (header, right)
$mtm_staff_project_grid->ListOptions->Render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
$mtm_staff_project_grid->StartRec = 1;
$mtm_staff_project_grid->StopRec = $mtm_staff_project_grid->TotalRecs; // Show all records

// Restore number of post back records
if ($objForm) {
	$objForm->Index = -1;
	if ($objForm->HasValue($mtm_staff_project_grid->FormKeyCountName) && ($mtm_staff_project->CurrentAction == "gridadd" || $mtm_staff_project->CurrentAction == "gridedit" || $mtm_staff_project->CurrentAction == "F")) {
		$mtm_staff_project_grid->KeyCount = $objForm->GetValue($mtm_staff_project_grid->FormKeyCountName);
		$mtm_staff_project_grid->StopRec = $mtm_staff_project_grid->StartRec + $mtm_staff_project_grid->KeyCount - 1;
	}
}
$mtm_staff_project_grid->RecCnt = $mtm_staff_project_grid->StartRec - 1;
if ($mtm_staff_project_grid->Recordset && !$mtm_staff_project_grid->Recordset->EOF) {
	$mtm_staff_project_grid->Recordset->MoveFirst();
	$bSelectLimit = $mtm_staff_project_grid->UseSelectLimit;
	if (!$bSelectLimit && $mtm_staff_project_grid->StartRec > 1)
		$mtm_staff_project_grid->Recordset->Move($mtm_staff_project_grid->StartRec - 1);
} elseif (!$mtm_staff_project->AllowAddDeleteRow && $mtm_staff_project_grid->StopRec == 0) {
	$mtm_staff_project_grid->StopRec = $mtm_staff_project->GridAddRowCount;
}

// Initialize aggregate
$mtm_staff_project->RowType = EW_ROWTYPE_AGGREGATEINIT;
$mtm_staff_project->ResetAttrs();
$mtm_staff_project_grid->RenderRow();
if ($mtm_staff_project->CurrentAction == "gridadd")
	$mtm_staff_project_grid->RowIndex = 0;
if ($mtm_staff_project->CurrentAction == "gridedit")
	$mtm_staff_project_grid->RowIndex = 0;
while ($mtm_staff_project_grid->RecCnt < $mtm_staff_project_grid->StopRec) {
	$mtm_staff_project_grid->RecCnt++;
	if (intval($mtm_staff_project_grid->RecCnt) >= intval($mtm_staff_project_grid->StartRec)) {
		$mtm_staff_project_grid->RowCnt++;
		if ($mtm_staff_project->CurrentAction == "gridadd" || $mtm_staff_project->CurrentAction == "gridedit" || $mtm_staff_project->CurrentAction == "F") {
			$mtm_staff_project_grid->RowIndex++;
			$objForm->Index = $mtm_staff_project_grid->RowIndex;
			if ($objForm->HasValue($mtm_staff_project_grid->FormActionName))
				$mtm_staff_project_grid->RowAction = strval($objForm->GetValue($mtm_staff_project_grid->FormActionName));
			elseif ($mtm_staff_project->CurrentAction == "gridadd")
				$mtm_staff_project_grid->RowAction = "insert";
			else
				$mtm_staff_project_grid->RowAction = "";
		}

		// Set up key count
		$mtm_staff_project_grid->KeyCount = $mtm_staff_project_grid->RowIndex;

		// Init row class and style
		$mtm_staff_project->ResetAttrs();
		$mtm_staff_project->CssClass = "";
		if ($mtm_staff_project->CurrentAction == "gridadd") {
			if ($mtm_staff_project->CurrentMode == "copy") {
				$mtm_staff_project_grid->LoadRowValues($mtm_staff_project_grid->Recordset); // Load row values
				$mtm_staff_project_grid->SetRecordKey($mtm_staff_project_grid->RowOldKey, $mtm_staff_project_grid->Recordset); // Set old record key
			} else {
				$mtm_staff_project_grid->LoadDefaultValues(); // Load default values
				$mtm_staff_project_grid->RowOldKey = ""; // Clear old key value
			}
		} else {
			$mtm_staff_project_grid->LoadRowValues($mtm_staff_project_grid->Recordset); // Load row values
		}
		$mtm_staff_project->RowType = EW_ROWTYPE_VIEW; // Render view
		if ($mtm_staff_project->CurrentAction == "gridadd") // Grid add
			$mtm_staff_project->RowType = EW_ROWTYPE_ADD; // Render add
		if ($mtm_staff_project->CurrentAction == "gridadd" && $mtm_staff_project->EventCancelled && !$objForm->HasValue("k_blankrow")) // Insert failed
			$mtm_staff_project_grid->RestoreCurrentRowFormValues($mtm_staff_project_grid->RowIndex); // Restore form values
		if ($mtm_staff_project->CurrentAction == "gridedit") { // Grid edit
			if ($mtm_staff_project->EventCancelled) {
				$mtm_staff_project_grid->RestoreCurrentRowFormValues($mtm_staff_project_grid->RowIndex); // Restore form values
			}
			if ($mtm_staff_project_grid->RowAction == "insert")
				$mtm_staff_project->RowType = EW_ROWTYPE_ADD; // Render add
			else
				$mtm_staff_project->RowType = EW_ROWTYPE_EDIT; // Render edit
		}
		if ($mtm_staff_project->CurrentAction == "gridedit" && ($mtm_staff_project->RowType == EW_ROWTYPE_EDIT || $mtm_staff_project->RowType == EW_ROWTYPE_ADD) && $mtm_staff_project->EventCancelled) // Update failed
			$mtm_staff_project_grid->RestoreCurrentRowFormValues($mtm_staff_project_grid->RowIndex); // Restore form values
		if ($mtm_staff_project->RowType == EW_ROWTYPE_EDIT) // Edit row
			$mtm_staff_project_grid->EditRowCnt++;
		if ($mtm_staff_project->CurrentAction == "F") // Confirm row
			$mtm_staff_project_grid->RestoreCurrentRowFormValues($mtm_staff_project_grid->RowIndex); // Restore form values

		// Set up row id / data-rowindex
		$mtm_staff_project->RowAttrs = array_merge($mtm_staff_project->RowAttrs, array('data-rowindex'=>$mtm_staff_project_grid->RowCnt, 'id'=>'r' . $mtm_staff_project_grid->RowCnt . '_mtm_staff_project', 'data-rowtype'=>$mtm_staff_project->RowType));

		// Render row
		$mtm_staff_project_grid->RenderRow();

		// Render list options
		$mtm_staff_project_grid->RenderListOptions();

		// Skip delete row / empty row for confirm page
		if ($mtm_staff_project_grid->RowAction <> "delete" && $mtm_staff_project_grid->RowAction <> "insertdelete" && !($mtm_staff_project_grid->RowAction == "insert" && $mtm_staff_project->CurrentAction == "F" && $mtm_staff_project_grid->EmptyRow())) {
?>
	<tr<?php echo $mtm_staff_project->RowAttributes() ?>>
<?php

// Render list options (body, left)
$mtm_staff_project_grid->ListOptions->Render("body", "left", $mtm_staff_project_grid->RowCnt);
?>
	<?php if ($mtm_staff_project->projID->Visible) { // projID ?>
		<td data-name="projID"<?php echo $mtm_staff_project->projID->CellAttributes() ?>>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<?php if ($mtm_staff_project->projID->getSessionValue() <> "") { ?>
<span id="el<?php echo $mtm_staff_project_grid->RowCnt ?>_mtm_staff_project_projID" class="form-group mtm_staff_project_projID">
<span<?php echo $mtm_staff_project->projID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_project->projID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_projID" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_projID" value="<?php echo ew_HtmlEncode($mtm_staff_project->projID->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $mtm_staff_project_grid->RowCnt ?>_mtm_staff_project_projID" class="form-group mtm_staff_project_projID">
<select data-table="mtm_staff_project" data-field="x_projID" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_project->projID->DisplayValueSeparator) ? json_encode($mtm_staff_project->projID->DisplayValueSeparator) : $mtm_staff_project->projID->DisplayValueSeparator) ?>" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_projID" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_projID"<?php echo $mtm_staff_project->projID->EditAttributes() ?>>
<?php
if (is_array($mtm_staff_project->projID->EditValue)) {
	$arwrk = $mtm_staff_project->projID->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = ew_SameStr($mtm_staff_project->projID->CurrentValue, $arwrk[$rowcntwrk][0]) ? " selected" : "";
		if ($selwrk <> "") $emptywrk = FALSE;		
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $mtm_staff_project->projID->DisplayValue($arwrk[$rowcntwrk]) ?>
</option>
<?php
	}
	if ($emptywrk && strval($mtm_staff_project->projID->CurrentValue) <> "") {
?>
<option value="<?php echo ew_HtmlEncode($mtm_staff_project->projID->CurrentValue) ?>" selected><?php echo $mtm_staff_project->projID->CurrentValue ?></option>
<?php
    }
}
if (@$emptywrk) $mtm_staff_project->projID->OldValue = "";
?>
</select>
<?php
$sSqlWrk = "SELECT `id`, `name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `project`";
$sWhereWrk = "";
$mtm_staff_project->projID->LookupFilters = array("s" => $sSqlWrk, "d" => "");
$mtm_staff_project->projID->LookupFilters += array("f0" => "`id` = {filter_value}", "t0" => "16", "fn0" => "");
$sSqlWrk = "";
$mtm_staff_project->Lookup_Selecting($mtm_staff_project->projID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
if ($sSqlWrk <> "") $mtm_staff_project->projID->LookupFilters["s"] .= $sSqlWrk;
?>
<input type="hidden" name="s_x<?php echo $mtm_staff_project_grid->RowIndex ?>_projID" id="s_x<?php echo $mtm_staff_project_grid->RowIndex ?>_projID" value="<?php echo $mtm_staff_project->projID->LookupFilterQuery() ?>">
</span>
<?php } ?>
<input type="hidden" data-table="mtm_staff_project" data-field="x_projID" name="o<?php echo $mtm_staff_project_grid->RowIndex ?>_projID" id="o<?php echo $mtm_staff_project_grid->RowIndex ?>_projID" value="<?php echo ew_HtmlEncode($mtm_staff_project->projID->OldValue) ?>">
<?php } ?>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mtm_staff_project_grid->RowCnt ?>_mtm_staff_project_projID" class="form-group mtm_staff_project_projID">
<span<?php echo $mtm_staff_project->projID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_project->projID->EditValue ?></p></span>
</span>
<input type="hidden" data-table="mtm_staff_project" data-field="x_projID" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_projID" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_projID" value="<?php echo ew_HtmlEncode($mtm_staff_project->projID->CurrentValue) ?>">
<?php } ?>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mtm_staff_project_grid->RowCnt ?>_mtm_staff_project_projID" class="mtm_staff_project_projID">
<span<?php echo $mtm_staff_project->projID->ViewAttributes() ?>>
<?php echo $mtm_staff_project->projID->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="mtm_staff_project" data-field="x_projID" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_projID" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_projID" value="<?php echo ew_HtmlEncode($mtm_staff_project->projID->FormValue) ?>">
<input type="hidden" data-table="mtm_staff_project" data-field="x_projID" name="o<?php echo $mtm_staff_project_grid->RowIndex ?>_projID" id="o<?php echo $mtm_staff_project_grid->RowIndex ?>_projID" value="<?php echo ew_HtmlEncode($mtm_staff_project->projID->OldValue) ?>">
<?php } ?>
<a id="<?php echo $mtm_staff_project_grid->PageObjName . "_row_" . $mtm_staff_project_grid->RowCnt ?>"></a></td>
	<?php } ?>
	<?php if ($mtm_staff_project->staffID->Visible) { // staffID ?>
		<td data-name="staffID"<?php echo $mtm_staff_project->staffID->CellAttributes() ?>>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<?php if ($mtm_staff_project->staffID->getSessionValue() <> "") { ?>
<span id="el<?php echo $mtm_staff_project_grid->RowCnt ?>_mtm_staff_project_staffID" class="form-group mtm_staff_project_staffID">
<span<?php echo $mtm_staff_project->staffID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_project->staffID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_project->staffID->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $mtm_staff_project_grid->RowCnt ?>_mtm_staff_project_staffID" class="form-group mtm_staff_project_staffID">
<select data-table="mtm_staff_project" data-field="x_staffID" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_project->staffID->DisplayValueSeparator) ? json_encode($mtm_staff_project->staffID->DisplayValueSeparator) : $mtm_staff_project->staffID->DisplayValueSeparator) ?>" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID"<?php echo $mtm_staff_project->staffID->EditAttributes() ?>>
<?php
if (is_array($mtm_staff_project->staffID->EditValue)) {
	$arwrk = $mtm_staff_project->staffID->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = ew_SameStr($mtm_staff_project->staffID->CurrentValue, $arwrk[$rowcntwrk][0]) ? " selected" : "";
		if ($selwrk <> "") $emptywrk = FALSE;		
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $mtm_staff_project->staffID->DisplayValue($arwrk[$rowcntwrk]) ?>
</option>
<?php
	}
	if ($emptywrk && strval($mtm_staff_project->staffID->CurrentValue) <> "") {
?>
<option value="<?php echo ew_HtmlEncode($mtm_staff_project->staffID->CurrentValue) ?>" selected><?php echo $mtm_staff_project->staffID->CurrentValue ?></option>
<?php
    }
}
if (@$emptywrk) $mtm_staff_project->staffID->OldValue = "";
?>
</select>
<?php
$sSqlWrk = "SELECT `id`, `Name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `staff`";
$sWhereWrk = "";
if (!$GLOBALS["mtm_staff_project"]->UserIDAllow("grid")) $sWhereWrk = $GLOBALS["staff"]->AddUserIDFilter($sWhereWrk);
$mtm_staff_project->staffID->LookupFilters = array("s" => $sSqlWrk, "d" => "");
$mtm_staff_project->staffID->LookupFilters += array("f0" => "`id` = {filter_value}", "t0" => "3", "fn0" => "");
$sSqlWrk = "";
$mtm_staff_project->Lookup_Selecting($mtm_staff_project->staffID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
if ($sSqlWrk <> "") $mtm_staff_project->staffID->LookupFilters["s"] .= $sSqlWrk;
?>
<input type="hidden" name="s_x<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID" id="s_x<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID" value="<?php echo $mtm_staff_project->staffID->LookupFilterQuery() ?>">
</span>
<?php } ?>
<input type="hidden" data-table="mtm_staff_project" data-field="x_staffID" name="o<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID" id="o<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_project->staffID->OldValue) ?>">
<?php } ?>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mtm_staff_project_grid->RowCnt ?>_mtm_staff_project_staffID" class="form-group mtm_staff_project_staffID">
<span<?php echo $mtm_staff_project->staffID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_project->staffID->EditValue ?></p></span>
</span>
<input type="hidden" data-table="mtm_staff_project" data-field="x_staffID" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_project->staffID->CurrentValue) ?>">
<?php } ?>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mtm_staff_project_grid->RowCnt ?>_mtm_staff_project_staffID" class="mtm_staff_project_staffID">
<span<?php echo $mtm_staff_project->staffID->ViewAttributes() ?>>
<?php echo $mtm_staff_project->staffID->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="mtm_staff_project" data-field="x_staffID" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_project->staffID->FormValue) ?>">
<input type="hidden" data-table="mtm_staff_project" data-field="x_staffID" name="o<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID" id="o<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_project->staffID->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($mtm_staff_project->role->Visible) { // role ?>
		<td data-name="role"<?php echo $mtm_staff_project->role->CellAttributes() ?>>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $mtm_staff_project_grid->RowCnt ?>_mtm_staff_project_role" class="form-group mtm_staff_project_role">
<div id="tp_x<?php echo $mtm_staff_project_grid->RowIndex ?>_role" class="ewTemplate"><input type="radio" data-table="mtm_staff_project" data-field="x_role" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_project->role->DisplayValueSeparator) ? json_encode($mtm_staff_project->role->DisplayValueSeparator) : $mtm_staff_project->role->DisplayValueSeparator) ?>" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_role" value="{value}"<?php echo $mtm_staff_project->role->EditAttributes() ?>></div>
<div id="dsl_x<?php echo $mtm_staff_project_grid->RowIndex ?>_role" data-repeatcolumn="5" class="ewItemList" style="display: none;"><div>
<?php
$arwrk = $mtm_staff_project->role->EditValue;
if (is_array($arwrk)) {
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = (strval($mtm_staff_project->role->CurrentValue) == strval($arwrk[$rowcntwrk][0])) ? " checked" : "";
		if ($selwrk <> "")
			$emptywrk = FALSE;
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_project" data-field="x_role" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_role_<?php echo $rowcntwrk ?>" value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?><?php echo $mtm_staff_project->role->EditAttributes() ?>><?php echo $mtm_staff_project->role->DisplayValue($arwrk[$rowcntwrk]) ?></label>
<?php
	}
	if ($emptywrk && strval($mtm_staff_project->role->CurrentValue) <> "") {
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_project" data-field="x_role" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_role_<?php echo $rowswrk ?>" value="<?php echo ew_HtmlEncode($mtm_staff_project->role->CurrentValue) ?>" checked<?php echo $mtm_staff_project->role->EditAttributes() ?>><?php echo $mtm_staff_project->role->CurrentValue ?></label>
<?php
    }
}
if (@$emptywrk) $mtm_staff_project->role->OldValue = "";
?>
</div></div>
</span>
<input type="hidden" data-table="mtm_staff_project" data-field="x_role" name="o<?php echo $mtm_staff_project_grid->RowIndex ?>_role" id="o<?php echo $mtm_staff_project_grid->RowIndex ?>_role" value="<?php echo ew_HtmlEncode($mtm_staff_project->role->OldValue) ?>">
<?php } ?>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mtm_staff_project_grid->RowCnt ?>_mtm_staff_project_role" class="form-group mtm_staff_project_role">
<div id="tp_x<?php echo $mtm_staff_project_grid->RowIndex ?>_role" class="ewTemplate"><input type="radio" data-table="mtm_staff_project" data-field="x_role" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_project->role->DisplayValueSeparator) ? json_encode($mtm_staff_project->role->DisplayValueSeparator) : $mtm_staff_project->role->DisplayValueSeparator) ?>" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_role" value="{value}"<?php echo $mtm_staff_project->role->EditAttributes() ?>></div>
<div id="dsl_x<?php echo $mtm_staff_project_grid->RowIndex ?>_role" data-repeatcolumn="5" class="ewItemList" style="display: none;"><div>
<?php
$arwrk = $mtm_staff_project->role->EditValue;
if (is_array($arwrk)) {
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = (strval($mtm_staff_project->role->CurrentValue) == strval($arwrk[$rowcntwrk][0])) ? " checked" : "";
		if ($selwrk <> "")
			$emptywrk = FALSE;
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_project" data-field="x_role" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_role_<?php echo $rowcntwrk ?>" value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?><?php echo $mtm_staff_project->role->EditAttributes() ?>><?php echo $mtm_staff_project->role->DisplayValue($arwrk[$rowcntwrk]) ?></label>
<?php
	}
	if ($emptywrk && strval($mtm_staff_project->role->CurrentValue) <> "") {
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_project" data-field="x_role" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_role_<?php echo $rowswrk ?>" value="<?php echo ew_HtmlEncode($mtm_staff_project->role->CurrentValue) ?>" checked<?php echo $mtm_staff_project->role->EditAttributes() ?>><?php echo $mtm_staff_project->role->CurrentValue ?></label>
<?php
    }
}
if (@$emptywrk) $mtm_staff_project->role->OldValue = "";
?>
</div></div>
</span>
<?php } ?>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mtm_staff_project_grid->RowCnt ?>_mtm_staff_project_role" class="mtm_staff_project_role">
<span<?php echo $mtm_staff_project->role->ViewAttributes() ?>>
<?php echo $mtm_staff_project->role->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="mtm_staff_project" data-field="x_role" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_role" value="<?php echo ew_HtmlEncode($mtm_staff_project->role->FormValue) ?>">
<input type="hidden" data-table="mtm_staff_project" data-field="x_role" name="o<?php echo $mtm_staff_project_grid->RowIndex ?>_role" id="o<?php echo $mtm_staff_project_grid->RowIndex ?>_role" value="<?php echo ew_HtmlEncode($mtm_staff_project->role->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($mtm_staff_project->TimeSpentProject->Visible) { // TimeSpentProject ?>
		<td data-name="TimeSpentProject"<?php echo $mtm_staff_project->TimeSpentProject->CellAttributes() ?>>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $mtm_staff_project_grid->RowCnt ?>_mtm_staff_project_TimeSpentProject" class="form-group mtm_staff_project_TimeSpentProject">
<input type="text" data-table="mtm_staff_project" data-field="x_TimeSpentProject" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_TimeSpentProject" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_TimeSpentProject" size="30" placeholder="<?php echo ew_HtmlEncode($mtm_staff_project->TimeSpentProject->getPlaceHolder()) ?>" value="<?php echo $mtm_staff_project->TimeSpentProject->EditValue ?>"<?php echo $mtm_staff_project->TimeSpentProject->EditAttributes() ?>>
</span>
<input type="hidden" data-table="mtm_staff_project" data-field="x_TimeSpentProject" name="o<?php echo $mtm_staff_project_grid->RowIndex ?>_TimeSpentProject" id="o<?php echo $mtm_staff_project_grid->RowIndex ?>_TimeSpentProject" value="<?php echo ew_HtmlEncode($mtm_staff_project->TimeSpentProject->OldValue) ?>">
<?php } ?>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mtm_staff_project_grid->RowCnt ?>_mtm_staff_project_TimeSpentProject" class="form-group mtm_staff_project_TimeSpentProject">
<input type="text" data-table="mtm_staff_project" data-field="x_TimeSpentProject" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_TimeSpentProject" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_TimeSpentProject" size="30" placeholder="<?php echo ew_HtmlEncode($mtm_staff_project->TimeSpentProject->getPlaceHolder()) ?>" value="<?php echo $mtm_staff_project->TimeSpentProject->EditValue ?>"<?php echo $mtm_staff_project->TimeSpentProject->EditAttributes() ?>>
</span>
<?php } ?>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mtm_staff_project_grid->RowCnt ?>_mtm_staff_project_TimeSpentProject" class="mtm_staff_project_TimeSpentProject">
<span<?php echo $mtm_staff_project->TimeSpentProject->ViewAttributes() ?>>
<?php echo $mtm_staff_project->TimeSpentProject->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="mtm_staff_project" data-field="x_TimeSpentProject" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_TimeSpentProject" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_TimeSpentProject" value="<?php echo ew_HtmlEncode($mtm_staff_project->TimeSpentProject->FormValue) ?>">
<input type="hidden" data-table="mtm_staff_project" data-field="x_TimeSpentProject" name="o<?php echo $mtm_staff_project_grid->RowIndex ?>_TimeSpentProject" id="o<?php echo $mtm_staff_project_grid->RowIndex ?>_TimeSpentProject" value="<?php echo ew_HtmlEncode($mtm_staff_project->TimeSpentProject->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$mtm_staff_project_grid->ListOptions->Render("body", "right", $mtm_staff_project_grid->RowCnt);
?>
	</tr>
<?php if ($mtm_staff_project->RowType == EW_ROWTYPE_ADD || $mtm_staff_project->RowType == EW_ROWTYPE_EDIT) { ?>
<script type="text/javascript">
fmtm_staff_projectgrid.UpdateOpts(<?php echo $mtm_staff_project_grid->RowIndex ?>);
</script>
<?php } ?>
<?php
	}
	} // End delete row checking
	if ($mtm_staff_project->CurrentAction <> "gridadd" || $mtm_staff_project->CurrentMode == "copy")
		if (!$mtm_staff_project_grid->Recordset->EOF) $mtm_staff_project_grid->Recordset->MoveNext();
}
?>
<?php
	if ($mtm_staff_project->CurrentMode == "add" || $mtm_staff_project->CurrentMode == "copy" || $mtm_staff_project->CurrentMode == "edit") {
		$mtm_staff_project_grid->RowIndex = '$rowindex$';
		$mtm_staff_project_grid->LoadDefaultValues();

		// Set row properties
		$mtm_staff_project->ResetAttrs();
		$mtm_staff_project->RowAttrs = array_merge($mtm_staff_project->RowAttrs, array('data-rowindex'=>$mtm_staff_project_grid->RowIndex, 'id'=>'r0_mtm_staff_project', 'data-rowtype'=>EW_ROWTYPE_ADD));
		ew_AppendClass($mtm_staff_project->RowAttrs["class"], "ewTemplate");
		$mtm_staff_project->RowType = EW_ROWTYPE_ADD;

		// Render row
		$mtm_staff_project_grid->RenderRow();

		// Render list options
		$mtm_staff_project_grid->RenderListOptions();
		$mtm_staff_project_grid->StartRowCnt = 0;
?>
	<tr<?php echo $mtm_staff_project->RowAttributes() ?>>
<?php

// Render list options (body, left)
$mtm_staff_project_grid->ListOptions->Render("body", "left", $mtm_staff_project_grid->RowIndex);
?>
	<?php if ($mtm_staff_project->projID->Visible) { // projID ?>
		<td data-name="projID">
<?php if ($mtm_staff_project->CurrentAction <> "F") { ?>
<?php if ($mtm_staff_project->projID->getSessionValue() <> "") { ?>
<span id="el$rowindex$_mtm_staff_project_projID" class="form-group mtm_staff_project_projID">
<span<?php echo $mtm_staff_project->projID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_project->projID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_projID" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_projID" value="<?php echo ew_HtmlEncode($mtm_staff_project->projID->CurrentValue) ?>">
<?php } else { ?>
<span id="el$rowindex$_mtm_staff_project_projID" class="form-group mtm_staff_project_projID">
<select data-table="mtm_staff_project" data-field="x_projID" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_project->projID->DisplayValueSeparator) ? json_encode($mtm_staff_project->projID->DisplayValueSeparator) : $mtm_staff_project->projID->DisplayValueSeparator) ?>" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_projID" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_projID"<?php echo $mtm_staff_project->projID->EditAttributes() ?>>
<?php
if (is_array($mtm_staff_project->projID->EditValue)) {
	$arwrk = $mtm_staff_project->projID->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = ew_SameStr($mtm_staff_project->projID->CurrentValue, $arwrk[$rowcntwrk][0]) ? " selected" : "";
		if ($selwrk <> "") $emptywrk = FALSE;		
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $mtm_staff_project->projID->DisplayValue($arwrk[$rowcntwrk]) ?>
</option>
<?php
	}
	if ($emptywrk && strval($mtm_staff_project->projID->CurrentValue) <> "") {
?>
<option value="<?php echo ew_HtmlEncode($mtm_staff_project->projID->CurrentValue) ?>" selected><?php echo $mtm_staff_project->projID->CurrentValue ?></option>
<?php
    }
}
if (@$emptywrk) $mtm_staff_project->projID->OldValue = "";
?>
</select>
<?php
$sSqlWrk = "SELECT `id`, `name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `project`";
$sWhereWrk = "";
$mtm_staff_project->projID->LookupFilters = array("s" => $sSqlWrk, "d" => "");
$mtm_staff_project->projID->LookupFilters += array("f0" => "`id` = {filter_value}", "t0" => "16", "fn0" => "");
$sSqlWrk = "";
$mtm_staff_project->Lookup_Selecting($mtm_staff_project->projID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
if ($sSqlWrk <> "") $mtm_staff_project->projID->LookupFilters["s"] .= $sSqlWrk;
?>
<input type="hidden" name="s_x<?php echo $mtm_staff_project_grid->RowIndex ?>_projID" id="s_x<?php echo $mtm_staff_project_grid->RowIndex ?>_projID" value="<?php echo $mtm_staff_project->projID->LookupFilterQuery() ?>">
</span>
<?php } ?>
<?php } else { ?>
<span id="el$rowindex$_mtm_staff_project_projID" class="form-group mtm_staff_project_projID">
<span<?php echo $mtm_staff_project->projID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_project->projID->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="mtm_staff_project" data-field="x_projID" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_projID" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_projID" value="<?php echo ew_HtmlEncode($mtm_staff_project->projID->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="mtm_staff_project" data-field="x_projID" name="o<?php echo $mtm_staff_project_grid->RowIndex ?>_projID" id="o<?php echo $mtm_staff_project_grid->RowIndex ?>_projID" value="<?php echo ew_HtmlEncode($mtm_staff_project->projID->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mtm_staff_project->staffID->Visible) { // staffID ?>
		<td data-name="staffID">
<?php if ($mtm_staff_project->CurrentAction <> "F") { ?>
<?php if ($mtm_staff_project->staffID->getSessionValue() <> "") { ?>
<span id="el$rowindex$_mtm_staff_project_staffID" class="form-group mtm_staff_project_staffID">
<span<?php echo $mtm_staff_project->staffID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_project->staffID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_project->staffID->CurrentValue) ?>">
<?php } else { ?>
<span id="el$rowindex$_mtm_staff_project_staffID" class="form-group mtm_staff_project_staffID">
<select data-table="mtm_staff_project" data-field="x_staffID" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_project->staffID->DisplayValueSeparator) ? json_encode($mtm_staff_project->staffID->DisplayValueSeparator) : $mtm_staff_project->staffID->DisplayValueSeparator) ?>" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID"<?php echo $mtm_staff_project->staffID->EditAttributes() ?>>
<?php
if (is_array($mtm_staff_project->staffID->EditValue)) {
	$arwrk = $mtm_staff_project->staffID->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = ew_SameStr($mtm_staff_project->staffID->CurrentValue, $arwrk[$rowcntwrk][0]) ? " selected" : "";
		if ($selwrk <> "") $emptywrk = FALSE;		
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $mtm_staff_project->staffID->DisplayValue($arwrk[$rowcntwrk]) ?>
</option>
<?php
	}
	if ($emptywrk && strval($mtm_staff_project->staffID->CurrentValue) <> "") {
?>
<option value="<?php echo ew_HtmlEncode($mtm_staff_project->staffID->CurrentValue) ?>" selected><?php echo $mtm_staff_project->staffID->CurrentValue ?></option>
<?php
    }
}
if (@$emptywrk) $mtm_staff_project->staffID->OldValue = "";
?>
</select>
<?php
$sSqlWrk = "SELECT `id`, `Name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `staff`";
$sWhereWrk = "";
if (!$GLOBALS["mtm_staff_project"]->UserIDAllow("grid")) $sWhereWrk = $GLOBALS["staff"]->AddUserIDFilter($sWhereWrk);
$mtm_staff_project->staffID->LookupFilters = array("s" => $sSqlWrk, "d" => "");
$mtm_staff_project->staffID->LookupFilters += array("f0" => "`id` = {filter_value}", "t0" => "3", "fn0" => "");
$sSqlWrk = "";
$mtm_staff_project->Lookup_Selecting($mtm_staff_project->staffID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
if ($sSqlWrk <> "") $mtm_staff_project->staffID->LookupFilters["s"] .= $sSqlWrk;
?>
<input type="hidden" name="s_x<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID" id="s_x<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID" value="<?php echo $mtm_staff_project->staffID->LookupFilterQuery() ?>">
</span>
<?php } ?>
<?php } else { ?>
<span id="el$rowindex$_mtm_staff_project_staffID" class="form-group mtm_staff_project_staffID">
<span<?php echo $mtm_staff_project->staffID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_project->staffID->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="mtm_staff_project" data-field="x_staffID" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_project->staffID->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="mtm_staff_project" data-field="x_staffID" name="o<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID" id="o<?php echo $mtm_staff_project_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_project->staffID->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mtm_staff_project->role->Visible) { // role ?>
		<td data-name="role">
<?php if ($mtm_staff_project->CurrentAction <> "F") { ?>
<span id="el$rowindex$_mtm_staff_project_role" class="form-group mtm_staff_project_role">
<div id="tp_x<?php echo $mtm_staff_project_grid->RowIndex ?>_role" class="ewTemplate"><input type="radio" data-table="mtm_staff_project" data-field="x_role" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_project->role->DisplayValueSeparator) ? json_encode($mtm_staff_project->role->DisplayValueSeparator) : $mtm_staff_project->role->DisplayValueSeparator) ?>" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_role" value="{value}"<?php echo $mtm_staff_project->role->EditAttributes() ?>></div>
<div id="dsl_x<?php echo $mtm_staff_project_grid->RowIndex ?>_role" data-repeatcolumn="5" class="ewItemList" style="display: none;"><div>
<?php
$arwrk = $mtm_staff_project->role->EditValue;
if (is_array($arwrk)) {
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = (strval($mtm_staff_project->role->CurrentValue) == strval($arwrk[$rowcntwrk][0])) ? " checked" : "";
		if ($selwrk <> "")
			$emptywrk = FALSE;
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_project" data-field="x_role" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_role_<?php echo $rowcntwrk ?>" value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?><?php echo $mtm_staff_project->role->EditAttributes() ?>><?php echo $mtm_staff_project->role->DisplayValue($arwrk[$rowcntwrk]) ?></label>
<?php
	}
	if ($emptywrk && strval($mtm_staff_project->role->CurrentValue) <> "") {
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_project" data-field="x_role" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_role_<?php echo $rowswrk ?>" value="<?php echo ew_HtmlEncode($mtm_staff_project->role->CurrentValue) ?>" checked<?php echo $mtm_staff_project->role->EditAttributes() ?>><?php echo $mtm_staff_project->role->CurrentValue ?></label>
<?php
    }
}
if (@$emptywrk) $mtm_staff_project->role->OldValue = "";
?>
</div></div>
</span>
<?php } else { ?>
<span id="el$rowindex$_mtm_staff_project_role" class="form-group mtm_staff_project_role">
<span<?php echo $mtm_staff_project->role->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_project->role->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="mtm_staff_project" data-field="x_role" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_role" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_role" value="<?php echo ew_HtmlEncode($mtm_staff_project->role->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="mtm_staff_project" data-field="x_role" name="o<?php echo $mtm_staff_project_grid->RowIndex ?>_role" id="o<?php echo $mtm_staff_project_grid->RowIndex ?>_role" value="<?php echo ew_HtmlEncode($mtm_staff_project->role->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mtm_staff_project->TimeSpentProject->Visible) { // TimeSpentProject ?>
		<td data-name="TimeSpentProject">
<?php if ($mtm_staff_project->CurrentAction <> "F") { ?>
<span id="el$rowindex$_mtm_staff_project_TimeSpentProject" class="form-group mtm_staff_project_TimeSpentProject">
<input type="text" data-table="mtm_staff_project" data-field="x_TimeSpentProject" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_TimeSpentProject" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_TimeSpentProject" size="30" placeholder="<?php echo ew_HtmlEncode($mtm_staff_project->TimeSpentProject->getPlaceHolder()) ?>" value="<?php echo $mtm_staff_project->TimeSpentProject->EditValue ?>"<?php echo $mtm_staff_project->TimeSpentProject->EditAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_mtm_staff_project_TimeSpentProject" class="form-group mtm_staff_project_TimeSpentProject">
<span<?php echo $mtm_staff_project->TimeSpentProject->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_project->TimeSpentProject->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="mtm_staff_project" data-field="x_TimeSpentProject" name="x<?php echo $mtm_staff_project_grid->RowIndex ?>_TimeSpentProject" id="x<?php echo $mtm_staff_project_grid->RowIndex ?>_TimeSpentProject" value="<?php echo ew_HtmlEncode($mtm_staff_project->TimeSpentProject->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="mtm_staff_project" data-field="x_TimeSpentProject" name="o<?php echo $mtm_staff_project_grid->RowIndex ?>_TimeSpentProject" id="o<?php echo $mtm_staff_project_grid->RowIndex ?>_TimeSpentProject" value="<?php echo ew_HtmlEncode($mtm_staff_project->TimeSpentProject->OldValue) ?>">
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$mtm_staff_project_grid->ListOptions->Render("body", "right", $mtm_staff_project_grid->RowCnt);
?>
<script type="text/javascript">
fmtm_staff_projectgrid.UpdateOpts(<?php echo $mtm_staff_project_grid->RowIndex ?>);
</script>
	</tr>
<?php
}
?>
</tbody>
</table>
<?php if ($mtm_staff_project->CurrentMode == "add" || $mtm_staff_project->CurrentMode == "copy") { ?>
<input type="hidden" name="a_list" id="a_list" value="gridinsert">
<input type="hidden" name="<?php echo $mtm_staff_project_grid->FormKeyCountName ?>" id="<?php echo $mtm_staff_project_grid->FormKeyCountName ?>" value="<?php echo $mtm_staff_project_grid->KeyCount ?>">
<?php echo $mtm_staff_project_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($mtm_staff_project->CurrentMode == "edit") { ?>
<input type="hidden" name="a_list" id="a_list" value="gridupdate">
<input type="hidden" name="<?php echo $mtm_staff_project_grid->FormKeyCountName ?>" id="<?php echo $mtm_staff_project_grid->FormKeyCountName ?>" value="<?php echo $mtm_staff_project_grid->KeyCount ?>">
<?php echo $mtm_staff_project_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($mtm_staff_project->CurrentMode == "") { ?>
<input type="hidden" name="a_list" id="a_list" value="">
<?php } ?>
<input type="hidden" name="detailpage" value="fmtm_staff_projectgrid">
</div>
<?php

// Close recordset
if ($mtm_staff_project_grid->Recordset)
	$mtm_staff_project_grid->Recordset->Close();
?>
<?php if ($mtm_staff_project_grid->ShowOtherOptions) { ?>
<div class="panel-footer ewGridLowerPanel">
<?php
	foreach ($mtm_staff_project_grid->OtherOptions as &$option)
		$option->Render("body", "bottom");
?>
</div>
<div class="clearfix"></div>
<?php } ?>
</div>
</div>
<?php } ?>
<?php if ($mtm_staff_project_grid->TotalRecs == 0 && $mtm_staff_project->CurrentAction == "") { // Show other options ?>
<div class="ewListOtherOptions">
<?php
	foreach ($mtm_staff_project_grid->OtherOptions as &$option) {
		$option->ButtonClass = "";
		$option->Render("body", "");
	}
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php if ($mtm_staff_project->Export == "") { ?>
<script type="text/javascript">
fmtm_staff_projectgrid.Init();
</script>
<?php } ?>
<?php
$mtm_staff_project_grid->ShowPageFooter();
if (EW_DEBUG_ENABLED)
	echo ew_DebugMsg();
?>
<?php
$mtm_staff_project_grid->Page_Terminate();
?>
