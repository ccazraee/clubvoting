<?php include_once "staffinfo.php" ?>
<?php

// Create page object
if (!isset($mtm_staff_committee_grid)) $mtm_staff_committee_grid = new cmtm_staff_committee_grid();

// Page init
$mtm_staff_committee_grid->Page_Init();

// Page main
$mtm_staff_committee_grid->Page_Main();

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$mtm_staff_committee_grid->Page_Render();
?>
<?php if ($mtm_staff_committee->Export == "") { ?>
<script type="text/javascript">

// Form object
var fmtm_staff_committeegrid = new ew_Form("fmtm_staff_committeegrid", "grid");
fmtm_staff_committeegrid.FormKeyCountName = '<?php echo $mtm_staff_committee_grid->FormKeyCountName ?>';

// Validate form
fmtm_staff_committeegrid.Validate = function() {
	if (!this.ValidateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.GetForm(), $fobj = $(fobj);
	if ($fobj.find("#a_confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.FormKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = $fobj.find("#a_list").val() == "gridinsert";
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
		var checkrow = (gridinsert) ? !this.EmptyRow(infix) : true;
		if (checkrow) {
			addcnt++;
			elm = this.GetElements("x" + infix + "_committeeID");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $mtm_staff_committee->committeeID->FldCaption(), $mtm_staff_committee->committeeID->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_staffID");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $mtm_staff_committee->staffID->FldCaption(), $mtm_staff_committee->staffID->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_TimeSpent");
			if (elm && !ew_CheckInteger(elm.value))
				return this.OnError(elm, "<?php echo ew_JsEncode2($mtm_staff_committee->TimeSpent->FldErrMsg()) ?>");
			elm = this.GetElements("x" + infix + "_ValidDate");
			if (elm && !ew_CheckEuroDate(elm.value))
				return this.OnError(elm, "<?php echo ew_JsEncode2($mtm_staff_committee->ValidDate->FldErrMsg()) ?>");

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
		} // End Grid Add checking
	}
	return true;
}

// Check empty row
fmtm_staff_committeegrid.EmptyRow = function(infix) {
	var fobj = this.Form;
	if (ew_ValueChanged(fobj, infix, "committeeID", false)) return false;
	if (ew_ValueChanged(fobj, infix, "staffID", false)) return false;
	if (ew_ValueChanged(fobj, infix, "role", false)) return false;
	if (ew_ValueChanged(fobj, infix, "TimeSpent", false)) return false;
	if (ew_ValueChanged(fobj, infix, "ValidDate", false)) return false;
	return true;
}

// Form_CustomValidate event
fmtm_staff_committeegrid.Form_CustomValidate = 
 function(fobj) { // DO NOT CHANGE THIS LINE!

 	// Your custom validation code here, return false if invalid. 
 	return true;
 }

// Use JavaScript validation or not
<?php if (EW_CLIENT_VALIDATE) { ?>
fmtm_staff_committeegrid.ValidateRequired = true;
<?php } else { ?>
fmtm_staff_committeegrid.ValidateRequired = false; 
<?php } ?>

// Dynamic selection lists
fmtm_staff_committeegrid.Lists["x_committeeID"] = {"LinkField":"x_id","Ajax":true,"AutoFill":false,"DisplayFields":["x_Name","","",""],"ParentFields":[],"ChildFields":[],"FilterFields":[],"Options":[],"Template":""};
fmtm_staff_committeegrid.Lists["x_staffID"] = {"LinkField":"x_id","Ajax":true,"AutoFill":false,"DisplayFields":["x_Name","","",""],"ParentFields":[],"ChildFields":[],"FilterFields":[],"Options":[],"Template":""};
fmtm_staff_committeegrid.Lists["x_role"] = {"LinkField":"","Ajax":null,"AutoFill":false,"DisplayFields":["","","",""],"ParentFields":[],"ChildFields":[],"FilterFields":[],"Options":[],"Template":""};
fmtm_staff_committeegrid.Lists["x_role"].Options = <?php echo json_encode($mtm_staff_committee->role->Options()) ?>;

// Form object for search
</script>
<?php } ?>
<?php
if ($mtm_staff_committee->CurrentAction == "gridadd") {
	if ($mtm_staff_committee->CurrentMode == "copy") {
		$bSelectLimit = $mtm_staff_committee_grid->UseSelectLimit;
		if ($bSelectLimit) {
			$mtm_staff_committee_grid->TotalRecs = $mtm_staff_committee->SelectRecordCount();
			$mtm_staff_committee_grid->Recordset = $mtm_staff_committee_grid->LoadRecordset($mtm_staff_committee_grid->StartRec-1, $mtm_staff_committee_grid->DisplayRecs);
		} else {
			if ($mtm_staff_committee_grid->Recordset = $mtm_staff_committee_grid->LoadRecordset())
				$mtm_staff_committee_grid->TotalRecs = $mtm_staff_committee_grid->Recordset->RecordCount();
		}
		$mtm_staff_committee_grid->StartRec = 1;
		$mtm_staff_committee_grid->DisplayRecs = $mtm_staff_committee_grid->TotalRecs;
	} else {
		$mtm_staff_committee->CurrentFilter = "0=1";
		$mtm_staff_committee_grid->StartRec = 1;
		$mtm_staff_committee_grid->DisplayRecs = $mtm_staff_committee->GridAddRowCount;
	}
	$mtm_staff_committee_grid->TotalRecs = $mtm_staff_committee_grid->DisplayRecs;
	$mtm_staff_committee_grid->StopRec = $mtm_staff_committee_grid->DisplayRecs;
} else {
	$bSelectLimit = $mtm_staff_committee_grid->UseSelectLimit;
	if ($bSelectLimit) {
		if ($mtm_staff_committee_grid->TotalRecs <= 0)
			$mtm_staff_committee_grid->TotalRecs = $mtm_staff_committee->SelectRecordCount();
	} else {
		if (!$mtm_staff_committee_grid->Recordset && ($mtm_staff_committee_grid->Recordset = $mtm_staff_committee_grid->LoadRecordset()))
			$mtm_staff_committee_grid->TotalRecs = $mtm_staff_committee_grid->Recordset->RecordCount();
	}
	$mtm_staff_committee_grid->StartRec = 1;
	$mtm_staff_committee_grid->DisplayRecs = $mtm_staff_committee_grid->TotalRecs; // Display all records
	if ($bSelectLimit)
		$mtm_staff_committee_grid->Recordset = $mtm_staff_committee_grid->LoadRecordset($mtm_staff_committee_grid->StartRec-1, $mtm_staff_committee_grid->DisplayRecs);

	// Set no record found message
	if ($mtm_staff_committee->CurrentAction == "" && $mtm_staff_committee_grid->TotalRecs == 0) {
		if (!$Security->CanList())
			$mtm_staff_committee_grid->setWarningMessage(ew_DeniedMsg());
		if ($mtm_staff_committee_grid->SearchWhere == "0=101")
			$mtm_staff_committee_grid->setWarningMessage($Language->Phrase("EnterSearchCriteria"));
		else
			$mtm_staff_committee_grid->setWarningMessage($Language->Phrase("NoRecord"));
	}
}
$mtm_staff_committee_grid->RenderOtherOptions();
?>
<?php $mtm_staff_committee_grid->ShowPageHeader(); ?>
<?php
$mtm_staff_committee_grid->ShowMessage();
?>
<?php if ($mtm_staff_committee_grid->TotalRecs > 0 || $mtm_staff_committee->CurrentAction <> "") { ?>
<div class="panel panel-default ewGrid">
<div id="fmtm_staff_committeegrid" class="ewForm form-inline">
<?php if ($mtm_staff_committee_grid->ShowOtherOptions) { ?>
<div class="panel-heading ewGridUpperPanel">
<?php
	foreach ($mtm_staff_committee_grid->OtherOptions as &$option)
		$option->Render("body");
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<div id="gmp_mtm_staff_committee" class="<?php if (ew_IsResponsiveLayout()) { echo "table-responsive "; } ?>ewGridMiddlePanel">
<table id="tbl_mtm_staff_committeegrid" class="table ewTable">
<?php echo $mtm_staff_committee->TableCustomInnerHtml ?>
<thead><!-- Table header -->
	<tr class="ewTableHeader">
<?php

// Header row
$mtm_staff_committee_grid->RowType = EW_ROWTYPE_HEADER;

// Render list options
$mtm_staff_committee_grid->RenderListOptions();

// Render list options (header, left)
$mtm_staff_committee_grid->ListOptions->Render("header", "left");
?>
<?php if ($mtm_staff_committee->committeeID->Visible) { // committeeID ?>
	<?php if ($mtm_staff_committee->SortUrl($mtm_staff_committee->committeeID) == "") { ?>
		<th data-name="committeeID"><div id="elh_mtm_staff_committee_committeeID" class="mtm_staff_committee_committeeID"><div class="ewTableHeaderCaption"><?php echo $mtm_staff_committee->committeeID->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="committeeID"><div><div id="elh_mtm_staff_committee_committeeID" class="mtm_staff_committee_committeeID">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $mtm_staff_committee->committeeID->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($mtm_staff_committee->committeeID->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($mtm_staff_committee->committeeID->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($mtm_staff_committee->staffID->Visible) { // staffID ?>
	<?php if ($mtm_staff_committee->SortUrl($mtm_staff_committee->staffID) == "") { ?>
		<th data-name="staffID"><div id="elh_mtm_staff_committee_staffID" class="mtm_staff_committee_staffID"><div class="ewTableHeaderCaption"><?php echo $mtm_staff_committee->staffID->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="staffID"><div><div id="elh_mtm_staff_committee_staffID" class="mtm_staff_committee_staffID">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $mtm_staff_committee->staffID->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($mtm_staff_committee->staffID->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($mtm_staff_committee->staffID->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($mtm_staff_committee->role->Visible) { // role ?>
	<?php if ($mtm_staff_committee->SortUrl($mtm_staff_committee->role) == "") { ?>
		<th data-name="role"><div id="elh_mtm_staff_committee_role" class="mtm_staff_committee_role"><div class="ewTableHeaderCaption"><?php echo $mtm_staff_committee->role->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="role"><div><div id="elh_mtm_staff_committee_role" class="mtm_staff_committee_role">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $mtm_staff_committee->role->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($mtm_staff_committee->role->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($mtm_staff_committee->role->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($mtm_staff_committee->TimeSpent->Visible) { // TimeSpent ?>
	<?php if ($mtm_staff_committee->SortUrl($mtm_staff_committee->TimeSpent) == "") { ?>
		<th data-name="TimeSpent"><div id="elh_mtm_staff_committee_TimeSpent" class="mtm_staff_committee_TimeSpent"><div class="ewTableHeaderCaption"><?php echo $mtm_staff_committee->TimeSpent->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="TimeSpent"><div><div id="elh_mtm_staff_committee_TimeSpent" class="mtm_staff_committee_TimeSpent">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $mtm_staff_committee->TimeSpent->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($mtm_staff_committee->TimeSpent->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($mtm_staff_committee->TimeSpent->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($mtm_staff_committee->ValidDate->Visible) { // ValidDate ?>
	<?php if ($mtm_staff_committee->SortUrl($mtm_staff_committee->ValidDate) == "") { ?>
		<th data-name="ValidDate"><div id="elh_mtm_staff_committee_ValidDate" class="mtm_staff_committee_ValidDate"><div class="ewTableHeaderCaption"><?php echo $mtm_staff_committee->ValidDate->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="ValidDate"><div><div id="elh_mtm_staff_committee_ValidDate" class="mtm_staff_committee_ValidDate">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $mtm_staff_committee->ValidDate->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($mtm_staff_committee->ValidDate->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($mtm_staff_committee->ValidDate->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php

// Render list options (header, right)
$mtm_staff_committee_grid->ListOptions->Render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
$mtm_staff_committee_grid->StartRec = 1;
$mtm_staff_committee_grid->StopRec = $mtm_staff_committee_grid->TotalRecs; // Show all records

// Restore number of post back records
if ($objForm) {
	$objForm->Index = -1;
	if ($objForm->HasValue($mtm_staff_committee_grid->FormKeyCountName) && ($mtm_staff_committee->CurrentAction == "gridadd" || $mtm_staff_committee->CurrentAction == "gridedit" || $mtm_staff_committee->CurrentAction == "F")) {
		$mtm_staff_committee_grid->KeyCount = $objForm->GetValue($mtm_staff_committee_grid->FormKeyCountName);
		$mtm_staff_committee_grid->StopRec = $mtm_staff_committee_grid->StartRec + $mtm_staff_committee_grid->KeyCount - 1;
	}
}
$mtm_staff_committee_grid->RecCnt = $mtm_staff_committee_grid->StartRec - 1;
if ($mtm_staff_committee_grid->Recordset && !$mtm_staff_committee_grid->Recordset->EOF) {
	$mtm_staff_committee_grid->Recordset->MoveFirst();
	$bSelectLimit = $mtm_staff_committee_grid->UseSelectLimit;
	if (!$bSelectLimit && $mtm_staff_committee_grid->StartRec > 1)
		$mtm_staff_committee_grid->Recordset->Move($mtm_staff_committee_grid->StartRec - 1);
} elseif (!$mtm_staff_committee->AllowAddDeleteRow && $mtm_staff_committee_grid->StopRec == 0) {
	$mtm_staff_committee_grid->StopRec = $mtm_staff_committee->GridAddRowCount;
}

// Initialize aggregate
$mtm_staff_committee->RowType = EW_ROWTYPE_AGGREGATEINIT;
$mtm_staff_committee->ResetAttrs();
$mtm_staff_committee_grid->RenderRow();
if ($mtm_staff_committee->CurrentAction == "gridadd")
	$mtm_staff_committee_grid->RowIndex = 0;
if ($mtm_staff_committee->CurrentAction == "gridedit")
	$mtm_staff_committee_grid->RowIndex = 0;
while ($mtm_staff_committee_grid->RecCnt < $mtm_staff_committee_grid->StopRec) {
	$mtm_staff_committee_grid->RecCnt++;
	if (intval($mtm_staff_committee_grid->RecCnt) >= intval($mtm_staff_committee_grid->StartRec)) {
		$mtm_staff_committee_grid->RowCnt++;
		if ($mtm_staff_committee->CurrentAction == "gridadd" || $mtm_staff_committee->CurrentAction == "gridedit" || $mtm_staff_committee->CurrentAction == "F") {
			$mtm_staff_committee_grid->RowIndex++;
			$objForm->Index = $mtm_staff_committee_grid->RowIndex;
			if ($objForm->HasValue($mtm_staff_committee_grid->FormActionName))
				$mtm_staff_committee_grid->RowAction = strval($objForm->GetValue($mtm_staff_committee_grid->FormActionName));
			elseif ($mtm_staff_committee->CurrentAction == "gridadd")
				$mtm_staff_committee_grid->RowAction = "insert";
			else
				$mtm_staff_committee_grid->RowAction = "";
		}

		// Set up key count
		$mtm_staff_committee_grid->KeyCount = $mtm_staff_committee_grid->RowIndex;

		// Init row class and style
		$mtm_staff_committee->ResetAttrs();
		$mtm_staff_committee->CssClass = "";
		if ($mtm_staff_committee->CurrentAction == "gridadd") {
			if ($mtm_staff_committee->CurrentMode == "copy") {
				$mtm_staff_committee_grid->LoadRowValues($mtm_staff_committee_grid->Recordset); // Load row values
				$mtm_staff_committee_grid->SetRecordKey($mtm_staff_committee_grid->RowOldKey, $mtm_staff_committee_grid->Recordset); // Set old record key
			} else {
				$mtm_staff_committee_grid->LoadDefaultValues(); // Load default values
				$mtm_staff_committee_grid->RowOldKey = ""; // Clear old key value
			}
		} else {
			$mtm_staff_committee_grid->LoadRowValues($mtm_staff_committee_grid->Recordset); // Load row values
		}
		$mtm_staff_committee->RowType = EW_ROWTYPE_VIEW; // Render view
		if ($mtm_staff_committee->CurrentAction == "gridadd") // Grid add
			$mtm_staff_committee->RowType = EW_ROWTYPE_ADD; // Render add
		if ($mtm_staff_committee->CurrentAction == "gridadd" && $mtm_staff_committee->EventCancelled && !$objForm->HasValue("k_blankrow")) // Insert failed
			$mtm_staff_committee_grid->RestoreCurrentRowFormValues($mtm_staff_committee_grid->RowIndex); // Restore form values
		if ($mtm_staff_committee->CurrentAction == "gridedit") { // Grid edit
			if ($mtm_staff_committee->EventCancelled) {
				$mtm_staff_committee_grid->RestoreCurrentRowFormValues($mtm_staff_committee_grid->RowIndex); // Restore form values
			}
			if ($mtm_staff_committee_grid->RowAction == "insert")
				$mtm_staff_committee->RowType = EW_ROWTYPE_ADD; // Render add
			else
				$mtm_staff_committee->RowType = EW_ROWTYPE_EDIT; // Render edit
		}
		if ($mtm_staff_committee->CurrentAction == "gridedit" && ($mtm_staff_committee->RowType == EW_ROWTYPE_EDIT || $mtm_staff_committee->RowType == EW_ROWTYPE_ADD) && $mtm_staff_committee->EventCancelled) // Update failed
			$mtm_staff_committee_grid->RestoreCurrentRowFormValues($mtm_staff_committee_grid->RowIndex); // Restore form values
		if ($mtm_staff_committee->RowType == EW_ROWTYPE_EDIT) // Edit row
			$mtm_staff_committee_grid->EditRowCnt++;
		if ($mtm_staff_committee->CurrentAction == "F") // Confirm row
			$mtm_staff_committee_grid->RestoreCurrentRowFormValues($mtm_staff_committee_grid->RowIndex); // Restore form values

		// Set up row id / data-rowindex
		$mtm_staff_committee->RowAttrs = array_merge($mtm_staff_committee->RowAttrs, array('data-rowindex'=>$mtm_staff_committee_grid->RowCnt, 'id'=>'r' . $mtm_staff_committee_grid->RowCnt . '_mtm_staff_committee', 'data-rowtype'=>$mtm_staff_committee->RowType));

		// Render row
		$mtm_staff_committee_grid->RenderRow();

		// Render list options
		$mtm_staff_committee_grid->RenderListOptions();

		// Skip delete row / empty row for confirm page
		if ($mtm_staff_committee_grid->RowAction <> "delete" && $mtm_staff_committee_grid->RowAction <> "insertdelete" && !($mtm_staff_committee_grid->RowAction == "insert" && $mtm_staff_committee->CurrentAction == "F" && $mtm_staff_committee_grid->EmptyRow())) {
?>
	<tr<?php echo $mtm_staff_committee->RowAttributes() ?>>
<?php

// Render list options (body, left)
$mtm_staff_committee_grid->ListOptions->Render("body", "left", $mtm_staff_committee_grid->RowCnt);
?>
	<?php if ($mtm_staff_committee->committeeID->Visible) { // committeeID ?>
		<td data-name="committeeID"<?php echo $mtm_staff_committee->committeeID->CellAttributes() ?>>
<?php if ($mtm_staff_committee->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<?php if ($mtm_staff_committee->committeeID->getSessionValue() <> "") { ?>
<span id="el<?php echo $mtm_staff_committee_grid->RowCnt ?>_mtm_staff_committee_committeeID" class="form-group mtm_staff_committee_committeeID">
<span<?php echo $mtm_staff_committee->committeeID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_committee->committeeID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID" value="<?php echo ew_HtmlEncode($mtm_staff_committee->committeeID->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $mtm_staff_committee_grid->RowCnt ?>_mtm_staff_committee_committeeID" class="form-group mtm_staff_committee_committeeID">
<select data-table="mtm_staff_committee" data-field="x_committeeID" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_committee->committeeID->DisplayValueSeparator) ? json_encode($mtm_staff_committee->committeeID->DisplayValueSeparator) : $mtm_staff_committee->committeeID->DisplayValueSeparator) ?>" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID"<?php echo $mtm_staff_committee->committeeID->EditAttributes() ?>>
<?php
if (is_array($mtm_staff_committee->committeeID->EditValue)) {
	$arwrk = $mtm_staff_committee->committeeID->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = ew_SameStr($mtm_staff_committee->committeeID->CurrentValue, $arwrk[$rowcntwrk][0]) ? " selected" : "";
		if ($selwrk <> "") $emptywrk = FALSE;		
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $mtm_staff_committee->committeeID->DisplayValue($arwrk[$rowcntwrk]) ?>
</option>
<?php
	}
	if ($emptywrk && strval($mtm_staff_committee->committeeID->CurrentValue) <> "") {
?>
<option value="<?php echo ew_HtmlEncode($mtm_staff_committee->committeeID->CurrentValue) ?>" selected><?php echo $mtm_staff_committee->committeeID->CurrentValue ?></option>
<?php
    }
}
if (@$emptywrk) $mtm_staff_committee->committeeID->OldValue = "";
?>
</select>
<?php
$sSqlWrk = "SELECT `id`, `Name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `committee`";
$sWhereWrk = "";
$mtm_staff_committee->committeeID->LookupFilters = array("s" => $sSqlWrk, "d" => "");
$mtm_staff_committee->committeeID->LookupFilters += array("f0" => "`id` = {filter_value}", "t0" => "3", "fn0" => "");
$sSqlWrk = "";
$mtm_staff_committee->Lookup_Selecting($mtm_staff_committee->committeeID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
if ($sSqlWrk <> "") $mtm_staff_committee->committeeID->LookupFilters["s"] .= $sSqlWrk;
?>
<input type="hidden" name="s_x<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID" id="s_x<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID" value="<?php echo $mtm_staff_committee->committeeID->LookupFilterQuery() ?>">
</span>
<?php } ?>
<input type="hidden" data-table="mtm_staff_committee" data-field="x_committeeID" name="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID" id="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID" value="<?php echo ew_HtmlEncode($mtm_staff_committee->committeeID->OldValue) ?>">
<?php } ?>
<?php if ($mtm_staff_committee->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mtm_staff_committee_grid->RowCnt ?>_mtm_staff_committee_committeeID" class="form-group mtm_staff_committee_committeeID">
<span<?php echo $mtm_staff_committee->committeeID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_committee->committeeID->EditValue ?></p></span>
</span>
<input type="hidden" data-table="mtm_staff_committee" data-field="x_committeeID" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID" value="<?php echo ew_HtmlEncode($mtm_staff_committee->committeeID->CurrentValue) ?>">
<?php } ?>
<?php if ($mtm_staff_committee->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mtm_staff_committee_grid->RowCnt ?>_mtm_staff_committee_committeeID" class="mtm_staff_committee_committeeID">
<span<?php echo $mtm_staff_committee->committeeID->ViewAttributes() ?>>
<?php echo $mtm_staff_committee->committeeID->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="mtm_staff_committee" data-field="x_committeeID" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID" value="<?php echo ew_HtmlEncode($mtm_staff_committee->committeeID->FormValue) ?>">
<input type="hidden" data-table="mtm_staff_committee" data-field="x_committeeID" name="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID" id="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID" value="<?php echo ew_HtmlEncode($mtm_staff_committee->committeeID->OldValue) ?>">
<?php } ?>
<a id="<?php echo $mtm_staff_committee_grid->PageObjName . "_row_" . $mtm_staff_committee_grid->RowCnt ?>"></a></td>
	<?php } ?>
	<?php if ($mtm_staff_committee->staffID->Visible) { // staffID ?>
		<td data-name="staffID"<?php echo $mtm_staff_committee->staffID->CellAttributes() ?>>
<?php if ($mtm_staff_committee->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<?php if ($mtm_staff_committee->staffID->getSessionValue() <> "") { ?>
<span id="el<?php echo $mtm_staff_committee_grid->RowCnt ?>_mtm_staff_committee_staffID" class="form-group mtm_staff_committee_staffID">
<span<?php echo $mtm_staff_committee->staffID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_committee->staffID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_committee->staffID->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $mtm_staff_committee_grid->RowCnt ?>_mtm_staff_committee_staffID" class="form-group mtm_staff_committee_staffID">
<select data-table="mtm_staff_committee" data-field="x_staffID" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_committee->staffID->DisplayValueSeparator) ? json_encode($mtm_staff_committee->staffID->DisplayValueSeparator) : $mtm_staff_committee->staffID->DisplayValueSeparator) ?>" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID"<?php echo $mtm_staff_committee->staffID->EditAttributes() ?>>
<?php
if (is_array($mtm_staff_committee->staffID->EditValue)) {
	$arwrk = $mtm_staff_committee->staffID->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = ew_SameStr($mtm_staff_committee->staffID->CurrentValue, $arwrk[$rowcntwrk][0]) ? " selected" : "";
		if ($selwrk <> "") $emptywrk = FALSE;		
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $mtm_staff_committee->staffID->DisplayValue($arwrk[$rowcntwrk]) ?>
</option>
<?php
	}
	if ($emptywrk && strval($mtm_staff_committee->staffID->CurrentValue) <> "") {
?>
<option value="<?php echo ew_HtmlEncode($mtm_staff_committee->staffID->CurrentValue) ?>" selected><?php echo $mtm_staff_committee->staffID->CurrentValue ?></option>
<?php
    }
}
if (@$emptywrk) $mtm_staff_committee->staffID->OldValue = "";
?>
</select>
<?php
$sSqlWrk = "SELECT `id`, `Name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `staff`";
$sWhereWrk = "";
if (!$GLOBALS["mtm_staff_committee"]->UserIDAllow("grid")) $sWhereWrk = $GLOBALS["staff"]->AddUserIDFilter($sWhereWrk);
$mtm_staff_committee->staffID->LookupFilters = array("s" => $sSqlWrk, "d" => "");
$mtm_staff_committee->staffID->LookupFilters += array("f0" => "`id` = {filter_value}", "t0" => "3", "fn0" => "");
$sSqlWrk = "";
$mtm_staff_committee->Lookup_Selecting($mtm_staff_committee->staffID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
if ($sSqlWrk <> "") $mtm_staff_committee->staffID->LookupFilters["s"] .= $sSqlWrk;
?>
<input type="hidden" name="s_x<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID" id="s_x<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID" value="<?php echo $mtm_staff_committee->staffID->LookupFilterQuery() ?>">
</span>
<?php } ?>
<input type="hidden" data-table="mtm_staff_committee" data-field="x_staffID" name="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID" id="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_committee->staffID->OldValue) ?>">
<?php } ?>
<?php if ($mtm_staff_committee->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mtm_staff_committee_grid->RowCnt ?>_mtm_staff_committee_staffID" class="form-group mtm_staff_committee_staffID">
<span<?php echo $mtm_staff_committee->staffID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_committee->staffID->EditValue ?></p></span>
</span>
<input type="hidden" data-table="mtm_staff_committee" data-field="x_staffID" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_committee->staffID->CurrentValue) ?>">
<?php } ?>
<?php if ($mtm_staff_committee->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mtm_staff_committee_grid->RowCnt ?>_mtm_staff_committee_staffID" class="mtm_staff_committee_staffID">
<span<?php echo $mtm_staff_committee->staffID->ViewAttributes() ?>>
<?php echo $mtm_staff_committee->staffID->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="mtm_staff_committee" data-field="x_staffID" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_committee->staffID->FormValue) ?>">
<input type="hidden" data-table="mtm_staff_committee" data-field="x_staffID" name="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID" id="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_committee->staffID->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($mtm_staff_committee->role->Visible) { // role ?>
		<td data-name="role"<?php echo $mtm_staff_committee->role->CellAttributes() ?>>
<?php if ($mtm_staff_committee->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $mtm_staff_committee_grid->RowCnt ?>_mtm_staff_committee_role" class="form-group mtm_staff_committee_role">
<div id="tp_x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" class="ewTemplate"><input type="radio" data-table="mtm_staff_committee" data-field="x_role" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_committee->role->DisplayValueSeparator) ? json_encode($mtm_staff_committee->role->DisplayValueSeparator) : $mtm_staff_committee->role->DisplayValueSeparator) ?>" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" value="{value}"<?php echo $mtm_staff_committee->role->EditAttributes() ?>></div>
<div id="dsl_x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" data-repeatcolumn="5" class="ewItemList" style="display: none;"><div>
<?php
$arwrk = $mtm_staff_committee->role->EditValue;
if (is_array($arwrk)) {
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = (strval($mtm_staff_committee->role->CurrentValue) == strval($arwrk[$rowcntwrk][0])) ? " checked" : "";
		if ($selwrk <> "")
			$emptywrk = FALSE;
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_committee" data-field="x_role" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role_<?php echo $rowcntwrk ?>" value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?><?php echo $mtm_staff_committee->role->EditAttributes() ?>><?php echo $mtm_staff_committee->role->DisplayValue($arwrk[$rowcntwrk]) ?></label>
<?php
	}
	if ($emptywrk && strval($mtm_staff_committee->role->CurrentValue) <> "") {
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_committee" data-field="x_role" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role_<?php echo $rowswrk ?>" value="<?php echo ew_HtmlEncode($mtm_staff_committee->role->CurrentValue) ?>" checked<?php echo $mtm_staff_committee->role->EditAttributes() ?>><?php echo $mtm_staff_committee->role->CurrentValue ?></label>
<?php
    }
}
if (@$emptywrk) $mtm_staff_committee->role->OldValue = "";
?>
</div></div>
</span>
<input type="hidden" data-table="mtm_staff_committee" data-field="x_role" name="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" id="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" value="<?php echo ew_HtmlEncode($mtm_staff_committee->role->OldValue) ?>">
<?php } ?>
<?php if ($mtm_staff_committee->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mtm_staff_committee_grid->RowCnt ?>_mtm_staff_committee_role" class="form-group mtm_staff_committee_role">
<div id="tp_x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" class="ewTemplate"><input type="radio" data-table="mtm_staff_committee" data-field="x_role" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_committee->role->DisplayValueSeparator) ? json_encode($mtm_staff_committee->role->DisplayValueSeparator) : $mtm_staff_committee->role->DisplayValueSeparator) ?>" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" value="{value}"<?php echo $mtm_staff_committee->role->EditAttributes() ?>></div>
<div id="dsl_x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" data-repeatcolumn="5" class="ewItemList" style="display: none;"><div>
<?php
$arwrk = $mtm_staff_committee->role->EditValue;
if (is_array($arwrk)) {
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = (strval($mtm_staff_committee->role->CurrentValue) == strval($arwrk[$rowcntwrk][0])) ? " checked" : "";
		if ($selwrk <> "")
			$emptywrk = FALSE;
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_committee" data-field="x_role" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role_<?php echo $rowcntwrk ?>" value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?><?php echo $mtm_staff_committee->role->EditAttributes() ?>><?php echo $mtm_staff_committee->role->DisplayValue($arwrk[$rowcntwrk]) ?></label>
<?php
	}
	if ($emptywrk && strval($mtm_staff_committee->role->CurrentValue) <> "") {
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_committee" data-field="x_role" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role_<?php echo $rowswrk ?>" value="<?php echo ew_HtmlEncode($mtm_staff_committee->role->CurrentValue) ?>" checked<?php echo $mtm_staff_committee->role->EditAttributes() ?>><?php echo $mtm_staff_committee->role->CurrentValue ?></label>
<?php
    }
}
if (@$emptywrk) $mtm_staff_committee->role->OldValue = "";
?>
</div></div>
</span>
<?php } ?>
<?php if ($mtm_staff_committee->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mtm_staff_committee_grid->RowCnt ?>_mtm_staff_committee_role" class="mtm_staff_committee_role">
<span<?php echo $mtm_staff_committee->role->ViewAttributes() ?>>
<?php echo $mtm_staff_committee->role->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="mtm_staff_committee" data-field="x_role" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" value="<?php echo ew_HtmlEncode($mtm_staff_committee->role->FormValue) ?>">
<input type="hidden" data-table="mtm_staff_committee" data-field="x_role" name="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" id="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" value="<?php echo ew_HtmlEncode($mtm_staff_committee->role->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($mtm_staff_committee->TimeSpent->Visible) { // TimeSpent ?>
		<td data-name="TimeSpent"<?php echo $mtm_staff_committee->TimeSpent->CellAttributes() ?>>
<?php if ($mtm_staff_committee->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $mtm_staff_committee_grid->RowCnt ?>_mtm_staff_committee_TimeSpent" class="form-group mtm_staff_committee_TimeSpent">
<input type="text" data-table="mtm_staff_committee" data-field="x_TimeSpent" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_TimeSpent" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_TimeSpent" size="30" placeholder="<?php echo ew_HtmlEncode($mtm_staff_committee->TimeSpent->getPlaceHolder()) ?>" value="<?php echo $mtm_staff_committee->TimeSpent->EditValue ?>"<?php echo $mtm_staff_committee->TimeSpent->EditAttributes() ?>>
</span>
<input type="hidden" data-table="mtm_staff_committee" data-field="x_TimeSpent" name="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_TimeSpent" id="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_TimeSpent" value="<?php echo ew_HtmlEncode($mtm_staff_committee->TimeSpent->OldValue) ?>">
<?php } ?>
<?php if ($mtm_staff_committee->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mtm_staff_committee_grid->RowCnt ?>_mtm_staff_committee_TimeSpent" class="form-group mtm_staff_committee_TimeSpent">
<input type="text" data-table="mtm_staff_committee" data-field="x_TimeSpent" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_TimeSpent" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_TimeSpent" size="30" placeholder="<?php echo ew_HtmlEncode($mtm_staff_committee->TimeSpent->getPlaceHolder()) ?>" value="<?php echo $mtm_staff_committee->TimeSpent->EditValue ?>"<?php echo $mtm_staff_committee->TimeSpent->EditAttributes() ?>>
</span>
<?php } ?>
<?php if ($mtm_staff_committee->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mtm_staff_committee_grid->RowCnt ?>_mtm_staff_committee_TimeSpent" class="mtm_staff_committee_TimeSpent">
<span<?php echo $mtm_staff_committee->TimeSpent->ViewAttributes() ?>>
<?php echo $mtm_staff_committee->TimeSpent->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="mtm_staff_committee" data-field="x_TimeSpent" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_TimeSpent" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_TimeSpent" value="<?php echo ew_HtmlEncode($mtm_staff_committee->TimeSpent->FormValue) ?>">
<input type="hidden" data-table="mtm_staff_committee" data-field="x_TimeSpent" name="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_TimeSpent" id="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_TimeSpent" value="<?php echo ew_HtmlEncode($mtm_staff_committee->TimeSpent->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($mtm_staff_committee->ValidDate->Visible) { // ValidDate ?>
		<td data-name="ValidDate"<?php echo $mtm_staff_committee->ValidDate->CellAttributes() ?>>
<?php if ($mtm_staff_committee->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $mtm_staff_committee_grid->RowCnt ?>_mtm_staff_committee_ValidDate" class="form-group mtm_staff_committee_ValidDate">
<input type="text" data-table="mtm_staff_committee" data-field="x_ValidDate" data-format="7" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_ValidDate" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_ValidDate" placeholder="<?php echo ew_HtmlEncode($mtm_staff_committee->ValidDate->getPlaceHolder()) ?>" value="<?php echo $mtm_staff_committee->ValidDate->EditValue ?>"<?php echo $mtm_staff_committee->ValidDate->EditAttributes() ?>>
<?php if (!$mtm_staff_committee->ValidDate->ReadOnly && !$mtm_staff_committee->ValidDate->Disabled && !isset($mtm_staff_committee->ValidDate->EditAttrs["readonly"]) && !isset($mtm_staff_committee->ValidDate->EditAttrs["disabled"])) { ?>
<script type="text/javascript">
ew_CreateCalendar("fmtm_staff_committeegrid", "x<?php echo $mtm_staff_committee_grid->RowIndex ?>_ValidDate", "%d/%m/%Y");
</script>
<?php } ?>
</span>
<input type="hidden" data-table="mtm_staff_committee" data-field="x_ValidDate" name="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_ValidDate" id="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_ValidDate" value="<?php echo ew_HtmlEncode($mtm_staff_committee->ValidDate->OldValue) ?>">
<?php } ?>
<?php if ($mtm_staff_committee->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mtm_staff_committee_grid->RowCnt ?>_mtm_staff_committee_ValidDate" class="form-group mtm_staff_committee_ValidDate">
<input type="text" data-table="mtm_staff_committee" data-field="x_ValidDate" data-format="7" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_ValidDate" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_ValidDate" placeholder="<?php echo ew_HtmlEncode($mtm_staff_committee->ValidDate->getPlaceHolder()) ?>" value="<?php echo $mtm_staff_committee->ValidDate->EditValue ?>"<?php echo $mtm_staff_committee->ValidDate->EditAttributes() ?>>
<?php if (!$mtm_staff_committee->ValidDate->ReadOnly && !$mtm_staff_committee->ValidDate->Disabled && !isset($mtm_staff_committee->ValidDate->EditAttrs["readonly"]) && !isset($mtm_staff_committee->ValidDate->EditAttrs["disabled"])) { ?>
<script type="text/javascript">
ew_CreateCalendar("fmtm_staff_committeegrid", "x<?php echo $mtm_staff_committee_grid->RowIndex ?>_ValidDate", "%d/%m/%Y");
</script>
<?php } ?>
</span>
<?php } ?>
<?php if ($mtm_staff_committee->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mtm_staff_committee_grid->RowCnt ?>_mtm_staff_committee_ValidDate" class="mtm_staff_committee_ValidDate">
<span<?php echo $mtm_staff_committee->ValidDate->ViewAttributes() ?>>
<?php echo $mtm_staff_committee->ValidDate->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="mtm_staff_committee" data-field="x_ValidDate" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_ValidDate" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_ValidDate" value="<?php echo ew_HtmlEncode($mtm_staff_committee->ValidDate->FormValue) ?>">
<input type="hidden" data-table="mtm_staff_committee" data-field="x_ValidDate" name="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_ValidDate" id="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_ValidDate" value="<?php echo ew_HtmlEncode($mtm_staff_committee->ValidDate->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$mtm_staff_committee_grid->ListOptions->Render("body", "right", $mtm_staff_committee_grid->RowCnt);
?>
	</tr>
<?php if ($mtm_staff_committee->RowType == EW_ROWTYPE_ADD || $mtm_staff_committee->RowType == EW_ROWTYPE_EDIT) { ?>
<script type="text/javascript">
fmtm_staff_committeegrid.UpdateOpts(<?php echo $mtm_staff_committee_grid->RowIndex ?>);
</script>
<?php } ?>
<?php
	}
	} // End delete row checking
	if ($mtm_staff_committee->CurrentAction <> "gridadd" || $mtm_staff_committee->CurrentMode == "copy")
		if (!$mtm_staff_committee_grid->Recordset->EOF) $mtm_staff_committee_grid->Recordset->MoveNext();
}
?>
<?php
	if ($mtm_staff_committee->CurrentMode == "add" || $mtm_staff_committee->CurrentMode == "copy" || $mtm_staff_committee->CurrentMode == "edit") {
		$mtm_staff_committee_grid->RowIndex = '$rowindex$';
		$mtm_staff_committee_grid->LoadDefaultValues();

		// Set row properties
		$mtm_staff_committee->ResetAttrs();
		$mtm_staff_committee->RowAttrs = array_merge($mtm_staff_committee->RowAttrs, array('data-rowindex'=>$mtm_staff_committee_grid->RowIndex, 'id'=>'r0_mtm_staff_committee', 'data-rowtype'=>EW_ROWTYPE_ADD));
		ew_AppendClass($mtm_staff_committee->RowAttrs["class"], "ewTemplate");
		$mtm_staff_committee->RowType = EW_ROWTYPE_ADD;

		// Render row
		$mtm_staff_committee_grid->RenderRow();

		// Render list options
		$mtm_staff_committee_grid->RenderListOptions();
		$mtm_staff_committee_grid->StartRowCnt = 0;
?>
	<tr<?php echo $mtm_staff_committee->RowAttributes() ?>>
<?php

// Render list options (body, left)
$mtm_staff_committee_grid->ListOptions->Render("body", "left", $mtm_staff_committee_grid->RowIndex);
?>
	<?php if ($mtm_staff_committee->committeeID->Visible) { // committeeID ?>
		<td data-name="committeeID">
<?php if ($mtm_staff_committee->CurrentAction <> "F") { ?>
<?php if ($mtm_staff_committee->committeeID->getSessionValue() <> "") { ?>
<span id="el$rowindex$_mtm_staff_committee_committeeID" class="form-group mtm_staff_committee_committeeID">
<span<?php echo $mtm_staff_committee->committeeID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_committee->committeeID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID" value="<?php echo ew_HtmlEncode($mtm_staff_committee->committeeID->CurrentValue) ?>">
<?php } else { ?>
<span id="el$rowindex$_mtm_staff_committee_committeeID" class="form-group mtm_staff_committee_committeeID">
<select data-table="mtm_staff_committee" data-field="x_committeeID" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_committee->committeeID->DisplayValueSeparator) ? json_encode($mtm_staff_committee->committeeID->DisplayValueSeparator) : $mtm_staff_committee->committeeID->DisplayValueSeparator) ?>" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID"<?php echo $mtm_staff_committee->committeeID->EditAttributes() ?>>
<?php
if (is_array($mtm_staff_committee->committeeID->EditValue)) {
	$arwrk = $mtm_staff_committee->committeeID->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = ew_SameStr($mtm_staff_committee->committeeID->CurrentValue, $arwrk[$rowcntwrk][0]) ? " selected" : "";
		if ($selwrk <> "") $emptywrk = FALSE;		
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $mtm_staff_committee->committeeID->DisplayValue($arwrk[$rowcntwrk]) ?>
</option>
<?php
	}
	if ($emptywrk && strval($mtm_staff_committee->committeeID->CurrentValue) <> "") {
?>
<option value="<?php echo ew_HtmlEncode($mtm_staff_committee->committeeID->CurrentValue) ?>" selected><?php echo $mtm_staff_committee->committeeID->CurrentValue ?></option>
<?php
    }
}
if (@$emptywrk) $mtm_staff_committee->committeeID->OldValue = "";
?>
</select>
<?php
$sSqlWrk = "SELECT `id`, `Name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `committee`";
$sWhereWrk = "";
$mtm_staff_committee->committeeID->LookupFilters = array("s" => $sSqlWrk, "d" => "");
$mtm_staff_committee->committeeID->LookupFilters += array("f0" => "`id` = {filter_value}", "t0" => "3", "fn0" => "");
$sSqlWrk = "";
$mtm_staff_committee->Lookup_Selecting($mtm_staff_committee->committeeID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
if ($sSqlWrk <> "") $mtm_staff_committee->committeeID->LookupFilters["s"] .= $sSqlWrk;
?>
<input type="hidden" name="s_x<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID" id="s_x<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID" value="<?php echo $mtm_staff_committee->committeeID->LookupFilterQuery() ?>">
</span>
<?php } ?>
<?php } else { ?>
<span id="el$rowindex$_mtm_staff_committee_committeeID" class="form-group mtm_staff_committee_committeeID">
<span<?php echo $mtm_staff_committee->committeeID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_committee->committeeID->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="mtm_staff_committee" data-field="x_committeeID" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID" value="<?php echo ew_HtmlEncode($mtm_staff_committee->committeeID->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="mtm_staff_committee" data-field="x_committeeID" name="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID" id="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_committeeID" value="<?php echo ew_HtmlEncode($mtm_staff_committee->committeeID->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mtm_staff_committee->staffID->Visible) { // staffID ?>
		<td data-name="staffID">
<?php if ($mtm_staff_committee->CurrentAction <> "F") { ?>
<?php if ($mtm_staff_committee->staffID->getSessionValue() <> "") { ?>
<span id="el$rowindex$_mtm_staff_committee_staffID" class="form-group mtm_staff_committee_staffID">
<span<?php echo $mtm_staff_committee->staffID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_committee->staffID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_committee->staffID->CurrentValue) ?>">
<?php } else { ?>
<span id="el$rowindex$_mtm_staff_committee_staffID" class="form-group mtm_staff_committee_staffID">
<select data-table="mtm_staff_committee" data-field="x_staffID" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_committee->staffID->DisplayValueSeparator) ? json_encode($mtm_staff_committee->staffID->DisplayValueSeparator) : $mtm_staff_committee->staffID->DisplayValueSeparator) ?>" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID"<?php echo $mtm_staff_committee->staffID->EditAttributes() ?>>
<?php
if (is_array($mtm_staff_committee->staffID->EditValue)) {
	$arwrk = $mtm_staff_committee->staffID->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = ew_SameStr($mtm_staff_committee->staffID->CurrentValue, $arwrk[$rowcntwrk][0]) ? " selected" : "";
		if ($selwrk <> "") $emptywrk = FALSE;		
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $mtm_staff_committee->staffID->DisplayValue($arwrk[$rowcntwrk]) ?>
</option>
<?php
	}
	if ($emptywrk && strval($mtm_staff_committee->staffID->CurrentValue) <> "") {
?>
<option value="<?php echo ew_HtmlEncode($mtm_staff_committee->staffID->CurrentValue) ?>" selected><?php echo $mtm_staff_committee->staffID->CurrentValue ?></option>
<?php
    }
}
if (@$emptywrk) $mtm_staff_committee->staffID->OldValue = "";
?>
</select>
<?php
$sSqlWrk = "SELECT `id`, `Name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `staff`";
$sWhereWrk = "";
if (!$GLOBALS["mtm_staff_committee"]->UserIDAllow("grid")) $sWhereWrk = $GLOBALS["staff"]->AddUserIDFilter($sWhereWrk);
$mtm_staff_committee->staffID->LookupFilters = array("s" => $sSqlWrk, "d" => "");
$mtm_staff_committee->staffID->LookupFilters += array("f0" => "`id` = {filter_value}", "t0" => "3", "fn0" => "");
$sSqlWrk = "";
$mtm_staff_committee->Lookup_Selecting($mtm_staff_committee->staffID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
if ($sSqlWrk <> "") $mtm_staff_committee->staffID->LookupFilters["s"] .= $sSqlWrk;
?>
<input type="hidden" name="s_x<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID" id="s_x<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID" value="<?php echo $mtm_staff_committee->staffID->LookupFilterQuery() ?>">
</span>
<?php } ?>
<?php } else { ?>
<span id="el$rowindex$_mtm_staff_committee_staffID" class="form-group mtm_staff_committee_staffID">
<span<?php echo $mtm_staff_committee->staffID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_committee->staffID->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="mtm_staff_committee" data-field="x_staffID" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_committee->staffID->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="mtm_staff_committee" data-field="x_staffID" name="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID" id="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_committee->staffID->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mtm_staff_committee->role->Visible) { // role ?>
		<td data-name="role">
<?php if ($mtm_staff_committee->CurrentAction <> "F") { ?>
<span id="el$rowindex$_mtm_staff_committee_role" class="form-group mtm_staff_committee_role">
<div id="tp_x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" class="ewTemplate"><input type="radio" data-table="mtm_staff_committee" data-field="x_role" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_committee->role->DisplayValueSeparator) ? json_encode($mtm_staff_committee->role->DisplayValueSeparator) : $mtm_staff_committee->role->DisplayValueSeparator) ?>" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" value="{value}"<?php echo $mtm_staff_committee->role->EditAttributes() ?>></div>
<div id="dsl_x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" data-repeatcolumn="5" class="ewItemList" style="display: none;"><div>
<?php
$arwrk = $mtm_staff_committee->role->EditValue;
if (is_array($arwrk)) {
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = (strval($mtm_staff_committee->role->CurrentValue) == strval($arwrk[$rowcntwrk][0])) ? " checked" : "";
		if ($selwrk <> "")
			$emptywrk = FALSE;
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_committee" data-field="x_role" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role_<?php echo $rowcntwrk ?>" value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?><?php echo $mtm_staff_committee->role->EditAttributes() ?>><?php echo $mtm_staff_committee->role->DisplayValue($arwrk[$rowcntwrk]) ?></label>
<?php
	}
	if ($emptywrk && strval($mtm_staff_committee->role->CurrentValue) <> "") {
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_committee" data-field="x_role" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role_<?php echo $rowswrk ?>" value="<?php echo ew_HtmlEncode($mtm_staff_committee->role->CurrentValue) ?>" checked<?php echo $mtm_staff_committee->role->EditAttributes() ?>><?php echo $mtm_staff_committee->role->CurrentValue ?></label>
<?php
    }
}
if (@$emptywrk) $mtm_staff_committee->role->OldValue = "";
?>
</div></div>
</span>
<?php } else { ?>
<span id="el$rowindex$_mtm_staff_committee_role" class="form-group mtm_staff_committee_role">
<span<?php echo $mtm_staff_committee->role->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_committee->role->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="mtm_staff_committee" data-field="x_role" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" value="<?php echo ew_HtmlEncode($mtm_staff_committee->role->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="mtm_staff_committee" data-field="x_role" name="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" id="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_role" value="<?php echo ew_HtmlEncode($mtm_staff_committee->role->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mtm_staff_committee->TimeSpent->Visible) { // TimeSpent ?>
		<td data-name="TimeSpent">
<?php if ($mtm_staff_committee->CurrentAction <> "F") { ?>
<span id="el$rowindex$_mtm_staff_committee_TimeSpent" class="form-group mtm_staff_committee_TimeSpent">
<input type="text" data-table="mtm_staff_committee" data-field="x_TimeSpent" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_TimeSpent" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_TimeSpent" size="30" placeholder="<?php echo ew_HtmlEncode($mtm_staff_committee->TimeSpent->getPlaceHolder()) ?>" value="<?php echo $mtm_staff_committee->TimeSpent->EditValue ?>"<?php echo $mtm_staff_committee->TimeSpent->EditAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_mtm_staff_committee_TimeSpent" class="form-group mtm_staff_committee_TimeSpent">
<span<?php echo $mtm_staff_committee->TimeSpent->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_committee->TimeSpent->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="mtm_staff_committee" data-field="x_TimeSpent" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_TimeSpent" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_TimeSpent" value="<?php echo ew_HtmlEncode($mtm_staff_committee->TimeSpent->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="mtm_staff_committee" data-field="x_TimeSpent" name="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_TimeSpent" id="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_TimeSpent" value="<?php echo ew_HtmlEncode($mtm_staff_committee->TimeSpent->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mtm_staff_committee->ValidDate->Visible) { // ValidDate ?>
		<td data-name="ValidDate">
<?php if ($mtm_staff_committee->CurrentAction <> "F") { ?>
<span id="el$rowindex$_mtm_staff_committee_ValidDate" class="form-group mtm_staff_committee_ValidDate">
<input type="text" data-table="mtm_staff_committee" data-field="x_ValidDate" data-format="7" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_ValidDate" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_ValidDate" placeholder="<?php echo ew_HtmlEncode($mtm_staff_committee->ValidDate->getPlaceHolder()) ?>" value="<?php echo $mtm_staff_committee->ValidDate->EditValue ?>"<?php echo $mtm_staff_committee->ValidDate->EditAttributes() ?>>
<?php if (!$mtm_staff_committee->ValidDate->ReadOnly && !$mtm_staff_committee->ValidDate->Disabled && !isset($mtm_staff_committee->ValidDate->EditAttrs["readonly"]) && !isset($mtm_staff_committee->ValidDate->EditAttrs["disabled"])) { ?>
<script type="text/javascript">
ew_CreateCalendar("fmtm_staff_committeegrid", "x<?php echo $mtm_staff_committee_grid->RowIndex ?>_ValidDate", "%d/%m/%Y");
</script>
<?php } ?>
</span>
<?php } else { ?>
<span id="el$rowindex$_mtm_staff_committee_ValidDate" class="form-group mtm_staff_committee_ValidDate">
<span<?php echo $mtm_staff_committee->ValidDate->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_committee->ValidDate->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="mtm_staff_committee" data-field="x_ValidDate" name="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_ValidDate" id="x<?php echo $mtm_staff_committee_grid->RowIndex ?>_ValidDate" value="<?php echo ew_HtmlEncode($mtm_staff_committee->ValidDate->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="mtm_staff_committee" data-field="x_ValidDate" name="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_ValidDate" id="o<?php echo $mtm_staff_committee_grid->RowIndex ?>_ValidDate" value="<?php echo ew_HtmlEncode($mtm_staff_committee->ValidDate->OldValue) ?>">
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$mtm_staff_committee_grid->ListOptions->Render("body", "right", $mtm_staff_committee_grid->RowCnt);
?>
<script type="text/javascript">
fmtm_staff_committeegrid.UpdateOpts(<?php echo $mtm_staff_committee_grid->RowIndex ?>);
</script>
	</tr>
<?php
}
?>
</tbody>
</table>
<?php if ($mtm_staff_committee->CurrentMode == "add" || $mtm_staff_committee->CurrentMode == "copy") { ?>
<input type="hidden" name="a_list" id="a_list" value="gridinsert">
<input type="hidden" name="<?php echo $mtm_staff_committee_grid->FormKeyCountName ?>" id="<?php echo $mtm_staff_committee_grid->FormKeyCountName ?>" value="<?php echo $mtm_staff_committee_grid->KeyCount ?>">
<?php echo $mtm_staff_committee_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($mtm_staff_committee->CurrentMode == "edit") { ?>
<input type="hidden" name="a_list" id="a_list" value="gridupdate">
<input type="hidden" name="<?php echo $mtm_staff_committee_grid->FormKeyCountName ?>" id="<?php echo $mtm_staff_committee_grid->FormKeyCountName ?>" value="<?php echo $mtm_staff_committee_grid->KeyCount ?>">
<?php echo $mtm_staff_committee_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($mtm_staff_committee->CurrentMode == "") { ?>
<input type="hidden" name="a_list" id="a_list" value="">
<?php } ?>
<input type="hidden" name="detailpage" value="fmtm_staff_committeegrid">
</div>
<?php

// Close recordset
if ($mtm_staff_committee_grid->Recordset)
	$mtm_staff_committee_grid->Recordset->Close();
?>
<?php if ($mtm_staff_committee_grid->ShowOtherOptions) { ?>
<div class="panel-footer ewGridLowerPanel">
<?php
	foreach ($mtm_staff_committee_grid->OtherOptions as &$option)
		$option->Render("body", "bottom");
?>
</div>
<div class="clearfix"></div>
<?php } ?>
</div>
</div>
<?php } ?>
<?php if ($mtm_staff_committee_grid->TotalRecs == 0 && $mtm_staff_committee->CurrentAction == "") { // Show other options ?>
<div class="ewListOtherOptions">
<?php
	foreach ($mtm_staff_committee_grid->OtherOptions as &$option) {
		$option->ButtonClass = "";
		$option->Render("body", "");
	}
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php if ($mtm_staff_committee->Export == "") { ?>
<script type="text/javascript">
fmtm_staff_committeegrid.Init();
</script>
<?php } ?>
<?php
$mtm_staff_committee_grid->ShowPageFooter();
if (EW_DEBUG_ENABLED)
	echo ew_DebugMsg();
?>
<?php
$mtm_staff_committee_grid->Page_Terminate();
?>
