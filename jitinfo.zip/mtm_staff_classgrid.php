<?php include_once "staffinfo.php" ?>
<?php

// Create page object
if (!isset($mtm_staff_class_grid)) $mtm_staff_class_grid = new cmtm_staff_class_grid();

// Page init
$mtm_staff_class_grid->Page_Init();

// Page main
$mtm_staff_class_grid->Page_Main();

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$mtm_staff_class_grid->Page_Render();
?>
<?php if ($mtm_staff_class->Export == "") { ?>
<script type="text/javascript">

// Form object
var fmtm_staff_classgrid = new ew_Form("fmtm_staff_classgrid", "grid");
fmtm_staff_classgrid.FormKeyCountName = '<?php echo $mtm_staff_class_grid->FormKeyCountName ?>';

// Validate form
fmtm_staff_classgrid.Validate = function() {
	if (!this.ValidateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.GetForm(), $fobj = $(fobj);
	if ($fobj.find("#a_confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.FormKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = $fobj.find("#a_list").val() == "gridinsert";
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
		var checkrow = (gridinsert) ? !this.EmptyRow(infix) : true;
		if (checkrow) {
			addcnt++;
			elm = this.GetElements("x" + infix + "_staffID");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $mtm_staff_class->staffID->FldCaption(), $mtm_staff_class->staffID->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_classID");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $mtm_staff_class->classID->FldCaption(), $mtm_staff_class->classID->ReqErrMsg)) ?>");

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
		} // End Grid Add checking
	}
	return true;
}

// Check empty row
fmtm_staff_classgrid.EmptyRow = function(infix) {
	var fobj = this.Form;
	if (ew_ValueChanged(fobj, infix, "staffID", false)) return false;
	if (ew_ValueChanged(fobj, infix, "classID", false)) return false;
	if (ew_ValueChanged(fobj, infix, "Attendance", false)) return false;
	if (ew_ValueChanged(fobj, infix, "Certificate", false)) return false;
	return true;
}

// Form_CustomValidate event
fmtm_staff_classgrid.Form_CustomValidate = 
 function(fobj) { // DO NOT CHANGE THIS LINE!

 	// Your custom validation code here, return false if invalid. 
 	return true;
 }

// Use JavaScript validation or not
<?php if (EW_CLIENT_VALIDATE) { ?>
fmtm_staff_classgrid.ValidateRequired = true;
<?php } else { ?>
fmtm_staff_classgrid.ValidateRequired = false; 
<?php } ?>

// Dynamic selection lists
fmtm_staff_classgrid.Lists["x_staffID"] = {"LinkField":"x_id","Ajax":true,"AutoFill":false,"DisplayFields":["x_Name","","",""],"ParentFields":[],"ChildFields":[],"FilterFields":[],"Options":[],"Template":""};
fmtm_staff_classgrid.Lists["x_classID"] = {"LinkField":"x_id","Ajax":true,"AutoFill":false,"DisplayFields":["x_classname","","",""],"ParentFields":[],"ChildFields":[],"FilterFields":[],"Options":[],"Template":""};
fmtm_staff_classgrid.Lists["x_Attendance"] = {"LinkField":"","Ajax":null,"AutoFill":false,"DisplayFields":["","","",""],"ParentFields":[],"ChildFields":[],"FilterFields":[],"Options":[],"Template":""};
fmtm_staff_classgrid.Lists["x_Attendance"].Options = <?php echo json_encode($mtm_staff_class->Attendance->Options()) ?>;

// Form object for search
</script>
<?php } ?>
<?php
if ($mtm_staff_class->CurrentAction == "gridadd") {
	if ($mtm_staff_class->CurrentMode == "copy") {
		$bSelectLimit = $mtm_staff_class_grid->UseSelectLimit;
		if ($bSelectLimit) {
			$mtm_staff_class_grid->TotalRecs = $mtm_staff_class->SelectRecordCount();
			$mtm_staff_class_grid->Recordset = $mtm_staff_class_grid->LoadRecordset($mtm_staff_class_grid->StartRec-1, $mtm_staff_class_grid->DisplayRecs);
		} else {
			if ($mtm_staff_class_grid->Recordset = $mtm_staff_class_grid->LoadRecordset())
				$mtm_staff_class_grid->TotalRecs = $mtm_staff_class_grid->Recordset->RecordCount();
		}
		$mtm_staff_class_grid->StartRec = 1;
		$mtm_staff_class_grid->DisplayRecs = $mtm_staff_class_grid->TotalRecs;
	} else {
		$mtm_staff_class->CurrentFilter = "0=1";
		$mtm_staff_class_grid->StartRec = 1;
		$mtm_staff_class_grid->DisplayRecs = $mtm_staff_class->GridAddRowCount;
	}
	$mtm_staff_class_grid->TotalRecs = $mtm_staff_class_grid->DisplayRecs;
	$mtm_staff_class_grid->StopRec = $mtm_staff_class_grid->DisplayRecs;
} else {
	$bSelectLimit = $mtm_staff_class_grid->UseSelectLimit;
	if ($bSelectLimit) {
		if ($mtm_staff_class_grid->TotalRecs <= 0)
			$mtm_staff_class_grid->TotalRecs = $mtm_staff_class->SelectRecordCount();
	} else {
		if (!$mtm_staff_class_grid->Recordset && ($mtm_staff_class_grid->Recordset = $mtm_staff_class_grid->LoadRecordset()))
			$mtm_staff_class_grid->TotalRecs = $mtm_staff_class_grid->Recordset->RecordCount();
	}
	$mtm_staff_class_grid->StartRec = 1;
	$mtm_staff_class_grid->DisplayRecs = $mtm_staff_class_grid->TotalRecs; // Display all records
	if ($bSelectLimit)
		$mtm_staff_class_grid->Recordset = $mtm_staff_class_grid->LoadRecordset($mtm_staff_class_grid->StartRec-1, $mtm_staff_class_grid->DisplayRecs);

	// Set no record found message
	if ($mtm_staff_class->CurrentAction == "" && $mtm_staff_class_grid->TotalRecs == 0) {
		if (!$Security->CanList())
			$mtm_staff_class_grid->setWarningMessage(ew_DeniedMsg());
		if ($mtm_staff_class_grid->SearchWhere == "0=101")
			$mtm_staff_class_grid->setWarningMessage($Language->Phrase("EnterSearchCriteria"));
		else
			$mtm_staff_class_grid->setWarningMessage($Language->Phrase("NoRecord"));
	}
}
$mtm_staff_class_grid->RenderOtherOptions();
?>
<?php $mtm_staff_class_grid->ShowPageHeader(); ?>
<?php
$mtm_staff_class_grid->ShowMessage();
?>
<?php if ($mtm_staff_class_grid->TotalRecs > 0 || $mtm_staff_class->CurrentAction <> "") { ?>
<div class="panel panel-default ewGrid">
<div id="fmtm_staff_classgrid" class="ewForm form-inline">
<?php if ($mtm_staff_class_grid->ShowOtherOptions) { ?>
<div class="panel-heading ewGridUpperPanel">
<?php
	foreach ($mtm_staff_class_grid->OtherOptions as &$option)
		$option->Render("body");
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<div id="gmp_mtm_staff_class" class="<?php if (ew_IsResponsiveLayout()) { echo "table-responsive "; } ?>ewGridMiddlePanel">
<table id="tbl_mtm_staff_classgrid" class="table ewTable">
<?php echo $mtm_staff_class->TableCustomInnerHtml ?>
<thead><!-- Table header -->
	<tr class="ewTableHeader">
<?php

// Header row
$mtm_staff_class_grid->RowType = EW_ROWTYPE_HEADER;

// Render list options
$mtm_staff_class_grid->RenderListOptions();

// Render list options (header, left)
$mtm_staff_class_grid->ListOptions->Render("header", "left");
?>
<?php if ($mtm_staff_class->staffID->Visible) { // staffID ?>
	<?php if ($mtm_staff_class->SortUrl($mtm_staff_class->staffID) == "") { ?>
		<th data-name="staffID"><div id="elh_mtm_staff_class_staffID" class="mtm_staff_class_staffID"><div class="ewTableHeaderCaption"><?php echo $mtm_staff_class->staffID->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="staffID"><div><div id="elh_mtm_staff_class_staffID" class="mtm_staff_class_staffID">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $mtm_staff_class->staffID->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($mtm_staff_class->staffID->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($mtm_staff_class->staffID->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($mtm_staff_class->classID->Visible) { // classID ?>
	<?php if ($mtm_staff_class->SortUrl($mtm_staff_class->classID) == "") { ?>
		<th data-name="classID"><div id="elh_mtm_staff_class_classID" class="mtm_staff_class_classID"><div class="ewTableHeaderCaption"><?php echo $mtm_staff_class->classID->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="classID"><div><div id="elh_mtm_staff_class_classID" class="mtm_staff_class_classID">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $mtm_staff_class->classID->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($mtm_staff_class->classID->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($mtm_staff_class->classID->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($mtm_staff_class->Attendance->Visible) { // Attendance ?>
	<?php if ($mtm_staff_class->SortUrl($mtm_staff_class->Attendance) == "") { ?>
		<th data-name="Attendance"><div id="elh_mtm_staff_class_Attendance" class="mtm_staff_class_Attendance"><div class="ewTableHeaderCaption"><?php echo $mtm_staff_class->Attendance->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Attendance"><div><div id="elh_mtm_staff_class_Attendance" class="mtm_staff_class_Attendance">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $mtm_staff_class->Attendance->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($mtm_staff_class->Attendance->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($mtm_staff_class->Attendance->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($mtm_staff_class->Certificate->Visible) { // Certificate ?>
	<?php if ($mtm_staff_class->SortUrl($mtm_staff_class->Certificate) == "") { ?>
		<th data-name="Certificate"><div id="elh_mtm_staff_class_Certificate" class="mtm_staff_class_Certificate"><div class="ewTableHeaderCaption"><?php echo $mtm_staff_class->Certificate->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Certificate"><div><div id="elh_mtm_staff_class_Certificate" class="mtm_staff_class_Certificate">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $mtm_staff_class->Certificate->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($mtm_staff_class->Certificate->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($mtm_staff_class->Certificate->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php

// Render list options (header, right)
$mtm_staff_class_grid->ListOptions->Render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
$mtm_staff_class_grid->StartRec = 1;
$mtm_staff_class_grid->StopRec = $mtm_staff_class_grid->TotalRecs; // Show all records

// Restore number of post back records
if ($objForm) {
	$objForm->Index = -1;
	if ($objForm->HasValue($mtm_staff_class_grid->FormKeyCountName) && ($mtm_staff_class->CurrentAction == "gridadd" || $mtm_staff_class->CurrentAction == "gridedit" || $mtm_staff_class->CurrentAction == "F")) {
		$mtm_staff_class_grid->KeyCount = $objForm->GetValue($mtm_staff_class_grid->FormKeyCountName);
		$mtm_staff_class_grid->StopRec = $mtm_staff_class_grid->StartRec + $mtm_staff_class_grid->KeyCount - 1;
	}
}
$mtm_staff_class_grid->RecCnt = $mtm_staff_class_grid->StartRec - 1;
if ($mtm_staff_class_grid->Recordset && !$mtm_staff_class_grid->Recordset->EOF) {
	$mtm_staff_class_grid->Recordset->MoveFirst();
	$bSelectLimit = $mtm_staff_class_grid->UseSelectLimit;
	if (!$bSelectLimit && $mtm_staff_class_grid->StartRec > 1)
		$mtm_staff_class_grid->Recordset->Move($mtm_staff_class_grid->StartRec - 1);
} elseif (!$mtm_staff_class->AllowAddDeleteRow && $mtm_staff_class_grid->StopRec == 0) {
	$mtm_staff_class_grid->StopRec = $mtm_staff_class->GridAddRowCount;
}

// Initialize aggregate
$mtm_staff_class->RowType = EW_ROWTYPE_AGGREGATEINIT;
$mtm_staff_class->ResetAttrs();
$mtm_staff_class_grid->RenderRow();
if ($mtm_staff_class->CurrentAction == "gridadd")
	$mtm_staff_class_grid->RowIndex = 0;
if ($mtm_staff_class->CurrentAction == "gridedit")
	$mtm_staff_class_grid->RowIndex = 0;
while ($mtm_staff_class_grid->RecCnt < $mtm_staff_class_grid->StopRec) {
	$mtm_staff_class_grid->RecCnt++;
	if (intval($mtm_staff_class_grid->RecCnt) >= intval($mtm_staff_class_grid->StartRec)) {
		$mtm_staff_class_grid->RowCnt++;
		if ($mtm_staff_class->CurrentAction == "gridadd" || $mtm_staff_class->CurrentAction == "gridedit" || $mtm_staff_class->CurrentAction == "F") {
			$mtm_staff_class_grid->RowIndex++;
			$objForm->Index = $mtm_staff_class_grid->RowIndex;
			if ($objForm->HasValue($mtm_staff_class_grid->FormActionName))
				$mtm_staff_class_grid->RowAction = strval($objForm->GetValue($mtm_staff_class_grid->FormActionName));
			elseif ($mtm_staff_class->CurrentAction == "gridadd")
				$mtm_staff_class_grid->RowAction = "insert";
			else
				$mtm_staff_class_grid->RowAction = "";
		}

		// Set up key count
		$mtm_staff_class_grid->KeyCount = $mtm_staff_class_grid->RowIndex;

		// Init row class and style
		$mtm_staff_class->ResetAttrs();
		$mtm_staff_class->CssClass = "";
		if ($mtm_staff_class->CurrentAction == "gridadd") {
			if ($mtm_staff_class->CurrentMode == "copy") {
				$mtm_staff_class_grid->LoadRowValues($mtm_staff_class_grid->Recordset); // Load row values
				$mtm_staff_class_grid->SetRecordKey($mtm_staff_class_grid->RowOldKey, $mtm_staff_class_grid->Recordset); // Set old record key
			} else {
				$mtm_staff_class_grid->LoadDefaultValues(); // Load default values
				$mtm_staff_class_grid->RowOldKey = ""; // Clear old key value
			}
		} else {
			$mtm_staff_class_grid->LoadRowValues($mtm_staff_class_grid->Recordset); // Load row values
		}
		$mtm_staff_class->RowType = EW_ROWTYPE_VIEW; // Render view
		if ($mtm_staff_class->CurrentAction == "gridadd") // Grid add
			$mtm_staff_class->RowType = EW_ROWTYPE_ADD; // Render add
		if ($mtm_staff_class->CurrentAction == "gridadd" && $mtm_staff_class->EventCancelled && !$objForm->HasValue("k_blankrow")) // Insert failed
			$mtm_staff_class_grid->RestoreCurrentRowFormValues($mtm_staff_class_grid->RowIndex); // Restore form values
		if ($mtm_staff_class->CurrentAction == "gridedit") { // Grid edit
			if ($mtm_staff_class->EventCancelled) {
				$mtm_staff_class_grid->RestoreCurrentRowFormValues($mtm_staff_class_grid->RowIndex); // Restore form values
			}
			if ($mtm_staff_class_grid->RowAction == "insert")
				$mtm_staff_class->RowType = EW_ROWTYPE_ADD; // Render add
			else
				$mtm_staff_class->RowType = EW_ROWTYPE_EDIT; // Render edit
		}
		if ($mtm_staff_class->CurrentAction == "gridedit" && ($mtm_staff_class->RowType == EW_ROWTYPE_EDIT || $mtm_staff_class->RowType == EW_ROWTYPE_ADD) && $mtm_staff_class->EventCancelled) // Update failed
			$mtm_staff_class_grid->RestoreCurrentRowFormValues($mtm_staff_class_grid->RowIndex); // Restore form values
		if ($mtm_staff_class->RowType == EW_ROWTYPE_EDIT) // Edit row
			$mtm_staff_class_grid->EditRowCnt++;
		if ($mtm_staff_class->CurrentAction == "F") // Confirm row
			$mtm_staff_class_grid->RestoreCurrentRowFormValues($mtm_staff_class_grid->RowIndex); // Restore form values

		// Set up row id / data-rowindex
		$mtm_staff_class->RowAttrs = array_merge($mtm_staff_class->RowAttrs, array('data-rowindex'=>$mtm_staff_class_grid->RowCnt, 'id'=>'r' . $mtm_staff_class_grid->RowCnt . '_mtm_staff_class', 'data-rowtype'=>$mtm_staff_class->RowType));

		// Render row
		$mtm_staff_class_grid->RenderRow();

		// Render list options
		$mtm_staff_class_grid->RenderListOptions();

		// Skip delete row / empty row for confirm page
		if ($mtm_staff_class_grid->RowAction <> "delete" && $mtm_staff_class_grid->RowAction <> "insertdelete" && !($mtm_staff_class_grid->RowAction == "insert" && $mtm_staff_class->CurrentAction == "F" && $mtm_staff_class_grid->EmptyRow())) {
?>
	<tr<?php echo $mtm_staff_class->RowAttributes() ?>>
<?php

// Render list options (body, left)
$mtm_staff_class_grid->ListOptions->Render("body", "left", $mtm_staff_class_grid->RowCnt);
?>
	<?php if ($mtm_staff_class->staffID->Visible) { // staffID ?>
		<td data-name="staffID"<?php echo $mtm_staff_class->staffID->CellAttributes() ?>>
<?php if ($mtm_staff_class->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<?php if ($mtm_staff_class->staffID->getSessionValue() <> "") { ?>
<span id="el<?php echo $mtm_staff_class_grid->RowCnt ?>_mtm_staff_class_staffID" class="form-group mtm_staff_class_staffID">
<span<?php echo $mtm_staff_class->staffID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_class->staffID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_class->staffID->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $mtm_staff_class_grid->RowCnt ?>_mtm_staff_class_staffID" class="form-group mtm_staff_class_staffID">
<select data-table="mtm_staff_class" data-field="x_staffID" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_class->staffID->DisplayValueSeparator) ? json_encode($mtm_staff_class->staffID->DisplayValueSeparator) : $mtm_staff_class->staffID->DisplayValueSeparator) ?>" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID"<?php echo $mtm_staff_class->staffID->EditAttributes() ?>>
<?php
if (is_array($mtm_staff_class->staffID->EditValue)) {
	$arwrk = $mtm_staff_class->staffID->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = ew_SameStr($mtm_staff_class->staffID->CurrentValue, $arwrk[$rowcntwrk][0]) ? " selected" : "";
		if ($selwrk <> "") $emptywrk = FALSE;		
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $mtm_staff_class->staffID->DisplayValue($arwrk[$rowcntwrk]) ?>
</option>
<?php
	}
	if ($emptywrk && strval($mtm_staff_class->staffID->CurrentValue) <> "") {
?>
<option value="<?php echo ew_HtmlEncode($mtm_staff_class->staffID->CurrentValue) ?>" selected><?php echo $mtm_staff_class->staffID->CurrentValue ?></option>
<?php
    }
}
if (@$emptywrk) $mtm_staff_class->staffID->OldValue = "";
?>
</select>
<?php
$sSqlWrk = "SELECT `id`, `Name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `staff`";
$sWhereWrk = "";
if (!$GLOBALS["mtm_staff_class"]->UserIDAllow("grid")) $sWhereWrk = $GLOBALS["staff"]->AddUserIDFilter($sWhereWrk);
$mtm_staff_class->staffID->LookupFilters = array("s" => $sSqlWrk, "d" => "");
$mtm_staff_class->staffID->LookupFilters += array("f0" => "`id` = {filter_value}", "t0" => "3", "fn0" => "");
$sSqlWrk = "";
$mtm_staff_class->Lookup_Selecting($mtm_staff_class->staffID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
if ($sSqlWrk <> "") $mtm_staff_class->staffID->LookupFilters["s"] .= $sSqlWrk;
?>
<input type="hidden" name="s_x<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID" id="s_x<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID" value="<?php echo $mtm_staff_class->staffID->LookupFilterQuery() ?>">
</span>
<?php } ?>
<input type="hidden" data-table="mtm_staff_class" data-field="x_staffID" name="o<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID" id="o<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_class->staffID->OldValue) ?>">
<?php } ?>
<?php if ($mtm_staff_class->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mtm_staff_class_grid->RowCnt ?>_mtm_staff_class_staffID" class="form-group mtm_staff_class_staffID">
<span<?php echo $mtm_staff_class->staffID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_class->staffID->EditValue ?></p></span>
</span>
<input type="hidden" data-table="mtm_staff_class" data-field="x_staffID" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_class->staffID->CurrentValue) ?>">
<?php } ?>
<?php if ($mtm_staff_class->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mtm_staff_class_grid->RowCnt ?>_mtm_staff_class_staffID" class="mtm_staff_class_staffID">
<span<?php echo $mtm_staff_class->staffID->ViewAttributes() ?>>
<?php echo $mtm_staff_class->staffID->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="mtm_staff_class" data-field="x_staffID" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_class->staffID->FormValue) ?>">
<input type="hidden" data-table="mtm_staff_class" data-field="x_staffID" name="o<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID" id="o<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_class->staffID->OldValue) ?>">
<?php } ?>
<a id="<?php echo $mtm_staff_class_grid->PageObjName . "_row_" . $mtm_staff_class_grid->RowCnt ?>"></a></td>
	<?php } ?>
	<?php if ($mtm_staff_class->classID->Visible) { // classID ?>
		<td data-name="classID"<?php echo $mtm_staff_class->classID->CellAttributes() ?>>
<?php if ($mtm_staff_class->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<?php if ($mtm_staff_class->classID->getSessionValue() <> "") { ?>
<span id="el<?php echo $mtm_staff_class_grid->RowCnt ?>_mtm_staff_class_classID" class="form-group mtm_staff_class_classID">
<span<?php echo $mtm_staff_class->classID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_class->classID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_classID" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_classID" value="<?php echo ew_HtmlEncode($mtm_staff_class->classID->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $mtm_staff_class_grid->RowCnt ?>_mtm_staff_class_classID" class="form-group mtm_staff_class_classID">
<select data-table="mtm_staff_class" data-field="x_classID" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_class->classID->DisplayValueSeparator) ? json_encode($mtm_staff_class->classID->DisplayValueSeparator) : $mtm_staff_class->classID->DisplayValueSeparator) ?>" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_classID" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_classID"<?php echo $mtm_staff_class->classID->EditAttributes() ?>>
<?php
if (is_array($mtm_staff_class->classID->EditValue)) {
	$arwrk = $mtm_staff_class->classID->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = ew_SameStr($mtm_staff_class->classID->CurrentValue, $arwrk[$rowcntwrk][0]) ? " selected" : "";
		if ($selwrk <> "") $emptywrk = FALSE;		
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $mtm_staff_class->classID->DisplayValue($arwrk[$rowcntwrk]) ?>
</option>
<?php
	}
	if ($emptywrk && strval($mtm_staff_class->classID->CurrentValue) <> "") {
?>
<option value="<?php echo ew_HtmlEncode($mtm_staff_class->classID->CurrentValue) ?>" selected><?php echo $mtm_staff_class->classID->CurrentValue ?></option>
<?php
    }
}
if (@$emptywrk) $mtm_staff_class->classID->OldValue = "";
?>
</select>
<?php
$sSqlWrk = "SELECT `id`, `classname` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `class`";
$sWhereWrk = "";
$mtm_staff_class->classID->LookupFilters = array("s" => $sSqlWrk, "d" => "");
$mtm_staff_class->classID->LookupFilters += array("f0" => "`id` = {filter_value}", "t0" => "3", "fn0" => "");
$sSqlWrk = "";
$mtm_staff_class->Lookup_Selecting($mtm_staff_class->classID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
if ($sSqlWrk <> "") $mtm_staff_class->classID->LookupFilters["s"] .= $sSqlWrk;
?>
<input type="hidden" name="s_x<?php echo $mtm_staff_class_grid->RowIndex ?>_classID" id="s_x<?php echo $mtm_staff_class_grid->RowIndex ?>_classID" value="<?php echo $mtm_staff_class->classID->LookupFilterQuery() ?>">
</span>
<?php } ?>
<input type="hidden" data-table="mtm_staff_class" data-field="x_classID" name="o<?php echo $mtm_staff_class_grid->RowIndex ?>_classID" id="o<?php echo $mtm_staff_class_grid->RowIndex ?>_classID" value="<?php echo ew_HtmlEncode($mtm_staff_class->classID->OldValue) ?>">
<?php } ?>
<?php if ($mtm_staff_class->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mtm_staff_class_grid->RowCnt ?>_mtm_staff_class_classID" class="form-group mtm_staff_class_classID">
<span<?php echo $mtm_staff_class->classID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_class->classID->EditValue ?></p></span>
</span>
<input type="hidden" data-table="mtm_staff_class" data-field="x_classID" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_classID" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_classID" value="<?php echo ew_HtmlEncode($mtm_staff_class->classID->CurrentValue) ?>">
<?php } ?>
<?php if ($mtm_staff_class->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mtm_staff_class_grid->RowCnt ?>_mtm_staff_class_classID" class="mtm_staff_class_classID">
<span<?php echo $mtm_staff_class->classID->ViewAttributes() ?>>
<?php echo $mtm_staff_class->classID->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="mtm_staff_class" data-field="x_classID" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_classID" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_classID" value="<?php echo ew_HtmlEncode($mtm_staff_class->classID->FormValue) ?>">
<input type="hidden" data-table="mtm_staff_class" data-field="x_classID" name="o<?php echo $mtm_staff_class_grid->RowIndex ?>_classID" id="o<?php echo $mtm_staff_class_grid->RowIndex ?>_classID" value="<?php echo ew_HtmlEncode($mtm_staff_class->classID->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($mtm_staff_class->Attendance->Visible) { // Attendance ?>
		<td data-name="Attendance"<?php echo $mtm_staff_class->Attendance->CellAttributes() ?>>
<?php if ($mtm_staff_class->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $mtm_staff_class_grid->RowCnt ?>_mtm_staff_class_Attendance" class="form-group mtm_staff_class_Attendance">
<div id="tp_x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" class="ewTemplate"><input type="radio" data-table="mtm_staff_class" data-field="x_Attendance" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_class->Attendance->DisplayValueSeparator) ? json_encode($mtm_staff_class->Attendance->DisplayValueSeparator) : $mtm_staff_class->Attendance->DisplayValueSeparator) ?>" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" value="{value}"<?php echo $mtm_staff_class->Attendance->EditAttributes() ?>></div>
<div id="dsl_x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" data-repeatcolumn="5" class="ewItemList" style="display: none;"><div>
<?php
$arwrk = $mtm_staff_class->Attendance->EditValue;
if (is_array($arwrk)) {
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = (strval($mtm_staff_class->Attendance->CurrentValue) == strval($arwrk[$rowcntwrk][0])) ? " checked" : "";
		if ($selwrk <> "")
			$emptywrk = FALSE;
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_class" data-field="x_Attendance" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance_<?php echo $rowcntwrk ?>" value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?><?php echo $mtm_staff_class->Attendance->EditAttributes() ?>><?php echo $mtm_staff_class->Attendance->DisplayValue($arwrk[$rowcntwrk]) ?></label>
<?php
	}
	if ($emptywrk && strval($mtm_staff_class->Attendance->CurrentValue) <> "") {
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_class" data-field="x_Attendance" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance_<?php echo $rowswrk ?>" value="<?php echo ew_HtmlEncode($mtm_staff_class->Attendance->CurrentValue) ?>" checked<?php echo $mtm_staff_class->Attendance->EditAttributes() ?>><?php echo $mtm_staff_class->Attendance->CurrentValue ?></label>
<?php
    }
}
if (@$emptywrk) $mtm_staff_class->Attendance->OldValue = "";
?>
</div></div>
</span>
<input type="hidden" data-table="mtm_staff_class" data-field="x_Attendance" name="o<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" id="o<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" value="<?php echo ew_HtmlEncode($mtm_staff_class->Attendance->OldValue) ?>">
<?php } ?>
<?php if ($mtm_staff_class->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mtm_staff_class_grid->RowCnt ?>_mtm_staff_class_Attendance" class="form-group mtm_staff_class_Attendance">
<div id="tp_x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" class="ewTemplate"><input type="radio" data-table="mtm_staff_class" data-field="x_Attendance" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_class->Attendance->DisplayValueSeparator) ? json_encode($mtm_staff_class->Attendance->DisplayValueSeparator) : $mtm_staff_class->Attendance->DisplayValueSeparator) ?>" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" value="{value}"<?php echo $mtm_staff_class->Attendance->EditAttributes() ?>></div>
<div id="dsl_x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" data-repeatcolumn="5" class="ewItemList" style="display: none;"><div>
<?php
$arwrk = $mtm_staff_class->Attendance->EditValue;
if (is_array($arwrk)) {
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = (strval($mtm_staff_class->Attendance->CurrentValue) == strval($arwrk[$rowcntwrk][0])) ? " checked" : "";
		if ($selwrk <> "")
			$emptywrk = FALSE;
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_class" data-field="x_Attendance" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance_<?php echo $rowcntwrk ?>" value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?><?php echo $mtm_staff_class->Attendance->EditAttributes() ?>><?php echo $mtm_staff_class->Attendance->DisplayValue($arwrk[$rowcntwrk]) ?></label>
<?php
	}
	if ($emptywrk && strval($mtm_staff_class->Attendance->CurrentValue) <> "") {
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_class" data-field="x_Attendance" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance_<?php echo $rowswrk ?>" value="<?php echo ew_HtmlEncode($mtm_staff_class->Attendance->CurrentValue) ?>" checked<?php echo $mtm_staff_class->Attendance->EditAttributes() ?>><?php echo $mtm_staff_class->Attendance->CurrentValue ?></label>
<?php
    }
}
if (@$emptywrk) $mtm_staff_class->Attendance->OldValue = "";
?>
</div></div>
</span>
<?php } ?>
<?php if ($mtm_staff_class->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mtm_staff_class_grid->RowCnt ?>_mtm_staff_class_Attendance" class="mtm_staff_class_Attendance">
<span<?php echo $mtm_staff_class->Attendance->ViewAttributes() ?>>
<?php echo $mtm_staff_class->Attendance->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="mtm_staff_class" data-field="x_Attendance" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" value="<?php echo ew_HtmlEncode($mtm_staff_class->Attendance->FormValue) ?>">
<input type="hidden" data-table="mtm_staff_class" data-field="x_Attendance" name="o<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" id="o<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" value="<?php echo ew_HtmlEncode($mtm_staff_class->Attendance->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($mtm_staff_class->Certificate->Visible) { // Certificate ?>
		<td data-name="Certificate"<?php echo $mtm_staff_class->Certificate->CellAttributes() ?>>
<?php if ($mtm_staff_class->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $mtm_staff_class_grid->RowCnt ?>_mtm_staff_class_Certificate" class="form-group mtm_staff_class_Certificate">
<input type="text" data-table="mtm_staff_class" data-field="x_Certificate" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Certificate" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Certificate" size="30" maxlength="150" placeholder="<?php echo ew_HtmlEncode($mtm_staff_class->Certificate->getPlaceHolder()) ?>" value="<?php echo $mtm_staff_class->Certificate->EditValue ?>"<?php echo $mtm_staff_class->Certificate->EditAttributes() ?>>
</span>
<input type="hidden" data-table="mtm_staff_class" data-field="x_Certificate" name="o<?php echo $mtm_staff_class_grid->RowIndex ?>_Certificate" id="o<?php echo $mtm_staff_class_grid->RowIndex ?>_Certificate" value="<?php echo ew_HtmlEncode($mtm_staff_class->Certificate->OldValue) ?>">
<?php } ?>
<?php if ($mtm_staff_class->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mtm_staff_class_grid->RowCnt ?>_mtm_staff_class_Certificate" class="form-group mtm_staff_class_Certificate">
<input type="text" data-table="mtm_staff_class" data-field="x_Certificate" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Certificate" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Certificate" size="30" maxlength="150" placeholder="<?php echo ew_HtmlEncode($mtm_staff_class->Certificate->getPlaceHolder()) ?>" value="<?php echo $mtm_staff_class->Certificate->EditValue ?>"<?php echo $mtm_staff_class->Certificate->EditAttributes() ?>>
</span>
<?php } ?>
<?php if ($mtm_staff_class->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mtm_staff_class_grid->RowCnt ?>_mtm_staff_class_Certificate" class="mtm_staff_class_Certificate">
<span<?php echo $mtm_staff_class->Certificate->ViewAttributes() ?>>
<?php echo $mtm_staff_class->Certificate->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="mtm_staff_class" data-field="x_Certificate" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Certificate" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Certificate" value="<?php echo ew_HtmlEncode($mtm_staff_class->Certificate->FormValue) ?>">
<input type="hidden" data-table="mtm_staff_class" data-field="x_Certificate" name="o<?php echo $mtm_staff_class_grid->RowIndex ?>_Certificate" id="o<?php echo $mtm_staff_class_grid->RowIndex ?>_Certificate" value="<?php echo ew_HtmlEncode($mtm_staff_class->Certificate->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$mtm_staff_class_grid->ListOptions->Render("body", "right", $mtm_staff_class_grid->RowCnt);
?>
	</tr>
<?php if ($mtm_staff_class->RowType == EW_ROWTYPE_ADD || $mtm_staff_class->RowType == EW_ROWTYPE_EDIT) { ?>
<script type="text/javascript">
fmtm_staff_classgrid.UpdateOpts(<?php echo $mtm_staff_class_grid->RowIndex ?>);
</script>
<?php } ?>
<?php
	}
	} // End delete row checking
	if ($mtm_staff_class->CurrentAction <> "gridadd" || $mtm_staff_class->CurrentMode == "copy")
		if (!$mtm_staff_class_grid->Recordset->EOF) $mtm_staff_class_grid->Recordset->MoveNext();
}
?>
<?php
	if ($mtm_staff_class->CurrentMode == "add" || $mtm_staff_class->CurrentMode == "copy" || $mtm_staff_class->CurrentMode == "edit") {
		$mtm_staff_class_grid->RowIndex = '$rowindex$';
		$mtm_staff_class_grid->LoadDefaultValues();

		// Set row properties
		$mtm_staff_class->ResetAttrs();
		$mtm_staff_class->RowAttrs = array_merge($mtm_staff_class->RowAttrs, array('data-rowindex'=>$mtm_staff_class_grid->RowIndex, 'id'=>'r0_mtm_staff_class', 'data-rowtype'=>EW_ROWTYPE_ADD));
		ew_AppendClass($mtm_staff_class->RowAttrs["class"], "ewTemplate");
		$mtm_staff_class->RowType = EW_ROWTYPE_ADD;

		// Render row
		$mtm_staff_class_grid->RenderRow();

		// Render list options
		$mtm_staff_class_grid->RenderListOptions();
		$mtm_staff_class_grid->StartRowCnt = 0;
?>
	<tr<?php echo $mtm_staff_class->RowAttributes() ?>>
<?php

// Render list options (body, left)
$mtm_staff_class_grid->ListOptions->Render("body", "left", $mtm_staff_class_grid->RowIndex);
?>
	<?php if ($mtm_staff_class->staffID->Visible) { // staffID ?>
		<td data-name="staffID">
<?php if ($mtm_staff_class->CurrentAction <> "F") { ?>
<?php if ($mtm_staff_class->staffID->getSessionValue() <> "") { ?>
<span id="el$rowindex$_mtm_staff_class_staffID" class="form-group mtm_staff_class_staffID">
<span<?php echo $mtm_staff_class->staffID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_class->staffID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_class->staffID->CurrentValue) ?>">
<?php } else { ?>
<span id="el$rowindex$_mtm_staff_class_staffID" class="form-group mtm_staff_class_staffID">
<select data-table="mtm_staff_class" data-field="x_staffID" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_class->staffID->DisplayValueSeparator) ? json_encode($mtm_staff_class->staffID->DisplayValueSeparator) : $mtm_staff_class->staffID->DisplayValueSeparator) ?>" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID"<?php echo $mtm_staff_class->staffID->EditAttributes() ?>>
<?php
if (is_array($mtm_staff_class->staffID->EditValue)) {
	$arwrk = $mtm_staff_class->staffID->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = ew_SameStr($mtm_staff_class->staffID->CurrentValue, $arwrk[$rowcntwrk][0]) ? " selected" : "";
		if ($selwrk <> "") $emptywrk = FALSE;		
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $mtm_staff_class->staffID->DisplayValue($arwrk[$rowcntwrk]) ?>
</option>
<?php
	}
	if ($emptywrk && strval($mtm_staff_class->staffID->CurrentValue) <> "") {
?>
<option value="<?php echo ew_HtmlEncode($mtm_staff_class->staffID->CurrentValue) ?>" selected><?php echo $mtm_staff_class->staffID->CurrentValue ?></option>
<?php
    }
}
if (@$emptywrk) $mtm_staff_class->staffID->OldValue = "";
?>
</select>
<?php
$sSqlWrk = "SELECT `id`, `Name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `staff`";
$sWhereWrk = "";
if (!$GLOBALS["mtm_staff_class"]->UserIDAllow("grid")) $sWhereWrk = $GLOBALS["staff"]->AddUserIDFilter($sWhereWrk);
$mtm_staff_class->staffID->LookupFilters = array("s" => $sSqlWrk, "d" => "");
$mtm_staff_class->staffID->LookupFilters += array("f0" => "`id` = {filter_value}", "t0" => "3", "fn0" => "");
$sSqlWrk = "";
$mtm_staff_class->Lookup_Selecting($mtm_staff_class->staffID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
if ($sSqlWrk <> "") $mtm_staff_class->staffID->LookupFilters["s"] .= $sSqlWrk;
?>
<input type="hidden" name="s_x<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID" id="s_x<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID" value="<?php echo $mtm_staff_class->staffID->LookupFilterQuery() ?>">
</span>
<?php } ?>
<?php } else { ?>
<span id="el$rowindex$_mtm_staff_class_staffID" class="form-group mtm_staff_class_staffID">
<span<?php echo $mtm_staff_class->staffID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_class->staffID->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="mtm_staff_class" data-field="x_staffID" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_class->staffID->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="mtm_staff_class" data-field="x_staffID" name="o<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID" id="o<?php echo $mtm_staff_class_grid->RowIndex ?>_staffID" value="<?php echo ew_HtmlEncode($mtm_staff_class->staffID->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mtm_staff_class->classID->Visible) { // classID ?>
		<td data-name="classID">
<?php if ($mtm_staff_class->CurrentAction <> "F") { ?>
<?php if ($mtm_staff_class->classID->getSessionValue() <> "") { ?>
<span id="el$rowindex$_mtm_staff_class_classID" class="form-group mtm_staff_class_classID">
<span<?php echo $mtm_staff_class->classID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_class->classID->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_classID" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_classID" value="<?php echo ew_HtmlEncode($mtm_staff_class->classID->CurrentValue) ?>">
<?php } else { ?>
<span id="el$rowindex$_mtm_staff_class_classID" class="form-group mtm_staff_class_classID">
<select data-table="mtm_staff_class" data-field="x_classID" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_class->classID->DisplayValueSeparator) ? json_encode($mtm_staff_class->classID->DisplayValueSeparator) : $mtm_staff_class->classID->DisplayValueSeparator) ?>" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_classID" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_classID"<?php echo $mtm_staff_class->classID->EditAttributes() ?>>
<?php
if (is_array($mtm_staff_class->classID->EditValue)) {
	$arwrk = $mtm_staff_class->classID->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = ew_SameStr($mtm_staff_class->classID->CurrentValue, $arwrk[$rowcntwrk][0]) ? " selected" : "";
		if ($selwrk <> "") $emptywrk = FALSE;		
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $mtm_staff_class->classID->DisplayValue($arwrk[$rowcntwrk]) ?>
</option>
<?php
	}
	if ($emptywrk && strval($mtm_staff_class->classID->CurrentValue) <> "") {
?>
<option value="<?php echo ew_HtmlEncode($mtm_staff_class->classID->CurrentValue) ?>" selected><?php echo $mtm_staff_class->classID->CurrentValue ?></option>
<?php
    }
}
if (@$emptywrk) $mtm_staff_class->classID->OldValue = "";
?>
</select>
<?php
$sSqlWrk = "SELECT `id`, `classname` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `class`";
$sWhereWrk = "";
$mtm_staff_class->classID->LookupFilters = array("s" => $sSqlWrk, "d" => "");
$mtm_staff_class->classID->LookupFilters += array("f0" => "`id` = {filter_value}", "t0" => "3", "fn0" => "");
$sSqlWrk = "";
$mtm_staff_class->Lookup_Selecting($mtm_staff_class->classID, $sWhereWrk); // Call Lookup selecting
if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
if ($sSqlWrk <> "") $mtm_staff_class->classID->LookupFilters["s"] .= $sSqlWrk;
?>
<input type="hidden" name="s_x<?php echo $mtm_staff_class_grid->RowIndex ?>_classID" id="s_x<?php echo $mtm_staff_class_grid->RowIndex ?>_classID" value="<?php echo $mtm_staff_class->classID->LookupFilterQuery() ?>">
</span>
<?php } ?>
<?php } else { ?>
<span id="el$rowindex$_mtm_staff_class_classID" class="form-group mtm_staff_class_classID">
<span<?php echo $mtm_staff_class->classID->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_class->classID->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="mtm_staff_class" data-field="x_classID" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_classID" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_classID" value="<?php echo ew_HtmlEncode($mtm_staff_class->classID->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="mtm_staff_class" data-field="x_classID" name="o<?php echo $mtm_staff_class_grid->RowIndex ?>_classID" id="o<?php echo $mtm_staff_class_grid->RowIndex ?>_classID" value="<?php echo ew_HtmlEncode($mtm_staff_class->classID->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mtm_staff_class->Attendance->Visible) { // Attendance ?>
		<td data-name="Attendance">
<?php if ($mtm_staff_class->CurrentAction <> "F") { ?>
<span id="el$rowindex$_mtm_staff_class_Attendance" class="form-group mtm_staff_class_Attendance">
<div id="tp_x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" class="ewTemplate"><input type="radio" data-table="mtm_staff_class" data-field="x_Attendance" data-value-separator="<?php echo ew_HtmlEncode(is_array($mtm_staff_class->Attendance->DisplayValueSeparator) ? json_encode($mtm_staff_class->Attendance->DisplayValueSeparator) : $mtm_staff_class->Attendance->DisplayValueSeparator) ?>" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" value="{value}"<?php echo $mtm_staff_class->Attendance->EditAttributes() ?>></div>
<div id="dsl_x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" data-repeatcolumn="5" class="ewItemList" style="display: none;"><div>
<?php
$arwrk = $mtm_staff_class->Attendance->EditValue;
if (is_array($arwrk)) {
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = (strval($mtm_staff_class->Attendance->CurrentValue) == strval($arwrk[$rowcntwrk][0])) ? " checked" : "";
		if ($selwrk <> "")
			$emptywrk = FALSE;
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_class" data-field="x_Attendance" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance_<?php echo $rowcntwrk ?>" value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?><?php echo $mtm_staff_class->Attendance->EditAttributes() ?>><?php echo $mtm_staff_class->Attendance->DisplayValue($arwrk[$rowcntwrk]) ?></label>
<?php
	}
	if ($emptywrk && strval($mtm_staff_class->Attendance->CurrentValue) <> "") {
?>
<label class="radio-inline"><input type="radio" data-table="mtm_staff_class" data-field="x_Attendance" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance_<?php echo $rowswrk ?>" value="<?php echo ew_HtmlEncode($mtm_staff_class->Attendance->CurrentValue) ?>" checked<?php echo $mtm_staff_class->Attendance->EditAttributes() ?>><?php echo $mtm_staff_class->Attendance->CurrentValue ?></label>
<?php
    }
}
if (@$emptywrk) $mtm_staff_class->Attendance->OldValue = "";
?>
</div></div>
</span>
<?php } else { ?>
<span id="el$rowindex$_mtm_staff_class_Attendance" class="form-group mtm_staff_class_Attendance">
<span<?php echo $mtm_staff_class->Attendance->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_class->Attendance->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="mtm_staff_class" data-field="x_Attendance" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" value="<?php echo ew_HtmlEncode($mtm_staff_class->Attendance->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="mtm_staff_class" data-field="x_Attendance" name="o<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" id="o<?php echo $mtm_staff_class_grid->RowIndex ?>_Attendance" value="<?php echo ew_HtmlEncode($mtm_staff_class->Attendance->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mtm_staff_class->Certificate->Visible) { // Certificate ?>
		<td data-name="Certificate">
<?php if ($mtm_staff_class->CurrentAction <> "F") { ?>
<span id="el$rowindex$_mtm_staff_class_Certificate" class="form-group mtm_staff_class_Certificate">
<input type="text" data-table="mtm_staff_class" data-field="x_Certificate" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Certificate" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Certificate" size="30" maxlength="150" placeholder="<?php echo ew_HtmlEncode($mtm_staff_class->Certificate->getPlaceHolder()) ?>" value="<?php echo $mtm_staff_class->Certificate->EditValue ?>"<?php echo $mtm_staff_class->Certificate->EditAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_mtm_staff_class_Certificate" class="form-group mtm_staff_class_Certificate">
<span<?php echo $mtm_staff_class->Certificate->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $mtm_staff_class->Certificate->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="mtm_staff_class" data-field="x_Certificate" name="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Certificate" id="x<?php echo $mtm_staff_class_grid->RowIndex ?>_Certificate" value="<?php echo ew_HtmlEncode($mtm_staff_class->Certificate->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="mtm_staff_class" data-field="x_Certificate" name="o<?php echo $mtm_staff_class_grid->RowIndex ?>_Certificate" id="o<?php echo $mtm_staff_class_grid->RowIndex ?>_Certificate" value="<?php echo ew_HtmlEncode($mtm_staff_class->Certificate->OldValue) ?>">
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$mtm_staff_class_grid->ListOptions->Render("body", "right", $mtm_staff_class_grid->RowCnt);
?>
<script type="text/javascript">
fmtm_staff_classgrid.UpdateOpts(<?php echo $mtm_staff_class_grid->RowIndex ?>);
</script>
	</tr>
<?php
}
?>
</tbody>
</table>
<?php if ($mtm_staff_class->CurrentMode == "add" || $mtm_staff_class->CurrentMode == "copy") { ?>
<input type="hidden" name="a_list" id="a_list" value="gridinsert">
<input type="hidden" name="<?php echo $mtm_staff_class_grid->FormKeyCountName ?>" id="<?php echo $mtm_staff_class_grid->FormKeyCountName ?>" value="<?php echo $mtm_staff_class_grid->KeyCount ?>">
<?php echo $mtm_staff_class_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($mtm_staff_class->CurrentMode == "edit") { ?>
<input type="hidden" name="a_list" id="a_list" value="gridupdate">
<input type="hidden" name="<?php echo $mtm_staff_class_grid->FormKeyCountName ?>" id="<?php echo $mtm_staff_class_grid->FormKeyCountName ?>" value="<?php echo $mtm_staff_class_grid->KeyCount ?>">
<?php echo $mtm_staff_class_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($mtm_staff_class->CurrentMode == "") { ?>
<input type="hidden" name="a_list" id="a_list" value="">
<?php } ?>
<input type="hidden" name="detailpage" value="fmtm_staff_classgrid">
</div>
<?php

// Close recordset
if ($mtm_staff_class_grid->Recordset)
	$mtm_staff_class_grid->Recordset->Close();
?>
<?php if ($mtm_staff_class_grid->ShowOtherOptions) { ?>
<div class="panel-footer ewGridLowerPanel">
<?php
	foreach ($mtm_staff_class_grid->OtherOptions as &$option)
		$option->Render("body", "bottom");
?>
</div>
<div class="clearfix"></div>
<?php } ?>
</div>
</div>
<?php } ?>
<?php if ($mtm_staff_class_grid->TotalRecs == 0 && $mtm_staff_class->CurrentAction == "") { // Show other options ?>
<div class="ewListOtherOptions">
<?php
	foreach ($mtm_staff_class_grid->OtherOptions as &$option) {
		$option->ButtonClass = "";
		$option->Render("body", "");
	}
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php if ($mtm_staff_class->Export == "") { ?>
<script type="text/javascript">
fmtm_staff_classgrid.Init();
</script>
<?php } ?>
<?php
$mtm_staff_class_grid->ShowPageFooter();
if (EW_DEBUG_ENABLED)
	echo ew_DebugMsg();
?>
<?php
$mtm_staff_class_grid->Page_Terminate();
?>
